<?php
class Home_m extends CI_Model {

	function __construct()
	{
		parent::__construct();
	}

	 function view_category1()
	{
		//var_dump($userData);exit();
		$this->db->select('*');
		return $this->db->get('art_craft')->result();
	}
	
	function view_Antiques()
	{
		$this->db->select('*');
		$this->db->where('sub_category','antiques');
	}
	function view_Drawing()
	{
		$this->db->select('*');
		$this->db->where('sub_category','Drawing and Painting');
		return $this->db->get('art_craft')->result();
	}
	function view_Handcrafts()
	{
		$this->db->select('*');
		$this->db->where('sub_category','Handcrafts, Scupture and Carvings');
		return $this->db->get('art_craft')->result();
	}
	function view_Islamic()
	{
		$this->db->select('*');
		$this->db->where('sub_category','Islamic');
		return $this->db->get('art_craft')->result();
	}
	function view_Prints()
	{
		$this->db->select('*');
		$this->db->where('sub_category','Prints and Posters');
		return $this->db->get('art_craft')->result();
	}
	function view_pd($id)
	{
		$this->db->select('*');
		$this->db->where('id',$id);
		return $this->db->get('art_craft')->result();
	}
}