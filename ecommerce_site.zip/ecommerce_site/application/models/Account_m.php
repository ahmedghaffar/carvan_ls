<?php
class Account_m extends CI_Model {

	function __construct()
	{
		parent::__construct();
	}

	 function add_user($userData)
	{
		//var_dump($userData);exit();
		$this->db->insert('user_detail',$userData);
	}
	function add_dealer($userData)
	{
		//var_dump($userData);exit();
		$this->db->insert('bd_dealer',$userData);
	}
	function add_item($userData)
	{
		//var_dump($userData);exit();
		$this->db->insert('bd_item',$userData);
	}
	function users($data)
	{
		//var_dump($userData);exit();
		$this->db->insert('users',$data);
	}
	function check_user($data)
	{
		$this->db->select('*');
		$this->db->where($data);
		return $this->db->get('users')->row();
	}
	function city()
	{
		$this->db->select('city');
		return $this->db->get('bd_city')->result();
	}
	function make()
	{
		$this->db->select('mk_name,id');
		return $this->db->get('bd_maker')->result();
	}
	function model($id)
	{
		$this->db->select('md_model');
		$this->db->where('md_maker',$id);
		return $this->db->get('bd_model')->result();
	}
}