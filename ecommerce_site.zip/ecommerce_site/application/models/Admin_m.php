<?php
class Admin_m extends CI_Model {

	function __construct()
	{
		parent::__construct();
	}

	 function add_product($userData)
	{
		// var_dump($userData);
		$this->db->insert('add_product',$userData);
	}

	function view_product()
	{
		$this->db->select('*');
		return $this->db->get('art_craft')->result();
	}
	function edit_category1($id)
	{
		$this->db->select('*');
		$this->db->where('id',$id);
		return $this->db->get('art_craft')->row();
	}
	function update_category1($userData,$id)
	{
		$this->db->where('id',$id);
		$this->db->update('art_craft',$userData);	
	}
     function delete_category1($id)
	{
		$this->db->where('id',$id);
		$this->db->delete('art_craft');
	}
		  	function add_category1($userData)
{
			$this->db->insert('art_craft',$userData);

}
	// function add_dealer($userData)
	// {
	// 	//var_dump($userData);exit();
	// 	$this->db->insert('bd_dealer',$userData);
	// }
	// function add_item($userData)
	// {
	// 	//var_dump($userData);exit();
	// 	$this->db->insert('bd_item',$userData);
	// }
	// function users($data)
	// {
	// 	//var_dump($userData);exit();
	// 	$this->db->insert('users',$data);
	// }
	// function check_user($data)
	// {
	// 	$this->db->select('*');
	// 	$this->db->where($data);
	// 	return $this->db->get('users')->row();
	// }
	// function city()
	// {
	// 	$this->db->select('city');
	// 	return $this->db->get('bd_city')->result();
	// }
	// function make()
	// {
	// 	$this->db->select('mk_name,id');
	// 	return $this->db->get('bd_maker')->result();
	// }
	// function model($id)
	// {
	// 	$this->db->select('md_model');
	// 	$this->db->where('md_maker',$id);
	// 	return $this->db->get('bd_model')->result();
	// }
}