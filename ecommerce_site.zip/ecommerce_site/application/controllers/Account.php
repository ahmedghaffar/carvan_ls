<?php
//     define('ENVIRONMENT', 'development');

//  *---------------------------------------------------------------
//  * ERROR REPORTING
//  *---------------------------------------------------------------
//  *
//  * Different environments will require different levels of error reporting.
//  * By default development will show errors but testing and live will hide them.
 

// if (defined('ENVIRONMENT'))
// {
//     switch (ENVIRONMENT)
//     {
//         case 'development':
//             error_reporting(E_ALL);
//         break;

//     case 'testing':
//     case 'production':
//         error_reporting(0);
//     break;

//     default:
//         exit('The application environment is not set correctly.');
// }
// }





defined('BASEPATH') OR exit('No direct script access allowed');

class Account extends CI_Controller {
	
		function __construct()
	{
		parent::__construct();
		$this->load->model('Account_m');
		// $this->load->library('image_lib');
	}

public function index()
	{
		
		$this->load->view('Account/login');
	}

	public function Login()
	{
		
		$this->load->view('Account/login');
	}

	public function Signup()
	{
		$this->load->view('Account/signup');
	}

	function add_user()
	{

       
		$this->form_validation->set_rules('fname','Fisrt Name','trim|required|min_length[4]|max_length[20]');
		$this->form_validation->set_rules('lname','Last Name','trim|required|min_length[4]|max_length[20]');//is_unique[bd_guser.email]
		$this->form_validation->set_rules('email','Email','trim|required|is_unique[users.email]');//is_unique[bd_guser.phone]
		$this->form_validation->set_rules('password','Password','trim|required|min_length[8]|max_length[20]');
		$this->form_validation->set_rules('cpassword','Confirm Password','trim|required|matches[password]');
		if ($this->form_validation->run() == FALSE) 
		{
			$data['error'] = $this->session->set_flashdata('errors');
			$this->load->view('Account/signup',$data);
		}
		else
		{
				$userData = array(
					'fname' => $this->input->post('fname'),
					'lname' => $this->input->post('lname'),
					'email' => $this->input->post('email'),
					'password' => $this->input->post('password'),
					'cpassword' => $this->input->post('cpassword'));
				 $data = array(
					'email' => $this->input->post('email'),
					'password' => $this->input->post('password'),
					'user_type' => '1');
				 //var_dump($data);

				$this->Account_m->add_user($userData);
				$this->Account_m->users($data);
				redirect('index.php/Admin/index');	
		}


	}

	function check_user()
	{
		$this->form_validation->set_rules('email','Email','trim|required');
		$this->form_validation->set_rules('password','password','trim|required');
		if ($this->form_validation->run() == FALSE) 
		{
			$data['error'] = $this->session->set_flashdata('errors');
			$this->load->view('Account/login',$data);
		}
		else
		{
					$data = array(
			'email' => $this->input->post('email'),
			'password' => $this->input->post('password'));
			$userid = $this->Account_m->check_user($data);

              if($userid->user_type == 1 ) //&& $userid->user_status == 1
             {
                redirect('index.php/Admin/index');
             }
             if($userid->user_type == 2 && $userid->user_status == 1)
             {
                redirect('home/index');
             }
             else
             {     

             	// redirect('home/login');
             }

         }
	}

	function logout()
{
	// $this->session->sess_destroy();
	redirect(base_url('index.php/Home/index1'));
}

}
