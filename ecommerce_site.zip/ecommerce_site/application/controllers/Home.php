<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	function __construct()
	{
		parent::__construct();
		$this->load->model('Home_m');
	}
	public function index()
	{
		$this->load->view('index');
	}
	public function index1()
	{
		$data['results'] = $this->Home_m-> view_category1();
		$this->load->view('header');
		$this->load->view('index1',$data);
		$this->load->view('footer');
	}
	
	public function header()
	{
		$this->load->view('header');
	}

	public function contact()
	{
		$this->load->view('header');
		$this->load->view('contact');
		$this->load->view('footer');
	}

	public function newaddress()
	{
		$this->load->view('header');
		$this->load->view('newadd');
		$this->load->view('footer');
	}

	public function security()
	{
		$this->load->view('header');
		$this->load->view('security');
		$this->load->view('footer');
	}

	public function orders()
	{
		$this->load->view('header');
		$this->load->view('orders');
		$this->load->view('footer');
	}

	public function payment()
	{
		$this->load->view('header');
		$this->load->view('payment');
		$this->load->view('footer');
	}

	public function reportitem()
	{
		$this->load->view('header');
		$this->load->view('report');
		$this->load->view('footer');
	}

	public function returnitem()
	{
		$this->load->view('header');
		$this->load->view('return');
		$this->load->view('footer');
	}

	public function address()
	{
		$this->load->view('header');
		$this->load->view('address');
		$this->load->view('footer');
	}

	public function basket()
	{
		$this->load->view('header');
		$this->load->view('basket');
		$this->load->view('footer');
	}

	public function wishlist()
	{
		$this->load->view('header');
		$this->load->view('wishlist');
		$this->load->view('footer');
	}

	public function checkout()
	{
		$this->load->view('header');
		$this->load->view('checkout');
		$this->load->view('footer');
	}

	public function user()
	{
		$this->load->view('header');
		$this->load->view('user');
		$this->load->view('footer');
	}

	public function about()
	{
		$this->load->view('about');
	}
	
	public function footer()
	{
		$this->load->view('header');
		$this->load->view('footer');
	}
    public function antiques()
	{
	    $this->load->view('header');
		$this->load->view('antiques');
		$this->load->view('footer');
	}

	public function psample()
	{
	    $this->load->view('header');
		$this->load->view('psample');
		$this->load->view('footer');

	}
	public function Antiques1()
	{
		$data['results'] = $this->Home_m->view_Antiques();
		$data['sub'] = "Antiques";
		 	$this->load->view('header');
		 	$this->load->view('antiques',$data);
		 	$this->load->view('footer');
	}
public function Drawing()
	{
		$data['results'] = $this->Home_m->view_Drawing();
		$data['sub'] = "Drawing and Paintings";
		 	$this->load->view('header');
		 	$this->load->view('antiques',$data);
		 	$this->load->view('footer');
	}
	public function Handcrafts()
	{
		$data['results'] = $this->Home_m->view_Handcrafts();
		$data['sub'] = "Handcrafts, Scupture and Carvings"; 
		 	$this->load->view('header');
		 	$this->load->view('antiques',$data);
		 	$this->load->view('footer');
	}
	public function Islamic()
	{
		$data['results'] = $this->Home_m->view_Islamic();
		$data['sub'] = "Islamic";
		 	$this->load->view('header');
		 	$this->load->view('antiques',$data);
		 	$this->load->view('footer');
	}
	public function Prints()
	{
		$data['results'] = $this->Home_m->view_Prints();
		$data['sub'] = "Prints and Posters";
		 	$this->load->view('header');
		 	$this->load->view('antiques',$data);
		 	$this->load->view('footer');
	}
	public function pd($id)
	{
		$data['results'] = $this->Home_m->view_pd($id);
		
		 	$this->load->view('header');
		 	$this->load->view('pd',$data);
		 	$this->load->view('footer');
	}
}
