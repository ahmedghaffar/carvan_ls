<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {
	/**


	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	function __construct()
	{
		parent::__construct();
		$this->load->model('Admin_m');
		$this->load->library('session');
		$this->load->library('image_lib');
		$this->load->helper('security');

	}
	public function index()
	{
	    $this->load->view('Admin/header');
	    $this->load->view('Admin/index');
		$this->load->view('Admin/footer');

	}
	public function category()
	{
	    $this->load->view('Admin/header');
	    $this->load->view('Admin/category');
		$this->load->view('Admin/footer');

	}

	public function cat()
	{
	    $this->load->view('Admin/header');
	    $this->load->view('Admin/cat');
		$this->load->view('Admin/footer');

	}

	public function business_report()
	{
	    $this->load->view('Admin/header');
	    $this->load->view('Admin/business_report');
		$this->load->view('Admin/footer');

	}
	public function sample()
	{
		$this->load->view('Admin/add');

	}
	  	function add_post()
	{
		//echo "<pre>"; print_r($_FILES);
		// $config['upload_path'] = 'base_url(carrovan\assets)';
			$config['upload_path'] = './uploads/';
			$config['allowed_types'] = 'gif|jpg|png';
			$config['max_size']     = '0';
			$config['max_width'] = '0';
			$config['max_height'] = '0';
			$config['encrypt_name'] = 'TRUE';
			$config['overwrite'] = 'FALSE';
			// $config['wm_text'] = 'Deveil Birds';
			$config['wm_type'] = 'text';
			// $config['wm_font_path'] = 'C:\xampp\htdocs\devilbirds/fonts/fontawesome-webfont.ttf';
			$config['wm_font_size'] = '16';
			$config['wm_font_color'] = 'aabbcc';
			$config['wm_vrt_alignment'] = 'bottom';
			$config['wm_hor_alignment'] = 'center';
			$config['wm_padding'] = '20';
             
             $img= 'image';
	         $this->load->library('upload', $config);
	         // $this->image_lib->watermark();
	         $abc = $this->upload->do_upload($img);
	         var_dump($abc);
	         	         if(!$this->upload->do_upload($img))
	         {
        $uploadedDetails    = $this->upload->display_errors();
           var_dump($uploadedDetails);
           exit();

               }
    else
	        // $abc = $this->upload->do_upload('myimage');
	       { $abc = $this->upload->do_upload($img);
	          $upload_data = $this->upload->data();

	          $file_name = $upload_data['file_name'];
	          var_dump($abc);
	      }
		$this->form_validation->set_rules('pid','Pid','trim');
		$this->form_validation->set_rules('pn','Pn','trim');
		$this->form_validation->set_rules('bn','Bn','trim');
		$this->form_validation->set_rules('manuf','Manuf','trim');
		$this->form_validation->set_rules('col','Col','trim');
		$this->form_validation->set_rules('size','Size','trim');
		$this->form_validation->set_rules('vary','Vary','trim');
		$this->form_validation->set_rules('price','Price','trim');
		$this->form_validation->set_rules('sku','Sku','trim');
		$this->form_validation->set_rules('sprice','Sprice','trim');
		$this->form_validation->set_rules('sfrom','Sfrom','trim');
		$this->form_validation->set_rules('send','Send','trim');
		$this->form_validation->set_rules('quan','Quan','trim');
		$this->form_validation->set_rules('cond','Cond','trim');
        $this->form_validation->set_rules('no','No','trim');
        $this->form_validation->set_rules('yes','Yes','trim');
        // $this->form_validation->set_rules('myimage','Myimage','trim');
        $this->form_validation->set_rules('pd','Pd','trim');
        $this->form_validation->set_rules('keyf1','Keyf1','trim');
        $this->form_validation->set_rules('keyf2','Keyf2','trim');
        $this->form_validation->set_rules('keyf3','Keyf3','trim');
        $this->form_validation->set_rules('keyf4','Keyf4','trim');
        $this->form_validation->set_rules('keyf5','keyf5','trim');
        $this->form_validation->set_rules('ld','Ld','trim');
        $this->form_validation->set_rules('il','Il','trim');
        $this->form_validation->set_rules('iw','Iw','trim');
        $this->form_validation->set_rules('ih','Ih','trim');
        $this->form_validation->set_rules('sw','Sw','trim');
        // $this->form_validation->set_rules('il','IL','trim');
        // $this->form_validation->set_rules('il','IL','trim');


		if ($this->form_validation->run() == FALSE) 
		{
			
			 $data['error'] = $this->session->set_flashdata('errors');
			var_dump($data);
			var_dump($file_name);
			exit();
		}
		else
		{
				$userData = array(
					'p_id' => $this->input->post('pid'),
					'p_name' => $this->input->post('pn'),
					'b_name' => $this->input->post('bn'),
					'manufacturer' => $this->input->post('manuf'),
					'color' => $this->input->post('col'),
					'size' => $this->input->post('size'),
					'variation' => $this->input->post('vary'),
					'y_price' => $this->input->post('price'),
					'sku' => $this->input->post('sku'),
					's_price' => $this->input->post('sprice'),
					's_from' => $this->input->post('sform'),
					's_end' => $this->input->post('send'),
					'quantity' => $this->input->post('quan'),
					'condition' => $this->input->post('cond'),
					'nothing' => $this->input->post('no'),
					'gift' => $this->input->post('yes'),
					'image' => $file_name,
					'p_disc' => $this->input->post('pd'),
					'key1' => $this->input->post('keyf1'),
					'key2' => $this->input->post('keyf2'),
					'key3' => $this->input->post('keyf3'),
					'key4' => $this->input->post('keyf4'),
					'key5' => $this->input->post('keyf5'),
					'l_disc' => $this->input->post('keyf5'),
					'length' => $this->input->post('il'),
					'width' => $this->input->post('iw'),
					'height' => $this->input->post('ih'),
					'weight' => $this->input->post('sw')
					);
				 // $data = array(
					// 'email' => $this->input->post('email'),
					// 'password' => $this->input->post('password'),
					// 'user_type' => '2');
				//
				// $this->Home_m->add_dealer($userData);
				//var_dump($userData);
			$new =	$this->Admin_m->add_product($userData);
                 echo "successfull";
                 var_dump($new);
                 exit();

				redirect('Home/login');	
		}
	}
	function edit_product($id)
	 {
	 	$data['results'] = $this->Admin_m->edit_product($id);
	 	$this->load->view('Admin/edit_product',$data);
	 }
	 	function update_product($id)
	{
		//echo "<pre>"; print_r($_FILES);
		// $config['upload_path'] = 'base_url(carrovan\assets)';
			$config['upload_path'] = './uploads/';
			$config['allowed_types'] = 'gif|jpg|png';
			$config['max_size']     = '0';
			$config['max_width'] = '0';
			$config['max_height'] = '0';
			$config['encrypt_name'] = 'TRUE';
			$config['overwrite'] = 'FALSE';
			// $config['wm_text'] = 'Deveil Birds';
			$config['wm_type'] = 'text';
			// $config['wm_font_path'] = 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/fonts/fontawesome-webfont.ttf';
			$config['wm_font_size'] = '16';
			$config['wm_font_color'] = 'aabbcc';
			$config['wm_vrt_alignment'] = 'bottom';
			$config['wm_hor_alignment'] = 'center';
			$config['wm_padding'] = '20';
             
             $img= 'image';
	         $this->load->library('upload', $config);
	         // $this->image_lib->watermark();
	         $abc = $this->upload->do_upload($img);
	         // var_dump($abc);
	          if(!$this->upload->do_upload($img))
	         {
	         	$data= $this->Admin_m->edit_product($id);
	         	$abc= $data->image;
	         	$file_name = $abc;
        // $uploadedDetails    = $this->upload->display_errors();
        //    var_dump($uploadedDetails);
        //    exit();

               }
    else
	        // $abc = $this->upload->do_upload('myimage');
	       { $abc = $this->upload->do_upload($img);
	          $upload_data = $this->upload->data();

	          $file_name = $upload_data['file_name'];
	          // var_dump($abc);
	      }
		$this->form_validation->set_rules('pid','Pid','trim');
		$this->form_validation->set_rules('pn','Pn','trim');
		$this->form_validation->set_rules('bn','Bn','trim');
		$this->form_validation->set_rules('manuf','Manuf','trim');
		$this->form_validation->set_rules('col','Col','trim');
		$this->form_validation->set_rules('size','Size','trim');
		$this->form_validation->set_rules('vary','Vary','trim');
		$this->form_validation->set_rules('price','Price','trim');
		$this->form_validation->set_rules('sku','Sku','trim');
		$this->form_validation->set_rules('sprice','Sprice','trim');
		$this->form_validation->set_rules('sfrom','Sfrom','trim');
		$this->form_validation->set_rules('send','Send','trim');
		$this->form_validation->set_rules('quan','Quan','trim');
		$this->form_validation->set_rules('cond','Cond','trim');
        $this->form_validation->set_rules('no','No','trim');
        $this->form_validation->set_rules('yes','Yes','trim');
        // $this->form_validation->set_rules('myimage','Myimage','trim');
        $this->form_validation->set_rules('pd','Pd','trim');
        $this->form_validation->set_rules('keyf1','Keyf1','trim');
        $this->form_validation->set_rules('keyf2','Keyf2','trim');
        $this->form_validation->set_rules('keyf3','Keyf3','trim');
        $this->form_validation->set_rules('keyf4','Keyf4','trim');
        $this->form_validation->set_rules('keyf5','keyf5','trim');
        $this->form_validation->set_rules('ld','Ld','trim');
        $this->form_validation->set_rules('il','Il','trim');
        $this->form_validation->set_rules('iw','Iw','trim');
        $this->form_validation->set_rules('ih','Ih','trim');
        $this->form_validation->set_rules('sw','Sw','trim');
        // $this->form_validation->set_rules('il','IL','trim');
        // $this->form_validation->set_rules('il','IL','trim');


		if ($this->form_validation->run() == FALSE) 
		{
			
			 $data['error'] = $this->session->set_flashdata('errors');
			var_dump($data);
			var_dump($file_name);
			exit();
		}
		else
		{
				$userData = array(
					'p_id' => $this->input->post('pid'),
					'p_name' => $this->input->post('pn'),
					'b_name' => $this->input->post('bn'),
					'manufacturer' => $this->input->post('manuf'),
					'color' => $this->input->post('col'),
					'size' => $this->input->post('size'),
					'variation' => $this->input->post('vary'),
					'y_price' => $this->input->post('price'),
					'sku' => $this->input->post('sku'),
					's_price' => $this->input->post('sprice'),
					's_from' => $this->input->post('sform'),
					's_end' => $this->input->post('send'),
					'quantity' => $this->input->post('quan'),
					'condition' => $this->input->post('cond'),
					'nothing' => $this->input->post('no'),
					'gift' => $this->input->post('yes'),
					'image' => $file_name,
					'p_disc' => $this->input->post('pd'),
					'key1' => $this->input->post('keyf1'),
					'key2' => $this->input->post('keyf2'),
					'key3' => $this->input->post('keyf3'),
					'key4' => $this->input->post('keyf4'),
					'key5' => $this->input->post('keyf5'),
					'l_disc' => $this->input->post('keyf5'),
					'length' => $this->input->post('il'),
					'width' => $this->input->post('iw'),
					'height' => $this->input->post('ih'),
					'weight' => $this->input->post('sw')
					);
				 // $data = array(
					// 'email' => $this->input->post('email'),
					// 'password' => $this->input->post('password'),
					// 'user_type' => '2');
				//
				// $this->Home_m->add_dealer($userData);
				//var_dump($userData);
			$new =	$this->Admin_m->update_product($userData,$id);
                 

				redirect('index.php/Admin/inventory');	
		}
	}
     
       function delete_product($id)
	  {	
	 	$this->Admin_m->delete_product($id);
       redirect('index.php/Admin/inventory');
	 }

	public function inventory()
	{
		$data['results'] =  $this->Admin_m->view_product();	
        //   var_dump($data);
        // // echo  count($data);
        //   exit();
		$this->load->view('Admin/header');
		$this->load->view('Admin/inventory',$data);
		$this->load->view('Admin/footer');
	}

	public function msg()
	{
		$this->load->view('Admin/header');
		$this->load->view('Admin/msg');
		$this->load->view('Admin/footer');
	}

	public function add_product()
	{
		$this->load->view('Admin/header');
		$this->load->view('Admin/add_product');
		$this->load->view('Admin/footer');
	}
	
	public function finance()
	{
       $this->load->view('Admin/finance');
	}

	public function inventory_admin()
	{
	   $data['results'] =  $this->Admin_m->view_product();
       $this->load->view('Admin/inventory_admin',$data);
	}
	
	public function order_admin()
	{
       $this->load->view('Admin/order_admin');
	}

	public function inventory_read()
	{
	   $data['results'] =  $this->Admin_m->view_product();	
       $this->load->view('Admin/inventory_read',$data);
	}

	public function order_read()
	{
       $this->load->view('Admin/order_read');
	}
	public function product_upload()
	{
		$this->load->view('Admin/header');
		$this->load->view('Admin/product_upload');
		$this->load->view('Admin/footer');
	}


	public function refund()
	{
		$this->load->view('Admin/header');
		$this->load->view('Admin/refund');
		$this->load->view('Admin/footer');
	}

	public function slip()
	{
		$this->load->view('Admin/header');
		$this->load->view('Admin/slip');
		$this->load->view('Admin/footer');
	}

	public function buyer()
	{
		$this->load->view('Admin/header');
		$this->load->view('Admin/contact_buyer');
		$this->load->view('Admin/footer');
	}

	public function payment_summery()
	{
		$this->load->view('Admin/header');
		$this->load->view('Admin/payment_summery');
		$this->load->view('Admin/footer');
	}

	public function payment_statement()
	{
		$this->load->view('Admin/header');
		$this->load->view('Admin/payment_statement');
		$this->load->view('Admin/footer');
	}

	public function confirm_order()
	{
		$this->load->view('Admin/header');
		$this->load->view('Admin/confirm_order');
		$this->load->view('Admin/footer');
	}

	public function seller_performance()
	{
		$this->load->view('Admin/header');
		$this->load->view('Admin/seller_performance');
		$this->load->view('Admin/footer');
	}

	public function return_request()
	{
		$this->load->view('Admin/header');
		$this->load->view('Admin/return_request');
		$this->load->view('Admin/footer');
	}

	public function cancel_order()
	{
		$this->load->view('Admin/header');
		$this->load->view('Admin/cancel_order');
		$this->load->view('Admin/footer');
	}

	public function products()
	{
		$this->load->view('Admin/products');
	}
	public function services()
	{
		$this->load->view('Admin/header');
		$this->load->view('Admin/services');
		$this->load->view('Admin/footer');
	}


	public function mang_returns()

	{
		$this->load->view('Admin/header');
		$this->load->view('Admin/mang_return');
		$this->load->view('Admin/footer');
	}

	public function mang_orders()

	{
		$this->load->view('Admin/header');
		$this->load->view('Admin/mang_orders');
		$this->load->view('Admin/footer');
	}

	public function reports()
	{
		$this->load->view('Admin/header');
		$this->load->view('Admin/reports');
		$this->load->view('Admin/footer');
	}

	public function permission()
	{
		$this->load->view('Admin/header');
		$this->load->view('Admin/permission');
		$this->load->view('Admin/footer');
	}

	public function emp()
	{
		$this->load->view('Admin/header');
		$this->load->view('Admin/manage_employee');
		$this->load->view('Admin/footer');
	}

	public function memp()
	{
		$this->load->view('Admin/header');
		$this->load->view('Admin/add_employee');
		$this->load->view('Admin/footer');
	}

	  	function add_category1()
	{
		
		    $config['image_library'] = 'gd2';
			$config['upload_path'] = './uploads/';
			$config['allowed_types'] = 'jpg|png';
			$config['max_size']     = '0';
			$config['max_width'] = '0';
			$config['max_height'] = '0';
			$config['encrypt_name'] = 'TRUE';
			 $img= 'image';
	         $this->load->library('upload', $config);	        
	         if(!$this->upload->do_upload($img))
	         {
		        $uploadedDetails    = $this->upload->display_errors();
		           var_dump($uploadedDetails);
		           exit();
               }

	          else
	          {
		          $upload_data = $this->upload->data();
		          $file_name = $upload_data['file_name'];
	          }

				$this->form_validation->set_rules('category','Category','trim');
				$this->form_validation->set_rules('sub-category','Sub-Category','trim');
				$this->form_validation->set_rules('sku','Sku','trim|required');
				$this->form_validation->set_rules('it','Item Title ','trim|required');
				$this->form_validation->set_rules('ic','Item Code','trim|required');
				$this->form_validation->set_rules('bn','Brand Name','trim|required');
				$this->form_validation->set_rules('manuf','Manufacturer','trim|required');
				$this->form_validation->set_rules('color','Color','trim');
				$this->form_validation->set_rules('dimension','Dimension','trim|required');
				$this->form_validation->set_rules('weight','Weight','trim|required');
				$this->form_validation->set_rules('sex','Sex','trim');
				$this->form_validation->set_rules('expiry','Expiry','trim');
				$this->form_validation->set_rules('battery','Battery','trim');
				$this->form_validation->set_rules('currency','Currency','trim');
				$this->form_validation->set_rules('sponsered','Sponsered','trim');
				$this->form_validation->set_rules('uom','Uom','trim');
		        $this->form_validation->set_rules('quantity','Quantity','trim');
		        $this->form_validation->set_rules('uprice','Unit price','trim');
		        $this->form_validation->set_rules('pd','Product Discreption','trim|required');
		        $this->form_validation->set_rules('cond','Condition','trim');
		        $this->form_validation->set_rules('keyf1','Keyf1','trim');
		        $this->form_validation->set_rules('keyf2','Keyf2','trim');
		        $this->form_validation->set_rules('keyf3','Keyf3','trim');
		        $this->form_validation->set_rules('keyf4','Keyf4','trim');
		        $this->form_validation->set_rules('keyf5','keyf5','trim');
		        $this->form_validation->set_rules('ld','Legal Diclemar','trim');

		if ($this->form_validation->run() == FALSE) 
		{
			 // echo validation_errors(); 
			 // var_dump($this->input->post());
			 // exit();
			
			 $data['error'] = $this->session->set_flashdata('errors');
			$data['div'] = "myform1";
			$this->load->view('Admin/add',$data);
	    }
		else
		{
				$userData = array(
					'category' => $this->input->post('category'),
					'sub_category' => $this->input->post('sub-category'),
					'sku' => $this->input->post('sku'),
					'title' => $this->input->post('it'),
					'code' => $this->input->post('ic'),
					'brand' => $this->input->post('bn'),
					'manufacturer' => $this->input->post('manuf'),
					'color' => $this->input->post('color'),
					'dimension' => $this->input->post('dimension'),
					'weight' => $this->input->post('weight'),
					'sex' => $this->input->post('sex'),
					'expiry' => $this->input->post('expiry'),
					'battery' => $this->input->post('battery'),
					'currency' => $this->input->post('currency'),
					'uom' => $this->input->post('uom'),
					'quantity' => $this->input->post('quantity'),
					'sponsered' => $this->input->post('sponsered'),
					'uprice' => $this->input->post('uprice'),
					'cond' => $this->input->post('cond'),
					'image' => $file_name,
					'pd' => $this->input->post('pd'),
					'keyf1' => $this->input->post('keyf1'),
					'keyf2' => $this->input->post('keyf2'),
					'keyf3' => $this->input->post('keyf3'),
					'keyf4' => $this->input->post('keyf4'),
					'keyf5' => $this->input->post('keyf5'),
					'ld' => $this->input->post('ld')					
					);
				// echo "successfull";
				// var_dump($userData);
				// exit();
			$new =	$this->Admin_m->add_category1($userData);
                 // echo "successfull";
                 // var_dump($new);
                 // exit();

				redirect('index.php/Admin/inventory');	
		}
	}
	function edit_category1($id)
	 {
	 	$data['results'] = $this->Admin_m->edit_category1($id);
	 	$data['div'] = "myform1";
	 	$data['a1']="a2";
	 	$this->load->view('Admin/edit_product',$data);
	 }

	  	function update_category1($id)
	{
		
		    $config['image_library'] = 'gd2';
			$config['upload_path'] = './uploads/';
			$config['allowed_types'] = 'gif|jpg|png';
			$config['max_size']     = '0';
			$config['max_width'] = '0';
			$config['max_height'] = '0';
			$config['encrypt_name'] = 'TRUE';
			 $img= 'image';
	         $this->load->library('upload', $config);	        
	          if(!$this->upload->do_upload($img))
	         {
	         	$data= $this->Admin_m->edit_category1($id);
	         	$file_name = $data->image;
	         	// $file_name = $abc;
}
	          else
	          {
		          $upload_data = $this->upload->data();
		          $file_name = $upload_data['file_name'];
	          }

				$this->form_validation->set_rules('category','Category','trim');
				$this->form_validation->set_rules('sub-category','Sub-Category','trim');
				$this->form_validation->set_rules('sku','Sku','trim|required');
				$this->form_validation->set_rules('it','Item Title ','trim|required');
				$this->form_validation->set_rules('ic','Item Code','trim|required');
				$this->form_validation->set_rules('bn','Brand Name','trim|required');
				$this->form_validation->set_rules('manuf','Manufacturer','trim|required');
				$this->form_validation->set_rules('color','Color','trim');
				$this->form_validation->set_rules('dimension','Dimension','trim|required');
				$this->form_validation->set_rules('weight','Weight','trim|required');
				$this->form_validation->set_rules('sex','Sex','trim');
				$this->form_validation->set_rules('expiry','Expiry','trim');
				$this->form_validation->set_rules('battery','Battery','trim');
				$this->form_validation->set_rules('currency','Currency','trim');
				$this->form_validation->set_rules('sponsered','Sponsered','trim');
				$this->form_validation->set_rules('uom','Uom','trim');
		        $this->form_validation->set_rules('quantity','Quantity','trim');
		        $this->form_validation->set_rules('uprice','Unit price','trim');
		        $this->form_validation->set_rules('pd','Product Discreption','trim|required');
		        $this->form_validation->set_rules('cond','Condition','trim');
		        $this->form_validation->set_rules('keyf1','Keyf1','trim');
		        $this->form_validation->set_rules('keyf2','Keyf2','trim');
		        $this->form_validation->set_rules('keyf3','Keyf3','trim');
		        $this->form_validation->set_rules('keyf4','Keyf4','trim');
		        $this->form_validation->set_rules('keyf5','keyf5','trim');
		        $this->form_validation->set_rules('ld','Legal Diclemar','trim');

		if ($this->form_validation->run() == FALSE) 
		{	 	
			$data['error'] = $this->session->set_flashdata('errors');
			$data['div'] = "myform1";
			$data['a1'] = "a1";
			$this->load->view('Admin/edit_product',$data);
	    }
		else
		{
				$userData = array(
					'category' => $this->input->post('category'),
					'sub_category' => $this->input->post('sub-category'),
					'sku' => $this->input->post('sku'),
					'title' => $this->input->post('it'),
					'code' => $this->input->post('ic'),
					'brand' => $this->input->post('bn'),
					'manufacturer' => $this->input->post('manuf'),
					'color' => $this->input->post('color'),
					'dimension' => $this->input->post('dimension'),
					'weight' => $this->input->post('weight'),
					'sex' => $this->input->post('sex'),
					'expiry' => $this->input->post('expiry'),
					'battery' => $this->input->post('battery'),
					'currency' => $this->input->post('currency'),
					'uom' => $this->input->post('uom'),
					'quantity' => $this->input->post('quantity'),
					'sponsered' => $this->input->post('sponsered'),
					'uprice' => $this->input->post('uprice'),
					'cond' => $this->input->post('cond'),
					'image' => $file_name,
					'pd' => $this->input->post('pd'),
					'keyf1' => $this->input->post('keyf1'),
					'keyf2' => $this->input->post('keyf2'),
					'keyf3' => $this->input->post('keyf3'),
					'keyf4' => $this->input->post('keyf4'),
					'keyf5' => $this->input->post('keyf5'),
					'ld' => $this->input->post('ld')					
					);
				// echo "successfull";
				// var_dump($userData);
				// exit();
			$new =	$this->Admin_m->update_category1($userData,$id);
                 // echo "successfull";
                 // var_dump($new);
                 // exit();

				redirect('index.php/Admin/inventory');	
		}
	}
	 function delete_category1($id)
	  {	
	 	$this->Admin_m->delete_category1($id);
       redirect('index.php/Admin/inventory');
	 }


}
