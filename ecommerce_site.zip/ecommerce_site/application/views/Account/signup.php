<!--created by leamug
authoer : leamug-->
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Carrovan - Sign Up</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="<?= base_url()?>/assets/css/signup1.css">
    <link href="https://fonts.googleapis.com/css?family=Gudea" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Great+Vibes" rel="stylesheet">
</head>
<body>

<div class="login-wrap">
    <div class="login-html">
        <!-- <div class="col-sm-3 col-md-2 columns">
            <h2 class="text-white top-font right">Login to Continue</h2>
        </div> -->
        </br>

        <input id="tab-1" type="radio" name="tab" class="sign-in fs1" checked><label for="tab-1" class="tab "><span style="color: #fed007" class="fs1">Not a Supplier? Click here to signup as Buyer</span><hr>
        <!-- &nbsp;<img src="img/loader_ulamama_1.gif" height="30" style="border-radius: 50%">-->
        
            <h2 class="text-center hs1">Supplier SignUp</h2>
       
        </label> 
        <input id="tab-2" type="radio" name="tab" class="sign-up fs1"><label for="tab-2" class="tab text-signup"><span class="fs1" style="color: #fed007">Not a Buyer? Click here to signup as Supplier</span><hr>
        <!-- &nbsp;<img src="img/loader_ulamama.gif" height="30" style="border-radius: 50%"> -->
          
            <h2 class="text-center hs1">Buyer SignUp</h2>
        
         </label>
        <div class="login-form">
            <div class="sign-in-htm">
            <form action="#" method="post">
                <div class="group">
                    <input type="text" class="input" placeholder="Full Name">
                </div>
                <div class="group">
                    <input type="text" class="input" placeholder="Gender">
                </div>
                <div class="group">
                    <input type="Date" class="input" placeholder="Date Of Birth">
                </div>
                <div class="group">
                    <select class="input">
                        <option class="active">--Country--</option>
                        <option>Pakistan</option>
                        <option>Canada</option>
                    </select>
                </div>
                <div class="group">
                    <input type="text" class="input" placeholder="Province">
                </div>
                <div class="group">
                    <input type="text" class="input" placeholder="City">
                </div>
                <div class="group">
                    <input type="text" class="input" placeholder="Address">
                </div>
                <div class="group">
                    <input type="text" class="input" placeholder="Post Code">
                </div>
                <div class="group">
                    <input type="text" class="input" placeholder="Phone Number">
                </div>
                <div class="group">
                    <input type="email" class="input" placeholder="Email">
                </div>
                <div class="group">
                    <input type="email" class="input" placeholder="Confirm Email">
                </div>
                
                <div class="group">
                    <input type="submit" class="button" value="Sign Up">
                </div>
               <div><a href="login" style="color: black" class="fs1">Already have an account? LogIn here</a></div> 
            </form>
            </div>
            <div class="sign-up-htm">
            <form action="#" method="post">
                <div class="group">
                    <input type="text" class="input" placeholder="Full Name">
                </div>
                <div class="group">
                    <input type="text" class="input" placeholder="Gender">
                </div>
                <div class="group">
                    <input type="Date" class="input" placeholder="Date Of Birth">
                </div>
                <div class="group">
                    <select class="input">
                        <option class="active">--Country--</option>
                        <option>Pakistan</option>
                        <option>Canada</option>
                    </select>
                </div>
                <div class="group">
                    <input type="text" class="input" placeholder="Province">
                </div>
                <div class="group">
                    <input type="text" class="input" placeholder="City">
                </div>
                <div class="group">
                    <input type="text" class="input" placeholder="Address">
                </div>
                <div class="group">
                    <input type="text" class="input" placeholder="Post Code">
                </div>
                <div class="group">
                    <input type="text" class="input" placeholder="Phone Number">
                </div>
                <div class="group">
                    <input type="email" class="input" placeholder="Email">
                </div>
                <div class="group">
                    <input type="email" class="input" placeholder="Confirm Email">
                </div>
                
                <div class="group">
                    <input type="submit" class="button" value="Sign Up">
                </div>
               <div><a href="login" style="color: black" class="fs1">Already have an account? LogIn here</a></div> 
            </form>
            </div>
        </div>
    </div>
</div>

</body>
</html>