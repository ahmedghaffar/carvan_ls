<!DOCTYPE html>
<html lang="en">
  
<head>
    <meta charset="utf-8">
    <title>Login - Carrovan</title>

	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="apple-mobile-web-app-capable" content="yes"> 
    
<link href="<?= base_url()?>/assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
<link href="<?= base_url()?>/assets/css/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />

<link href="<?= base_url()?>/assets/css/font-awesome.css" rel="stylesheet">
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600" rel="stylesheet">
    
<link href="<?= base_url()?>/assets/css/style.css" rel="stylesheet" type="text/css">
<link href="<?= base_url()?>/assets/css/pages/signin.css" rel="stylesheet" type="text/css">


<style type="text/css">
	a:hover{
		text-decoration: none !important;
	}
</style>
</head>

<body>

<div class="account-container">
	
	<div class="content clearfix">
		
		<form action="check_user" method="post">
		
			<h1 align="center" class="hs1">Login</h1>		
			
			<div class="login-fields">
				
				<p>Please provide your details</p>
				
				<div class="field">
					<label for="username">Username</label>
					<input type="text" id="username" name="email" value="" placeholder="Email" />
				</div> <!-- /field -->
				
				<div class="field">
					<label for="password">Password:</label>
					<input type="password" id="password" name="password" value="" placeholder="Password"/>
				</div> <!-- /password -->
				
			</div> <!-- /login-fields -->
			
			<div class="login-actions">
				
				<span class="login-checkbox">
					<input id="Field" name="Field" type="checkbox" class="field login-checkbox" value="First Choice" tabindex="4" />
					<label class="choice" for="Field">Keep me signed in</label>
				</span>
									
				<button class="button btn btn-success btn-large">Sign In</button>
				
			</div> <!-- .actions -->
			
	<a href="#" style="color: #fed007">Reset Password</a> <br>
	<a href="signup" style="color: #fed007">Don't Have an Account? </a>
			
			
		</form>
		
	</div> <!-- /content -->
	
</div> <!-- /account-container -->



<div class="login-extra">
</div>
<div class="login-extra">
</div>
 <!-- /login-extra -->


<script src="<?= base_url()?>/assets/js/jquery-1.7.2.min.js"></script>
<script src="<?= base_url()?>/assets/js/bootstrap.js"></script>

<script src="<?= base_url()?>/assets/js/signin.js"></script>

</body>

</html>
