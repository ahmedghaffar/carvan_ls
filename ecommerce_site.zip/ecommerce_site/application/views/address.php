<div class="container">
	<div class="header" style="margin-top: 5%">
		<h1 class="hs1">Your Addresses</h1>
	</div>
	<div class="row">
		<div class="col-md-4">
			<div class="panel panel-default text-center" style="padding: 23%">
				<a class="text-center" role="button" href="newaddress" ><i class="fa fa-plus fa-4x"></i><br>Add New Address</a>
			</div>
		</div>
		<div class="col-md-4">
			<div class="panel panel-default">
				<div class="panel-heading"> <div class="fs2">Default : <spna class="fs3"><b>Carrovan</b></spna></div></div>
				<div class="panel-body">
					<p class="fs2">Teresa Qureshi</p>
					<p class="fs3">9 WORTON ROAD<br> ISLEWORTH, Middx TW7 6HJ<br> Unired Kingdom</br></p>
					<p class="fs3">Phone number: 01234566789</p><br><br>
					<a href="#" class="btn btn-primary">Edit</a>
					<a href="#" class="btn btn-primary">Delete</a>
				</div>
			</div>
		</div>
		<div class="col-md-4">
			<div class="panel panel-default">
				<div class="panel-heading"> <div class="fs2">Shipping Address</div></div>
				<div class="panel-body">
					<p class="fs2">Ahsan Munir</p>
					<p class="fs3">9 WORTON ROAD<br> ISLEWORTH, Middx TW7 6HJ<br> Unired Kingdom</br></p>
					<p class="fs3">Phone number: 01234566789</p><br><br>
					<a href="#" class="btn btn-primary">Edit</a>
					<a href="#" class="btn btn-primary">Delete</a>
					<a href="#" class="btn btn-primary">Set as Default</a>
				</div>
			</div>
		</div>
		<div class="col-md-4">
			<div class="panel panel-default">
				<div class="panel-heading"> <div class="fs2">Billing Address</div></div>
				<div class="panel-body">
					<p class="fs2">Ahsan Munir</p>
					<p class="fs3">9 WORTON ROAD<br> ISLEWORTH, Middx TW7 6HJ<br> Unired Kingdom</br></p>
					<p class="fs3">Phone number: 01234566789</p><br><br>
					<a href="#" class="btn btn-primary">Edit</a>
					<a href="#" class="btn btn-primary">Delete</a>
					<a href="#" class="btn btn-primary">Set as Default</a>
				</div>
			</div>
		</div>
	</div>
</div>