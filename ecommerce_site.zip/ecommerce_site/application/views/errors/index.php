
<!DOCTYPE html>
<html lang="en" prefix="og: http://ogp.me/ns# fb: http://ogp.me/ns/fb#">
  
<head>

<title>Carrovan-The Smart Shop</title>
<!--<link rel="stylesheet" type="text/css" href="css/bootstrap.css">-->

<link href="<?= base_url(); ?>css/boot.css" rel="stylesheet" type="text/css" media="all" />
<link href="<?= base_url(); ?>css/3.css" rel="stylesheet" type="text/css" media="screen" />
<link href="<?= base_url(); ?>css/4.css" rel="stylesheet" type="text/css" media="screen" />
<link href="<?= base_url(); ?>css/font2.css" rel="stylesheet" type="text/css" media="all" />
<!-- <link href="<?= base_url(); ?>css/bootstrap.min.css" rel="stylesheet" type="text/css" media="all" />
 --><link href="<?= base_url(); ?>css/slide.css" rel="stylesheet" type="text/css" media="print" />
<link rel="stylesheet" href="<?= base_url(); ?>font/fontawesome-all.min.css">
<!-- <link rel="stylesheet" href="<?= base_url(); ?>font/font-awesome.min.css"> -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">



<script type="text/javascript">
var xliteConfig = {
  script: 'cart.php',
  admin_script: 'admin.php',
  target:   'main',
  language: 'en',
  ajax_prefix: '',
  form_id: 'Oh6ppUmqDu0GsyFZm9d3kzkCUnsaI1mD',
  form_id_name: 'xcart_form_id',
  developer_mode: false,
  clean_url: false,
  clean_urls_base: 'cart.php',
};
</script>

<script type="text/javascript">
  window.xlite_preloaded_labels ={"Menu":"Menu"};
</script>

</head>

<body class="area-c skin-customer skin-Multistore-customer skin-theme_tweaker-customer unauthorized target-main no-sidebars responsive-desktop">
<script type="text/x-cart-data">
{"dragDropCart":true,"tabletDevice":false,"cloudSearch":{"apiKey":"0d7702adb2bc411b11e241a2e7393445","priceTemplate":"$0.00","selector":"input[name=\"substring\"]","lng":{"lbl_showing_results_for":"Showing results for","lbl_see_details":"See details","lbl_see_more_results_for":"See more results for","lbl_suggestions":"Suggestions","lbl_products":"Products","lbl_categories":"Categories","lbl_pages":"Pages","lbl_manufacturers":"Manufacturers","lbl_did_you_mean":"Did you mean"},"dynamicPricesEnabled":false,"requestData":{"limits":{"products":7}}}}
</script>


<nav id="slidebar" data-mobile-navbar>
        <ul class="dropdown">

                    <li class="slidebar-categories ">
                <span data-toggle="dropdown">Categories</span>
              
<ul class="menu menu-tree catalog-categories catalog-categories-tree">
          <li >
        <a href="cart.php?target=category&amp;category_id=9"  class="first" title="Women&#039;s Clothing">
      <span class="category-menu-icon"><img src="<?= base_url(); ?>images/women.jpeg" alt=""  height="30" width="30" data-max-width="30" data-max-height="30" data-is-default-image="" />
</span>
    <span class="category-label">Women&#039;s Clothing</span>
      <span class="icon-triangle"></span>
</a>
                  
<ul class="menu menu-tree sublevel">
          <li >
        <a href="#"  class="first" title="Tops">
    <span class="category-label">Tops</span>
  </a>

                  
<ul class="menu menu-tree sublevel">
          <li >
        <a href="#"  class="leaf first" title="T-Shirts">
    <span class="category-label">T-Shirts</span>
  </a>

              </li>
        </ul>
              </li>
          <li >
        <a href="#"  class="first" title="Bottoms">
    <span class="category-label">Bottoms</span>
  </a>

                  
<ul class="menu menu-tree sublevel">
          <li >
        <a href="#"  class="leaf first" title="Skirts">
    <span class="category-label">Skirts</span>
  </a>

              </li>
          <li >
        <a href="#"  class="leaf first" title="Pants">
    <span class="category-label">Pants</span>
  </a>

              </li>
        </ul>
              </li>
          <li >
        <a href="#"  class="first" title="Outerwear">
    <span class="category-label">Outerwear</span>
  </a>

                  
<ul class="menu menu-tree sublevel">
          <li >
        <a href="#"  class="leaf first" title="Jackets">
    <span class="category-label">Jackets</span>
  </a>

              </li>
          <li >
        <a href="#"  class="leaf first" title="Bombers">
    <span class="category-label">Bombers</span>
  </a>

              </li>
          <li >
        <a href="#"  class="leaf first" title="Coats">
    <span class="category-label">Coats</span>
  </a>

              </li>
        </ul>
              </li>
          <li >
        <a href="#"  class="leaf first" title="Accessories">
    <span class="category-label">Accessories</span>
  </a>

              </li>
        </ul>
              </li>
          <li >
        <a href="cart.php?target=category&amp;category_id=10"  class="first" title="Men&#039;s Clothing">
      <span class="category-menu-icon"><img src="//design.x-cart.com/demo/templates/multistore/images/category_icon/men_1.jpg" alt=""  height="30" width="30" data-max-width="30" data-max-height="30" data-is-default-image="" />
</span>
    <span class="category-label">Men&#039;s Clothing</span>
      <span class="icon-triangle"></span>
  </a>

                  
<ul class="menu menu-tree sublevel">
          <li >
        <a href="cart.php?target=category&amp;category_id=32"  class="first" title="Tops">
    <span class="category-label">Tops</span>
  </a>

                  
<ul class="menu menu-tree sublevel">
          <li >
        <a href="cart.php?target=category&amp;category_id=36"  class="leaf first" title="Hoodies">
    <span class="category-label">Hoodies</span>
  </a>

              </li>
          <li >
        <a href="cart.php?target=category&amp;category_id=35"  class="leaf first" title="T-Shirts">
    <span class="category-label">T-Shirts</span>
  </a>

              </li>
        </ul>
              </li>
          <li >
        <a href="cart.php?target=category&amp;category_id=33"  class="first" title="Bottoms">
    <span class="category-label">Bottoms</span>
  </a>

                  
<ul class="menu menu-tree sublevel">
          <li >
        <a href="cart.php?target=category&amp;category_id=37"  class="leaf first" title="Pants">
    <span class="category-label">Pants</span>
  </a>

              </li>
          <li >
        <a href="cart.php?target=category&amp;category_id=38"  class="leaf first" title="Jeans">
    <span class="category-label">Jeans</span>
  </a>

              </li>
        </ul>
              </li>
          <li >
        <a href="cart.php?target=category&amp;category_id=34"  class="first" title="Outerwear">
    <span class="category-label">Outerwear</span>
  </a>

                  
<ul class="menu menu-tree sublevel">
          <li >
        <a href="cart.php?target=category&amp;category_id=39"  class="leaf first" title="Coats">
    <span class="category-label">Coats</span>
  </a>

              </li>
          <li >
        <a href="cart.php?target=category&amp;category_id=40"  class="leaf first" title="Bombers">
    <span class="category-label">Bombers</span>
  </a>

              </li>
          <li >
        <a href="cart.php?target=category&amp;category_id=41"  class="leaf first" title="Jackets">
    <span class="category-label">Jackets</span>
  </a>

              </li>
        </ul>
              </li>
        </ul>
              </li>
          <li >
        <a href="cart.php?target=category&amp;category_id=11"  class="leaf first" title="Jewerly &amp; Watches">
      <span class="category-menu-icon"><img src="//design.x-cart.com/demo/templates/multistore/images/category_icon/Jewelry.jpg" alt=""  height="30" width="30" data-max-width="30" data-max-height="30" data-is-default-image="" />
</span>
    <span class="category-label">Jewerly &amp; Watches</span>
  </a>

              </li>
          <li >
        <a href="cart.php?target=category&amp;category_id=12"  class="leaf first" title="Home &amp; Furniture">
      <span class="category-menu-icon"><img src="//design.x-cart.com/demo/templates/multistore/images/category_icon/Furniture.jpg" alt=""  height="30" width="30" data-max-width="30" data-max-height="30" data-is-default-image="" />
</span>
    <span class="category-label">Home &amp; Furniture</span>
  </a>

              </li>
          <li >
        <a href="cart.php?target=category&amp;category_id=13"  class="leaf first" title="Bags &amp; Shoes">
      <span class="category-menu-icon"><img src="//design.x-cart.com/demo/templates/multistore/images/category_icon/Shoes.jpg" alt=""  height="30" width="30" data-max-width="30" data-max-height="30" data-is-default-image="" />
</span>
    <span class="category-label">Bags &amp; Shoes</span>
  </a>

              </li>
          <li >
        <a href="cart.php?target=category&amp;category_id=14"  class="first" title="Toys, Kids &amp; Baby">
      <span class="category-menu-icon"><img src="//design.x-cart.com/demo/templates/multistore/images/category_icon/kids.jpg" alt=""  height="30" width="30" data-max-width="30" data-max-height="30" data-is-default-image="" />
</span>
    <span class="category-label">Toys, Kids &amp; Baby</span>
      <span class="icon-triangle"></span>
  </a>

                  
<ul class="menu menu-tree sublevel">
          <li >
        <a href="cart.php?target=category&amp;category_id=5"  class="first" title="Toys">
    <span class="category-label">Toys</span>
  </a>

                  
<ul class="menu menu-tree sublevel">
          <li >
        <a href="cart.php?target=category&amp;category_id=6"  class="leaf first" title="Geek toys">
    <span class="category-label">Geek toys</span>
  </a>

              </li>
          <li >
        <a href="cart.php?target=category&amp;category_id=7"  class="leaf first" title="Office Pranks">
    <span class="category-label">Office Pranks</span>
  </a>

              </li>
          <li >
        <a href="cart.php?target=category&amp;category_id=8"  class="leaf first" title="Home &amp; office">
    <span class="category-label">Home &amp; office</span>
  </a>

              </li>
        </ul>
              </li>
        </ul>
              </li>
          <li >
        <a href="cart.php?target=category&amp;category_id=15"  class="leaf first" title="Sports &amp; Outdoors">
      <span class="category-menu-icon"><img src="//design.x-cart.com/demo/templates/multistore/images/category_icon/ball.jpg" alt=""  height="30" width="30" data-max-width="30" data-max-height="30" data-is-default-image="" />
</span>
    <span class="category-label">Sports &amp; Outdoors</span>
  </a>

              </li>
          <li >
        <a href="cart.php?target=category&amp;category_id=16"  class="first" title="Tools">
      <span class="category-menu-icon"><img src="//design.x-cart.com/demo/templates/multistore/images/category_icon/Improvement.jpg" alt=""  height="30" width="30" data-max-width="30" data-max-height="30" data-is-default-image="" />
</span>
    <span class="category-label">Tools</span>
      <span class="icon-triangle"></span>
  </a>

                  
<ul class="menu menu-tree sublevel">
          <li >
        <a href="cart.php?target=category&amp;category_id=29"  class="first" title="Hand Tools">
    <span class="category-label">Hand Tools</span>
  </a>

                  
<ul class="menu menu-tree sublevel">
          <li >
        <a href="cart.php?target=category&amp;category_id=17"  class="leaf first" title="Sanders">
    <span class="category-label">Sanders</span>
  </a>

              </li>
          <li >
        <a href="cart.php?target=category&amp;category_id=18"  class="leaf first" title="Saws">
    <span class="category-label">Saws</span>
  </a>

              </li>
          <li >
        <a href="cart.php?target=category&amp;category_id=19"  class="leaf first" title="Drills">
    <span class="category-label">Drills</span>
  </a>

              </li>
          <li >
        <a href="cart.php?target=category&amp;category_id=20"  class="leaf first" title="Grinders">
    <span class="category-label">Grinders</span>
  </a>

              </li>
          <li >
        <a href="cart.php?target=category&amp;category_id=21"  class="leaf first" title="Protection">
    <span class="category-label">Protection</span>
  </a>

              </li>
        </ul>
              </li>
        </ul>
              </li>
          <li >
        <a href="cart.php?target=category&amp;category_id=3"  class="leaf first" title="Electronic">
      <span class="category-menu-icon"><img src="//design.x-cart.com/demo/templates/multistore/images/category_icon/loptop.jpg" alt=""  height="30" width="30" data-max-width="30" data-max-height="30" data-is-default-image="" />
</span>
    <span class="category-label">Electronic</span>
  </a>

              </li>
          <li >
        <a href="cart.php?target=category&amp;category_id=2"  class="leaf first" title="Phones &amp; Accessories">
      <span class="category-menu-icon"><img src="//design.x-cart.com/demo/templates/multistore/images/category_icon/phone.jpg" alt=""  height="30" width="30" data-max-width="30" data-max-height="30" data-is-default-image="" />
</span>
    <span class="category-label">Phones &amp; Accessories</span>
  </a>

              </li>
        </ul>
            </li>
                
  
                
    
    <li  class="leaf first">
          <a href="#" ><span>Blog</span></a>
                    </li>
          
    
    <li  class="leaf has-sub">
          <span class="primary-title">Hot deals</span>
            <ul>
    
    
    <li  class="leaf">
          <a href="#" ><span>Sale</span></a>
                    </li>
          
    
    <li  class="leaf">
          <a href="#" ><span>Bestsellers</span></a>
                    </li>
          
    </ul></li>
    <li  class="leaf">
          <a href="#" ><span>New!</span></a>
                    </li>
          
    
    <li  class="leaf last">
          <a href="#" ><span>Contact us</span></a>
          </li>
  
    <li class="Divider"></li>
    <li class="additional-menu-wrapper">
        <ul class="Inset additional-menu">
                            <li><li class="wishlist-link">
  <a class="wishlist-link log-in" href="cart.php?target=wishlist" data-return-url="cart.php?target=wishlist" title="Wishlist">
    <i class="fa fa-heart-o"></i>
           <span class="wishlist-label">Wishlist</span>
        <span class="wishlist-product-count"  style="display: none" >
    </span>
</a>

</li>
</li>
                            <li>
    <ul class='my-account-quick- fa fa-user'><li><i class="fa fa-user"></i><span>My account</span><ul><ul class="sign-in_block"><li class="account-link-sign_in"><button type="button" class="btn  regular-button  popup-button popup-login" data-without-close="1"><script type="text/x-cart-data">
{"url_params":{"target":"login","widget":"\\XLite\\View\\Authorization","fromURL":"cart.php"}}
</script><span>Sign in / sign up</span></button></li></ul></ul></li></ul></li>
                    </ul>
    </li>

    </ul>
    </nav>



<div id="page-wrapper">
  <div id="page" class="">
    

<!-- <div class="bannerBox">
                        <div class="banner_container HeaderTop" style="  ">
                
<div
id="slideshowHeaderTop7"
>
    
        <div class="banner_item">
                                                
       <img src="//design.x-cart.com/demo/templates/multistore/images/banner/Header_Banner.png" alt=""  id="banner_image_8" height="120" width="2880" data-max-width="0" data-max-height="0" data-is-default-image="" />

                                                        
                    </div>

    </div>

            </div>
            </div> -->

<div class="status-messages-wrapper">
  <div class="status-messages-wrapper2">

    <div id="status-messages"  style="display: none;">

      <a href="#" class="close" title="Close"><img src="<?= base_url(); ?>skins/Multistore/images/spacer.gif" alt="Close" /></a>

      
    </div>

  </div>
</div>
<div id="header-area">
  <div class="desktop-header">
    <div class="container">
      <div id="logo" class="company-logo">
  <a href="cart.php" title="Home" rel="home"><img src="<?= base_url(); ?>images/logo.png" alt="Home" /></a>
</div>

<div id="search">
  
<div class="simple-search-product-form">

   
<form action="?" method="post" accept-charset="utf-8" onsubmit="javascript: return true;" class="form5b0dbe080730d0.67653857">
<div class="form-params" style="display: none;">
      <input type="hidden" name="target" value="search" />
      <input type="hidden" name="action" value="search" />
      <input type="hidden" name="itemsList" value="\XLite\View\ItemsList\Product\Customer\Search" />
      <input type="hidden" name="mode" value="search" />
      <input type="hidden" name="searchInSubcats" value="Y" />
      <input type="hidden" name="including" value="all" />
      <input type="hidden" name="returnURL" value="/demo/templates/multistore/" />
  </div>
    
<div class="simple-search-box">
  


<div class="table-value substring-value">
  <span class="input-field-wrapper input input-text-searchbox">
  <script type="text/x-cart-data">
{"defaultValue":"","selectOnFocus":false}
</script>

  <input name="substring" placeholder="What do you want to find?" type="text" value="" autocomplete="off" maxlength="255" class="validate[maxSize[255]]  form-text" />
</span>
        </div>




<button type="submit"  Class="btn btn-default" ><i class="fas fa-search"></i>
  
    <span>Search</span>
</button>


</div>

  </form>

</div>

</div>

<div class="navbar navbar-inverse mobile-hidden" role="navigation">
    <div class="collapse navbar-collapse">
        <ul class="nav navbar-nav top-main-menu menu-categories">
            <li class="leaf has-sub">
                <span class="primary-title">Shop by Categories</span>
                
<ul class="menu menu-list catalog-categories catalog-categories-tree">
          <li >
        <a href="#"  title="Women&#039;s Clothing">
      <span class="category-menu-icon"><img src="<?= base_url(); ?>images/women.jpg" alt=""  height="30" width="30" data-max-width="30" data-max-height="30" data-is-default-image="" />
</span>
    <span class="category-label">Women&#039;s Clothing</span>
      <span class="icon-triangle"></span>
  </a>

                  
<ul class="menu menu-list sublevel">
          <li >
        <a href="#"  title="Tops">
    <span class="category-label">Tops</span>
  </a>

                  
<ul class="menu menu-list sublevel">
          <li  class="leaf">
        <a href="#"  title="T-Shirts">
    <span class="category-label">T-Shirts</span>
  </a>

              </li>
                    </ul>
              </li>
          <li >
        <a href="#"  title="Bottoms">
    <span class="category-label">Bottoms</span>
  </a>

                  
<ul class="menu menu-list sublevel">
          <li  class="leaf">
        <a href="#"  title="Skirts">
    <span class="category-label">Skirts</span>
  </a>

              </li>
          <li  class="leaf">
        <a href="#"  title="Pants">
    <span class="category-label">Pants</span>
  </a>

              </li>
                    </ul>
              </li>
          <li >
        <a href="#"  title="Outerwear">
    <span class="category-label">Outerwear</span>
  </a>

                  
<ul class="menu menu-list sublevel">
          <li  class="leaf">
        <a href="#"  title="Jackets">
    <span class="category-label">Jackets</span>
  </a>

              </li>
          <li  class="leaf">
        <a href="#"  title="Bombers">
    <span class="category-label">Bombers</span>
  </a>

              </li>
          <li  class="leaf">
        <a href="#"  title="Coats">
    <span class="category-label">Coats</span>
  </a>

              </li>
                    </ul>
              </li>
          <li  class="leaf">
        <a href="#"  title="Accessories">
    <span class="category-label">Accessories</span>
  </a>

              </li>
                    </ul>
              </li>
          <li >
        <a href="#"  title="Men&#039;s Clothing">
      <span class="category-menu-icon"><img src="//design.x-cart.com/demo/templates/multistore/images/category_icon/men_1.jpg" alt=""  height="30" width="30" data-max-width="30" data-max-height="30" data-is-default-image="" />
</span>
    <span class="category-label">Men&#039;s Clothing</span>
      <span class="icon-triangle"></span>
  </a>

                  
<ul class="menu menu-list sublevel">
          <li >
        <a href="#"  title="Tops">
    <span class="category-label">Tops</span>
  </a>

                  
<ul class="menu menu-list sublevel">
          <li  class="leaf">
        <a href="#"  title="Hoodies">
    <span class="category-label">Hoodies</span>
  </a>

              </li>
          <li  class="leaf">
        <a href="#"  title="T-Shirts">
    <span class="category-label">T-Shirts</span>
  </a>

              </li>
                    </ul>
              </li>
          <li >
        <a href="#"  title="Bottoms">
    <span class="category-label">Bottoms</span>
  </a>

                  
<ul class="menu menu-list sublevel">
          <li  class="leaf">
        <a href="#"  title="Pants">
    <span class="category-label">Pants</span>
  </a>

              </li>
          <li  class="leaf">
        <a href="#"  title="Jeans">
    <span class="category-label">Jeans</span>
  </a>

              </li>
                    </ul>
              </li>
          <li >
        <a href="#"  title="Outerwear">
    <span class="category-label">Outerwear</span>
  </a>

                  
<ul class="menu menu-list sublevel">
          <li  class="leaf">
        <a href="#"  title="Coats">
    <span class="category-label">Coats</span>
  </a>

              </li>
          <li  class="leaf">
        <a href="#"  title="Bombers">
    <span class="category-label">Bombers</span>
  </a>

              </li>
          <li  class="leaf">
        <a href="#"  title="Jackets">
    <span class="category-label">Jackets</span>
  </a>

              </li>
                    </ul>
              </li>
                    </ul>
              </li>
          <li  class="leaf">
        <a href="#"  title="Jewerly &amp; Watches">
      <span class="category-menu-icon"><img src="//design.x-cart.com/demo/templates/multistore/images/category_icon/Jewelry.jpg" alt=""  height="30" width="30" data-max-width="30" data-max-height="30" data-is-default-image="" />
</span>
    <span class="category-label">Jewerly &amp; Watches</span>
  </a>

              </li>
          <li  class="leaf">
        <a href="#"  title="Home &amp; Furniture">
      <span class="category-menu-icon"><img src="//design.x-cart.com/demo/templates/multistore/images/category_icon/Furniture.jpg" alt=""  height="30" width="30" data-max-width="30" data-max-height="30" data-is-default-image="" />
</span>
    <span class="category-label">Home &amp; Furniture</span>
  </a>

              </li>
          <li  class="leaf">
        <a href="#"  title="Bags &amp; Shoes">
      <span class="category-menu-icon"><img src="//design.x-cart.com/demo/templates/multistore/images/category_icon/Shoes.jpg" alt=""  height="30" width="30" data-max-width="30" data-max-height="30" data-is-default-image="" />
</span>
    <span class="category-label">Bags &amp; Shoes</span>
  </a>

              </li>
          <li >
        <a href="#"  title="Toys, Kids &amp; Baby">
      <span class="category-menu-icon"><img src="//design.x-cart.com/demo/templates/multistore/images/category_icon/kids.jpg" alt=""  height="30" width="30" data-max-width="30" data-max-height="30" data-is-default-image="" />
</span>
    <span class="category-label">Toys, Kids &amp; Baby</span>
      <span class="icon-triangle"></span>
  </a>

                  
<ul class="menu menu-list sublevel">
          <li >
        <a href="#"  title="Toys">
    <span class="category-label">Toys</span>
  </a>

                  
<ul class="menu menu-list sublevel">
          <li  class="leaf">
        <a href="#"  title="Geek toys">
    <span class="category-label">Geek toys</span>
  </a>

              </li>
          <li  class="leaf">
        <a href="#"  title="Office Pranks">
    <span class="category-label">Office Pranks</span>
  </a>

              </li>
          <li  class="leaf">
        <a href="#"  title="Home &amp; office">
    <span class="category-label">Home &amp; office</span>
  </a>

              </li>
                    </ul>
              </li>
                    </ul>
              </li>
          <li  class="leaf">
        <a href="#"  title="Sports &amp; Outdoors">
      <span class="category-menu-icon"><img src="//design.x-cart.com/demo/templates/multistore/images/category_icon/ball.jpg" alt=""  height="30" width="30" data-max-width="30" data-max-height="30" data-is-default-image="" />
</span>
    <span class="category-label">Sports &amp; Outdoors</span>
  </a>

              </li>
          <li >
        <a href="#"  title="Tools">
      <span class="category-menu-icon"><img src="//design.x-cart.com/demo/templates/multistore/images/category_icon/Improvement.jpg" alt=""  height="30" width="30" data-max-width="30" data-max-height="30" data-is-default-image="" />
</span>
    <span class="category-label">Tools</span>
      <span class="icon-triangle"></span>
  </a>

                  
<ul class="menu menu-list sublevel">
          <li >
        <a href="#"  title="Hand Tools">
    <span class="category-label">Hand Tools</span>
  </a>

                  
<ul class="menu menu-list sublevel">
          <li  class="leaf">
        <a href="#"  title="Sanders">
    <span class="category-label">Sanders</span>
  </a>

              </li>
          <li  class="leaf">
        <a href="#"  title="Saws">
    <span class="category-label">Saws</span>
  </a>

              </li>
          <li  class="leaf">
        <a href="#"  title="Drills">
    <span class="category-label">Drills</span>
  </a>

              </li>
          <li  class="leaf">
        <a href="#"  title="Grinders">
    <span class="category-label">Grinders</span>
  </a>

              </li>
          <li  class="leaf">
        <a href="#"  title="Protection">
    <span class="category-label">Protection</span>
  </a>

              </li>
                    </ul>
              </li>
                    </ul>
              </li>
          <li  class="leaf">
        <a href="#"  title="Electronic">
      <span class="category-menu-icon"><img src="//design.x-cart.com/demo/templates/multistore/images/category_icon/loptop.jpg" alt=""  height="30" width="30" data-max-width="30" data-max-height="30" data-is-default-image="" />
</span>
    <span class="category-label">Electronic</span>
  </a>

              </li>
          <li  class="leaf">
        <a href="#"  title="Phones &amp; Accessories">
      <span class="category-menu-icon"><img src="//design.x-cart.com/demo/templates/multistore/images/category_icon/phone.jpg" alt=""  height="30" width="30" data-max-width="30" data-max-height="30" data-is-default-image="" />
</span>
    <span class="category-label">Phones &amp; Accessories</span>
  </a>

              </li>
            </ul>
            </li>
        </ul>
        
<ul class="nav navbar-nav top-main-menu">
  
                
    
    <li  class="leaf first">
          <a href="#" ><span>Blog</span></a>
                    </li>
          
    
    <li  class="leaf has-sub">
          <span class="primary-title">Hot deals</span>
            <ul>
    
    
    <li  class="leaf">
          <a href="#" ><span>Sale</span></a>
                    </li>
          
    
    <li  class="leaf">
          <a href="#" ><span>Bestsellers</span></a>
                    </li>
          
    </ul></li>
    <li  class="leaf">
          <a href="#" ><span>New!</span></a>
                    </li>
          
    
    <li  class="leaf last">
          <a href="#" ><span>Contact us</span></a>
          </li>
  
</ul>

          <div id="header" class="header-right-bar">
    
<div class="header_search" title="Search">
  <a data-target=".header_search-panel" data-toggle="collapse" class="collapsed"></a>
  <div class="header_search-panel collapse">
    
<div class="simple-search-product-form">

   
<form action="?" method="post" accept-charset="utf-8" onsubmit="javascript: return true;" class="form5b0dbe080730d0.67653857">
<div class="form-params" style="display: none;">
      <input type="hidden" name="target" value="search" />
      <input type="hidden" name="action" value="search" />
      <input type="hidden" name="itemsList" value="\XLite\View\ItemsList\Product\Customer\Search" />
      <input type="hidden" name="mode" value="search" />
      <input type="hidden" name="searchInSubcats" value="Y" />
      <input type="hidden" name="including" value="all" />
      <input type="hidden" name="returnURL" value="/demo/templates/multistore/" />
  </div>
    
<div class="simple-search-box">
  


<div class="table-value substring-value">
  <span class="input-field-wrapper input input-text-searchbox">
  <script type="text/x-cart-data">
{"defaultValue":"","selectOnFocus":false}
</script>

  <input name="substring" placeholder="What do you want to find?" type="text" value="" autocomplete="off" maxlength="255" class="validate[maxSize[255]]  form-text" />
</span>
        </div>




<button type="submit"  Class="btn btn-default" ><i class="fas sa-search"></i>
  
    <span>Search</span>
</button>


</div>

  </form>

</div>

  </div>
</div>

<div class="header_settings dropdown " title="Menu">
    <a data-target="#" data-toggle="dropdown"></a>
    <div class="dropdown-menu">
        
    <ul class='quick-links'><ul class="sign-in_block"><li class="account-link-sign_in"><button type="button" class="btn  regular-button  popup-button popup-login" data-without-close="1"><script type="text/x-cart-data">
{"url_params":{"target":"login","widget":"\\XLite\\View\\Authorization","fromURL":"cart.php"}}
</script><span>Sign in / sign up</span></button></li></ul></ul>
<ul class="sign-in_block">
  <li class="account-link-sign_in">
      <button type="button" class="btn  regular-button  popup-button popup-login" data-without-close="1">
<script type="text/x-cart-data">
{"url_params":{"target":"login","widget":"\\XLite\\View\\Authorization","fromURL":"cart.php"}}
</script>

<span>Sign in / sign up</span>
</button>

  </li>
</ul>


    </div>
</div>
<div class="lc-minicart lc-minicart-horizontal collapsed empty" title="Your cart">

      <span class="fas fa-shopping-cart"></span>
<div class="internal-popup items-list empty-cart">

  <h4 class="title">
    <a href="cart.php?target=cart">0 items in cart</a>
  </h4>

  
  
  <p class="subtotal">
    <strong>Subtotal:</strong>
    <span>$0.00</span>
  </p>

  <div class="buttons-row">
    
<a class="regular-button cart" href="http://design.x-cart.com/demo/templates/multistore/cart.php?target=cart">
<span>View cart</span>
</a>
  
<a class="regular-main-button checkout disabled" href="http://design.x-cart.com/demo/templates/multistore/cart.php?target=checkout">
<span>Checkout</span>
</a>
  <div class="reason-details">
    
  </div>

  </div>

</div>


</div>



  </div>
<div id="header-bar">
  <div class="wishlist"><a class="wishlist-link log-in" href="cart.php?target=wishlist" data-return-url="cart.php?target=wishlist" title="Wishlist">
    <i class="fa fa-heart-o"></i>
        <span class="wishlist-product-count"  style="display: none" >
    </span>
</a>
</div>

  <div class="dropdown header_bar-my_account">
    <a data-toggle="dropdown" data-target="#">My account</a>
    <ul class="account-links dropdown-menu">
            <li class="sign-in"><button type="button" class="btn  regular-button  popup-button popup-login" data-without-close="1">
<script type="text/x-cart-data">
{"url_params":{"target":"login","widget":"\\XLite\\View\\Authorization","fromURL":"cart.php"}}
</script>

<span>Sign in</span>
</button>
</li>
      <li class="sign-up"><a href="#" class="popup-button create-account-link" type="button" class="popup-button create-account-link" data-without-close="">
  <script type="text/x-cart-data">
{"url_params":{"target":"profile","widget":"XLite\\View\\AccountDialog","mode":"register"}}
</script>

    Sign up
</a>
</li>
    </ul>
  </div>
  

</div>
<div class="header-break"></div>
    </div>
</div>

  </div>
  </div>

  
<div class="mobile_header">
  <ul class="nav nav-pills">
    
<li class="dropdown mobile_header-logo">
  <div id="logo_1" class="company-logo">
  <a href="cart.php" title="Home" rel="home"><img src="<?= base_url(); ?>skins/Multistore/images/logo.png" alt="Home" /></a>
</div>
</li>
<li class="dropdown mobile_header-right_menu">
    <div class="header-right-bar">
      
<div class="header_search" title="Search">
  <a data-target=".header_search-panel" data-toggle="collapse" class="collapsed"></a>
  <div class="header_search-panel collapse">
    
<div class="simple-search-product-form">

   
<form action="?" method="post" accept-charset="utf-8" onsubmit="javascript: return true;" class="form5b0dbe080730d0.67653857">
<div class="form-params" style="display: none;">
      <input type="hidden" name="target" value="search" />
      <input type="hidden" name="action" value="search" />
      <input type="hidden" name="itemsList" value="\XLite\View\ItemsList\Product\Customer\Search" />
      <input type="hidden" name="mode" value="search" />
      <input type="hidden" name="searchInSubcats" value="Y" />
      <input type="hidden" name="including" value="all" />
      <input type="hidden" name="returnURL" value="/demo/templates/multistore/" />
  </div>
    
<div class="simple-search-box">
  


<div class="table-value substring-value">
  <span class="input-field-wrapper input input-text-searchbox">
  <script type="text/x-cart-data">
{"defaultValue":"","selectOnFocus":false}
</script>

  <input name="substring" placeholder="What do you want to find?" type="text" value="" autocomplete="off" maxlength="255" class="validate[maxSize[255]]  form-text" />
</span>
        </div>




<button type="submit" class="btn  regular-button submit-button submit">
  
    <span>Search</span>
</button>


</div>

  </form>

</div>

  </div>
</div>

<div class="lc-minicart-placeholder"></div>

    </div>
</li>
<li class="dropdown mobile_header-slidebar">
  <a id="main_menu" href="#slidebar" class="icon-menu"></a>
</li>
  </ul>
</div>

</div>

<div id="banner-rotation-widget" class="carousel slide banner-carousel lazy-load">
  <script type="text/x-cart-data">
{"pause":false,"interval":5000}
</script>


  <!-- Indicators -->
      <ol class="carousel-indicators">
              <li data-target="#banner-rotation-widget" data-slide-to="0"></li>
              <li data-target="#banner-rotation-widget" data-slide-to="1"></li>
          </ol>
  
  <div class="carousel-inner" role="listbox">
          <a  href="cart.php?target=category&amp;category_id=5" class="item">
        <img src="<?= base_url(); ?>images/banner_toys_2x.jpg" alt="Toys" >
      </a>
          <a  href="cart.php?target=category&amp;category_id=4" class="item">
        <img src="<?= base_url(); ?>images/banner_apparel_2x.jpg" alt="Apparel" >
      </a>
      </div>
</div>
<div id="breadcrumb">
  
</div>



<div id="main-wrapper">
      <div id="main" class="clearfix">
    <div class="flex-container">
        

<div id="content" class="column">
    <div class="section">
    <a id="main-content"></a>
    
<div class="list-container" data-group="center">
  










<div class="bannerBox home-sidebanner">
                        <div class="banner_container SecondaryColumn" style="  ">
                
<div
id="slideshowSecondaryColumn1"
>
    
        <div class="banner_item">
                                                
                                            <img src="//design.x-cart.com/demo/templates/multistore/images/banner/Corsair-Gaming.jpg" alt=""  id="banner_image_9" height="840" width="410" data-max-width="0" data-max-height="0" data-is-default-image="" />

                                                        
                    </div>

    </div>

            </div>
                                <div class="banner_container SecondaryColumn" style="  ">
                
<div
id="slideshowSecondaryColumn2"
>
    
        <div class="banner_item">
                                                
                                            <img src="//design.x-cart.com/demo/templates/multistore/images/banner/Banner%20-%20glasses.jpg" alt=""  id="banner_image_10" height="924" width="414" data-max-width="0" data-max-height="0" data-is-default-image="" />

                                                        
                    </div>

    </div>

            </div>
                                <div class="banner_container SecondaryColumn" style="  ">
                
<div
id="slideshowSecondaryColumn3"
>
    
        <div class="banner_item">
                                                
                                            <img src="//design.x-cart.com/demo/templates/multistore/images/banner/iphone-bnr.png" alt=""  id="banner_image_11" height="880" width="410" data-max-width="0" data-max-height="0" data-is-default-image="" />

                                                        
                    </div>

    </div>

            </div>
            </div>


<a href="#0" class="back-to-top" title="Back to top">
  <i class="custom-icon" aria-hidden="true"></i>
</a>



<div class="block block-block block-subcategories">
    <div class="content">
</div>
</div>




<div class="bannerBox banners-group">
                        <div class="banner_container CenterTopGroup" style="  ">
                
<div
id="slideshowCenterTopGroup4"
>
    
        <div class="banner_item">
                                                
                                            <img src="//design.x-cart.com/demo/templates/multistore/images/banner/Banner-Music.png" alt=""  id="banner_image_12" height="360" width="1116" data-max-width="0" data-max-height="0" data-is-default-image="" />

                                                        
                    </div>

    </div>

            </div>
                                <div class="banner_container CenterTopGroup" style="  ">
                
<div
id="slideshowCenterTopGroup5"
>
    
        <div class="banner_item">
                                                
                                            <img src="//design.x-cart.com/demo/templates/multistore/images/banner/BannerToys.png" alt=""  id="banner_image_13" height="360" width="1116" data-max-width="0" data-max-height="0" data-is-default-image="" />

                                                        
                    </div>

    </div>

            </div>
            </div>

<div class="block block-block block-featured-products">
      <h3>Featured products</h3>
    <div class="content">
<div class="items-list items-list-products category-products" data-widget-arguments="{&quot;sortBy&quot;:&quot;featuredProducts.orderBy&quot;,&quot;sortOrder&quot;:&quot;asc&quot;,&quot;displayMode&quot;:&quot;grid&quot;}">
  <script type="text/x-cart-data">
{"widget_class":"XLite\\Module\\CDev\\FeaturedProducts\\View\\Customer\\FeaturedProducts","widget_target":"category","widget_params":{"category_id":1},"listenToHash":true,"listenToHashPrefix":"product.category","replaceState":false,"replaceStatePrefix":""}
</script>

<!--       
<div class="cart-tray cart-tray-box">
  <div class="tray-area">
    <div class="centered-tray-box">
      <div class="drop-here tray-status">Drop items here to shop</div>
      <div class="dropped-here tray-status">Product has been added to your cart</div>

      <div class="product-added tray-status">
        
<a class="regular-button" href="http://design.x-cart.com/demo/templates/multistore/cart.php?target=checkout">
<span>Checkout</span>
</a>
      </div>

      <div class="progress-bar">
        <div class="wait-progress">
          <div></div>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="preload-cart-tray"></div>


<div class="products">

      <ul class="products-grid grid-list">
              <li class="product-cell box-product">
    
          


<div class="product productid-16 draggable ">
      <a
            href="javascript:void(0);"
            title="Add to wishlist"
            data-productid="16"
            class="add-to-wishlist next-previous-assigned  log-in  fa fa-heart-o">
    </a>

<div class="product-photo lazy-load">
  <a
  href="cart.php?target=product&amp;product_id=16"
  class="product-thumbnail lazy-load">
  <img src="//design.x-cart.com/demo/templates/multistore/images/product/hukv_age_ultron_fabrikations_plush.jpeg" alt="Avengers: Fabrikations Plush [Related Products]"  class="photo" height="172" width="262" data-max-width="262" data-max-height="280" data-is-default-image="" />

</a>

  <div class="grid-buttons-wrapper">
      <div class="quicklook">
    
<button type="button" class="btn  regular-button quicklook-link quicklook-link-16 quicklook-link-category-1" onclick="javascript: return false;">
  
    <span></span>
</button>

  </div>

  <div class="add-to-cart-button">
    
    
<button type="button" class="btn  regular-button add-to-cart product-add2cart productid-16">
  
    <span></span>
</button>


  </div>

  </div>

</div>


<h5 class="product-name"><a class="fn url" href="cart.php?target=product&amp;product_id=16">Avengers: Fabrikations Plush [Related Products]</a></h5>

 
<form action="?" method="post" accept-charset="utf-8" onsubmit="javascript: return true;" class="form5b0dbe08402224.95275068">
<div class="form-params" style="display: none;">
      <input type="hidden" name="target" value="product" />
      <input type="hidden" name="action" value="rate" />
      <input type="hidden" name="return_target" value="main" />
      <input type="hidden" name="product_id" value="16" />
      <input type="hidden" name="target_widget" value="\\XLite\\Module\\XC\\Reviews\\View\\Customer\\ProductInfo\\ItemsList\\AverageRating" />
      <input type="hidden" name="returnURL" value="/demo/templates/multistore/" />
  </div>

    <div class="product-average-rating">
    <input type="hidden" name="target_widget" value="\XLite\Module\XC\Reviews\View\Customer\ProductInfo\Details\AverageRating" />
    <input type="hidden" name="widgetMode" value="grid" />
    
    <div class="rating">
                            
<div class="vote-bar">

  <div class="rating-stars">
    <div class="stars-row">
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
          </div>

    <div class="stars-row full" style="width: 81%;">
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
          </div>

      </div>

  </div>

                            <span class="votes-count">
              &nbsp;
              <span>
                22
              </span>
            </span>
        
                    <div class="rating-tooltip">
                <div class="text">
      <div>Score: 4.05 (votes: 22)</div>
    </div>

            </div>
        
    </div>


                  <span class="separator">|</span>
      <a href="cart.php?target=product&amp;product_id=16&amp;category_id=6#product-details-tab-reviews" class="link-to-tab">
            <p class=" add-review ">
<script type="text/x-cart-data">
{"url_params":{"target":"review","product_id":16,"return_target":"main","widget":"\\XLite\\Module\\XC\\Reviews\\View\\Customer\\ModifyReview"}}
</script>

<span class="link">Be the first and leave feedback</span>
</p>

      </a>
      </div>


</form>


  
    
<div class="product-price widget-fingerprint-product-price">
  <ul class="product-price">
    
<li class="product-price-base"><span class="price product-price">$14.99</span></li>

  </ul>
</div>

<div class="sale-price-value">$19.99</div>
<div class="product-marks">
  <div title="Added to cart" class="added-to-cart"><i class="icon-ok-mark"></i></div>

</div>

<ul class="labels">
      <li class="label-green sale-price">
      
<div class="label-main-box ">
  <div class="content">25% off</div>
</div>

    </li>
  </ul>


</div>



    
        </li>
              <li class="product-cell box-product">
    
          


<div class="product productid-15 draggable ">
      <a
            href="javascript:void(0);"
            title="Add to wishlist"
            data-productid="15"
            class="add-to-wishlist next-previous-assigned  log-in  fa fa-heart-o">
    </a>

<div class="product-photo lazy-load">
  <a
  href="cart.php?target=product&amp;product_id=15"
  class="product-thumbnail lazy-load">
  <img src="//design.x-cart.com/demo/templates/multistore/images/product/ea67_soft_kitty_singing_plush.jpeg" alt="Soft Kitty Singing Plush [Sale] [Reviews]"  class="photo" height="205" width="262" data-max-width="262" data-max-height="280" data-is-default-image="" />

</a>

  <div class="grid-buttons-wrapper">
      <div class="quicklook">
    
<button type="button" class="btn  regular-button quicklook-link quicklook-link-15 quicklook-link-category-1" onclick="javascript: return false;">
  
    <span></span>
</button>

  </div>

  <div class="add-to-cart-button">
    
    
<button type="button" class="btn  regular-button add-to-cart product-add2cart productid-15">
  
    <span></span>
</button>


  </div>

  </div>

</div>

  <span class="product-items-available low-stock">Only 4 left in stock</span>

<h5 class="product-name"><a class="fn url" href="cart.php?target=product&amp;product_id=15">Soft Kitty Singing Plush [Sale] [Reviews]</a></h5>

 
<form action="?" method="post" accept-charset="utf-8" onsubmit="javascript: return true;" class="form5b0dbe08475853.12967926">
<div class="form-params" style="display: none;">
      <input type="hidden" name="target" value="product" />
      <input type="hidden" name="action" value="rate" />
      <input type="hidden" name="return_target" value="main" />
      <input type="hidden" name="product_id" value="15" />
      <input type="hidden" name="target_widget" value="\\XLite\\Module\\XC\\Reviews\\View\\Customer\\ProductInfo\\ItemsList\\AverageRating" />
      <input type="hidden" name="returnURL" value="/demo/templates/multistore/" />
  </div>

    <div class="product-average-rating">
    <input type="hidden" name="target_widget" value="\XLite\Module\XC\Reviews\View\Customer\ProductInfo\Details\AverageRating" />
    <input type="hidden" name="widgetMode" value="grid" />
    
    <div class="rating">
                            
<div class="vote-bar">

  <div class="rating-stars">
    <div class="stars-row">
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
          </div>

    <div class="stars-row full" style="width: 97%;">
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
          </div>

      </div>

  </div>

                            <span class="votes-count">
              &nbsp;
              <span>
                21
              </span>
            </span>
        
                    <div class="rating-tooltip">
                <div class="text">
      <div>Score: 4.86 (votes: 21)</div>
    </div>

            </div>
        
    </div>


          <div class="reviews-count no-reviews">
        &mdash;
        <a href="cart.php?target=product&amp;product_id=15&amp;category_id=6#product-details-tab-reviews" class="link-to-tab">
          4
        </a>
      </div>
                  <span class="separator">|</span>
      <a href="cart.php?target=product&amp;product_id=15&amp;category_id=6#product-details-tab-reviews" class="link-to-tab">
            <p class=" add-review ">
<script type="text/x-cart-data">
{"url_params":{"target":"review","product_id":15,"return_target":"main","widget":"\\XLite\\Module\\XC\\Reviews\\View\\Customer\\ModifyReview"}}
</script>

<span class="link">Be the first and leave feedback</span>
</p>

      </a>
      </div>


</form>


  
    
<div class="product-price widget-fingerprint-product-price">
  <ul class="product-price">
    
<li class="product-price-base"><span class="price product-price">$25.49</span></li>

  </ul>
</div>

<div class="sale-price-value">$29.99</div>
<div class="product-marks">
  <div title="Added to cart" class="added-to-cart"><i class="icon-ok-mark"></i></div>

</div>

<ul class="labels">
      <li class="label-green sale-price">
      
<div class="label-main-box ">
  <div class="content">15% off</div>
</div>

    </li>
  </ul>


</div>



    
        </li>
              <li class="product-cell box-product">
    
          


<div class="product productid-4 draggable ">
      <a
            href="javascript:void(0);"
            title="Add to wishlist"
            data-productid="4"
            class="add-to-wishlist next-previous-assigned  log-in  fa fa-heart-o">
    </a>

<div class="product-photo lazy-load">
  <a
  href="cart.php?target=product&amp;product_id=4"
  class="product-thumbnail lazy-load">
  <img src="//design.x-cart.com/demo/templates/multistore/images/product/efba_star_wars_tissue_weight_babydoll.jpeg" alt="Star Wars Tissue-Weight Fitted Ladies&#039; Tee"  class="photo" height="280" width="224" data-max-width="262" data-max-height="280" data-is-default-image="" />

</a>

  <div class="grid-buttons-wrapper">
      <div class="quicklook">
    
<button type="button" class="btn  regular-button quicklook-link quicklook-link-4 quicklook-link-category-1" onclick="javascript: return false;">
  
    <span></span>
</button>

  </div>

  <div class="add-to-cart-button">
    
    
<button type="button" class="btn  regular-button add-to-cart product-add2cart productid-4">
  
    <span></span>
</button>


  </div>

  </div>

</div>

  <span class="product-items-available low-stock">Only 7 left in stock</span>

<h5 class="product-name"><a class="fn url" href="cart.php?target=product&amp;product_id=4">Star Wars Tissue-Weight Fitted Ladies&#039; Tee</a></h5>

 
<form action="?" method="post" accept-charset="utf-8" onsubmit="javascript: return true;" class="form5b0dbe084b0fa1.73477634">
<div class="form-params" style="display: none;">
      <input type="hidden" name="target" value="product" />
      <input type="hidden" name="action" value="rate" />
      <input type="hidden" name="return_target" value="main" />
      <input type="hidden" name="product_id" value="4" />
      <input type="hidden" name="target_widget" value="\\XLite\\Module\\XC\\Reviews\\View\\Customer\\ProductInfo\\ItemsList\\AverageRating" />
      <input type="hidden" name="returnURL" value="/demo/templates/multistore/" />
  </div>

    <div class="product-average-rating">
    <input type="hidden" name="target_widget" value="\XLite\Module\XC\Reviews\View\Customer\ProductInfo\Details\AverageRating" />
    <input type="hidden" name="widgetMode" value="grid" />
    
    <div class="rating">
                            
<div class="vote-bar">

  <div class="rating-stars">
    <div class="stars-row">
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
          </div>

    <div class="stars-row full" style="width: 38%;">
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
          </div>

      </div>

  </div>

                            <span class="votes-count">
              &nbsp;
              <span>
                17
              </span>
            </span>
        
                    <div class="rating-tooltip">
                <div class="text">
      <div>Score: 1.94 (votes: 17)</div>
    </div>

            </div>
        
    </div>


                  <span class="separator">|</span>
      <a href="cart.php?target=product&amp;product_id=4&amp;category_id=4#product-details-tab-reviews" class="link-to-tab">
            <p class=" add-review ">
<script type="text/x-cart-data">
{"url_params":{"target":"review","product_id":4,"return_target":"main","widget":"\\XLite\\Module\\XC\\Reviews\\View\\Customer\\ModifyReview"}}
</script>

<span class="link">Be the first and leave feedback</span>
</p>

      </a>
      </div>


</form>


  
    
<div class="product-price widget-fingerprint-product-price">
  <ul class="product-price">
    
<li class="product-price-base"><span class="price product-price">$24.99</span></li>

  </ul>
</div>

<div class="product-marks">
  <div title="Added to cart" class="added-to-cart"><i class="icon-ok-mark"></i></div>

</div>


</div>



    
        </li>
              <li class="product-cell box-product">
    
          


<div class="product productid-13 draggable ">
      <a
            href="javascript:void(0);"
            title="Add to wishlist"
            data-productid="13"
            class="add-to-wishlist next-previous-assigned  log-in  fa fa-heart-o">
    </a>

<div class="product-photo lazy-load">
  <a
  href="cart.php?target=product&amp;product_id=13"
  class="product-thumbnail lazy-load">
  <img src="//design.x-cart.com/demo/templates/multistore/images/product/ijro_ghostbusters_vinyl_idols.jpeg" alt="Vinyl Idolz: Ghostbusters"  class="photo" height="262" width="262" data-max-width="262" data-max-height="280" data-is-default-image="" />

</a>

  <div class="grid-buttons-wrapper">
      <div class="quicklook">
    
<button type="button" class="btn  regular-button quicklook-link quicklook-link-13 quicklook-link-category-1" onclick="javascript: return false;">
  
    <span></span>
</button>

  </div>

  <div class="add-to-cart-button">
    
    
<button type="button" class="btn  regular-button add-to-cart product-add2cart productid-13">
  
    <span></span>
</button>


  </div>

  </div>

</div>


<h5 class="product-name"><a class="fn url" href="cart.php?target=product&amp;product_id=13">Vinyl Idolz: Ghostbusters</a></h5>

 
<form action="?" method="post" accept-charset="utf-8" onsubmit="javascript: return true;" class="form5b0dbe084f1668.56874370">
<div class="form-params" style="display: none;">
      <input type="hidden" name="target" value="product" />
      <input type="hidden" name="action" value="rate" />
      <input type="hidden" name="return_target" value="main" />
      <input type="hidden" name="product_id" value="13" />
      <input type="hidden" name="target_widget" value="\\XLite\\Module\\XC\\Reviews\\View\\Customer\\ProductInfo\\ItemsList\\AverageRating" />
      <input type="hidden" name="returnURL" value="/demo/templates/multistore/" />
  </div>

    <div class="product-average-rating">
    <input type="hidden" name="target_widget" value="\XLite\Module\XC\Reviews\View\Customer\ProductInfo\Details\AverageRating" />
    <input type="hidden" name="widgetMode" value="grid" />
    
    <div class="rating">
                            
<div class="vote-bar">

  <div class="rating-stars">
    <div class="stars-row">
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
          </div>

    <div class="stars-row full" style="width: 76%;">
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
          </div>

      </div>

  </div>

                            <span class="votes-count">
              &nbsp;
              <span>
                15
              </span>
            </span>
        
                    <div class="rating-tooltip">
                <div class="text">
      <div>Score: 3.80 (votes: 15)</div>
    </div>

            </div>
        
    </div>


                  <span class="separator">|</span>
      <a href="cart.php?target=product&amp;product_id=13&amp;category_id=6#product-details-tab-reviews" class="link-to-tab">
            <p class=" add-review ">
<script type="text/x-cart-data">
{"url_params":{"target":"review","product_id":13,"return_target":"main","widget":"\\XLite\\Module\\XC\\Reviews\\View\\Customer\\ModifyReview"}}
</script>

<span class="link">Be the first and leave feedback</span>
</p>

      </a>
      </div>


</form>


  
    
<div class="product-price widget-fingerprint-product-price">
  <ul class="product-price">
    
<li class="product-price-base"><span class="price product-price">$19.99</span></li>

  </ul>
</div>

<div class="product-marks">
  <div title="Added to cart" class="added-to-cart"><i class="icon-ok-mark"></i></div>

</div>


</div>



    
        </li>
              <li class="product-cell box-product">
    
          


<div class="product productid-37 draggable ">
      <a
            href="javascript:void(0);"
            title="Add to wishlist"
            data-productid="37"
            class="add-to-wishlist next-previous-assigned  log-in  fa fa-heart-o">
    </a>

<div class="product-photo lazy-load">
  <a
  href="cart.php?target=product&amp;product_id=37"
  class="product-thumbnail lazy-load">
  <img src="//design.x-cart.com/demo/templates/multistore/images/product/iphone6.png" alt="Apple iPhone 6S [Options &amp; Attributes] [Custom tabs]"  class="photo" height="280" width="219" data-max-width="262" data-max-height="280" data-is-default-image="" />

</a>

  <div class="grid-buttons-wrapper">
      <div class="quicklook">
    
<button type="button" class="btn  regular-button quicklook-link quicklook-link-37 quicklook-link-category-1" onclick="javascript: return false;">
  
    <span></span>
</button>

  </div>

  <div class="add-to-cart-button">
    
    
<button type="button" class="btn  regular-button add-to-cart product-add2cart productid-37">
  
    <span></span>
</button>


  </div>

  </div>

</div>


<h5 class="product-name"><a class="fn url" href="cart.php?target=product&amp;product_id=37">Apple iPhone 6S [Options &amp; Attributes] [Custom tabs]</a></h5>

 
<form action="?" method="post" accept-charset="utf-8" onsubmit="javascript: return true;" class="form5b0dbe08530f46.98410285">
<div class="form-params" style="display: none;">
      <input type="hidden" name="target" value="product" />
      <input type="hidden" name="action" value="rate" />
      <input type="hidden" name="return_target" value="main" />
      <input type="hidden" name="product_id" value="37" />
      <input type="hidden" name="target_widget" value="\\XLite\\Module\\XC\\Reviews\\View\\Customer\\ProductInfo\\ItemsList\\AverageRating" />
      <input type="hidden" name="returnURL" value="/demo/templates/multistore/" />
  </div>

    <div class="product-average-rating">
    <input type="hidden" name="target_widget" value="\XLite\Module\XC\Reviews\View\Customer\ProductInfo\Details\AverageRating" />
    <input type="hidden" name="widgetMode" value="grid" />
    
    <div class="rating">
                            
<div class="vote-bar">

  <div class="rating-stars">
    <div class="stars-row">
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
          </div>

    <div class="stars-row full" style="width: 97%;">
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
          </div>

      </div>

  </div>

                            <span class="votes-count">
              &nbsp;
              <span>
                17
              </span>
            </span>
        
                    <div class="rating-tooltip">
                <div class="text">
      <div>Score: 4.88 (votes: 17)</div>
    </div>

            </div>
        
    </div>


                  <span class="separator">|</span>
      <a href="cart.php?target=product&amp;product_id=37&amp;category_id=2#product-details-tab-reviews" class="link-to-tab">
            <p class=" add-review ">
<script type="text/x-cart-data">
{"url_params":{"target":"review","product_id":37,"return_target":"main","widget":"\\XLite\\Module\\XC\\Reviews\\View\\Customer\\ModifyReview"}}
</script>

<span class="link">Be the first and leave feedback</span>
</p>

      </a>
      </div>


</form>


  
    
<div class="product-price widget-fingerprint-product-price">
  <ul class="product-price">
    
<li class="product-price-base"><span class="price product-price">$650.00</span></li>

  </ul>
</div>

<div class="product-marks">
  <div title="Added to cart" class="added-to-cart"><i class="icon-ok-mark"></i></div>

</div>


</div>



    
        </li>
              <li class="product-cell box-product">
    
          


<div class="product productid-41 draggable ">
      <a
            href="javascript:void(0);"
            title="Add to wishlist"
            data-productid="41"
            class="add-to-wishlist next-previous-assigned  log-in  fa fa-heart-o">
    </a>

<div class="product-photo lazy-load">
  <a
  href="cart.php?target=product&amp;product_id=41"
  class="product-thumbnail lazy-load">
  <img src="//design.x-cart.com/demo/templates/multistore/images/product/iphone6plus.png" alt="Apple iPhone 6S Plus [Options &amp; Attributes]"  class="photo" height="280" width="219" data-max-width="262" data-max-height="280" data-is-default-image="" />

</a>

  <div class="grid-buttons-wrapper">
      <div class="quicklook">
    
<button type="button" class="btn  regular-button quicklook-link quicklook-link-41 quicklook-link-category-1" onclick="javascript: return false;">
  
    <span></span>
</button>

  </div>

  <div class="add-to-cart-button">
    
    
<button type="button" class="btn  regular-button add-to-cart product-add2cart productid-41">
  
    <span></span>
</button>


  </div>

  </div>

</div>

  <span class="product-items-available low-stock">Only 5 left in stock</span>

<h5 class="product-name"><a class="fn url" href="cart.php?target=product&amp;product_id=41">Apple iPhone 6S Plus [Options &amp; Attributes]</a></h5>

 
<form action="?" method="post" accept-charset="utf-8" onsubmit="javascript: return true;" class="form5b0dbe0857c7d1.23337375">
<div class="form-params" style="display: none;">
      <input type="hidden" name="target" value="product" />
      <input type="hidden" name="action" value="rate" />
      <input type="hidden" name="return_target" value="main" />
      <input type="hidden" name="product_id" value="41" />
      <input type="hidden" name="target_widget" value="\\XLite\\Module\\XC\\Reviews\\View\\Customer\\ProductInfo\\ItemsList\\AverageRating" />
      <input type="hidden" name="returnURL" value="/demo/templates/multistore/" />
  </div>

    <div class="product-average-rating">
    <input type="hidden" name="target_widget" value="\XLite\Module\XC\Reviews\View\Customer\ProductInfo\Details\AverageRating" />
    <input type="hidden" name="widgetMode" value="grid" />
    
    <div class="rating">
                            
<div class="vote-bar">

  <div class="rating-stars">
    <div class="stars-row">
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
          </div>

    <div class="stars-row full" style="width: 97%;">
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
          </div>

      </div>

  </div>

                            <span class="votes-count">
              &nbsp;
              <span>
                21
              </span>
            </span>
        
                    <div class="rating-tooltip">
                <div class="text">
      <div>Score: 4.86 (votes: 21)</div>
    </div>

            </div>
        
    </div>


                  <span class="separator">|</span>
      <a href="cart.php?target=product&amp;product_id=41&amp;category_id=2#product-details-tab-reviews" class="link-to-tab">
            <p class=" add-review ">
<script type="text/x-cart-data">
{"url_params":{"target":"review","product_id":41,"return_target":"main","widget":"\\XLite\\Module\\XC\\Reviews\\View\\Customer\\ModifyReview"}}
</script>

<span class="link">Be the first and leave feedback</span>
</p>

      </a>
      </div>


</form>


  
    
<div class="product-price widget-fingerprint-product-price">
  <ul class="product-price">
    
<li class="product-price-base"><span class="price product-price">$850.00</span></li>

  </ul>
</div>

<div class="product-marks">
  <div title="Added to cart" class="added-to-cart"><i class="icon-ok-mark"></i></div>

</div>


</div>



    
        </li>
              <li class="product-cell box-product">
    
          


<div class="product productid-42 draggable ">
      <a
            href="javascript:void(0);"
            title="Add to wishlist"
            data-productid="42"
            class="add-to-wishlist next-previous-assigned  log-in  fa fa-heart-o">
    </a>

<div class="product-photo lazy-load">
  <a
  href="cart.php?target=product&amp;product_id=42"
  class="product-thumbnail lazy-load">
  <img src="//design.x-cart.com/demo/templates/multistore/images/product/iphonese-select-2016.png" alt="iPhone 5S"  class="photo" height="280" width="246" data-max-width="262" data-max-height="280" data-is-default-image="" />

</a>

  <div class="grid-buttons-wrapper">
      <div class="quicklook">
    
<button type="button" class="btn  regular-button quicklook-link quicklook-link-42 quicklook-link-category-1" onclick="javascript: return false;">
  
    <span></span>
</button>

  </div>

  <div class="add-to-cart-button">
    
    
<button type="button" class="btn  regular-button add-to-cart product-add2cart productid-42">
  
    <span></span>
</button>


  </div>

  </div>

</div>

  <span class="product-items-available low-stock">Only 4 left in stock</span>

<h5 class="product-name"><a class="fn url" href="cart.php?target=product&amp;product_id=42">Apple iPhone SE [Options &amp; Attributes] [Tabs]</a></h5>

 
<form action="?" method="post" accept-charset="utf-8" onsubmit="javascript: return true;" class="form5b0dbe085ca7a7.32666667">
<div class="form-params" style="display: none;">
      <input type="hidden" name="target" value="product" />
      <input type="hidden" name="action" value="rate" />
      <input type="hidden" name="return_target" value="main" />
      <input type="hidden" name="product_id" value="42" />
      <input type="hidden" name="target_widget" value="\\XLite\\Module\\XC\\Reviews\\View\\Customer\\ProductInfo\\ItemsList\\AverageRating" />
      <input type="hidden" name="returnURL" value="/demo/templates/multistore/" />
  </div>

    <div class="product-average-rating">
    <input type="hidden" name="target_widget" value="\XLite\Module\XC\Reviews\View\Customer\ProductInfo\Details\AverageRating" />
    <input type="hidden" name="widgetMode" value="grid" />
    
    <div class="rating">
                            
<div class="vote-bar">

  <div class="rating-stars">
    <div class="stars-row">
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
          </div>

    <div class="stars-row full" style="width: 98%;">
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
          </div>

      </div>

  </div>

                            <span class="votes-count">
              &nbsp;
              <span>
                15
              </span>
            </span>
        
                    <div class="rating-tooltip">
                <div class="text">
      <div>Score: 4.93 (votes: 15)</div>
    </div>

            </div>
        
    </div>


                  <span class="separator">|</span>
      <a href="cart.php?target=product&amp;product_id=42&amp;category_id=2#product-details-tab-reviews" class="link-to-tab">
            <p class=" add-review ">
<script type="text/x-cart-data">
{"url_params":{"target":"review","product_id":42,"return_target":"main","widget":"\\XLite\\Module\\XC\\Reviews\\View\\Customer\\ModifyReview"}}
</script>

<span class="link">Be the first and leave feedback</span>
</p>

      </a>
      </div>


</form>


  
    
<div class="product-price widget-fingerprint-product-price">
  <ul class="product-price">
    
<li class="product-price-base"><span class="price product-price">$299.00</span></li>

  </ul>
</div>

<div class="product-marks">
  <div title="Added to cart" class="added-to-cart"><i class="icon-ok-mark"></i></div>

</div>


</div>



    
        </li>
              <li class="product-cell box-product">
    
          


<div class="product productid-30 draggable ">
      <a
            href="javascript:void(0);"
            title="Add to wishlist"
            data-productid="30"
            class="add-to-wishlist next-previous-assigned  log-in  fa fa-heart-o">
    </a>

<div class="product-photo lazy-load">
  <a
  href="cart.php?target=product&amp;product_id=30"
  class="product-thumbnail lazy-load">
  <img src="//design.x-cart.com/demo/templates/multistore/images/product/htjo_astro_a50_halo_headset.jpeg" alt="Astro A50 Halo Edition"  class="photo" height="262" width="262" data-max-width="262" data-max-height="280" data-is-default-image="" />

</a>

  <div class="grid-buttons-wrapper">
      <div class="quicklook">
    
<button type="button" class="btn  regular-button quicklook-link quicklook-link-30 quicklook-link-category-1" onclick="javascript: return false;">
  
    <span></span>
</button>

  </div>

  <div class="add-to-cart-button">
    
    
<button type="button" class="btn  regular-button add-to-cart product-add2cart productid-30">
  
    <span></span>
</button>


  </div>

  </div>

</div>


<h5 class="product-name"><a class="fn url" href="cart.php?target=product&amp;product_id=30">Astro A50 Halo Edition</a></h5>

 
<form action="?" method="post" accept-charset="utf-8" onsubmit="javascript: return true;" class="form5b0dbe08620be4.65195629">
<div class="form-params" style="display: none;">
      <input type="hidden" name="target" value="product" />
      <input type="hidden" name="action" value="rate" />
      <input type="hidden" name="return_target" value="main" />
      <input type="hidden" name="product_id" value="30" />
      <input type="hidden" name="target_widget" value="\\XLite\\Module\\XC\\Reviews\\View\\Customer\\ProductInfo\\ItemsList\\AverageRating" />
      <input type="hidden" name="returnURL" value="/demo/templates/multistore/" />
  </div>

    <div class="product-average-rating">
    <input type="hidden" name="target_widget" value="\XLite\Module\XC\Reviews\View\Customer\ProductInfo\Details\AverageRating" />
    <input type="hidden" name="widgetMode" value="grid" />
    
    <div class="rating">
                            
<div class="vote-bar">

  <div class="rating-stars">
    <div class="stars-row">
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
          </div>

    <div class="stars-row full" style="width: 99%;">
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
          </div>

      </div>

  </div>

                            <span class="votes-count">
              &nbsp;
              <span>
                20
              </span>
            </span>
        
                    <div class="rating-tooltip">
                <div class="text">
      <div>Score: 4.95 (votes: 20)</div>
    </div>

            </div>
        
    </div>


                  <span class="separator">|</span>
      <a href="cart.php?target=product&amp;product_id=30&amp;category_id=3#product-details-tab-reviews" class="link-to-tab">
            <p class=" add-review ">
<script type="text/x-cart-data">
{"url_params":{"target":"review","product_id":30,"return_target":"main","widget":"\\XLite\\Module\\XC\\Reviews\\View\\Customer\\ModifyReview"}}
</script>

<span class="link">Be the first and leave feedback</span>
</p>

      </a>
      </div>


</form>


  
    
<div class="product-price widget-fingerprint-product-price">
  <ul class="product-price">
    
<li class="product-price-base"><span class="price product-price">$299.99</span></li>

  </ul>
</div>

<div class="product-marks">
  <div title="Added to cart" class="added-to-cart"><i class="icon-ok-mark"></i></div>

</div>


</div>



    
        </li>
                </ul>
  
</div>

    
  </div>
</div>
</div>




<div class="bannerBox banners-center">
                        <div class="banner_container StandardCenter" style="  ">
                
<div
id="slideshowStandardCenter6"
>
    
        <div class="banner_item">
                                                
                                            <img src="//design.x-cart.com/demo/templates/multistore/images/banner/Banner-book.png" alt=""  id="banner_image_14" height="280" width="2290" data-max-width="0" data-max-height="0" data-is-default-image="" />

                                                        
                    </div>

    </div>

            </div>
            </div>

<div class="block block-block block-bestsellers">
      <h3>Bestsellers</h3>
    <div class="content">
<div class="items-list items-list-products" data-widget-arguments="{&quot;sortBy&quot;:&quot;translations.name&quot;,&quot;sortOrder&quot;:&quot;asc&quot;,&quot;displayMode&quot;:&quot;grid&quot;}">
  <script type="text/x-cart-data">
{"widget_class":"XLite\\Module\\CDev\\Bestsellers\\View\\Bestsellers","widget_target":"","widget_params":[],"listenToHash":false,"listenToHashPrefix":"","replaceState":false,"replaceStatePrefix":""}
</script>

      


<div class="products">

      <ul class="products-grid grid-list">
              <li class="product-cell box-product">
    
          


<div class="product productid-15 draggable ">
      <a
            href="javascript:void(0);"
            title="Add to wishlist"
            data-productid="15"
            class="add-to-wishlist next-previous-assigned  log-in  fa fa-heart-o">
    </a>

<div class="product-photo lazy-load">
  <a
  href="cart.php?target=product&amp;product_id=15"
  class="product-thumbnail lazy-load">
  <img src="//design.x-cart.com/demo/templates/multistore/images/product/ea67_soft_kitty_singing_plush.jpeg" alt="Soft Kitty Singing Plush [Sale] [Reviews]"  class="photo" height="205" width="262" data-max-width="262" data-max-height="280" data-is-default-image="" />

</a>

  <div class="grid-buttons-wrapper">
      <div class="quicklook">
    
<button type="button" class="btn  regular-button quicklook-link quicklook-link-15 quicklook-link-category-1" onclick="javascript: return false;">
  
    <span></span>
</button>

  </div>

  <div class="add-to-cart-button">
    
    
<button type="button" class="btn  regular-button add-to-cart product-add2cart productid-15">
  
    <span></span>
</button>


  </div>

  </div>

</div>

  <span class="product-items-available low-stock">Only 4 left in stock</span>

<h5 class="product-name"><a class="fn url" href="cart.php?target=product&amp;product_id=15">Soft Kitty Singing Plush [Sale] [Reviews]</a></h5>

 
<form action="?" method="post" accept-charset="utf-8" onsubmit="javascript: return true;" class="form5b0dbe08475853.12967926">
<div class="form-params" style="display: none;">
      <input type="hidden" name="target" value="product" />
      <input type="hidden" name="action" value="rate" />
      <input type="hidden" name="return_target" value="main" />
      <input type="hidden" name="product_id" value="15" />
      <input type="hidden" name="target_widget" value="\\XLite\\Module\\XC\\Reviews\\View\\Customer\\ProductInfo\\ItemsList\\AverageRating" />
      <input type="hidden" name="returnURL" value="/demo/templates/multistore/" />
  </div>

    <div class="product-average-rating">
    <input type="hidden" name="target_widget" value="\XLite\Module\XC\Reviews\View\Customer\ProductInfo\Details\AverageRating" />
    <input type="hidden" name="widgetMode" value="grid" />
    
    <div class="rating">
                            
<div class="vote-bar">

  <div class="rating-stars">
    <div class="stars-row">
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
          </div>

    <div class="stars-row full" style="width: 97%;">
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
          </div>

      </div>

  </div>

                            <span class="votes-count">
              &nbsp;
              <span>
                21
              </span>
            </span>
        
                    <div class="rating-tooltip">
                <div class="text">
      <div>Score: 4.86 (votes: 21)</div>
    </div>

            </div>
        
    </div>


          <div class="reviews-count no-reviews">
        &mdash;
        <a href="cart.php?target=product&amp;product_id=15&amp;category_id=6#product-details-tab-reviews" class="link-to-tab">
          4
        </a>
      </div>
                  <span class="separator">|</span>
      <a href="cart.php?target=product&amp;product_id=15&amp;category_id=6#product-details-tab-reviews" class="link-to-tab">
            <p class=" add-review ">
<script type="text/x-cart-data">
{"url_params":{"target":"review","product_id":15,"return_target":"main","widget":"\\XLite\\Module\\XC\\Reviews\\View\\Customer\\ModifyReview"}}
</script>

<span class="link">Be the first and leave feedback</span>
</p>

      </a>
      </div>


</form>


  
    
<div class="product-price widget-fingerprint-product-price">
  <ul class="product-price">
    
<li class="product-price-base"><span class="price product-price">$25.49</span></li>

  </ul>
</div>

<div class="sale-price-value">$29.99</div>
<div class="product-marks">
  <div title="Added to cart" class="added-to-cart"><i class="icon-ok-mark"></i></div>

</div>

<ul class="labels">
      <li class="label-green sale-price">
      
<div class="label-main-box ">
  <div class="content">15% off</div>
</div>

    </li>
  </ul>


</div>



    
        </li>
              <li class="product-cell box-product">
    
          


<div class="product productid-27 draggable ">
      <a
            href="javascript:void(0);"
            title="Add to wishlist"
            data-productid="27"
            class="add-to-wishlist next-previous-assigned  log-in  fa fa-heart-o">
    </a>

<div class="product-photo lazy-load">
  <a
  href="cart.php?target=product&amp;product_id=27"
  class="product-thumbnail lazy-load">
  <img src="//design.x-cart.com/demo/templates/multistore/images/product/htro_superhero_mom_mug.jpeg" alt="Superhero Mom Mug"  class="photo" height="221" width="262" data-max-width="262" data-max-height="280" data-is-default-image="" />

</a>

  <div class="grid-buttons-wrapper">
      <div class="quicklook">
    
<button type="button" class="btn  regular-button quicklook-link quicklook-link-27 quicklook-link-category-1" onclick="javascript: return false;">
  
    <span></span>
</button>

  </div>

  <div class="add-to-cart-button">
    
    
<button type="button" class="btn  regular-button add-to-cart product-add2cart productid-27">
  
    <span></span>
</button>


  </div>

  </div>

</div>


<h5 class="product-name"><a class="fn url" href="cart.php?target=product&amp;product_id=27">Superhero Mom Mug</a></h5>

 
<form action="?" method="post" accept-charset="utf-8" onsubmit="javascript: return true;" class="form5b0dbe0881f1b2.70249817">
<div class="form-params" style="display: none;">
      <input type="hidden" name="target" value="product" />
      <input type="hidden" name="action" value="rate" />
      <input type="hidden" name="return_target" value="main" />
      <input type="hidden" name="product_id" value="27" />
      <input type="hidden" name="target_widget" value="\\XLite\\Module\\XC\\Reviews\\View\\Customer\\ProductInfo\\ItemsList\\AverageRating" />
      <input type="hidden" name="returnURL" value="/demo/templates/multistore/" />
  </div>

    <div class="product-average-rating">
    <input type="hidden" name="target_widget" value="\XLite\Module\XC\Reviews\View\Customer\ProductInfo\Details\AverageRating" />
    <input type="hidden" name="widgetMode" value="grid" />
    
    <div class="rating">
                            
<div class="vote-bar">

  <div class="rating-stars">
    <div class="stars-row">
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
          </div>

    <div class="stars-row full" style="width: 96%;">
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
          </div>

      </div>

  </div>

                            <span class="votes-count">
              &nbsp;
              <span>
                15
              </span>
            </span>
        
                    <div class="rating-tooltip">
                <div class="text">
      <div>Score: 4.80 (votes: 15)</div>
    </div>

            </div>
        
    </div>


                  <span class="separator">|</span>
      <a href="cart.php?target=product&amp;product_id=27&amp;category_id=8#product-details-tab-reviews" class="link-to-tab">
            <p class=" add-review ">
<script type="text/x-cart-data">
{"url_params":{"target":"review","product_id":27,"return_target":"main","widget":"\\XLite\\Module\\XC\\Reviews\\View\\Customer\\ModifyReview"}}
</script>

<span class="link">Be the first and leave feedback</span>
</p>

      </a>
      </div>


</form>


  
    
<div class="product-price widget-fingerprint-product-price">
  <ul class="product-price">
    
<li class="product-price-base"><span class="price product-price">$6.49</span></li>

  </ul>
</div>

<div class="sale-price-value">$12.99</div>
<div class="product-marks">
  <div title="Added to cart" class="added-to-cart"><i class="icon-ok-mark"></i></div>

</div>

<ul class="labels">
      <li class="label-green sale-price">
      
<div class="label-main-box ">
  <div class="content">50% off</div>
</div>

    </li>
  </ul>


</div>



    
        </li>
              <li class="product-cell box-product">
    
          


<div class="product productid-12 draggable ">
      <a
            href="javascript:void(0);"
            title="Add to wishlist"
            data-productid="12"
            class="add-to-wishlist next-previous-assigned  log-in  fa fa-heart-o">
    </a>

<div class="product-photo lazy-load">
  <a
  href="cart.php?target=product&amp;product_id=12"
  class="product-thumbnail lazy-load">
  <img src="//design.x-cart.com/demo/templates/multistore/images/product/inli_minions_pop_figs.jpeg" alt="Minions Pop Vinyl Figures"  class="photo" height="262" width="262" data-max-width="262" data-max-height="280" data-is-default-image="" />

</a>

  <div class="grid-buttons-wrapper">
      <div class="quicklook">
    
<button type="button" class="btn  regular-button quicklook-link quicklook-link-12 quicklook-link-category-1" onclick="javascript: return false;">
  
    <span></span>
</button>

  </div>

  <div class="add-to-cart-button">
    
    
<button type="button" class="btn  regular-button add-to-cart product-add2cart productid-12">
  
    <span></span>
</button>


  </div>

  </div>

</div>


<h5 class="product-name"><a class="fn url" href="cart.php?target=product&amp;product_id=12">Minions Pop Vinyl Figures</a></h5>

 
<form action="?" method="post" accept-charset="utf-8" onsubmit="javascript: return true;" class="form5b0dbe08908ed2.56756456">
<div class="form-params" style="display: none;">
      <input type="hidden" name="target" value="product" />
      <input type="hidden" name="action" value="rate" />
      <input type="hidden" name="return_target" value="main" />
      <input type="hidden" name="product_id" value="12" />
      <input type="hidden" name="target_widget" value="\\XLite\\Module\\XC\\Reviews\\View\\Customer\\ProductInfo\\ItemsList\\AverageRating" />
      <input type="hidden" name="returnURL" value="/demo/templates/multistore/" />
  </div>

    <div class="product-average-rating">
    <input type="hidden" name="target_widget" value="\XLite\Module\XC\Reviews\View\Customer\ProductInfo\Details\AverageRating" />
    <input type="hidden" name="widgetMode" value="grid" />
    
    <div class="rating">
                            
<div class="vote-bar">

  <div class="rating-stars">
    <div class="stars-row">
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
          </div>

    <div class="stars-row full" style="width: 79%;">
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
          </div>

      </div>

  </div>

                            <span class="votes-count">
              &nbsp;
              <span>
                20
              </span>
            </span>
        
                    <div class="rating-tooltip">
                <div class="text">
      <div>Score: 3.95 (votes: 20)</div>
    </div>

            </div>
        
    </div>


                  <span class="separator">|</span>
      <a href="cart.php?target=product&amp;product_id=12&amp;category_id=6#product-details-tab-reviews" class="link-to-tab">
            <p class=" add-review ">
<script type="text/x-cart-data">
{"url_params":{"target":"review","product_id":12,"return_target":"main","widget":"\\XLite\\Module\\XC\\Reviews\\View\\Customer\\ModifyReview"}}
</script>

<span class="link">Be the first and leave feedback</span>
</p>

      </a>
      </div>


</form>


  
    
<div class="product-price widget-fingerprint-product-price">
  <ul class="product-price">
    
<li class="product-price-base"><span class="price product-price">$9.99</span></li>

  </ul>
</div>

<div class="product-marks">
  <div title="Added to cart" class="added-to-cart"><i class="icon-ok-mark"></i></div>

</div>


</div>



    
        </li>
              <li class="product-cell box-product">
    
          


<div class="product productid-8 draggable ">
      <a
            href="javascript:void(0);"
            title="Add to wishlist"
            data-productid="8"
            class="add-to-wishlist next-previous-assigned  log-in  fa fa-heart-o">
    </a>

<div class="product-photo lazy-load">
  <a
  href="cart.php?target=product&amp;product_id=8"
  class="product-thumbnail lazy-load">
  <img src="//design.x-cart.com/demo/templates/multistore/images/product/ec8a_bow_ties.jpeg" alt="Bow Ties Are Cool [Unlimited QTY]"  class="photo" height="280" width="224" data-max-width="262" data-max-height="280" data-is-default-image="" />

</a>

  <div class="grid-buttons-wrapper">
      <div class="quicklook">
    
<button type="button" class="btn  regular-button quicklook-link quicklook-link-8 quicklook-link-category-1" onclick="javascript: return false;">
  
    <span></span>
</button>

  </div>

  <div class="add-to-cart-button">
    
    
<button type="button" class="btn  regular-button add-to-cart product-add2cart productid-8">
  
    <span></span>
</button>


  </div>

  </div>

</div>


<h5 class="product-name"><a class="fn url" href="cart.php?target=product&amp;product_id=8">Bow Ties Are Cool [Unlimited QTY]</a></h5>

 
<form action="?" method="post" accept-charset="utf-8" onsubmit="javascript: return true;" class="form5b0dbe089e7aa7.75480957">
<div class="form-params" style="display: none;">
      <input type="hidden" name="target" value="product" />
      <input type="hidden" name="action" value="rate" />
      <input type="hidden" name="return_target" value="main" />
      <input type="hidden" name="product_id" value="8" />
      <input type="hidden" name="target_widget" value="\\XLite\\Module\\XC\\Reviews\\View\\Customer\\ProductInfo\\ItemsList\\AverageRating" />
      <input type="hidden" name="returnURL" value="/demo/templates/multistore/" />
  </div>

    <div class="product-average-rating">
    <input type="hidden" name="target_widget" value="\XLite\Module\XC\Reviews\View\Customer\ProductInfo\Details\AverageRating" />
    <input type="hidden" name="widgetMode" value="grid" />
    
    <div class="rating">
                            
<div class="vote-bar">

  <div class="rating-stars">
    <div class="stars-row">
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
          </div>

    <div class="stars-row full" style="width: 60%;">
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
          </div>

      </div>

  </div>

                            <span class="votes-count">
              &nbsp;
              <span>
                24
              </span>
            </span>
        
                    <div class="rating-tooltip">
                <div class="text">
      <div>Score: 3.00 (votes: 24)</div>
    </div>

            </div>
        
    </div>


                  <span class="separator">|</span>
      <a href="cart.php?target=product&amp;product_id=8&amp;category_id=4#product-details-tab-reviews" class="link-to-tab">
            <p class=" add-review ">
<script type="text/x-cart-data">
{"url_params":{"target":"review","product_id":8,"return_target":"main","widget":"\\XLite\\Module\\XC\\Reviews\\View\\Customer\\ModifyReview"}}
</script>

<span class="link">Be the first and leave feedback</span>
</p>

      </a>
      </div>


</form>


  
    
<div class="product-price widget-fingerprint-product-price">
  <ul class="product-price">
    
<li class="product-price-base"><span class="price product-price">$14.99</span></li>

  </ul>
</div>

<div class="sale-price-value">$19.99</div>
<div class="product-marks">
  <div title="Added to cart" class="added-to-cart"><i class="icon-ok-mark"></i></div>

</div>

<ul class="labels">
      <li class="label-green sale-price">
      
<div class="label-main-box ">
  <div class="content">25% off</div>
</div>

    </li>
  </ul>


</div>



    
        </li>
              <li class="product-cell box-product">
    
          


<div class="product productid-13 draggable ">
      <a
            href="javascript:void(0);"
            title="Add to wishlist"
            data-productid="13"
            class="add-to-wishlist next-previous-assigned  log-in  fa fa-heart-o">
    </a>

<div class="product-photo lazy-load">
  <a
  href="cart.php?target=product&amp;product_id=13"
  class="product-thumbnail lazy-load">
  <img src="//design.x-cart.com/demo/templates/multistore/images/product/ijro_ghostbusters_vinyl_idols.jpeg" alt="Vinyl Idolz: Ghostbusters"  class="photo" height="262" width="262" data-max-width="262" data-max-height="280" data-is-default-image="" />

</a>

  <div class="grid-buttons-wrapper">
      <div class="quicklook">
    
<button type="button" class="btn  regular-button quicklook-link quicklook-link-13 quicklook-link-category-1" onclick="javascript: return false;">
  
    <span></span>
</button>

  </div>

  <div class="add-to-cart-button">
    
    
<button type="button" class="btn  regular-button add-to-cart product-add2cart productid-13">
  
    <span></span>
</button>


  </div>

  </div>

</div>


<h5 class="product-name"><a class="fn url" href="cart.php?target=product&amp;product_id=13">Vinyl Idolz: Ghostbusters</a></h5>

 
<form action="?" method="post" accept-charset="utf-8" onsubmit="javascript: return true;" class="form5b0dbe084f1668.56874370">
<div class="form-params" style="display: none;">
      <input type="hidden" name="target" value="product" />
      <input type="hidden" name="action" value="rate" />
      <input type="hidden" name="return_target" value="main" />
      <input type="hidden" name="product_id" value="13" />
      <input type="hidden" name="target_widget" value="\\XLite\\Module\\XC\\Reviews\\View\\Customer\\ProductInfo\\ItemsList\\AverageRating" />
      <input type="hidden" name="returnURL" value="/demo/templates/multistore/" />
  </div>

    <div class="product-average-rating">
    <input type="hidden" name="target_widget" value="\XLite\Module\XC\Reviews\View\Customer\ProductInfo\Details\AverageRating" />
    <input type="hidden" name="widgetMode" value="grid" />
    
    <div class="rating">
                            
<div class="vote-bar">

  <div class="rating-stars">
    <div class="stars-row">
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
          </div>

    <div class="stars-row full" style="width: 76%;">
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
          </div>

      </div>

  </div>

                            <span class="votes-count">
              &nbsp;
              <span>
                15
              </span>
            </span>
        
                    <div class="rating-tooltip">
                <div class="text">
      <div>Score: 3.80 (votes: 15)</div>
    </div>

            </div>
        
    </div>


                  <span class="separator">|</span>
      <a href="cart.php?target=product&amp;product_id=13&amp;category_id=6#product-details-tab-reviews" class="link-to-tab">
            <p class=" add-review ">
<script type="text/x-cart-data">
{"url_params":{"target":"review","product_id":13,"return_target":"main","widget":"\\XLite\\Module\\XC\\Reviews\\View\\Customer\\ModifyReview"}}
</script>

<span class="link">Be the first and leave feedback</span>
</p>

      </a>
      </div>


</form>


  
    
<div class="product-price widget-fingerprint-product-price">
  <ul class="product-price">
    
<li class="product-price-base"><span class="price product-price">$19.99</span></li>

  </ul>
</div>

<div class="product-marks">
  <div title="Added to cart" class="added-to-cart"><i class="icon-ok-mark"></i></div>

</div>


</div>



    
        </li>
              <li class="product-cell box-product">
    
          


<div class="product productid-17 draggable ">
      <a
            href="javascript:void(0);"
            title="Add to wishlist"
            data-productid="17"
            class="add-to-wishlist next-previous-assigned  log-in  fa fa-heart-o">
    </a>

<div class="product-photo lazy-load">
  <a
  href="cart.php?target=product&amp;product_id=17"
  class="product-thumbnail lazy-load">
  <img src="//design.x-cart.com/demo/templates/multistore/images/product/hrsp_sphero_ollie.jpeg" alt="Ollie - The App Controlled Robot"  class="photo" height="262" width="262" data-max-width="262" data-max-height="280" data-is-default-image="" />

</a>

  <div class="grid-buttons-wrapper">
      <div class="quicklook">
    
<button type="button" class="btn  regular-button quicklook-link quicklook-link-17 quicklook-link-category-1" onclick="javascript: return false;">
  
    <span></span>
</button>

  </div>

  <div class="add-to-cart-button">
    
    
<button type="button" class="btn  regular-button add-to-cart product-add2cart productid-17">
  
    <span></span>
</button>


  </div>

  </div>

</div>


<h5 class="product-name"><a class="fn url" href="cart.php?target=product&amp;product_id=17">Ollie - The App Controlled Robot</a></h5>

 
<form action="?" method="post" accept-charset="utf-8" onsubmit="javascript: return true;" class="form5b0dbe08b168b7.42748000">
<div class="form-params" style="display: none;">
      <input type="hidden" name="target" value="product" />
      <input type="hidden" name="action" value="rate" />
      <input type="hidden" name="return_target" value="main" />
      <input type="hidden" name="product_id" value="17" />
      <input type="hidden" name="target_widget" value="\\XLite\\Module\\XC\\Reviews\\View\\Customer\\ProductInfo\\ItemsList\\AverageRating" />
      <input type="hidden" name="returnURL" value="/demo/templates/multistore/" />
  </div>

    <div class="product-average-rating">
    <input type="hidden" name="target_widget" value="\XLite\Module\XC\Reviews\View\Customer\ProductInfo\Details\AverageRating" />
    <input type="hidden" name="widgetMode" value="grid" />
    
    <div class="rating">
                            
<div class="vote-bar">

  <div class="rating-stars">
    <div class="stars-row">
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
          </div>

    <div class="stars-row full" style="width: 81%;">
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
              <div class="star-single"><span class="fa fa-star"><span></div>
          </div>

      </div>

  </div>

                            <span class="votes-count">
              &nbsp;
              <span>
                21
              </span>
            </span>
        
                    <div class="rating-tooltip">
                <div class="text">
      <div>Score: 4.05 (votes: 21)</div>
    </div>

            </div>
        
    </div>


                  <span class="separator">|</span>
      <a href="cart.php?target=product&amp;product_id=17&amp;category_id=6#product-details-tab-reviews" class="link-to-tab">
            <p class=" add-review ">
<script type="text/x-cart-data">
{"url_params":{"target":"review","product_id":17,"return_target":"main","widget":"\\XLite\\Module\\XC\\Reviews\\View\\Customer\\ModifyReview"}}
</script>

<span class="link">Be the first and leave feedback</span>
</p>

      </a>
      </div>


</form>


  
    
<div class="product-price widget-fingerprint-product-price">
  <ul class="product-price">
    
<li class="product-price-base"><span class="price product-price">$99.00</span></li>

  </ul>
</div>

<div class="product-marks">
  <div title="Added to cart" class="added-to-cart"><i class="icon-ok-mark"></i></div>

</div>


</div>



    
        </li>
                </ul>
  
</div>

    
  </div>
</div>
</div>







</div>

  </div>
</div>


    </div>
  </div>
  </div> 


<div class="brands-block">
    <div class="container">
                    <div class="brands-block-static">
                <div class="content owl-carousel">
                    <div class="brand-link"><img src="<?= base_url(); ?>skins/Multistore/images/brands-images/BOSCH.png" alt="" /></div>
                    <div class="brand-link"><img src="<?= base_url(); ?>skins/Multistore/images/brands-images/CalvinKlein.png" alt="" /></div>
                    <div class="brand-link"><img src="<?= base_url(); ?>skins/Multistore/images/brands-images/H&M.png" alt="" /></div>
                    <div class="brand-link"><img src="<?= base_url(); ?>skins/Multistore/images/brands-images/Samsung.png" alt="" /></div>
                    <div class="brand-link"><img src="<?= base_url(); ?>skins/Multistore/images/brands-images/Sony.png" alt="" /></div>
                </div>
            </div>
                
    </div>
</div>



  </div>
  
<div id="footer-area">
    <div class="container">
        
<div id="secondary-menu" class="clearfix">
 <ul class="footer-menu">
     <li class="footer-contacts leaf">
         
<span class="footer-title">Contact us</span>

<ul class="contact-us-content">
    <li>
        <div>
<div>First Store</div>
<div>No. 96, Jecica City, NJ</div>
<div>07305, New York, USA</div>
</div>
<br/>
<div>
<div>Two Store</div>
<div>No.37, Jecica City, NJ</div>
<div>04305, New York, USA</div>
</div>
    </li>
</ul>
         <ul class="follow-us-block">
            <li>
                <span class="footer-title-follow-us">Follow us</span>

                                <ul>
                    <li><a href="#"><img src="<?= base_url(); ?>skins/Multistore/images/pinterest.svg" alt="" /></a></li>
                    <li><a href="#"><img src="<?= base_url(); ?>skins/Multistore/images/twitter.svg" alt="" /></a></li>
                    <li><a href="#"><img src="<?= base_url(); ?>skins/Multistore/images/gplus.svg" alt="" /></a></li>
                    <li><a href="#"><img src="<?= base_url(); ?>skins/Multistore/images/facebook.svg" alt="" /></a></li>
                </ul>
            </li>
         </ul>
     </li>
                        
      
      <li  class="leaf first">
                <span class="footer-title">Offers</span>
        
                  <ul>
      
      
      <li  class="leaf">
                <a href="?target=sale_products" >Sale</a>
        
                        
      
      <li  class="leaf">
                <a href="?target=coming_soon" >Coming soon</a>
        
                        
      
      <li  class="leaf">
                <a href="?target=new_arrivals" >New!</a>
        
                        
      </ul></li>
      <li  class="leaf">
                <span class="footer-title">Info links</span>
        
                  <ul>
      
      
      <li  class="leaf">
                <a href="cart.php?target=page&amp;id=2" >Shipping</a>
        
                        
      
      <li  class="leaf">
                <a href="?target=map" >Sitemap</a>
        
                        
      
      <li  class="leaf">
                <a href="cart.php?target=page&amp;id=1" >Terms &amp; Conditions</a>
        
                        
      </ul></li>
      <li  class="leaf">
                <span class="footer-title">Services</span>
        
                  <ul>
      
      
      <li  class="leaf">
                <a href="cart.php?target=page&amp;id=2" >Shipping info</a>
        
                        
      
      <li  class="leaf last">
                <a href="?target=contact_us" >Contact us</a>
        
          </li>
    </ul></li>
    

<li class="subscription-form leaf">
    <span class="footer-title">Subscription</span>
        <ul>
            <li>
                <div class="subscription-block">
                    <div class="subscription-form-block">
                        
 
<form action="?" method="post" accept-charset="utf-8" onsubmit="javascript: return true;" class="form5b0c68cf510924.75459228">
<div class="form-params" style="display: none;">
      <input type="hidden" name="target" value="NewsletterSubscriptions" />
      <input type="hidden" name="action" value="subscribe" />
      <input type="hidden" name="returnURL" value="/demo/templates/multistore/" />
  </div>
    <div class="subscription-form-label">
        Register now to get updates on promotions and coupons.
    </div>
    
  <div class="table-label newlettersubscription-email-label table-label-required">
    <label for="newlettersubscription-email">
      
          </label>
  </div>
  <div class="star">
    *  </div>

<div class="table-value newlettersubscription-email-value table-value-required">
  <span class="input-field-wrapper input input-text-email">
  <script type="text/x-cart-data">
{"defaultValue":"","selectOnFocus":false}
</script>

  <input id="newlettersubscription-email" name="newlettersubscription_email" placeholder="Please enter your email" type="text" value="" autocomplete="off" maxlength="255" class="validate[required,maxSize[255],custom[email]] form-control" />
</span>
        </div>

  <div class="clear"></div>

    
<button type="submit" class="btn  regular-button  submit">
  
    <span>Subscribe</span>
</button>

</form>


                        <div class="subscription-error-block hidden">
                            
Can&#039;t subscribe you right now. Try later

                        </div>
                    </div>
                    <div class="subscription-success-block hidden">
                        
Thank you for subscribing to the newsletter! We hope you enjoy shopping at Carrovan

                    </div>
                </div>
            </li>
        </ul>
</li>

 </ul>
</div>
    </div>
    
<div id="footer">
  <div class="section container">
    

<div class="powered-by">
  <p class="copyright">&copy; 2017 - 2018 Carrovan. All rights reserved.</p>
  <p class="powered-by-label"><a href="http://www.x-cart.com/?sl=en" target="_blank">Powered by ILegendsTechnologies</a></p>
</div>

    <div class="footer-payments"><img src="<?= base_url(); ?>skins/Multistore/images/footer-payments.svg" alt="" /></div>
  </div>
</div>

</div>

</div>-->

  <script type="text/javascript"
          src="http://design.x-cart.com/demo/templates/multistore/var/resources/js/118c42e26e7f845af533d0d8b5fb05498cb565dd8715e5d1213a883dae21b2d8.js?1502780308"
                    ></script>
<script type="application/javascript">
  (function () {
    var resources = ["skins\/common\/css\/normalize.css","skins\/common\/ui\/jquery-ui.css","skins\/common\/css\/jquery.mousewheel.css","skins\/common\/css\/validationEngine.jquery.css","skins\/common\/css\/font-awesome\/font-awesome.min.css","skins\/common\/css\/lazy-load.css","http:\/\/design.x-cart.com\/demo\/templates\/multistore\/var\/resources\/default\/http\/screen\/c76d6e75e2ef50cb62bb10a909b90b56.css","http:\/\/design.x-cart.com\/demo\/templates\/multistore\/var\/resources\/default\/http\/screen\/491aebe5f4db0ba03633027d519f2a3f.css","http:\/\/design.x-cart.com\/demo\/templates\/multistore\/var\/resources\/default\/http\/screen\/8fd32cf11862afb4abfcd6567ee3932e.css","\/\/fonts.googleapis.com\/css?family=Open+Sans%3A300italic%2C400italic%2C600italic%2C700italic%2C400%2C300%2C600%2C700&subset=latin%2Ccyrillic%2Clatin-ext","skins\/common\/froala-editor\/css\/froala_style.fixed.css","skins\/Multistore\/customer\/css\/theme.css","skins\/Multistore\/customer\/css\/style.css","skins\/Multistore\/customer\/css\/ajax.css","skins\/Multistore\/customer\/css\/lazy-load.css","skins\/Multistore\/customer\/js\/owl-carousel\/owl.carousel.min.css","skins\/Multistore\/customer\/js\/owl-carousel\/owl.theme.default.min.css","skins\/Multistore\/customer\/modules\/CDev\/SocialLogin\/style.css","skins\/customer\/modules\/CDev\/Sale\/css\/lc.css","skins\/customer\/modules\/CDev\/Paypal\/style.css","skins\/Multistore\/customer\/modules\/CDev\/SimpleCMS\/css\/primary_menu.css","skins\/customer\/button\/css\/button.css","skins\/customer\/top_message\/style.css","skins\/Multistore\/customer\/product\/search\/simple_form.css","skins\/Multistore\/customer\/form_field\/form_field.css","skins\/Multistore\/customer\/mini_cart\/minicart.css","skins\/Multistore\/customer\/banner_rotation\/style.css","skins\/customer\/modules\/XC\/ThemeTweaker\/list_container\/list_container.css","skins\/Multistore\/customer\/common\/grid-list.css","skins\/customer\/items_list\/items_list.css","skins\/customer\/pager\/pager.css","skins\/Multistore\/customer\/items_list\/product\/products_list.css","skins\/customer\/items_list\/product\/quick_look.css","skins\/Multistore\/customer\/labels\/style.css","skins\/Multistore\/customer\/modules\/CDev\/Sale\/style.css","skins\/Multistore\/customer\/modules\/CDev\/ProductAdvisor\/style.css","skins\/Multistore\/customer\/product\/details\/parts\/gallery.css","skins\/customer\/product\/quantity_box\/quantity_box.css","skins\/Multistore\/customer\/product\/details\/parts\/attributes_modify\/style.css","skins\/Multistore\/customer\/modules\/XC\/Reviews\/average_rating\/style.css","skins\/Multistore\/customer\/modules\/XC\/Reviews\/vote_bar\/vote_bar.css","skins\/customer\/modules\/XC\/Reviews\/form_field\/input\/rating\/rating.css","skins\/Multistore\/customer\/modules\/XC\/FreeShipping\/label\/style.css","skins\/Multistore\/customer\/modules\/XC\/Reviews\/review\/style.css","skins\/Multistore\/customer\/vote_bar\/vote_bar.css","skins\/Multistore\/customer\/modules\/QSL\/WordPress\/blog\/plugins\/recent_posts\/css\/recent_posts.css","skins\/Multistore\/customer\/modules\/CDev\/SimpleCMS\/css\/footer_menu.css","skins\/Multistore\/customer\/css\/powered_by.css","skins\/customer\/modules\/QSL\/MyWishlist\/style.css","skins\/Multistore\/customer\/modules\/QSL\/FlyoutCategoriesMenu\/flyout-menu.css","skins\/customer\/modules\/CDev\/SimpleCMS\/page\/style.css","skins\/Multistore\/customer\/css\/print.css","skins\/common\/js\/jquery.min.js","skins\/common\/js\/jquery-migrate.js","skins\/common\/js\/jquery-ui.min.js","skins\/common\/js\/jquery.ui.touch-punch.min.js","skins\/common\/js\/jquery.cookie.min.js","skins\/common\/js\/underscore-min.js","skins\/common\/js\/underscore.string.min.js","skins\/common\/bootstrap\/js\/bootstrap.min.js","skins\/common\/js\/hash.js","skins\/common\/js\/object_hash.js","skins\/common\/js\/validationEngine.min\/languages\/jquery.validationEngine-en.js","skins\/common\/js\/validationEngine.min\/jquery.validationEngine.js","skins\/common\/js\/validationEngine.min\/custom.validationEngine.js","skins\/common\/js\/jquery.mousewheel.min.js","skins\/common\/js\/regex-mask-plugin.js","skins\/common\/js\/common.js","skins\/common\/js\/core.element.js","skins\/common\/js\/core.js","skins\/common\/js\/core.extend.js","skins\/common\/js\/core.controller.js","skins\/common\/js\/core.loadable.js","skins\/common\/js\/core.utils.js","skins\/common\/js\/lazyload.js","skins\/common\/js\/json5.min.js","skins\/common\/js\/core.form.js","skins\/common\/js\/lazy-load.js","skins\/common\/js\/loadCSS.min.js","skins\/common\/js\/functionNamePolyfill\/Function.name.js","skins\/common\/js\/php.min.js","skins\/common\/js\/core\/amd.js","skins\/common\/js\/core\/translate.js","skins\/customer\/modules\/XC\/WebmasterKit\/core.js","skins\/customer\/js\/sticky_footer.js","skins\/customer\/js\/responsive_navbar.js","skins\/Multistore\/customer\/js\/bootstrap-tabcollapse.js","skins\/Multistore\/customer\/js\/jquery.collapser.js","skins\/Multistore\/customer\/js\/jquery.floating-label.js","skins\/Multistore\/customer\/js\/jquery.path.js","skins\/Multistore\/customer\/js\/jquery.fly.js","skins\/Multistore\/customer\/js\/utils.js","skins\/Multistore\/customer\/js\/header.js","skins\/Multistore\/customer\/js\/footer.js","skins\/Multistore\/customer\/js\/owl-carousel\/carouseldragging.js","skins\/Multistore\/customer\/js\/owl-carousel\/owl.carousel.min.js","skins\/Multistore\/customer\/js\/products_carousel.js","skins\/common\/js\/core.popup.js","skins\/common\/js\/core.popup_button.js","skins\/common\/js\/Sortable.js","skins\/customer\/modules\/QSL\/CloudSearch\/loader.js","skins\/customer\/modules\/QSL\/CloudSearch\/init.js","skins\/customer\/modules\/QSL\/CloudSearch\/lib\/handlebars.min.js","skins\/customer\/modules\/QSL\/CloudSearch\/lib\/jquery.hoverIntent.min.js","skins\/customer\/modules\/CDev\/SocialLogin\/fb_hash_fix.js","skins\/customer\/modules\/CDev\/Paypal\/button\/default.js","skins\/customer\/js\/jquery.mmenu.min.all.js","skins\/customer\/js\/slidebar.js","skins\/Multistore\/customer\/js\/slidebar_options.js","skins\/customer\/button\/js\/button.js","skins\/customer\/button\/js\/login.js","skins\/customer\/js\/login.js","skins\/customer\/top_message\/controller.js","skins\/customer\/form_field\/js\/text.js","skins\/Multistore\/customer\/js\/header_settings.js","skins\/customer\/mini_cart\/minicart.js","skins\/customer\/button\/js\/popup_button.js","skins\/Multistore\/customer\/banner_rotation\/controller.js","skins\/customer\/modules\/XC\/ThemeTweaker\/layout_block\/layout_block_controller.js","skins\/customer\/modules\/XC\/ThemeTweaker\/list_container\/jquery.listItem.js","skins\/customer\/modules\/XC\/ThemeTweaker\/list_container\/list_container.js","skins\/customer\/back_to_top\/component.js","skins\/customer\/items_list\/items_list.js","skins\/customer\/modules\/QSL\/Multistore\/items_list\/items_list.js","skins\/customer\/items_list\/product\/products_list.js","skins\/customer\/product\/details\/controller.js","skins\/customer\/modules\/XC\/ProductVariants\/product\/controller_quicklook.js","skins\/Multistore\/customer\/js\/details_gallery.js","skins\/Multistore\/customer\/js\/cycle2\/jquery.cycle2.min.js","skins\/Multistore\/customer\/js\/cycle2\/jquery.cycle2.carousel.min.js","skins\/customer\/product\/quantity_box\/controller.js","skins\/customer\/product\/details\/parts\/attributes_modify\/script.js","skins\/Multistore\/customer\/js\/add_to_cart.js","skins\/customer\/modules\/QSL\/Multistore\/items_list\/product\/products_list.js","skins\/customer\/modules\/XC\/Reviews\/average_rating\/rating.js","skins\/customer\/modules\/QSL\/MyWishlist\/items_list\/product\/close-button.js","skins\/customer\/modules\/XC\/Reviews\/button\/js\/add_review.js","skins\/Multistore\/customer\/modules\/CDev\/SimpleCMS\/js\/jquery_footer.js","skins\/customer\/modules\/XC\/NewsletterSubscriptions\/form\/subscribe.js","skins\/Multistore\/customer\/modules\/QSL\/MyWishlist\/header\/header-widget-common.js","skins\/customer\/modules\/QSL\/FlyoutCategoriesMenu\/flyout-menu.js","skins\/customer\/modules\/QSL\/Banner\/jquery.cycle2.flip.js","skins\/customer\/modules\/QSL\/Banner\/jquery.cycle2.swipe.min.js","skins\/customer\/modules\/QSL\/Banner\/jquery.cycle2.scrollVert.js","skins\/customer\/modules\/QSL\/Banner\/jquery.cycle2.tile.js"];

    if (window.CoreAMD !== undefined) {
      require('js/core', function (core) {
        core.registerResources(resources);
      });
    } else {
      document.addEventListener('amd-ready', function (event) {
        require('js/core', function (core) {
          core.registerResources(resources);
        });
      });
    }
  })();
</script>






</body>
</html>
