<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Carrovan</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="apple-mobile-web-app-capable" content="yes">
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/bootstrap-responsive.min.css" rel="stylesheet">
<link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600"
        rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="css/font-awesome.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link href="css/pages/bootstrap.css" rel="stylesheet">

<link href="css/custom.min.css" rel="stylesheet">
<link href="css/pages/dashboard.css" rel="stylesheet">
<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->


</head>
<body>

    <div class="navbar navbar-fixed-top">
  <div class="navbar-inner">
    <div class="container">
                   <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse"><span
                    class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span> </a><a class="brand" href="index.php">CARROVAN </a>
      <!-- <ul class="nav" style="margin-left: 20%; transform: translateX(30%);">
            <li><a href="#" style="font-size: 18px">MarketPlace</a></li>
        </ul> -->
      <span>
        <div class="dropdown market">
  <button class="dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    MarketPlace
  </button>
  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
    <a class="dropdown-item" href="#">United Kingdom</a>
    <a class="dropdown-item" href="#">Dubae</a>
    <a class="dropdown-item" href="#">Pakistan</a>
  </div>
</div>
</span>
        <div class="nav-collapse">
        <ul class="nav pull-right">
          <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown"><i
                            class="icon-cog"></i> Account <b class="caret"></b></a>
            <ul class="dropdown-menu">
              <li><a href="javascript:;">Settings</a></li>
              <li><a href="javascript:;">Help</a></li>
            </ul>
          </li>
          <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown"><i
                            class="icon-user"></i> Kamran <b class="caret"></b></a>
            <ul class="dropdown-menu">
              <li><a href="javascript:;">Profile</a></li>
              <li><a href="javascript:;">Logout</a></li>
            </ul>
          </li>
        </ul>
        <form class="navbar-search pull-right">
          <input type="text" class="search-query" placeholder="Search">
        </form>
      </div>
      <!--/.nav-collapse --> 
    </div>
    <!-- /container --> 
  </div>
  <!-- /navbar-inner --> 
</div>
<!-- /navbar -->
<div class="subnavbar">
  <div class="subnavbar-inner">
    <div class="container">
      <ul class="mainnav">
        <li class="active"><a href="index.php"><span>Dashboard</span> </a> </li>
        <li class="dropdown">         
      <a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown">
        <span>Employee</span>
        <b class="caret"></b>
      </a>  
      <ul class="dropdown-menu">
                <li><a href="add_employee.php">Add Employee</a></li>
        <li><a href="manage_employee.php">All Employee</a></li>
            </ul>           
    </li>
    <li class="dropdown">         
      <a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown">
        <span>Supplier</span>
        <b class="caret"></b>
      </a>  
      <ul class="dropdown-menu">
                <li><a href="add_suppliers.php">Add Supplier</a></li>
        <li><a href="manage_suppliers.php">All Supplier</a></li>
            </ul>           
    </li>
        <li><a href="msg.php"><span>Messages</span> </a> </li>
        <li><a href="Inventory.php"><span>Inventory</span> </a> </li>
        <li><a href="reports.php"><span>Reports</span> </a></li>
        <li><a href="orders.php"><span style="margin-top: 28%">Performance</span> </a> </li>
        <li><a href="products.php"><span>Store</span> </a> </li>
        <!-- <li class="dropdown"><a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown"> <i class="icon-long-arrow-down"></i><span>MarketPlace</span> <b class="caret"></b></a>
          <ul class="dropdown-menu">
            <li><a href="#">United Kingdom</a></li>
            <li><a href="#">United Arab Emirates</a></li>
            <li><a href="#">Pakistan</a></li>
            <li><a href="#">America</a></li>
            <li><a href="#">China</a></li>
            <li><a href="#">India</a></li>
          </ul>
        </li> -->
      </ul>
    </div>
    <!-- /container --> 
  </div>
  <!-- /subnavbar-inner --> 
</div>




<div class="right_col" role="main">
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3>Suppliers</h3>
            </div>
        </div>
        <div class="clearfix"></div>
        <hr>
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_title">
                        <h2>Manage Suppliers (you can't update/delete these 2 users ;) )</h2>
                        <ul class="nav navbar-right panel_toolbox">
                            <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                            <li><a class="close-link"><i class="fa fa-close"></i></a></li>
                        </ul>
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                        <table class="table table-striped">
                            <tr>
                                <th>
                                    Employee Id
                                </th>
                                <th>
                                    Name
                                </th>
                                <th>
                                    Email
                                </th>
                                <th>
                                    Mobile
                                </th>
                                
                                <th>
                                    Position
                                </th>
                                <th>
                                    Gender
                                </th>
                                <th>
                                    Access
                                </th>
                                <th colspan="2">
                                    Actions
                                </th>
                            </tr>
                            
                            {emp}
                            <tr>
                                <td>{id}</td>
                                <td>{first_name} {last_name}</td>
                                <td>{email}</td>
                                <td>{mobile}</td>
                                <td>{position}</td>
                                <td>{gender}</td>
                                <td>{type}</td>
                                <td>
                                    <a href=" <?php echo base_url(); ?>admin/employee/edit/{id}" class="btn btn-primary btn-xs">Edit</a>
                                    <a onclick="return confirm('All records will be deleted, continue?')" href=" <?php echo base_url(); ?>admin/employee/delete/{id}" class="btn btn-danger btn-xs">Delete</a>
                                </td>
                            </tr>
                            {/emp}
                        </table>
                    </div> <!-- /content --> 
                </div><!-- /x-panel --> 
            </div> <!-- /col --> 
    </div>
</div>


<!-- Le javascript
================================================== --> 

<script>
      $(document).ready(function(){
        $('.dropdown-submenu a.test').on("click", function(e){
          $(this).next('ul').toggle();
          e.stopPropagation();
          e.preventDefault();
        });
    });
</script>

<!-- Placed at the end of the document so the pages load faster --> 
<script src="js/jquery-1.7.2.min.js"></script> 
<script src="js/excanvas.min.js"></script> 
<script src="js/chart.min.js" type="text/javascript"></script> 
<script src="js/bootstrap.js"></script>
<script language="javascript" type="text/javascript" src="js/full-calendar/fullcalendar.min.js"></script>
 
<script src="js/base.js"></script> 

</body>
</html>
