<!DOCTYPE html>
<html lang="en">
  
 <head>
    <meta charset="utf-8">
    <title>Carrovan/ SignUp</title>

	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="apple-mobile-web-app-capable" content="yes"> 
    
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
<link href="css/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />

<link href="css/font-awesome.css" rel="stylesheet">
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600" rel="stylesheet">
    
<link href="css/style.css" rel="stylesheet" type="text/css">
<link href="css/pages/signin.css" rel="stylesheet" type="text/css">


	<link href="<?= base_url(); ?>assets/css/signup.css" rel='stylesheet' type='text/css'/>

</head>

<body>
	
	<div class="navbar navbar-fixed-top">
	
	<div class="navbar-inner">
		
		<div class="container">
			
			<a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</a>
			
			<a class="brand" href="index.html">
				Carrovan				
			</a>		
			
			<div class="nav-collapse">
				<ul class="nav pull-right">
					<li class="">						
						<a href="#" class="">
							Setting
						</a>
						
					</li>
					<li class="">						
						<a href="index.html" class="">
							<i class="icon-chevron-left"></i>
							Logout
						</a>
						
					</li>
				</ul>
				
			</div><!--/.nav-collapse -->	
	
		</div> <!-- /container -->
		
	</div> <!-- /navbar-inner -->
	
</div> <!-- /navbar -->



		<h2 style="text-align: center; margin-top: 20px;">Register Your Self !</h2>
	<div class="main-content">
		
        <div class="right-w3">
			<div class="sap_tabs">	
				<div id="horizontalTab" style="display: block; width: 100%; margin: 0px;">
					<ul>
						<li class="resp-tab-item" aria-controls="tab_item-0" role="tab"><span>User Sign up</span></li>
						<li class="resp-tab-item" aria-controls="tab_item-1" role="tab"><span>Supplier Sign in</span></li>
				    <div class="clear"></div>
					</ul>	
					<div class="agile-tb">
						<div class="tab-1 resp-tab-content" aria-labelledby="tab_item-0">
							<form action="#" method="post">				
								<input placeholder="Name" name="name" type="text" required="">
								<input placeholder="Email Address"name="email" type="text" required="">						
								<input placeholder="Password" name="password" type="password" required="">	
								<input placeholder="Confirm Password" name="password" type="password" required="">
								<span class="checkbox1">
									<label class="checkbox"><input type="checkbox" name="" checked=""><i> </i>I Agree To All Terms And Conditions</label>
								</span>

								<input type="submit" value="Sign up"/>
							</form>
						</div>	
						<div class="tab-2 resp-tab-content" aria-labelledby="tab_item-1">
							<form action="#" method="post">				
								<input placeholder="Name" name="name" type="text" required="">
								<input placeholder="Email Address"name="email" type="text" required="">						
								<input placeholder="Password" name="password" type="password" required="">	
								<input placeholder="Confirm Password" name="password" type="password" required="">
								<span class="checkbox1">
									<label class="checkbox"><input type="checkbox" name="" checked=""><i> </i>I Agree To All Terms And Conditions</label>
								</span>

								<input type="submit" value="Sign up"/>
							</form>
						</div>
					</div>
				</div> 
			</div> 			        					            	      
		</div>	
	</div>

<!-- Text Under Box -->
<div class="login-extra">
	Carrovan | <a href="login.html">ILegend Technologies</a>
</div> <!-- /login-extra -->

<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>

	<script src="<?= base_url(); ?>assets/js/jquery.min.js"></script>
				<script type="text/javascript">
					$(document).ready(function () {
						$('#horizontalTab').easyResponsiveTabs({
							type: 'default', //Types: default, vertical, accordion           
							width: 'auto', //auto or any width like 600px
							fit: true   // 100% fit in a container
						});
					});
				</script>

<script src="<?= base_url(); ?>assets/js/jquery-1.7.2.min.js"></script>
<script src="<?= base_url(); ?>assets/js/easyResponsiveTabs.js" type="text/javascript"></script>

</body>

 </html>
