<div class="main fs3">
  <div class="main-inner">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <h1 class="hs1">Add a Product</h1>
          <div>
          	<img class="img-responsive" style="width: 100%; height: 350px" src="<?= base_url(); ?>/image/catalog/demo/layerslider/bg_slider_home22.jpg" alt="">
          </div>
          <div style="margin-top: -15%; position: absolute; margin-left: 10%">
          	<div class="hs2">Successfully List your Product on Carrovan</div>
          	<div class="fs2">Learn about product detail page, variations, and other listing concepts.</div><br>
          	<a href="#" class="btn btn-primary">Skip</a>
          	<a href="#" class="btn btn-primary">Get Started</a>
          </div>
          <hr>
        </div>

        <div>
        <div class="col-md-9 col-sm-9 col-xs-12">
        	<div class="widget">
        		<div class="widget-content">
        		<div class="col-md-6 col-sm-6 col-xs-12" style="border-right: 1px solid gray">
        			<p class="hs2">List a new product</p>
        			<div class="fs1">Search Carrovan's catalogue first</div>
        			<span><input type="Search" name="search" placeholder="Product name"><a href="#" class="btn btn-primary">Search</a></span><br>
        			<p>if it is not in Carrovan's catalogue: <span><a href="#">Create a new product listing</a></span></p>
        			<p>To manage your selling applications, <span><a>click here</a></span></p>
        			<p>if you have requested for GTIN exemption, <span><a>check status here</a></span></p>
        			<div style="float: right;margin-right: -15px;margin-top: -100px;background: white;">Or</div>
        		</div>
        		<div class="col-md-6 col-sm-6 col-xs-12">
        			<p class="hs2">List many product via bulk upload</p>
        			<p class="fs1">Use Inventry File Templates</p>
        			<div>
        			<div><a href="#" class="fs3">Add variations using Variation Wizard</a></div>
        			<div><a href="#" class="fs3">Download an Inventory File</a></div>
        			<div><a href="#" class="fs3">Upload Your Inventory File</a></div>
        			<div><a href="#" class="fs3">Monitor Upload Status</a></div>
        			<div class="fs1">If you have your own catalogue file, use:</div>
        			<a href="#" class="fs3">Prepare Your Listings</a>
        			</div>
        		</div>
        	</div>
        </div>
        
    </div>
      </div>
      <div class="col-md-3 col-sm-3 col-xs-12">
        	<div class="widget">
        		<div class="widget-content">
        			<div class="hs2">Invenotry</div>
        			<h1 class="hs2" style="background: skyblue; padding: 5px">Draft Listings<span style="float: right;">...</span></h1>
        			<div class="fs2">Suppressed<span style="float: right;">64</span></div>
        			<hr>
        			<div class="fs2" style="text-align: center;"><a href="#">Manage Inventory</a></div>
        		</div>
        	</div>
        </div>
    </div>
    <div class="row" style="margin-top: 20px">
    	<div class="col-md-3 col-sm-3 col-xs-12">
    		<div class="widget widget-nopad">
            	<div class="widget-header">
            		<h3> Narrow your results</h3>
            	</div>
            	<!-- /widget-header -->
            	<div class="widget-content">
            		<ul style="list-style-type: none;">
            			<li style="color: #fed007">Categories</li>
            			<li><a href="#"><b>All Categories</b></a></li>
            			<li><a  id="#">Art Craft and Collectables</a></li>
                    	<li><a  id="#">Baby Items</a></li>
                    	<li><a  id="#">Beauty</a></li>
                    	<li><a  id="#">Bed and Bath</a></li>
                    	<li><a  id="#">Books</a></li>
                    	<li><a  id="#">Cameras</a></li>
                    	<li><a  id="#">Eyewear and Optics</a></li>
                    	<li><a  id="#">Computer IT and Networking</a></li>
                    	<li><a  id="#">Electronics</a></li>
                    	<li><a  id="#">Furniture</a></li>
                    	<li><a  id="#">Gaming</a></li>
                    	<li><a  id="#">Garden and Outdoors</a></li>
                    	<li><a  id="#">Grocery,Food and Beverages</a></li>
                    	<li><a  id="#">Health and Personal Care</a></li>
                    	<li><a  id="#">Home Appliances</a></li>
                    	<li><a  id="#">Home Decor and Furniture</a></li>
                    	<li><a  id="#">Jewellery and Accessories</a></li>
                    	<li><a  id="#">Kitchen Appliances</a></li>
                    	<li><a  id="#">Kitchen and Home Supplies</a></li>
                    	<li><a  id="#">Mobile Phone Tablet and Accessories</a></li>
                    	<li><a  id="#">Music and Movies</a></li>
                    	<li><a  id="#">Office Product and Supplies</a></li>
                    	<li><a  id="#">Perfume and Fragnances</a></li>
                    	<li><a  id="#">Pet Food and Supplies</a></li>
                    	<li><a  id="#">Sports and Fitness</a></li>
                    	<li><a  id="#">Tools and Home Improvements</a></li>
                    	<li><a  id="#">Toys</a></li>
            		</ul>

            	</div>
            </div>
    	</div>
    	<div class="col-md-6 col-sm-6 col-xs-12">
    		<div class="widget widget-nopad">
            	<div class="widget-header">
            		<h3> 1 of 10 of 2364 results</h3>
            	</div>
            	<!-- /widget-header -->
            	<div class="widget-content">
            		<table class="table" style="width: 100%">
            			<tbody>
            				<tr style="border-bottom: 1px solid #D5D5D5;">
            					<td><img src="<?= base_url(); ?>/image/cache/catalog/demo/product_05-199x201.jpg" alt="iMac" style="width: 100px; height: 100px"/></td>
            					<td>
            					<div class="fs3"> NOVIS Vita Juicer The 4-in-1 Juicer, Green Apple</div>
            					<div>35 new and used offers</div>
            					<div><a href="#">See all product details</a></div></td>
            					<td style="text-align: center;"><a href="#" class="btn btn-primary">Show Variations</a><p style="margin-top: 5px">(What's this?)</p></td>
            				</tr>
            				<tr style="border-bottom: 1px solid #D5D5D5;">
            					<td><img src="<?= base_url(); ?>/image/cache/catalog/demo/product_05-199x201.jpg" alt="iMac" style="width: 100px; height: 100px"/></td>
            					<td>
            					<div class="fs3"> NOVIS Vita Juicer The 4-in-1 Juicer, Green Apple</div>
            					<div>35 new and used offers</div>
            					<div><a href="#">See all product details</a></div></td>
            					<td style="text-align: center;"><a href="#" class="btn btn-primary">Show Variations</a><p style="margin-top: 5px">(What's this?)</p></td>
            				</tr>
            				<tr style="border-bottom: 1px solid #D5D5D5;">
            					<td><img src="<?= base_url(); ?>/image/cache/catalog/demo/product_05-199x201.jpg" alt="iMac" style="width: 100px; height: 100px"/></td>
            					<td>
            					<div class="fs3"> NOVIS Vita Juicer The 4-in-1 Juicer, Green Apple</div>
            					<div>35 new and used offers</div>
            					<div><a href="#">See all product details</a></div></td>
            					<td style="text-align: center;"><a href="#" class="btn btn-primary">Show Variations</a><p style="margin-top: 5px">(What's this?)</p></td>
            				</tr>
            				<tr style="border-bottom: 1px solid #D5D5D5;">
            					<td><img src="<?= base_url(); ?>/image/cache/catalog/demo/product_05-199x201.jpg" alt="iMac" style="width: 100px; height: 100px"/></td>
            					<td>
            					<div class="fs3"> NOVIS Vita Juicer The 4-in-1 Juicer, Green Apple</div>
            					<div>35 new and used offers</div>
            					<div><a href="#">See all product details</a></div></td>
            					<td style="text-align: center;"><a href="#" class="btn btn-primary">Show Variations</a><p style="margin-top: 5px">(What's this?)</p></td>
            				</tr>
            				<tr style="border-bottom: 1px solid #D5D5D5;">
            					<td><img src="<?= base_url(); ?>/image/cache/catalog/demo/product_05-199x201.jpg" alt="iMac" style="width: 100px; height: 100px"/></td>
            					<td>
            					<div class="fs3"> NOVIS Vita Juicer The 4-in-1 Juicer, Green Apple</div>
            					<div>35 new and used offers</div>
            					<div><a href="#">See all product details</a></div></td>
            					<td style="text-align: center;"><a href="#" class="btn btn-primary">Show Variations</a><p style="margin-top: 5px">(What's this?)</p></td>
            				</tr>
            				<tr style="border-bottom: 1px solid #D5D5D5;">
            					<td><img src="<?= base_url(); ?>/image/cache/catalog/demo/product_05-199x201.jpg" alt="iMac" style="width: 100px; height: 100px"/></td>
            					<td>
            					<div class="fs3"> NOVIS Vita Juicer The 4-in-1 Juicer, Green Apple</div>
            					<div>35 new and used offers</div>
            					<div><a href="#">See all product details</a></div></td>
            					<td style="text-align: center;"><a href="#" class="btn btn-primary">Show Variations</a><p style="margin-top: 5px">(What's this?)</p></td>
            				</tr>
            				<tr style="border-bottom: 1px solid #D5D5D5;">
            					<td><img src="<?= base_url(); ?>/image/cache/catalog/demo/product_05-199x201.jpg" alt="iMac" style="width: 100px; height: 100px"/></td>
            					<td>
            					<div class="fs3"> NOVIS Vita Juicer The 4-in-1 Juicer, Green Apple</div>
            					<div>35 new and used offers</div>
            					<div><a href="#">See all product details</a></div></td>
            					<td style="text-align: center;"><a href="#" class="btn btn-primary">Show Variations</a><p style="margin-top: 5px">(What's this?)</p></td>
            				</tr>
            				<tr style="border-bottom: 1px solid #D5D5D5;">
            					<td><img src="<?= base_url(); ?>/image/cache/catalog/demo/product_05-199x201.jpg" alt="iMac" style="width: 100px; height: 100px"/></td>
            					<td>
            					<div class="fs3"> NOVIS Vita Juicer The 4-in-1 Juicer, Green Apple</div>
            					<div>35 new and used offers</div>
            					<div><a href="#">See all product details</a></div></td>
            					<td style="text-align: center;"><a href="#" class="btn btn-primary">Show Variations</a><p style="margin-top: 5px">(What's this?)</p></td>
            				</tr>
            				<tr style="border-bottom: 1px solid #D5D5D5;">
            					<td><img src="<?= base_url(); ?>/image/cache/catalog/demo/product_05-199x201.jpg" alt="iMac" style="width: 100px; height: 100px"/></td>
            					<td>
            					<div class="fs3"> NOVIS Vita Juicer The 4-in-1 Juicer, Green Apple</div>
            					<div>35 new and used offers</div>
            					<div><a href="#">See all product details</a></div></td>
            					<td style="text-align: center;"><a href="#" class="btn btn-primary">Show Variations</a><p style="margin-top: 5px">(What's this?)</p></td>
            				</tr>
            				<tr style="border-bottom: 1px solid #D5D5D5;">
            					<td><img src="<?= base_url(); ?>/image/cache/catalog/demo/product_05-199x201.jpg" alt="iMac" style="width: 100px; height: 100px"/></td>
            					<td>
            					<div class="fs3"> NOVIS Vita Juicer The 4-in-1 Juicer, Green Apple</div>
            					<div>35 new and used offers</div>
            					<div><a href="#">See all product details</a></div></td>
            					<td style="text-align: center;"><a href="#" class="btn btn-primary">Show Variations</a><p style="margin-top: 5px">(What's this?)</p></td>
            				</tr>
            				<tr>
            					<td><img src="<?= base_url(); ?>/image/cache/catalog/demo/product_05-199x201.jpg" alt="iMac" style="width: 100px; height: 100px"/></td>
            					<td>
            					<div class="fs3"> NOVIS Vita Juicer The 4-in-1 Juicer, Green Apple</div>
            					<div>35 new and used offers</div>
            					<div><a href="#">See all product details</a></div></td>
            					<td style="text-align: center;"><a href="#" class="btn btn-primary">Show Variations</a><p style="margin-top: 5px">(What's this?)</p></td>
            				</tr>
            			</tbody>
            		</table>
            	</div>
            </div>
    	</div>
    </div>
  </div>
</div>

</div>