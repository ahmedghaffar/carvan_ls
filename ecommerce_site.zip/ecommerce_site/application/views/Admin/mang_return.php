  <div class="main fs3">
    <div class="main-inner">
      <div class="container-fluid">
          <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="dropdown">
                <button class="dropdown-toggle hs1 btn btn-primary" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  Manage Returns
                </button>
                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                  <a class="dropdown-item" href="orders">Orders</a>
                  <a class="dropdown-item" href="morder">Manage Orders</a>
                </div>
              </div> 
              <div class="widget widget-nopad"  style="margin-top: 20px">
                <div class="widget-header">
                  <div class="col-md-4 col-sm-4 col-xs-12">
                    <ul style="list-style-type: none;">
                      <li class="fs3">Requested: <span class="fs2">4 days ago</span></li>
                      <li class="fs3">Ordered: <span class="fs2">9 days ago</span></li>
                    </ul>
                  </div>
                  <div class="col-md-4 col-sm-4 col-xs-12">
                    <ul style="list-style-type: none">
                      <li class="fs3">Buyer: <span class="fs2">Anne Hutchison</span></li>
                      <li><a href="#">Communication History</a></li>
                    </ul>
                  </div>
                  <div class="col-md-4 col-sm-4 col-xs-12">
                    <ul style="list-style-type: none">
                      <li class="fs3">Order ID: <span class="fs2"><a href="#">026-9734298-87348</a></span></li>
                      <li class="fs3">RMA: <span class="fs2">RMA will be generated once authorised</span></li>
                    </ul>
                  </div>
                </div>
                <!-- /widget-header -->
                  <div class="widget-content">
                  <div class="col-md-3 col-sm-3 col-xs-12">
                    <div class="fs3">Return Reason: <span class="fs2">No longer needed</span></div>
                    <img src="<?= base_url(); ?>/image/cache/catalog/demo/product_12-199x201.jpg" alt="MacBook" class="img-responsive" />
                    <div class="fs3"><a href="#">&gt;&nbsp; View more details</a></div>
                  </div>
                  <div class="col-md-6 col-sm-6 col-xs-12">
                    <p>H-Cube Furniture Cube Design Divan Bed Base Headboard Turin/Linen Fabric Matching/Buttons - (Grey - 5FT) </p>
                    <div>Return Quantity: <span class="fs2">1</span></div>
                    <div>Buyer Comment: <span class="fs2">Too small</span></div>
                  </div>
                  <div class="col-md-3 col-sm-3 col-xs-12 pull-right">
                    <button href="#" class="btn btn-primary" style="width: 80%">Authorize</button>
                    <button href="#" class="btn btn-primary" style="width: 80%">Deny request</button>
                    <button href="#" class="btn btn-primary" style="width: 80%">Issue refund</button>
                    <button href="#" class="btn btn-primary" style="width: 80%">Contact buyer</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="container-fluid">
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12" style="margin-top: 20px"> 
            <div class="widget widget-nopad">
              <div class="widget-header">
                <div class="col-md-4 col-sm-4 col-xs-12">
                  <ul style="list-style-type: none;">
                    <li class="fs3">Requested: <span class="fs2">4 days ago</span></li>
                    <li class="fs3">Ordered: <span class="fs2">9 days ago</span></li>
                  </ul>
                </div>
                <div class="col-md-4 col-sm-4 col-xs-12">
                  <ul style="list-style-type: none">
                    <li class="fs3">Buyer: <span class="fs2">Anne Hutchison</span></li>
                    <li><a href="#">Communication History</a></li>
                  </ul>
                </div>
                <div class="col-md-4 col-sm-4 col-xs-12">
                  <ul style="list-style-type: none">
                    <li class="fs3">Order ID: <span class="fs2"><a href="#">026-9734298-87348</a></span></li>
                    <li class="fs3">RMA: <span class="fs2">RMA will be generated once authorised</span></li>
                  </ul>
                </div>
              </div>
              <!-- /widget-header -->
              <div class="widget-content">
                <div class="col-md-3 col-sm-3 col-xs-12">
                  <div class="fs3">Return Reason: <span class="fs2">No longer needed</span></div>
                  <img src="<?= base_url(); ?>/image/cache/catalog/demo/product_12-199x201.jpg" alt="MacBook" class="img-responsive" />
                  <div class="fs3"><a href="#">&gt;&nbsp; View more details</a></div>
                </div>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <p>H-Cube Furniture Cube Design Divan Bed Base Headboard Turin/Linen Fabric Matching/Buttons - (Grey - 5FT) </p>
                  <div>Return Quantity: <span class="fs2">1</span></div>
                  <div>Buyer Comment: <span class="fs2">Too small</span></div>
                </div>
                <div class="col-md-3 col-sm-3 col-xs-12 pull-right">
                  <button href="#" class="btn btn-primary" style="width: 80%">Authorize</button>
                  <button href="#" class="btn btn-primary" style="width: 80%">Deny request</button>
                  <button href="#" class="btn btn-primary" style="width: 80%">Issue refund</button>
                  <button href="#" class="btn btn-primary" style="width: 80%">Contact buyer</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>