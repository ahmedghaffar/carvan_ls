

<style type="text/css">
	.drop{

		width:180px;
	}

</style>



<div class="main">
  	<div class="main-inner">
    	<div class="container-fluid">
        <div class="row">
          <div class="span12 col-md-12  col-sm-12  col-xs-12">
					<div class="hs1">Sales Dashboard <span class="fs2"><a href="#">Learn More</a></span></div>
					<span><a href="#">Tell Us What you think of this new feature</a></span>
					
				</div>
			</div>
		



		<div class="span12 col-md-12  col-sm-12  col-xs-12">
			<div class="row">
				<div class="span2 col-md-2  col-sm-2  col-xs-12">
					<div>
						<h3>Date</h3>
						<select class="drop">
							<option>level 1</option>
							<option>level 1</option>
							<option>level 1</option>
							<option>level 1</option>
						</select>
					</div>
				</div>


				<div class="span2  col-md-2 col-sm-2  col-xs-12">
					<div>
						<h3>Sales breakdown</h3>
						<select class="drop">
							<option>level 1</option>
							<option>level 1</option>
							<option>level 1</option>
							<option>level 1</option>
						</select>
					</div>
				</div>



				<div class="span2 col-md-2  col-sm-2  col-xs-12">
					<div>
						<h3>Product Category</h3>
						<select class="drop">
							<option>level 1</option>
							<option>level 1</option>
							<option>level 1</option>
							<option>level 1</option>
						</select>
					</div>
				</div>




				<div class="span2 col-md-2  col-sm-2  col-xs-12" >
					<div>
						<h3>Fullfilment channel</h3>
						<select class="drop">
							<option>level 1</option>
							<option>level 1</option>
							<option>level 1</option>
							<option>level 1</option>
						</select>
					</div>
				</div>

				<div class="span2 col-md-2  col-sm-2  col-xs-12">
					<div style="    margin-top: 29px;">
						<a href="#" class="btn btn-primary">Apply</a>
					</div>
				</div>		
</div>
			</div>
		</div>

		<div class="row">
        			<div class="span12 col-md-12  col-sm-12  col-xs-12">
          				<div class="widget widget-nopad">
            				<div class="widget-header">
            					<h3 class="hsv2">Sales Snapshots<span> taken at 30 september 2018 15:22:02 BDT</span></h3>

            				</div>

            					<div class="widget-content">
              					
			                        <div class="row">
			                        <div class="span3 col-md-2  col-sm-2  col-xs-12" >
            				 <div class="widget-content" style="padding: 10px;">
                        <p>Total Order Items<br><b> 0 </b> </p>
                    </div>
                </div>

                		<div class="span2 col-md-2  col-sm-2  col-xs-12" >
                     <div class="widget-content" style="padding: 10px;">
                        <p>Units Ordered<br> <b> 0 </b>  </p>
                    </div>
                </div>
                	<div class="span2 col-md-2  col-sm-2  col-xs-12" >
                     <div class="widget-content" style="padding: 10px;">
                        <p>Oredered Product Sale<br><b> $0 </b> </p>
                    </div>
                </div>
                		<div class="span2 col-md-2  col-sm-2  col-xs-12" >
                     <div class="widget-content" style="padding: 10px;">
                        <p>Average Unit/order Item<br><b> 0 </b>  </p>
                    </div>
                </div>

                <div class="span2 col-md-2  col-sm-2  col-xs-12" >
                     <div class="widget-content" style="padding: 10px;">
                        <p>Average Sale Order Item<br><b> $.000 </b>  </p>
                    </div>
                </div>


                    	</div>
                    </div>


                    <div class="row">

                    
                    	<div class="span6 col-md-6  col-sm-6  col-xs-12">
                       
                           
                        <div class="widget">
                            <div class="widget-header">
                                <i class="icon-bar-chart"></i>
                                <h3>
                                    Line Chart</h3>
                            </div>
                            <!-- /widget-header -->
                            <div class="widget-content">
                                <canvas id="area-chart" class="chart-holder" width="538" height="auto" style="width: 538px; height: auto">
                                </canvas>
                                <!-- /line-chart -->
                            </div>
                            <!-- /widget-content -->
                        </div>


                       
                        <!-- /widget -->
                    </div>
                    <div class="span6 col-md-6  col-sm-6  col-xs-12">
                       
                           
                        <div class="widget">
                            <div class="widget-header">
                                <i class="icon-bar-chart"></i>
                                <h3>
                                    Line Chart</h3>
                            </div>
                            <!-- /widget-header -->
                            <div class="widget-content">
                                <canvas id="pie-chart" class="chart-holder" width="538" height="auto" style="height: auto;">
                                </canvas>
                                <!-- /line-chart -->
                            </div>
                            <!-- /widget-content -->
                        </div>

                        
                       
                        <!-- /widget -->
                    </div>


                </div>

            			</div>
            		</div>
            	</div>

						
	</div>
	</div>
	</div>
