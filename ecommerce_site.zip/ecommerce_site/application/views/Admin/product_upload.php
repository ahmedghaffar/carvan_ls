<div class="main fs3">
  	<div class="main-inner">
    	<div class="container-fluid">
      		<div class="row">
        		<div class="col-md-12 col-sm-12 col-xs-12">
          			<h1 class="hs1">Add Product Via Upload</h1>
          			<h3 class="hs2">Upload your Inventory File</h3><hr>
          		</div>
          	</div>
      		<div class="row">
        		<div class="col-md-9 col-sm-9 col-xs-12">
          			<div class="widget">
          				<div class="widget-header">
          					<h3 class="fs2"> STEP 1 - CHECK YOUR FILE</h3>
          				</div>
          				<div class="widget-content" class="fs3">
          					<p>This feature will not add products to your catalogue.</p>
          					<table>
          						<thead>
          							<tr>
          								<th style="float: right;"></th>
          								<th style="width: 65%; "></th>
          							</tr>
          						</thead>
          						<tbody>
          							<tr>
          								<td style="float: right; padding-right: 5%" class="fs2">Use Check My File to</td>
          								<td>
          									<ul>
          										<li>Automatically configure variations</li>
          										<li>Check for common listing errors in your inventory file.</li>
          									</ul>
          								</td>
          							</tr>
          							<tr>
          								<td style="float: right; padding-right: 5%" class="fs2">File type</td>
          								<td>
          									<select>
          										<option>Inventory Files for non-Media Categories</option>
          										<option>option1</option>
          										<option>option2</option>
          										<option>option3</option>
          									</select>
          									<div>Ut enim ad minim veniam,
          									quis nostrud exercitation ullamco laboris nis ut aliquip ex ea commodo
          									consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
          									cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
          									<br>
          									<a href="#">Learn more</a>
          									</div>
          									<input type="file" name="imag" >
          								</td>
          							</tr>
          							<tr>
          								<td style="float: right; padding-right: 5%" class="fs2">File to check</td>
          								<td>
          									Ut enim ad minim veniam,
          									quis nostrud exercitation ullamco laboris nis ut aliquip ex ea commodo
          									consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
          									cillum dolore eu fugiat nulla pariatur.
          								</td>
          							</tr>
          							<tr>
          								<td style="float: right; padding-right: 5%" class="fs2"><u>Email Alert</u></td>
          								<td>
          									Send me an email alert <input type="Email" name="email">&nbsp;when my upload is complete
          								</td>
          							<tr><td></td><td>&nbsp;</td></tr>
          							</tr>
          							<tr>
          								<td></td>
          								<td><a href="#" class="btn btn-primary">Check my file</a></td>
          							</tr>
          						</tbody>
          					</table>
          				</div>
          			</div>
          		</div>
          		<div class="col-md-3 col-sm-3 col-xs-12">
          			<div class="widget">
          				<div class="widget-header">
          					<h3 class="fs2"> FAQS</h3>
          				</div>
          				<div class="widget-content" class="fs3">
          					<ul>
          						<li><a href="#">How do I bulk activate suppressed listings?</a></li>
          						<li><a href="#">Upload your Inventory File</a></li>
          						<li><a href="#">How do I use the different inventory templates?</a></li>
          						<li><a href="#">How do I delete specific product listings, or replace all my listings</a></li>
          						<li><a href="#">What is Check My File and how it can help fix my Inventory File errors?</a></li>
          					</ul>	
          				</div>
          			</div>
          		</div>
          		<div class="col-md-3 col-sm-3 col-xs-12" style="margin-top: 20px">
          			<div class="widget">
          				<div class="widget-header">
          					<h3 class="fs2"> RELATED TOPICS</h3>
          				</div>
          				<div class="widget-content" class="fs3">
          					<ul>
          						<li><a href="#">Build My Inventory File</a></li>
          						<li><a href="#">Modify My Inventory File</a></li>
          						<li><a href="#">Update my Price and Inventory</a></li>
          						<li><a href="#">Upload My Inventory File</a></li>
          						<li><a href="#">Using the Check My File Feature</a></li>
          					</ul>
          				</div>
          			</div>
          		</div>
          		<div class="col-md-9 col-sm-9 col-xs-12" style="margin-top: 20px">
          			<div class="widget">
          				<div class="widget-header">
          					<h3 class="fs2"> STEP 2 - UPLOAD FILE</h3>
          				</div>
          				<div class="widget-content" class="fs3">
          					<table>
          						<thead>
          							<tr>
          								<th style="float: right;"></th>
          								<th style="width: 65%; "></th>
          							</tr>
          						</thead>
          						<tbody>
          							<tr>
          								<td style="float: right; padding-right: 5%" class="fs2">File type</td>
          								<td>
          									<select>
          										<option>Inventory Files for non-Media Categories</option>
          										<option>option1</option>
          										<option>option2</option>
          										<option>option3</option>
          									</select>
          									<div>Ut enim ad minim veniam,
          									quis nostrud exercitation ullamco laboris nis ut aliquip ex ea commodo
          									consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
          									cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
          									<br>
          									<a href="#">Learn more</a>
          									</div>
          									<input type="file" name="imag" >
          								</td>
          							</tr>
          							<tr>
          								<td style="float: right; padding-right: 5%" class="fs2">File to check</td>
          								<td>
          									Ut enim ad minim veniam,
          									quis nostrud exercitation ullamco laboris nis ut aliquip ex ea commodo
          									consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
          									cillum dolore eu fugiat nulla pariatur.
          								</td>
          							</tr>
          							<tr>
          								<td style="float: right; padding-right: 5%" class="fs2"><u>Email Alert</u></td>
          								<td>
          									Send me an email alert <input type="Email" name="email">&nbsp;when my upload is complete
          								</td>
          							<tr>
          								<td style="float: right; padding-right: 5%" class="fs2">Processing Report (Output) Format</td>
          								<td>
          									<div class="col-md-3">
          										<input type="radio" name="slct" value="excel">Excel - Recommended<br>
          										<input type="radio" name="slct" value="text">Text
          									</div>
          									<div class="col-md-9" style="line-height: normal;">
          										Ut enim ad minim veniam,
          									quis nostrud exercitation ullamco laboris nis ut aliquip ex ea commodo
          									consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
          									</div>
          								</td>
          								<!-- <td>
          									
          								</td> -->
          							</tr>
          							<tr>
          								<td></td><td>&nbsp;</td></tr>
          							</tr>
          							<tr>
          								<td></td>
          								<td><a href="#" class="btn btn-primary">Upload</a></td>
          							</tr>
          						</tbody>
          					</table>
          				</div>
          			</div>
          		</div>
          	</div>
        </div>
    </div>
</div>
