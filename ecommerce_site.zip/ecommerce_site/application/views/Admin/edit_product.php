
<!DOCTYPE html>
<html lang="en">
  
 <head>
    <meta charset="utf-8">
    <title>Carrovan/ Add Product</title>

    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="apple-mobile-web-app-capable" content="yes"> 
    
<link href="<?= base_url(); ?>assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
<link href="<?= base_url(); ?>assets/css/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />

<link href="<?= base_url(); ?>assets/css/font-awesome.css" rel="stylesheet">
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600" rel="stylesheet">
    
<link href="<?= base_url(); ?>assets/css/style.css" rel="stylesheet" type="text/css">
<link href="<?= base_url(); ?>assets/css/pages/signin.css" rel="stylesheet" type="text/css">

      <link rel="stylesheet" href="<?= base_url(); ?>assets/tcss/style.css">

<!-- 
<style type="text/css">

    @media (min-width:768px){
        #msform{
            width: 70% !important;
            margin-left: 15% !important;
        }
    }
</style> -->
<style type="text/css">
    #myform1{
        display: none;
        position: absolute;
    }#myform1a{
        display: none;
        position: absolute;
    }#myform1b{
        display: none;
        position: absolute;
    }#myform1c{
        display: none;
        position: absolute;
    }#myform1d{
        display: none;
        position: absolute;
    }
    #myform2{
        display: none;
        position: absolute;
    }
    #myform3{
        display: none;
        position: absolute;
    }
    #myform4{
        display: none;
        position: absolute;
    }
    #myform5{
        display: none;
        position: absolute;
    }
    #myform5a{
        display: none;
        position: absolute;
    }
    #myform6{
        display: none;
        position: absolute;
    }
    #myform6a{
        display: none;
        position: absolute;
    }
    #myform6b{
        display: none;
        position: absolute;
    }
    #myform6c{
        display: none;
        position: absolute;
    }
    #myform7{
        display: none;
        position: absolute;
    }
    #myform8{
        display: none;
        position: absolute;
    }
    #myform8a{
        display: none;
        position: absolute;
    }
    #myform8b{
        display: none;
        position: absolute;
    }
    #myform8c{
        display: none;
        position: absolute;
    }
    #myform9{
        display: none;
        position: absolute;
    }
    #myform10{
        display: none;
        position: absolute;
    }
    #myform11{
        display: none;
        position: absolute;
    }
    #myform12{
        display: none;
        position: absolute;
    }
    #myform13{
        display: none;
        position: absolute;
    }
    #myform14{
        display: none;
        position: absolute;
    }
    #myform15{
        display: none;
        position: absolute;
    }
    #myform16{
        display: none;
        position: absolute;
    }
.footer{
    position: fixed !important;
}
#msform{
    margin-bottom: 55px;
}
</style>

</head>

<body style="min-height: 100%; position: relative;">
    
    
<div class="navbar">
    <div class="navbar-inner">
        <div class="container">
            
            <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </a>
            
            <a class="brand" href="index.html">
                Carrovan    
            </a>        
            
            <div class="nav-collapse">
                <ul class="nav pull-right">
                    <li class="dropdown">                       
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                            <i class="icon-cog"></i>
                            Account
                            <b class="caret"></b>
                        </a>
                        
                        <ul class="dropdown-menu">
                            <li><a href="javascript:;">Settings</a></li>
                            <li><a href="javascript:;">Help</a></li>
                        </ul>                       
                    </li>
            
                    <li class="dropdown">                       
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                            <i class="icon-user"></i> 
                            Kamran
                            <b class="caret"></b>
                        </a>
                        
                        <ul class="dropdown-menu">
                            <li><a href="javascript:;">Profile</a></li>
                            <li><a href="javascript:;">Logout</a></li>
                        </ul>                       
                    </li>
                </ul>
            
                <form class="navbar-search pull-right">
                    <input type="text" class="search-query" placeholder="Search">
                </form>
                
            </div><!--/.nav-collapse -->    
    
        </div> <!-- /container -->
        
    </div> <!-- /navbar-inner -->
    
</div> <!-- /navbar -->
    



    
<div class="subnavbar">
  <div class="subnavbar-inner">
    <div class="container">
      <ul class="mainnav">
        <li><a href="index.php"><span>Dashboard</span> </a> </li>
        <li><a href="msg.php"><span>Messages</span> </a> </li>
        <li><a href="Inventory.php"><span>Inventory</span> </a> </li>
        <li><a href="reports.php"><span>Reports</span> </a></li>
        <li><a href="orders.php"><span style="margin-top: 28%">Performance</span> </a> </li>
        <li class="active"><a href="products.php"><span>Store</span> </a> </li>
            
            </ul>

        </div> <!-- /container -->
    
    </div> <!-- /subnavbar-inner -->

</div> <!-- /subnavbar -->
    


  <!-- MultiStep Form -->
<div class="container">
    <div class="col-md-2">
        <div class="dropdown">
        <!-- <a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown" style="padding: 10px; background: black; color: white"><span>All Categories</span> <b class="caret"></b></a>
         -->    <!-- /widget-header -->
            <!-- <div class="dropdown-menu">
                <ul style="list-style-type: none ">
                    <li><a  id="mylink1">Art Craft and Collectables</a></li>
                    <li><a  id="mylink1a">Baby Items</a></li>
                    <li><a  id="mylink1b">Beauty</a></li>
                    <li><a  id="mylink1c">Bed and Bath</a></li>
                    <li><a  id="mylink1d">Books</a></li>
                    <li><a  id="mylink2">Cameras</a></li>
                    <li><a  id="mylink3">Eyewear and Optics</a></li>
                    <li><a  id="mylink4">Computer IT and Networking</a></li>
                    <li><a  id="mylink5">Electronics</a></li>
                    <li><a  id="mylink6">Furniture</a></li>
                    <li><a  id="mylink7">Gaming</a></li>
                    <li><a  id="mylink6a">Garden and Outdoors</a></li>
                    <li><a  id="mylink8">Grocery,Food and Beverages</a></li>
                    <li><a  id="mylink9">Health and Personal Care</a></li>
                    <li><a  id="mylink5a">Home Appliances</a></li>
                    <li><a  id="mylink6b">Home Decor and Furniture</a></li>
                    <li><a  id="mylink10">Jewellery and Accessories</a></li>
                    <li><a  id="mylink11">Kitchen Appliances</a></li>
                    <li><a  id="mylink6c">Kitchen and Home Supplies</a></li>
                    <li><a  id="mylink12">Mobile Phone Tablet and Accessories</a></li>
                    <li><a  id="mylink8a">Music and Movies</a></li>
                    <li><a  id="mylink13">Office Product and Supplies</a></li>
                    <li><a  id="mylink8b">Perfume and Fragnances</a></li>
                    <li><a  id="mylink8c">Pet Food and Supplies</a></li>
                    <li><a  id="mylink14">Sports and Fitness</a></li>
                    <li><a  id="mylink15">Tools and Home Improvements</a></li>
                    <li><a  id="mylink16">Toys</a></li>
                </ul>
            </div> -->
        </div>
    </div>
<!--     <iframe id="myform" name="myform" aria->
 -->    <div class="col-md-8" id="myform1">
        <form id="msform" method="post" action="<?= base_url();?>/index.php/Admin/update_category1/<?= $results->id;?>" enctype='multipart/form-data'>
            <!-- progressbar -->
            <ul id="progressbar">
                <li class="active">Basic Info</li>
                <li>Additional</li>
                <li>Offers</li>
                <li>Images</li>
                <li>Description</li>
            </ul>
            <!-- fieldset  style="text-align: left;" s -->
            <fieldset  style="text-align: left;">
                <h2 class="fs-title">Basic Information Of Product</h2>
                <label class="hs2" style="text-align: center;">Art Craft and Colactables</label>
                 <label id="label1" style="display: none; color: red">Some Thing Went wrong Please see erros Below and Fill Form again</label>

                 <input type="hidden" name="category" value="Art Craft and Colactables">
                <label>Sub-Category</label>
                <select name="sub-category">
                    <option><?=$results->sub_category;?></option>
                    <option>Antiques</option>
                    <option>Drawing and Paintings</option>
                    <option>Handcrafts, Scupture and Carvings</option>
                    <option>Islamic</option>
                    <option>Prints and Posters</option>
                </select>
                <label for="pid">Seller SKU</label>
                <input type="text" name="sku" id="sku" value="<?=$results->sku;?>">
                <lable style="color: red"><?php echo form_error('sku'); ?></lable>
                <label>Item Title</label>
                <input type="text" name="it" value="<?=$results->title;?>">
                <lable style="color: red"><?php echo form_error('title'); ?></lable>

                <label>Item Code</label>
                <input type="text" name="ic" value="<?=$results->code;?>">
<lable style="color: red"><?php echo form_error('ic'); ?></lable>
                <label>Brand Name</label>
                <input type="text" name="bn" value="<?=$results->brand;?>">
<lable style="color: red"><?php echo form_error('bn'); ?></lable>
                <label>Manufacturer</label>
                <input type="text" name="manuf" value="<?=$results->manufacturer;?>">
                <lable style="color: red"><?php echo form_error('manuf'); ?></lable>
                <label>Color</label>
                <select name="color">
                    <option><?=$results->color;?></option>
                    <option>White</option>
                    <option>Black</option>
                    <option>Blue</option>
                    <option>Red</option>
                </select>
                <label>Dimension</label>
                <input type="text" name="dimension" value="<?=$results->dimension;?>">
<lable style="color: red"><?php echo form_error('dimension'); ?></lable>
                <label>Weight</label>
                <input type="text" name="weight" value="<?=$results->weight;?>">
                                <lable style="color: red"><?php echo form_error('weight'); ?></lable>

                <input type="button" name="next" class="next action-button" value="Next" style="float: right">
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"  >
                <h2 class="fs-title">Additional Attributes</h2>
                <label>Targeted Audience Sex</label>
                <select name="sex">
                    <option><?=$results->sex;?></option>
                    <option>Male</option>
                    <option>Female</option>
                    <option>Both</option>
                </select>
                <label>Is the Item Expirable</label>
                <input type="radio" name="expiry" value="yes" id="myradio1">Yes
                <input type="radio" name="expiry" value="no" id="myradio2">No
               
                <label>Battery Required</label>
                          
                <input type="radio" name="battery" value="yes" id="myradio3"  style="text-align: center">Yes
                <input type="radio" name="battery" value="no" id="myradio4" style="text-align: center">No
                      
                <input style="float: right" type="button" name="next" class="next action-button" value="Next"/>
                <input style="float: right" type="button" name="previous" class="previous action-button-previous" value="Previous"/>
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Offers of Product</h2>
                <label>Currancy</label>
                <input type="text" name="currency" value="<?=$results->currency;?>">
                <label>Sponsered</label>
                <input type="text" name="sponsered" value="<?=$results->sponsered;?>">
                <label>Unit of Measurement</label>
                <input type="text" name="uom" value="<?=$results->uom;?>">
                <label>Available Quantity</label>
                <input type="text" name="quantity" value="<?=$results->quantity;?>">
                <label>Unit Price</label>
                <input type="text" name="uprice" value="<?=$results->uprice;?>">
                <label class="con" style="text-align: left;">Condition</label>
                <select name="cond" class="con" >
                    <option style="color: #2C3E50;"><?=$results->cond;?></option>
                    <option>New</option>
                    <option>Used</option>
                    <option>Open Packet</option>
                </select>
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right"/>
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right"/>
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <label>Choose Images</label>
                <input type="file" name="image" multiple="multiple">
                <label><?=$results->image;?>"</label>
                <input type="button" name="next" class="next action-button" value="Next" style="float: right;" />    
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right;"/>            

            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Description of Product</h2>
                <label>Product Description</label>
                <textarea name="pd" placeholder="Enter Product Description Here..."><?=$results->pd;?></textarea>
                <lable style="color: red"><?php echo form_error('pd'); ?></lable>
                <label>Key Product Features</label>
                    <input type="text" name="keyf1" value="<?=$results->keyf1;?>">
                    <input type="text" name="keyf2" value="<?=$results->keyf2;?>">
                    <input type="text" name="keyf3" value="<?=$results->keyf3;?>">
                    <input type="text" name="keyf4" value="<?=$results->keyf4;?>">
                    <input type="text" name="keyf5" value="<?=$results->keyf5;?>">
                <label>Additional Information</label>
                    <textarea name="ld" placeholder="Enter Legal Disclaimer Here..."><?=$results->ld;?></textarea>
                
                <input type="submit" name="Submit" class="action-button" value="Submit" style="float: right;" />
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right;"/>
            </fieldset  style="text-align: left;">
        </form>
    </div>
<!-- /.MultiStep Form -->

<div class="col-md-8" id="myform1a">
        <form id="msform" method="post" action="add_post" enctype='multipart/form-data'>
            <!-- progressbar -->
            <ul id="progressbar">
                <li class="active">Basic Info</li>
                <li>Additional</li>
                <li>Offers</li>
                <li>Images</li>
                <li>Description</li>
            </ul>
            <!-- fieldset  style="text-align: left;" s -->
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Basic Information Of Product</h2>
                <label class="hs2" style="text-align: center;">Baby Items</label>
                <input type="hidden" name="Art" value="C02">
                <label>Sub-Category</label>
                <select name="sub-category">
                    <option value="SC02001">Baby Accessories</option>
                    <option value="SC02002">Baby Bags</option>
                    <option value="SC02003">Baby Bath and Skin Care</option>
                    <option value="SC02004">Baby Clothing and Shoes</option>
                    <option value="SC02005">Baby Gear</option>
                    <option value="SC02006">Baby Gift Sets</option>
                    <option value="SC02007">Baby Safety and Health</option>
                    <option value="SC02008">Baby Toys and Accessories</option>
                    <option value="SC02009">Diapers</option>
                    <option value="SC02010">Feeding</option>
                </select
                <label for="pid">Seller SKU</label>
                <input type="text" name="sku" id="sku">
                <label>Item Title</label>
                <input type="text" name="it" >
                <label>Item Code</label>
                <input type="text" name="ic">
                <label>Brand Name</label>
                <input type="text" name="bn">
                <label>Manufacturer</label>
                <input type="text" name="manuf">
                <label>Color</label>
                <select >
                    <option>White</option>
                    <option>Black</option>
                    <option>Blue</option>
                    <option>Red</option>
                </select>
                <label>Dimension</label>
                <input type="text" name="dimension">
                <label>Weight</label>
                <input type="text" name="weight">
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right">
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"  >
                <h2 class="fs-title">Additional Attributes</h2>
                <label>Targeted Audience Sex</label>
                <select>
                    <option>---Select---</option>
                    <option>Male</option>
                    <option>Female</option>
                    <option>Both</option>
                </select>
                <label>Is the Item Expirable</label>
                <input type="radio" name="expiry" value="yes">Yes
                <input type="radio" name="expiry" value="no">No
                <label>Battery Required</label>
                <input type="radio" name="battery" value="yes">Yes
                <input type="radio" name="battery" value="no">No
                
                <input style="float: right" type="button" name="next" class="next action-button" value="Next"/>
                <input style="float: right" type="button" name="previous" class="previous action-button-previous" value="Previous"/>
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Offers of Product</h2>
                <label>Currancy</label>
                <input type="text" name="currency">
                <label>Sponsered</label>
                <input type="text" name="sponsered">
                <label>Unit of Measurement</label>
                <input type="text" name="uom">
                <label>Available Quantity</label>
                <input type="text" name="quantity">
                <label>Unit Price</label>
                <input type="text" name="uprice">
                <label class="con" style="text-align: left;">Condition</label>
                <select name="cond" class="con">
                    <option style="color: #2C3E50;">List Of Value</option>
                    <option>New</option>
                    <option>Used</option>
                    <option>Open Packet</option>
                </select>
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right"/>
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right"/>
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <label>Choose Images</label>
                <input type="file" name="image" multiple="multiple">
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right;" />    
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right;"/>            

            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Description of Product</h2>
                <label>Product Description</label>
                <textarea name="pd" placeholder="Enter Product Description Here..."></textarea>
                <label>Key Product Features</label>
                    <input type="text" name="keyf1">
                    <input type="text" name="keyf2">
                    <input type="text" name="keyf3">
                    <input type="text" name="keyf4">
                    <input type="text" name="keyf5">
                <label>Additional Information</label>
                    <textarea name="ld" placeholder="Enter Legal Disclaimer Here..."></textarea>
                
                <input type="submit" name="Submit" class="action-button" value="Submit" style="float: right;" />
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right;"/>
            </fieldset  style="text-align: left;" >
        </form>
    </div>
<!-- /.MultiStep Form -->

<div class="col-md-8" id="myform1b">
        <form id="msform" method="post" action="add_post" enctype='multipart/form-data'>
            <!-- progressbar -->
            <ul id="progressbar">
                <li class="active">Basic Info</li>
                <li>Additional</li>
                <li>Offers</li>
                <li>Images</li>
                <li>Description</li>
            </ul>
            <!-- fieldset  style="text-align: left;" s -->
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Basic Information Of Product</h2>
                <label class="hs2" style="text-align: center;">Beauty</label>
                <input type="hidden" name="Art" value="C03">
                <label>Sub-Category</label>
                <select>
                    <option value="SC03001">Beauty Gift Sets</option>
                    <option value="SC03002">Beauty Tools and Accessories</option>
                    <option value="SC03003">Hair Care tools and Accessories</option>
                    <option value="SC03004">Makeup</option>
                    <option value="SC03005">Mirrors</option>
                    <option value="SC03006">Skin Care</option>
                    <option value="SC03007">Wigs</option>
                </select>
                <label for="pid">Seller SKU</label>
                <input type="text" name="sku" id="sku">
                <label>Item Title</label>
                <input type="text" name="it" >
                <label>Item Code</label>
                <input type="text" name="ic">
                <label>Brand Name</label>
                <input type="text" name="bn">
                <label>Manufacturer</label>
                <input type="text" name="manuf">
                <label>Color</label>
                <select>
                    <option>White</option>
                    <option>Black</option>
                    <option>Blue</option>
                    <option>Red</option>
                </select>
                <label>Dimension</label>
                <input type="text" name="dimension">
                <label>Weight</label>
                <input type="text" name="weight">
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right">
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"  >
                <h2 class="fs-title">Additional Attributes</h2>
                <label>Targeted Audience Sex</label>
                <select>
                    <option>---Select---</option>
                    <option>Male</option>
                    <option>Female</option>
                    <option>Both</option>
                </select>
                <label>Is the Item Expirable</label>
                <input type="radio" name="expiry" value="yes">Yes
                <input type="radio" name="expiry" value="no">No
                <label>Battery Required</label>
                <input type="radio" name="battery" value="yes">Yes
                <input type="radio" name="battery" value="no">No
                
                <input style="float: right" type="button" name="next" class="next action-button" value="Next"/>
                <input style="float: right" type="button" name="previous" class="previous action-button-previous" value="Previous"/>
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Offers of Product</h2>
                <label>Currancy</label>
                <input type="text" name="currency">
                <label>Sponsered</label>
                <input type="text" name="sponsered">
                <label>Unit of Measurement</label>
                <input type="text" name="uom">
                <label>Available Quantity</label>
                <input type="text" name="quantity">
                <label>Unit Price</label>
                <input type="text" name="uprice">
                <label class="con" style="text-align: left;">Condition</label>
                <select name="cond" class="con">
                    <option style="color: #2C3E50;">List Of Value</option>
                    <option>New</option>
                    <option>Used</option>
                    <option>Open Packet</option>
                </select>
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right"/>
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right"/>
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <label>Choose Images</label>
                <input type="file" name="image" multiple="multiple">
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right;" />    
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right;"/>            

            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Description of Product</h2>
                <label>Product Description</label>
                <textarea name="pd" placeholder="Enter Product Description Here..."></textarea>
                <label>Key Product Features</label>
                    <input type="text" name="keyf1">
                    <input type="text" name="keyf2">
                    <input type="text" name="keyf3">
                    <input type="text" name="keyf4">
                    <input type="text" name="keyf5">
                <label>Additional Information</label>
                    <textarea name="ld" placeholder="Enter Legal Disclaimer Here..."></textarea>
                
                <input type="submit" name="Submit" class="action-button" value="Submit" style="float: right;" />
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right;"/>
            </fieldset style="text-align: left;" >
        </form>
    </div>
<!-- /.MultiStep Form -->

<div class="col-md-8" id="myform1c">
        <form id="msform" method="post" action="add_post" enctype='multipart/form-data'>
            <!-- progressbar -->
            <ul id="progressbar">
                <li class="active">Basic Info</li>
                <li>Additional</li>
                <li>Offers</li>
                <li>Images</li>
                <li>Description</li>
            </ul>
            <!-- fieldset  style="text-align: left;" s -->
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Basic Information Of Product</h2>
                <label class="hs2" style="text-align: center;">Bed and Bath</label>
                <input type="hidden" name="Art" value="C04">
                <label>Sub-Category</label>
                <select>
                    <option value="SC04001">Bathroom Equipments</option>
                    <option value="SC04002">Bedding</option>
                    <option value="SC04003">Blankets</option>
                    <option value="SC04004">Curtains</option>
                    <option value="SC04005">Mattresses</option>
                    <option value="SC04006">Pillows</option>
                    <option value="SC04007">Showers and Shower Heads</option>
                    <option value="SC04008">Storage and Organization</option>
                    <option value="SC04009">Towels</option>
                </select>
                <label for="pid">Seller SKU</label>
                <input type="text" name="sku" id="sku">
                <label>Item Title</label>
                <input type="text" name="it" >
                <label>Item Code</label>
                <input type="text" name="ic">
                <label>Brand Name</label>
                <input type="text" name="bn">
                <label>Manufacturer</label>
                <input type="text" name="manuf">
                <label>Color</label>
                <select>
                    <option>White</option>
                    <option>Black</option>
                    <option>Blue</option>
                    <option>Red</option>
                </select>
                <label>Dimension</label>
                <input type="text" name="dimension">
                <label>Weight</label>
                <input type="text" name="weight">
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right">
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"  >
                <h2 class="fs-title">Additional Attributes</h2>
                <label>Targeted Audience Sex</label>
                <select>
                    <option>---Select---</option>
                    <option>Male</option>
                    <option>Female</option>
                    <option>Both</option>
                </select>
                <label>Is the Item Expirable</label>
                <input type="radio" name="expiry" value="yes">Yes
                <input type="radio" name="expiry" value="no">No
                <label>Battery Required</label>
                <input type="radio" name="battery" value="yes">Yes
                <input type="radio" name="battery" value="no">No
                
                <input style="float: right" type="button" name="next" class="next action-button" value="Next"/>
                <input style="float: right" type="button" name="previous" class="previous action-button-previous" value="Previous"/>
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Offers of Product</h2>
                <label>Currancy</label>
                <input type="text" name="currency">
                <label>Sponsered</label>
                <input type="text" name="sponsered">
                <label>Unit of Measurement</label>
                <input type="text" name="uom">
                <label>Available Quantity</label>
                <input type="text" name="quantity">
                <label>Unit Price</label>
                <input type="text" name="uprice">
                <label class="con" style="text-align: left;">Condition</label>
                <select name="cond" class="con">
                    <option style="color: #2C3E50;">List Of Value</option>
                    <option>New</option>
                    <option>Used</option>
                    <option>Open Packet</option>
                </select>
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right"/>
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right"/>
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <label>Choose Images</label>
                <input type="file" name="image" multiple="multiple">
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right;" />    
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right;"/>            

            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Description of Product</h2>
                <label>Product Description</label>
                <textarea name="pd" placeholder="Enter Product Description Here..."></textarea>
                <label>Key Product Features</label>
                    <input type="text" name="keyf1">
                    <input type="text" name="keyf2">
                    <input type="text" name="keyf3">
                    <input type="text" name="keyf4">
                    <input type="text" name="keyf5">
                <label>Additional Information</label>
                    <textarea name="ld" placeholder="Enter Legal Disclaimer Here..."></textarea>
                
                <input type="submit" name="Submit" class="action-button" value="Submit" style="float: right;" />
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right;"/>
            </fieldset  style="text-align: left;" >
        </form>
    </div>
<!-- /.MultiStep Form -->

<div class="col-md-8" id="myform1d">
        <form id="msform" method="post" action="add_post" enctype='multipart/form-data'>
            <!-- progressbar -->
            <ul id="progressbar">
                <li class="active">Basic Info</li>
                <li>Additional</li>
                <li>Offers</li>
                <li>Images</li>
                <li>Description</li>
            </ul>
            <!-- fieldset  style="text-align: left;" s -->
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Basic Information Of Product</h2>
                <label class="hs2" style="text-align: center;">Books</label>
                <input type="hidden" name="Art" value="C05">
                <label>Sub-Category</label>
                <select>
                    <option value="SC05001">Business and Trade Books</option>
                    <option value="SC05002">Children's Books</option>
                    <option value="SC05003">Comics and Graphic Novels</option>
                    <option value="SC05004">Educataion, Learning and Self Help Books</option>
                    <option value="SC05005">Life Style Books</option>
                    <option value="SC05006">Literature and Fiction</option>
                </select>
                <label for="pid">Seller SKU</label>
                <input type="text" name="sku" id="sku">
                <label>Item Title</label>
                <input type="text" name="it" >
                <label>Item Code</label>
                <input type="text" name="ic">
                <label>Brand Name</label>
                <input type="text" name="bn">
                <label>Manufacturer</label>
                <input type="text" name="manuf">
                <label>Color</label>
                <select>
                    <option>White</option>
                    <option>Black</option>
                    <option>Blue</option>
                    <option>Red</option>
                </select>
                <label>Dimension</label>
                <input type="text" name="dimension">
                <label>Weight</label>
                <input type="text" name="weight">
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right">
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"  >
                <h2 class="fs-title">Additional Attributes</h2>
                <label>Targeted Audience Sex</label>
                <select>
                    <option>---Select---</option>
                    <option>Male</option>
                    <option>Female</option>
                    <option>Both</option>
                </select>
                <label>Is the Item Expirable</label>
                <input type="radio" name="expiry" value="yes">Yes
                <input type="radio" name="expiry" value="no">No
                <label>Battery Required</label>
                <input type="radio" name="battery" value="yes">Yes
                <input type="radio" name="battery" value="no">No
                
                <input style="float: right" type="button" name="next" class="next action-button" value="Next"/>
                <input style="float: right" type="button" name="previous" class="previous action-button-previous" value="Previous"/>
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Offers of Product</h2>
                <label>Currancy</label>
                <input type="text" name="currency">
                <label>Sponsered</label>
                <input type="text" name="sponsered">
                <label>Unit of Measurement</label>
                <input type="text" name="uom">
                <label>Available Quantity</label>
                <input type="text" name="quantity">
                <label>Unit Price</label>
                <input type="text" name="uprice">
                <label class="con" style="text-align: left;">Condition</label>
                <select name="cond" class="con">
                    <option style="color: #2C3E50;">List Of Value</option>
                    <option>New</option>
                    <option>Used</option>
                    <option>Open Packet</option>
                </select>
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right"/>
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right"/>
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <label>Choose Images</label>
                <input type="file" name="image" multiple="multiple">
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right;" />    
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right;"/>            

            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Description of Product</h2>
                <label>Product Description</label>
                <textarea name="pd" placeholder="Enter Product Description Here..."></textarea>
                <label>Key Product Features</label>
                    <input type="text" name="keyf1">
                    <input type="text" name="keyf2">
                    <input type="text" name="keyf3">
                    <input type="text" name="keyf4">
                    <input type="text" name="keyf5">
                <label>Additional Information</label>
                    <textarea name="ld" placeholder="Enter Legal Disclaimer Here..."></textarea>
                
                <input type="submit" name="Submit" class="action-button" value="Submit" style="float: right;" />
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right;"/>
            </fieldset  style="text-align: left;" >
        </form>
    </div>
<!-- /.MultiStep Form -->


<div class="col-md-8" id="myform2">
        <form id="msform" method="post" action="add_post" enctype='multipart/form-data'>
            <!-- progressbar -->
            <ul id="progressbar">
                <li class="active">Basic Info</li>
                <li>Additional</li>
                <li>Offers</li>
                <li>Images</li>
                <li>Description</li>
            </ul>
            <!-- fieldset  style="text-align: left;" s -->
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Basic Information Of Product</h2>
                <label class="hs2" style="text-align: center;">Cameras</label>
                <input type="hidden" name="Art" value="C06">
                <label>Sub-Category</label>
                <select>
                    <option value="SC06001">Analogue Camera</option>
                    <option value="SC06002">Batteries</option>
                    <option value="SC06003">Camcoders</option>
                    <option value="SC06004">Cables</option>
                    <option value="SC06005">Camera  Bags</option>
                    <option value="SC06006">Camera and Camcoder Accessories</option>
                    <option value="SC06007">Chargers</option>
                    <option value="SC06008">Digital Cameras</option>
                    <option value="SC06009">Digital Photo Frames</option>
                    <option value="SC06010">Elecctronic Flashes</option>
                    <option value="SC06011">Interchangable Lenses</option>
                    <option value="SC06012">Memory Cards</option>
                    <option value="SC06013">Screen Protectors</option>
                </select>
                <label for="pid">Seller SKU</label>
                <input type="text" name="sku" id="sku">
                <label>Item Title</label>
                <input type="text" name="it" >
                <label>Item Code</label>
                <input type="text" name="ic">
                <label>Brand Name</label>
                <input type="text" name="bn">
                <label>Manufacturer</label>
                <input type="text" name="manuf">
                <label>Color</label>
                <select>
                    <option>White</option>
                    <option>Black</option>
                    <option>Blue</option>
                    <option>Red</option>
                </select>
                <label>Dimension</label>
                <input type="text" name="dimension">
                <label>Weight</label>
                <input type="text" name="weight">
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right">
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"  >
                <h2 class="fs-title">Additional Attributes</h2>
                <label>Is this an Accessory</label>
                <input type="radio" name="expiry" value="yes">Yes
                <input type="radio" name="expiry" value="no">No
                <label>Model</label>
                <input type="text" name="model">
                <label>Battery Required</label>
                <input type="radio" name="battery" value="yes">Yes
                <input type="radio" name="battery" value="no">No
                <label>Camera Type</label>
                <select>
                    <option>---Select---</option>
                    <option>DSLR</option>
                    <option>Digital</option>
                    <option>Others</option>
                </select>
                <label>Touch Screen</label>
                <select>
                    <option>---Select---</option>
                    <option>Yes</option>
                    <option>No</option>
                </select>
                <label>Display Type</label>
                <select>
                    <option>---Select---</option>
                    <option>LED</option>
                    <option>LCD</option>
                </select>
                <label>Screen Size</label>
                <select>
                    <option>---Select---</option>
                    <option>3.0"</option>
                    <option>3.2"</option>
                    <option>3.5"</option>
                </select>
                <label>Optical Zoom</label>
                <select>
                    <option>---select---</option>
                    <option>2x</option>
                    <option>4x</option>
                    <option>6x</option>
                    <option>8x</option>
                </select>
                <label>Interchangeable Lens</label>
                <input type="radio" name="lens" value="yes">Yes
                <input type="radio" name="lens" value="No">No
                <label>Mega Pixels</label>
                <select>
                    <option>---select---</option>
                    <option>12mp</option>
                    <option>16mp</option>
                    <option>20mp</option>
                    <option>24mp</option>
                    <option>30mp</option>
                    <option>40mp</option>
                </select>
                <label>Accessory Type</label>
                <select>
                    <option>---select---</option>
                    <option>Charger</option>
                    <option>Battery</option>
                    <option>Lens</option>
                </select>
                <label>Compatible with</label>
                <select>
                    <option>---select---</option>
                </select>
                
                <input style="float: right" type="button" name="next" class="next action-button" value="Next"/>
                <input style="float: right" type="button" name="previous" class="previous action-button-previous" value="Previous"/>
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Offers of Product</h2>
                <label>Currancy</label>
                <input type="text" name="currency">
                <label>Sponsered</label>
                <input type="text" name="sponsered">
                <label>Unit of Measurement</label>
                <input type="text" name="uom">
                <label>Available Quantity</label>
                <input type="text" name="quantity">
                <label>Unit Price</label>
                <input type="text" name="uprice">
                <label class="con" style="text-align: left;">Condition</label>
                <select name="cond" class="con">
                    <option style="color: #2C3E50;">List Of Value</option>
                    <option>New</option>
                    <option>Used</option>
                    <option>Open Packet</option>
                </select>
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right"/>
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right"/>
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <label>Choose Images</label>
                <input type="file" name="image" multiple="multiple">
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right;" />    
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right;"/>            

            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Description of Product</h2>
                <label>Product Description</label>
                <textarea name="pd" placeholder="Enter Product Description Here..."></textarea>
                <label>Key Product Features</label>
                    <input type="text" name="keyf1">
                    <input type="text" name="keyf2">
                    <input type="text" name="keyf3">
                    <input type="text" name="keyf4">
                    <input type="text" name="keyf5">
                <label>Additional Information</label>
                    <textarea name="ld" placeholder="Enter Legal Disclaimer Here..."></textarea>
                
                <input type="submit" name="Submit" class="action-button" value="Submit" style="float: right;" />
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right;"/>
            </fieldset  style="text-align: left;" >
        </form>
    </div>
    <!-- /.MultiStep Form -->




<div class="col-md-8" id="myform3">
        <form id="msform" method="post" action="add_post" enctype='multipart/form-data'>
            <!-- progressbar -->
            <ul id="progressbar">
                <li class="active">Basic Info</li>
                <li>Additional</li>
                <li>Offers</li>
                <li>Images</li>
                <li>Description</li>
            </ul>
            <!-- fieldset  style="text-align: left;" s -->
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Basic Information Of Product</h2>
                <label class="hs2" style="text-align: center;">Eyewear and Optics</label>
                <input type="hidden" name="Art" value="C07">
                <label>Sub-Category</label>
                <select>
                    <option value="SC07001">Contact Lenses</option>
                    <option value="SC07002">Eyewear</option>
                    <option value="SC07003">Eyewear Accessories</option>
                    <option value="SC07004">Glasses Frames</option>
                </select>
                <label for="pid">Seller SKU</label>
                <input type="text" name="sku" id="sku">
                <label>Item Title</label>
                <input type="text" name="it" >
                <label>Item Code</label>
                <input type="text" name="ic">
                <label>Brand Name</label>
                <input type="text" name="bn">
                <label>Manufacturer</label>
                <input type="text" name="manuf">
                <label>Color</label>
                <select>
                    <option>White</option>
                    <option>Black</option>
                    <option>Blue</option>
                    <option>Red</option>
                </select>
                <label>Dimension</label>
                <input type="text" name="dimension">
                <label>Weight</label>
                <input type="text" name="weight">
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right">
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"  >
                <h2 class="fs-title">Additional Attributes</h2>
                <label>Is this an Accessory</label>
                <input type="radio" name="expiry" value="yes">Yes
                <input type="radio" name="expiry" value="no">No
                <label>Type</label>
                <select>
                    <option>---Select---</option>
                    <option>type1</option>
                    <option>type2</option>
                    <option>type3</option>
                </select>
                <label>Diameter</label>
                <select>
                    <option>---Select---</option>
                    <option>diameter1</option>
                    <option>diameter2</option>
                </select>
                <label>Base Curve</label>
                <select>
                    <option>---Select---</option>
                    <option>base1</option>
                    <option>base2</option>
                </select>
                <label>Color</label>
                <select>
                    <option>---Select---</option>
                    <option>white</option>
                    <option>black</option>
                    <option>brown</option>
                </select>
                <label>Left Lens Power</label>
                <select>
                    <option>---select---</option>
                    <option>2x</option>
                    <option>4x</option>
                    <option>6x</option>
                </select>
                <label>Right Lens Power</label>
                <select>
                    <option>---select---</option>
                    <option>2x</option>
                    <option>4x</option>
                    <option>6x</option>
                </select>
                <label>Battery Required</label>
                <input type="radio" name="battery" value="yes">Yes
                <input type="radio" name="battery" value="No">No
                <label>Accessory Type</label>
                <select>
                    <option>---select---</option>
                    <option>Charger</option>
                    <option>Battery</option>
                    <option>Lens</option>
                </select>
                
                <input style="float: right" type="button" name="next" class="next action-button" value="Next"/>
                <input style="float: right" type="button" name="previous" class="previous action-button-previous" value="Previous"/>
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Offers of Product</h2>
                <label>Currancy</label>
                <input type="text" name="currency">
                <label>Sponsered</label>
                <input type="text" name="sponsered">
                <label>Unit of Measurement</label>
                <input type="text" name="uom">
                <label>Available Quantity</label>
                <input type="text" name="quantity">
                <label>Unit Price</label>
                <input type="text" name="uprice">
                <label class="con" style="text-align: left;">Condition</label>
                <select name="cond" class="con">
                    <option style="color: #2C3E50;">List Of Value</option>
                    <option>New</option>
                    <option>Used</option>
                    <option>Open Packet</option>
                </select>
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right"/>
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right"/>
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <label>Choose Images</label>
                <input type="file" name="image" multiple="multiple">
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right;" />    
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right;"/>            

            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Description of Product</h2>
                <label>Product Description</label>
                <textarea name="pd" placeholder="Enter Product Description Here..."></textarea>
                <label>Key Product Features</label>
                    <input type="text" name="keyf1">
                    <input type="text" name="keyf2">
                    <input type="text" name="keyf3">
                    <input type="text" name="keyf4">
                    <input type="text" name="keyf5">
                <label>Additional Information</label>
                    <textarea name="ld" placeholder="Enter Legal Disclaimer Here..."></textarea>
                
                <input type="submit" name="Submit" class="action-button" value="Submit" style="float: right;" />
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right;"/>
            </fieldset  style="text-align: left;" >
        </form>
    
</div>
<!-- /.MultiStep Form -->




<div class="col-md-8" id="myform4">
        <form id="msform" method="post" action="add_post" enctype='multipart/form-data'>
            <!-- progressbar -->
            <ul id="progressbar">
                <li class="active">Basic Info</li>
                <li>Additional</li>
                <li>Offers</li>
                <li>Images</li>
                <li>Description</li>
            </ul>
            <!-- fieldset  style="text-align: left;" s -->
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Basic Information Of Product</h2>
                <label class="hs2" style="text-align: center;">Computer, IT and Networking</label>
                <input type="hidden" name="Art" value="C08">
                <label>Sub-Category</label>
                <select>
                    <option value="SC08001">Computer and Laptop Accessories</option>
                    <option value="SC08002">Computer parts and Components</option>
                    <option value="SC08003">Computer and Servers</option>
                    <option value="SC08004">Networking and Accessories</option>
                    <option value="SC08005">Printer, Scanners, Hardware and Acessories</option>
                    <option value="SC08006">Software</option>
                    <option value="SC08007">Laptop and Netbooks</option>
                    <option value="SC08008">VR Gadgets</option>
                </select>
                <label for="pid">Seller SKU</label>
                <input type="text" name="sku" id="sku">
                <label>Item Title</label>
                <input type="text" name="it" >
                <label>Item Code</label>
                <input type="text" name="ic">
                <label>Brand Name</label>
                <input type="text" name="bn">
                <label>Manufacturer</label>
                <input type="text" name="manuf">
                <label>Color</label>
                <select>
                    <option>White</option>
                    <option>Black</option>
                    <option>Blue</option>
                    <option>Red</option>
                </select>
                <label>Dimension</label>
                <input type="text" name="dimension">
                <label>Weight</label>
                <input type="text" name="weight">
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right">
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"  >
                <h2 class="fs-title">Additional Attributes</h2>
                <label>Is this an Accessory</label>
                <input type="radio" name="expiry" value="yes">Yes
                <input type="radio" name="expiry" value="no">No
                <label>Model</label>
                <input type="text" name="model">
                <label>Battery Required</label>
                <input type="radio" name="battery" value="yes">Yes
                <input type="radio" name="battery" value="no">No
                <label>Processor Type</label>
                <select>
                    <option>---Select---</option>
                    <option>Intel</option>
                    <option>Apple</option>
                    <option>Amd</option>
                </select>
                <label>USB Type</label>
                <select>
                    <option>---Select---</option>
                    <option>3.0</option>
                    <option>2.0</option>
                </select>
                <label>Processor Speed</label>
                <select>
                    <option>---Select---</option>
                    <option>3.8</option>
                    <option>3.5</option>
                    <option>3.2</option>
                    <option>3.0</option>
                </select>
                <label>Display Size</label>
                <input type="text" name="display">
                <label>Color</label>
                <select>
                    <option>---select---</option>
                    <option>black</option>
                    <option>white</option>
                    <option>blue</option>
                    <option>red</option>
                </select>
                <label>Hard Disk Capacity</label>
                <input type="text" name="hdd">
                <label>RAM Size</label>
                <input type="text" name="ram">
                <label>Shipping Weight</label>
                <input type="text" name="sweight">
                <label>Accessory Type</label>
                <select>
                    <option>---select---</option>
                    <option>Charger</option>
                    <option>Battery</option>
                    <option>Lens</option>
                </select>
                <label>Compatible with</label>
                <select>
                    <option>---select---</option>
                </select>
                
                <input style="float: right" type="button" name="next" class="next action-button" value="Next"/>
                <input style="float: right" type="button" name="previous" class="previous action-button-previous" value="Previous"/>
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Offers of Product</h2>
                <label>Currancy</label>
                <input type="text" name="currency">
                <label>Sponsered</label>
                <input type="text" name="sponsered">
                <label>Unit of Measurement</label>
                <input type="text" name="uom">
                <label>Available Quantity</label>
                <input type="text" name="quantity">
                <label>Unit Price</label>
                <input type="text" name="uprice">
                <label class="con" style="text-align: left;">Condition</label>
                <select name="cond" class="con">
                    <option style="color: #2C3E50;">List Of Value</option>
                    <option>New</option>
                    <option>Used</option>
                    <option>Open Packet</option>
                </select>
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right"/>
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right"/>
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <label>Choose Images</label>
                <input type="file" name="image" multiple="multiple">
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right;" />    
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right;"/>            

            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Description of Product</h2>
                <label>Product Description</label>
                <textarea name="pd" placeholder="Enter Product Description Here..."></textarea>
                <label>Key Product Features</label>
                    <input type="text" name="keyf1">
                    <input type="text" name="keyf2">
                    <input type="text" name="keyf3">
                    <input type="text" name="keyf4">
                    <input type="text" name="keyf5">
                <label>Additional Information</label>
                    <textarea name="ld" placeholder="Enter Legal Disclaimer Here..."></textarea>
                
                <input type="submit" name="Submit" class="action-button" value="Submit" style="float: right;" />
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right;"/>
            </fieldset  style="text-align: left;" >
        </form>
    
</div>
<!-- /.MultiStep Form -->




<div class="col-md-8" id="myform5">
        <form id="msform" method="post" action="add_post" enctype='multipart/form-data'>
            <!-- progressbar -->
            <ul id="progressbar">
                <li class="active">Basic Info</li>
                <li>Additional</li>
                <li>Offers</li>
                <li>Images</li>
                <li>Description</li>
            </ul>
            <!-- fieldset  style="text-align: left;" s -->
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Basic Information Of Product</h2>
                <label class="hs2" style="text-align: center;">Electronics</label>
                <input type="hidden" name="Art" value="C09">
                <label>Sub-Category</label>
                <select>
                    <option value="SC09001">Audio and Accessories</option>
                    <option value="SC09002">Batteries</option>
                    <option value="SC09003">Binoculars and Telecscopes</option>
                    <option value="SC09004">CD Recording Media</option>
                    <option value="SC09005">Clock Radios</option>
                    <option value="SC09006">E-Book Readers</option>
                    <option value="SC09007">Home and Office Electronics</option>
                    <option value="SC09008">Home Theater Systems</option>
                    <option value="SC09009">Power Banks</option>
                    <option value="SC09010">Projectors and Accessories</option>
                    <option value="SC09011">Recording and Studio Equipments</option>
                    <option value="SC09012">Security and Survelliance Systems</option>
                    <option value="SC09013">Smart Watches</option>
                    <option value="SC09014">Stereo System and Equilizers</option>
                    <option value="SC09015">VCD, VCP and VCR  Players</option>
                    <option value="SC09016">Webcams</option>
                </select>
                <label for="pid">Seller SKU</label>
                <input type="text" name="sku" id="sku">
                <label>Item Title</label>
                <input type="text" name="it" >
                <label>Item Code</label>
                <input type="text" name="ic">
                <label>Brand Name</label>
                <input type="text" name="bn">
                <label>Manufacturer</label>
                <input type="text" name="manuf">
                <label>Color</label>
                <select>
                    <option>White</option>
                    <option>Black</option>
                    <option>Blue</option>
                    <option>Red</option>
                </select>
                <label>Dimension</label>
                <input type="text" name="dimension">
                <label>Weight</label>
                <input type="text" name="weight">
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right">
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"  >
                <h2 class="fs-title">Additional Attributes</h2>
                <label>Is this an Accessory</label>
                <input type="radio" name="expiry" value="yes">Yes
                <input type="radio" name="expiry" value="no">No
                <label>Model</label>
                <input type="text" name="model">
                <label>Battery Required</label>
                <input type="radio" name="battery" value="yes">Yes
                <input type="radio" name="battery" value="no">No
                <label>Capacity</label>
                <input type="text" name="capacity">
                <label>Material</label>
                <input type="text" name="material">
                <label>Style</label>
                <input type="text" name="style">
                <label>Shipping Weight</label>
                <input type="text" name="sweight">
                <label>Accessory Type</label>
                <input type="text" name="type">
                <label>Compatible with</label>
                <input type="text" name="compatible">
                
                <input style="float: right" type="button" name="next" class="next action-button" value="Next"/>
                <input style="float: right" type="button" name="previous" class="previous action-button-previous" value="Previous"/>
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Offers of Product</h2>
                <label>Currancy</label>
                <input type="text" name="currency">
                <label>Sponsered</label>
                <input type="text" name="sponsered">
                <label>Unit of Measurement</label>
                <input type="text" name="uom">
                <label>Available Quantity</label>
                <input type="text" name="quantity">
                <label>Unit Price</label>
                <input type="text" name="uprice">
                <label class="con" style="text-align: left;">Condition</label>
                <select name="cond" class="con">
                    <option style="color: #2C3E50;">List Of Value</option>
                    <option>New</option>
                    <option>Used</option>
                    <option>Open Packet</option>
                </select>
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right"/>
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right"/>
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <label>Choose Images</label>
                <input type="file" name="image" multiple="multiple">
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right;" />    
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right;"/>            

            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Description of Product</h2>
                <label>Product Description</label>
                <textarea name="pd" placeholder="Enter Product Description Here..."></textarea>
                <label>Key Product Features</label>
                    <input type="text" name="keyf1">
                    <input type="text" name="keyf2">
                    <input type="text" name="keyf3">
                    <input type="text" name="keyf4">
                    <input type="text" name="keyf5">
                <label>Additional Information</label>
                    <textarea name="ld" placeholder="Enter Legal Disclaimer Here..."></textarea>
                
                <input type="submit" name="Submit" class="action-button" value="Submit" style="float: right;" />
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right;"/>
            </fieldset  style="text-align: left;" >
        </form>
    
</div>
<!-- /.MultiStep Form -->




<div class="col-md-8" id="myform6">
        <form id="msform" method="post" action="add_post" enctype='multipart/form-data'>
            <!-- progressbar -->
            <ul id="progressbar">
                <li class="active">Basic Info</li>
                <li>Additional</li>
                <li>Offers</li>
                <li>Images</li>
                <li>Description</li>
            </ul>
            <!-- fieldset  style="text-align: left;" s -->
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Basic Information Of Product</h2>
                <label class="hs2" style="text-align: center;">Furniture</label>
                <input type="hidden" name="Art" value="C10">
                <label>Sub-Category</label>
                <select>
                    <option value="SC10001">Bedroom Sets</option>
                    <option value="SC10002">Bed and Bed Frames</option>
                    <option value="SC10003">Chair and Benches</option>
                    <option value="SC10004">Garden Furniture</option>
                    <option value="SC10005">Kitchen and Dinning room sets</option>
                    <option value="SC10006">Living Room Sets</option>
                    <option value="SC10007">Office Furniture</option>
                    <option value="SC10008">Sofas and Bean bags</option>
                    <option value="SC10009">Tables</option>
                </select>
                <label for="pid">Seller SKU</label>
                <input type="text" name="sku" id="sku">
                <label>Item Title</label>
                <input type="text" name="it" >
                <label>Item Code</label>
                <input type="text" name="ic">
                <label>Brand Name</label>
                <input type="text" name="bn">
                <label>Manufacturer</label>
                <input type="text" name="manuf">
                <label>Color</label>
                <select>
                    <option>White</option>
                    <option>Black</option>
                    <option>Blue</option>
                    <option>Red</option>
                </select>
                <label>Dimension</label>
                <input type="text" name="dimension">
                <label>Weight</label>
                <input type="text" name="weight">
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right">
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"  >
                <h2 class="fs-title">Additional Attributes</h2>
                
                <label>Battery Required</label>
                <input type="radio" name="battery" value="yes">Yes
                <input type="radio" name="battery" value="no">No
                <label>Number of Pieces</label>
                <input type="text" name="piece">
                <label>Material</label>
                <input type="text" name="material">
                <label>Shipping Weight</label>
                <input type="text" name="sweight">
                <label>Dimensions</label>
                <input type="text" name="dimension">
                <label>Item Suitable for</label>
                <select>
                    <option>---select---</option>
                    <option>Home</option>
                    <option>Office</option>
                    <option>Outdoor</option>
                </select>
                
                <input style="float: right" type="button" name="next" class="next action-button" value="Next"/>
                <input style="float: right" type="button" name="previous" class="previous action-button-previous" value="Previous"/>
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Offers of Product</h2>
                <label>Currancy</label>
                <input type="text" name="currency">
                <label>Sponsered</label>
                <input type="text" name="sponsered">
                <label>Unit of Measurement</label>
                <input type="text" name="uom">
                <label>Available Quantity</label>
                <input type="text" name="quantity">
                <label>Unit Price</label>
                <input type="text" name="uprice">
                <label class="con" style="text-align: left;">Condition</label>
                <select name="cond" class="con">
                    <option style="color: #2C3E50;">List Of Value</option>
                    <option>New</option>
                    <option>Used</option>
                    <option>Open Packet</option>
                </select>
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right"/>
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right"/>
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <label>Choose Images</label>
                <input type="file" name="image" multiple="multiple">
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right;" />    
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right;"/>            

            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Description of Product</h2>
                <label>Product Description</label>
                <textarea name="pd" placeholder="Enter Product Description Here..."></textarea>
                <label>Key Product Features</label>
                    <input type="text" name="keyf1">
                    <input type="text" name="keyf2">
                    <input type="text" name="keyf3">
                    <input type="text" name="keyf4">
                    <input type="text" name="keyf5">
                <label>Additional Information</label>
                    <textarea name="ld" placeholder="Enter Legal Disclaimer Here..."></textarea>
                
                <input type="submit" name="Submit" class="action-button" value="Submit" style="float: right;" />
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right;"/>
            </fieldset  style="text-align: left;" >
        </form>
    
</div>
<!-- /.MultiStep Form -->





<div class="col-md-8" id="myform6a">
        <form id="msform" method="post" action="add_post" enctype='multipart/form-data'>
            <!-- progressbar -->
            <ul id="progressbar">
                <li class="active">Basic Info</li>
                <li>Additional</li>
                <li>Offers</li>
                <li>Images</li>
                <li>Description</li>
            </ul>
            <!-- fieldset  style="text-align: left;" s -->
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Basic Information Of Product</h2>
                <label class="hs2" style="text-align: center;">Garden and outdoors</label>
                <input type="hidden" name="Art" value="C12">
                <label>Sub-Category</label>
                <select>
                    <option value="SC12001">Barbecue Tools and Accessories</option>
                    <option value="SC12002">Flowers</option>
                    <option value="SC12003">Garder Decoration</option>
                    <option value="SC12004">Grills and Smokers</option>
                    <option value="SC12005">Gardening and Water Supplies</option>
                </select>
                <label for="pid">Seller SKU</label>
                <input type="text" name="sku" id="sku">
                <label>Item Title</label>
                <input type="text" name="it" >
                <label>Item Code</label>
                <input type="text" name="ic">
                <label>Brand Name</label>
                <input type="text" name="bn">
                <label>Manufacturer</label>
                <input type="text" name="manuf">
                <label>Color</label>
                <select>
                    <option>White</option>
                    <option>Black</option>
                    <option>Blue</option>
                    <option>Red</option>
                </select>
                <label>Dimension</label>
                <input type="text" name="dimension">
                <label>Weight</label>
                <input type="text" name="weight">
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right">
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"  >
                <h2 class="fs-title">Additional Attributes</h2>
                
                <label>Battery Required</label>
                <input type="radio" name="battery" value="yes">Yes
                <input type="radio" name="battery" value="no">No
                <label>Number of Pieces</label>
                <input type="text" name="piece">
                <label>Material</label>
                <input type="text" name="material">
                <label>Shipping Weight</label>
                <input type="text" name="sweight">
                <label>Dimensions</label>
                <input type="text" name="dimension">
                <label>Item Suitable for</label>
                <select>
                    <option>---select---</option>
                    <option>Home</option>
                    <option>Office</option>
                    <option>Outdoor</option>
                </select>
                
                <input style="float: right" type="button" name="next" class="next action-button" value="Next"/>
                <input style="float: right" type="button" name="previous" class="previous action-button-previous" value="Previous"/>
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Offers of Product</h2>
                <label>Currancy</label>
                <input type="text" name="currency">
                <label>Sponsered</label>
                <input type="text" name="sponsered">
                <label>Unit of Measurement</label>
                <input type="text" name="uom">
                <label>Available Quantity</label>
                <input type="text" name="quantity">
                <label>Unit Price</label>
                <input type="text" name="uprice">
                <label class="con" style="text-align: left;">Condition</label>
                <select name="cond" class="con">
                    <option style="color: #2C3E50;">List Of Value</option>
                    <option>New</option>
                    <option>Used</option>
                    <option>Open Packet</option>
                </select>
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right"/>
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right"/>
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <label>Choose Images</label>
                <input type="file" name="image" multiple="multiple">
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right;" />    
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right;"/>            

            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Description of Product</h2>
                <label>Product Description</label>
                <textarea name="pd" placeholder="Enter Product Description Here..."></textarea>
                <label>Key Product Features</label>
                    <input type="text" name="keyf1">
                    <input type="text" name="keyf2">
                    <input type="text" name="keyf3">
                    <input type="text" name="keyf4">
                    <input type="text" name="keyf5">
                <label>Additional Information</label>
                    <textarea name="ld" placeholder="Enter Legal Disclaimer Here..."></textarea>
                
                <input type="submit" name="Submit" class="action-button" value="Submit" style="float: right;" />
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right;"/>
            </fieldset  style="text-align: left;" >
        </form>
    
</div>
<!-- /.MultiStep Form -->





<div class="col-md-8" id="myform6b">
        <form id="msform" method="post" action="add_post" enctype='multipart/form-data'>
            <!-- progressbar -->
            <ul id="progressbar">
                <li class="active">Basic Info</li>
                <li>Additional</li>
                <li>Offers</li>
                <li>Images</li>
                <li>Description</li>
            </ul>
            <!-- fieldset  style="text-align: left;" s -->
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Basic Information Of Product</h2>
                <label class="hs2" style="text-align: center;">Home Décor and Furniture</label>
                <input type="hidden" name="Art" value="C16">
                <label>Sub-Category</label>
                <select>
                    <option value="SC16001">Home décor</option>
                    <option value="SC16002">Lamps and Lightenings</option>
                    <option value="SC16003">Small Furniture</option>
                </select>
                <label for="pid">Seller SKU</label>
                <input type="text" name="sku" id="sku">
                <label>Item Title</label>
                <input type="text" name="it" >
                <label>Item Code</label>
                <input type="text" name="ic">
                <label>Brand Name</label>
                <input type="text" name="bn">
                <label>Manufacturer</label>
                <input type="text" name="manuf">
                <label>Color</label>
                <select>
                    <option>White</option>
                    <option>Black</option>
                    <option>Blue</option>
                    <option>Red</option>
                </select>
                <label>Dimension</label>
                <input type="text" name="dimension">
                <label>Weight</label>
                <input type="text" name="weight">
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right">
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"  >
                <h2 class="fs-title">Additional Attributes</h2>
                
                <label>Battery Required</label>
                <input type="radio" name="battery" value="yes">Yes
                <input type="radio" name="battery" value="no">No
                <label>Number of Pieces</label>
                <input type="text" name="piece">
                <label>Material</label>
                <input type="text" name="material">
                <label>Shipping Weight</label>
                <input type="text" name="sweight">
                <label>Dimensions</label>
                <input type="text" name="dimension">
                <label>Item Suitable for</label>
                <select>
                    <option>---select---</option>
                    <option>Home</option>
                    <option>Office</option>
                    <option>Outdoor</option>
                </select>
                
                <input style="float: right" type="button" name="next" class="next action-button" value="Next"/>
                <input style="float: right" type="button" name="previous" class="previous action-button-previous" value="Previous"/>
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Offers of Product</h2>
                <label>Currancy</label>
                <input type="text" name="currency">
                <label>Sponsered</label>
                <input type="text" name="sponsered">
                <label>Unit of Measurement</label>
                <input type="text" name="uom">
                <label>Available Quantity</label>
                <input type="text" name="quantity">
                <label>Unit Price</label>
                <input type="text" name="uprice">
                <label class="con" style="text-align: left;">Condition</label>
                <select name="cond" class="con">
                    <option style="color: #2C3E50;">List Of Value</option>
                    <option>New</option>
                    <option>Used</option>
                    <option>Open Packet</option>
                </select>
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right"/>
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right"/>
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <label>Choose Images</label>
                <input type="file" name="image" multiple="multiple">
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right;" />    
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right;"/>            

            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Description of Product</h2>
                <label>Product Description</label>
                <textarea name="pd" placeholder="Enter Product Description Here..."></textarea>
                <label>Key Product Features</label>
                    <input type="text" name="keyf1">
                    <input type="text" name="keyf2">
                    <input type="text" name="keyf3">
                    <input type="text" name="keyf4">
                    <input type="text" name="keyf5">
                <label>Additional Information</label>
                    <textarea name="ld" placeholder="Enter Legal Disclaimer Here..."></textarea>
                
                <input type="submit" name="Submit" class="action-button" value="Submit" style="float: right;" />
                <input type="button" name="next" class="next action-button" value="Next" style="float: right;" />
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right;"/>
            </fieldset  style="text-align: left;" >
        </form>
    
</div>
<!-- /.MultiStep Form -->





<div class="col-md-8" id="myform6c">
        <form id="msform" method="post" action="add_post" enctype='multipart/form-data'>
            <!-- progressbar -->
            <ul id="progressbar">
                <li class="active">Basic Info</li>
                <li>Additional</li>
                <li>Offers</li>
                <li>Images</li>
                <li>Description</li>
            </ul>
            <!-- fieldset  style="text-align: left;" s -->
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Basic Information Of Product</h2>
                <label class="hs2" style="text-align: center;">Kitchen and Home Supplies</label>
                <input type="hidden" name="Art" value="C19">
                <label>Sub-Category</label>
                <select>
                    <option value="SC19001">Bakeware and Accessories</option>
                    <option value="SC19002">Cooking Utensils</option>
                    <option value="SC19003">Cookware and Bakeware</option>
                    <option value="SC19004">Cutlery and Flatware Sets</option>
                    <option value="SC19005">Dinnerware and Serveware</option>
                    <option value="SC19006">Drinkware</option>
                    <option value="SC19007">Home Supplies</option>
                    <option value="SC19008">Kitchen Accessories</option>
                    <option value="SC19009">Kitchen Measuring Tools</option>
                    <option value="SC19010">Kitchen Storage</option>
                    <option value="SC19011">Table linens</option>
                </select>
                <label for="pid">Seller SKU</label>
                <input type="text" name="sku" id="sku">
                <label>Item Title</label>
                <input type="text" name="it" >
                <label>Item Code</label>
                <input type="text" name="ic">
                <label>Brand Name</label>
                <input type="text" name="bn">
                <label>Manufacturer</label>
                <input type="text" name="manuf">
                <label>Color</label>
                <select>
                    <option>White</option>
                    <option>Black</option>
                    <option>Blue</option>
                    <option>Red</option>
                </select>
                <label>Dimension</label>
                <input type="text" name="dimension">
                <label>Weight</label>
                <input type="text" name="weight">
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right">
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"  >
                <h2 class="fs-title">Additional Attributes</h2>
                
                <label>Battery Required</label>
                <input type="radio" name="battery" value="yes">Yes
                <input type="radio" name="battery" value="no">No
                <label>Number of Pieces</label>
                <input type="text" name="piece">
                <label>Material</label>
                <input type="text" name="material">
                <label>Shipping Weight</label>
                <input type="text" name="sweight">
                <label>Dimensions</label>
                <input type="text" name="dimension">
                <label>Item Suitable for</label>
                <select>
                    <option>---select---</option>
                    <option>Home</option>
                    <option>Office</option>
                    <option>Outdoor</option>
                </select>
                
                <input style="float: right" type="button" name="next" class="next action-button" value="Next"/>
                <input style="float: right" type="button" name="previous" class="previous action-button-previous" value="Previous"/>
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Offers of Product</h2>
                <label>Currancy</label>
                <input type="text" name="currency">
                <label>Sponsered</label>
                <input type="text" name="sponsered">
                <label>Unit of Measurement</label>
                <input type="text" name="uom">
                <label>Available Quantity</label>
                <input type="text" name="quantity">
                <label>Unit Price</label>
                <input type="text" name="uprice">
                <label class="con" style="text-align: left;">Condition</label>
                <select name="cond" class="con">
                    <option style="color: #2C3E50;">List Of Value</option>
                    <option>New</option>
                    <option>Used</option>
                    <option>Open Packet</option>
                </select>
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right"/>
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right"/>
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <label>Choose Images</label>
                <input type="file" name="image" multiple="multiple">
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right;" />    
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right;"/>            

            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Description of Product</h2>
                <label>Product Description</label>
                <textarea name="pd" placeholder="Enter Product Description Here..."></textarea>
                <label>Key Product Features</label>
                    <input type="text" name="keyf1">
                    <input type="text" name="keyf2">
                    <input type="text" name="keyf3">
                    <input type="text" name="keyf4">
                    <input type="text" name="keyf5">
                <label>Additional Information</label>
                    <textarea name="ld" placeholder="Enter Legal Disclaimer Here..."></textarea>
                
                <input type="submit" name="Submit" class="action-button" value="Submit" style="float: right;" />
                <input type="button" name="next" class="next action-button" value="Next" style="float: right;" />
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right;"/>
            </fieldset  style="text-align: left;" >
        </form>
    
</div>
<!-- /.MultiStep Form -->







<div class="col-md-8" id="myform7">
        <form id="msform" method="post" action="add_post" enctype='multipart/form-data'>
            <!-- progressbar -->
            <ul id="progressbar">
                <li class="active">Basic Info</li>
                <li>Additional</li>
                <li>Offers</li>
                <li>Images</li>
                <li>Description</li>
            </ul>
            <!-- fieldset  style="text-align: left;" s -->
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Basic Information Of Product</h2>
                <label class="hs2" style="text-align: center;">Gaming</label>
                <input type="hidden" name="Art" value="C11">
                <label>Sub-Category</label>
                <select>
                    <option value="SC11001">Gaming Consoles</option>
                    <option value="SC11002">Video Games</option>
                    <option value="SC11003">Games gadgets and Accessories</option>
                    <option value="SC11004">VR Gadgets</option>
                </select>
                <label for="pid">Seller SKU</label>
                <input type="text" name="sku" id="sku">
                <label>Item Title</label>
                <input type="text" name="it" >
                <label>Item Code</label>
                <input type="text" name="ic">
                <label>Brand Name</label>
                <input type="text" name="bn">
                <label>Manufacturer</label>
                <input type="text" name="manuf">
                <label>Color</label>
                <select>
                    <option>White</option>
                    <option>Black</option>
                    <option>Blue</option>
                    <option>Red</option>
                </select>
                <label>Dimension</label>
                <input type="text" name="dimension">
                <label>Weight</label>
                <input type="text" name="weight">
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right">
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"  >
                <h2 class="fs-title">Additional Attributes</h2>
                <label>Is this a game or console</label>
                <input type="radio" name="game" value="yes">Yes
                <input type="radio" name="game" value="no">No
                <label>Game Name</label>
                <input type="text" name="model">
                <label>Battery Required</label>
                <input type="radio" name="battery" value="yes">Yes
                <input type="radio" name="battery" value="no">No
                <label>Platform</label>
                <input type="text" name="platform">
                <label>Color</label>
                <select>
                    <option>---select---</option>
                    <option>black</option>
                    <option>white</option>
                    <option>blue</option>
                    <option>red</option>
                </select>
                <label>Hard Disk Capacity</label>
                <input type="text" name="hdd">
                
                <input style="float: right" type="button" name="next" class="next action-button" value="Next"/>
                <input style="float: right" type="button" name="previous" class="previous action-button-previous" value="Previous"/>
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Offers of Product</h2>
                <label>Currancy</label>
                <input type="text" name="currency">
                <label>Sponsered</label>
                <input type="text" name="sponsered">
                <label>Unit of Measurement</label>
                <input type="text" name="uom">
                <label>Available Quantity</label>
                <input type="text" name="quantity">
                <label>Unit Price</label>
                <input type="text" name="uprice">
                <label class="con" style="text-align: left;">Condition</label>
                <select name="cond" class="con">
                    <option style="color: #2C3E50;">List Of Value</option>
                    <option>New</option>
                    <option>Used</option>
                    <option>Open Packet</option>
                </select>
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right"/>
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right"/>
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <label>Choose Images</label>
                <input type="file" name="image" multiple="multiple">
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right;" />    
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right;"/>
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Description of Product</h2>
                <label>Product Description</label>
                <textarea name="pd" placeholder="Enter Product Description Here..."></textarea>
                <label>Key Product Features</label>
                    <input type="text" name="keyf1">
                    <input type="text" name="keyf2">
                    <input type="text" name="keyf3">
                    <input type="text" name="keyf4">
                    <input type="text" name="keyf5">
                <label>Additional Information</label>
                    <textarea name="ld" placeholder="Enter Legal Disclaimer Here..."></textarea>
                
                <input type="submit" name="Submit" class="action-button" value="Submit" style="float: right;" />
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right;"/>
            </fieldset  style="text-align: left;" >
        </form>
    
</div>
<!-- /.MultiStep Form -->




<div class="col-md-8" id="myform8">
        <form id="msform" method="post" action="add_post" enctype='multipart/form-data'>
            <!-- progressbar -->
            <ul id="progressbar">
                <li class="active">Basic Info</li>
                <li>Additional</li>
                <li>Offers</li>
                <li>Images</li>
                <li>Description</li>
            </ul>
            <!-- fieldset  style="text-align: left;" s -->
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Basic Information Of Product</h2>
                <label class="hs2" style="text-align: center;">Grocery, Food and Beverages</label>
                <input type="hidden" name="Art" value="C13">
                <label>Sub-Category</label>
                <select>
                    <option value="SC13001">Air Freshners</option>
                    <option value="SC13002">Baby Food</option>
                    <option value="SC13003">Bakery Items</option>
                    <option value="SC13004">Beverages</option>
                    <option value="SC13005">Cereals and Grains</option>
                    <option value="SC13006">Cleaning Products</option>
                    <option value="SC13007">Dairy Products</option>
                    <option value="SC13008">Dry Food</option>
                    <option value="SC13009">Fruits and Vegetables</option>
                    <option value="SC13010">Meat and Chicken</option>
                    <option value="SC13011">Pet Food</option>
                    <option value="SC13012">Seafood</option>
                    <option value="SC13013">Seasoning, Spices and Preservatives</option>
                </select>
                <label for="pid">Seller SKU</label>
                <input type="text" name="sku" id="sku">
                <label>Item Title</label>
                <input type="text" name="it" >
                <label>Item Code</label>
                <input type="text" name="ic">
                <label>Brand Name</label>
                <input type="text" name="bn">
                <label>Manufacturer</label>
                <input type="text" name="manuf">
                <label>Color</label>
                <select>
                    <option>White</option>
                    <option>Black</option>
                    <option>Blue</option>
                    <option>Red</option>
                </select>
                <label>Dimension</label>
                <input type="text" name="dimension">
                <label>Weight</label>
                <input type="text" name="weight">
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right">
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"  >
                <h2 class="fs-title">Additional Attributes</h2>
                <!-- <label>Is this an Accessory</label>
                <input type="radio" name="expiry" value="yes">Yes
                <input type="radio" name="expiry" value="no">No
                <label>Model</label>
                <input type="text" name="model">
                <label>Battery Required</label>
                <input type="radio" name="battery" value="yes">Yes
                <input type="radio" name="battery" value="no">No
                <label>Processor Type</label>
                <select>
                    <option>---Select---</option>
                    <option>Intel</option>
                    <option>Apple</option>
                    <option>Amd</option>
                </select>
                <label>USB Type</label>
                <select>
                    <option>---Select---</option>
                    <option>3.0</option>
                    <option>2.0</option>
                </select>
                <label>Processor Speed</label>
                <select>
                    <option>---Select---</option>
                    <option>3.8</option>
                    <option>3.5</option>
                    <option>3.2</option>
                    <option>3.0</option>
                </select>
                <label>Display Size</label>
                <input type="text" name="display">
                <label>Color</label>
                <select>
                    <option>---select---</option>
                    <option>black</option>
                    <option>white</option>
                    <option>blue</option>
                    <option>red</option>
                </select>
                <label>Hard Disk Capacity</label>
                <input type="text" name="hdd">
                <label>RAM Size</label>
                <input type="text" name="ram">
                <label>Shipping Weight</label>
                <input type="text" name="sweight">
                <label>Accessory Type</label>
                <select>
                    <option>---select---</option>
                    <option>Charger</option>
                    <option>Battery</option>
                    <option>Lens</option>
                </select>
                <label>Compatible with</label>
                <select>
                    <option>---select---</option>
                </select> --><label>No Additional Attributes yet</label>
                
                <input style="float: right" type="button" name="next" class="next action-button" value="Next"/>
                <input style="float: right" type="button" name="previous" class="previous action-button-previous" value="Previous"/>
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Offers of Product</h2>
                <label>Currancy</label>
                <input type="text" name="currency">
                <label>Sponsered</label>
                <input type="text" name="sponsered">
                <label>Unit of Measurement</label>
                <input type="text" name="uom">
                <label>Available Quantity</label>
                <input type="text" name="quantity">
                <label>Unit Price</label>
                <input type="text" name="uprice">
                <label class="con" style="text-align: left;">Condition</label>
                <select name="cond" class="con">
                    <option style="color: #2C3E50;">List Of Value</option>
                    <option>New</option>
                    <option>Used</option>
                    <option>Open Packet</option>
                </select>
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right"/>
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right"/>
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <label>Choose Images</label>
                <input type="file" name="image" multiple="multiple">
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right;" />    
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right;"/>            

            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Description of Product</h2>
                <label>Product Description</label>
                <textarea name="pd" placeholder="Enter Product Description Here..."></textarea>
                <label>Key Product Features</label>
                    <input type="text" name="keyf1">
                    <input type="text" name="keyf2">
                    <input type="text" name="keyf3">
                    <input type="text" name="keyf4">
                    <input type="text" name="keyf5">
                <label>Additional Information</label>
                    <textarea name="ld" placeholder="Enter Legal Disclaimer Here..."></textarea>
                
                <input type="submit" name="Submit" class="action-button" value="Submit" style="float: right;" />
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right;"/>
            </fieldset  style="text-align: left;" >
        </form>
    
</div>
<!-- /.MultiStep Form -->



<div class="col-md-8" id="myform8a">
        <form id="msform" method="post" action="add_post" enctype='multipart/form-data'>
            <!-- progressbar -->
            <ul id="progressbar">
                <li class="active">Basic Info</li>
                <li>Additional</li>
                <li>Offers</li>
                <li>Images</li>
                <li>Description</li>
            </ul>
            <!-- fieldset  style="text-align: left;" s -->
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Basic Information Of Product</h2>
                <label class="hs2" style="text-align: center;">Music and Movies</label>
                <input type="hidden" name="Art" value="C21">
                <label>Sub-Category</label>
                <select>
                    <option value="SC21001">Guitars</option>
                    <option value="SC21002">Movies, Play and Series</option>
                    <option value="SC21003">Music CDs</option>
                    <option value="SC21004">Musical Instruments</option>
                    <option value="SC21005">Musical Instruments parts and Accessories</option>
                    <option value="SC21006">Music Keyboards</option>
                    <option value="SC21007">Tuners</option>
                </select>
                <label for="pid">Seller SKU</label>
                <input type="text" name="sku" id="sku">
                <label>Item Title</label>
                <input type="text" name="it" >
                <label>Item Code</label>
                <input type="text" name="ic">
                <label>Brand Name</label>
                <input type="text" name="bn">
                <label>Manufacturer</label>
                <input type="text" name="manuf">
                <label>Color</label>
                <select>
                    <option>White</option>
                    <option>Black</option>
                    <option>Blue</option>
                    <option>Red</option>
                </select>
                <label>Dimension</label>
                <input type="text" name="dimension">
                <label>Weight</label>
                <input type="text" name="weight">
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right">
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"  >
                <h2 class="fs-title">Additional Attributes</h2>
                <!-- <label>Is this an Accessory</label>
                <input type="radio" name="expiry" value="yes">Yes
                <input type="radio" name="expiry" value="no">No
                <label>Model</label>
                <input type="text" name="model">
                <label>Battery Required</label>
                <input type="radio" name="battery" value="yes">Yes
                <input type="radio" name="battery" value="no">No
                <label>Processor Type</label>
                <select>
                    <option>---Select---</option>
                    <option>Intel</option>
                    <option>Apple</option>
                    <option>Amd</option>
                </select>
                <label>USB Type</label>
                <select>
                    <option>---Select---</option>
                    <option>3.0</option>
                    <option>2.0</option>
                </select>
                <label>Processor Speed</label>
                <select>
                    <option>---Select---</option>
                    <option>3.8</option>
                    <option>3.5</option>
                    <option>3.2</option>
                    <option>3.0</option>
                </select>
                <label>Display Size</label>
                <input type="text" name="display">
                <label>Color</label>
                <select>
                    <option>---select---</option>
                    <option>black</option>
                    <option>white</option>
                    <option>blue</option>
                    <option>red</option>
                </select>
                <label>Hard Disk Capacity</label>
                <input type="text" name="hdd">
                <label>RAM Size</label>
                <input type="text" name="ram">
                <label>Shipping Weight</label>
                <input type="text" name="sweight">
                <label>Accessory Type</label>
                <select>
                    <option>---select---</option>
                    <option>Charger</option>
                    <option>Battery</option>
                    <option>Lens</option>
                </select>
                <label>Compatible with</label>
                <select>
                    <option>---select---</option>
                </select> --><label>No Additional Attributes yet</label>
                
                <input style="float: right" type="button" name="next" class="next action-button" value="Next"/>
                <input style="float: right" type="button" name="previous" class="previous action-button-previous" value="Previous"/>
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Offers of Product</h2>
                <label>Currancy</label>
                <input type="text" name="currency">
                <label>Sponsered</label>
                <input type="text" name="sponsered">
                <label>Unit of Measurement</label>
                <input type="text" name="uom">
                <label>Available Quantity</label>
                <input type="text" name="quantity">
                <label>Unit Price</label>
                <input type="text" name="uprice">
                <label class="con" style="text-align: left;">Condition</label>
                <select name="cond" class="con">
                    <option style="color: #2C3E50;">List Of Value</option>
                    <option>New</option>
                    <option>Used</option>
                    <option>Open Packet</option>
                </select>
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right"/>
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right"/>
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <label>Choose Images</label>
                <input type="file" name="image" multiple="multiple">
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right;" />    
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right;"/>            

            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Description of Product</h2>
                <label>Product Description</label>
                <textarea name="pd" placeholder="Enter Product Description Here..."></textarea>
                <label>Key Product Features</label>
                    <input type="text" name="keyf1">
                    <input type="text" name="keyf2">
                    <input type="text" name="keyf3">
                    <input type="text" name="keyf4">
                    <input type="text" name="keyf5">
                <label>Additional Information</label>
                    <textarea name="ld" placeholder="Enter Legal Disclaimer Here..."></textarea>
                
                <input type="submit" name="Submit" class="action-button" value="Submit" style="float: right;" />
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right;"/>
            </fieldset  style="text-align: left;" >
        </form>
    
</div>
<!-- /.MultiStep Form -->



<div class="col-md-8" id="myform8b">
        <form id="msform" method="post" action="add_post" enctype='multipart/form-data'>
            <!-- progressbar -->
            <ul id="progressbar">
                <li class="active">Basic Info</li>
                <li>Additional</li>
                <li>Offers</li>
                <li>Images</li>
                <li>Description</li>
            </ul>
            <!-- fieldset  style="text-align: left;" s -->
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Basic Information Of Product</h2>
                <label class="hs2" style="text-align: center;">Perfume and Fragnances</label>
                <input type="hidden" name="Art" value="C23">
                <label>Sub-Category</label>
                <select>
                    <option value="SC23001">Perfume and Fragnances</option>
                    <option value="SC23002">Perfume Gift Sets</option>
                </select>
                <label for="pid">Seller SKU</label>
                <input type="text" name="sku" id="sku">
                <label>Item Title</label>
                <input type="text" name="it" >
                <label>Item Code</label>
                <input type="text" name="ic">
                <label>Brand Name</label>
                <input type="text" name="bn">
                <label>Manufacturer</label>
                <input type="text" name="manuf">
                <label>Color</label>
                <select>
                    <option>White</option>
                    <option>Black</option>
                    <option>Blue</option>
                    <option>Red</option>
                </select>
                <label>Dimension</label>
                <input type="text" name="dimension">
                <label>Weight</label>
                <input type="text" name="weight">
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right">
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"  >
                <h2 class="fs-title">Additional Attributes</h2>
                <!-- <label>Is this an Accessory</label>
                <input type="radio" name="expiry" value="yes">Yes
                <input type="radio" name="expiry" value="no">No
                <label>Model</label>
                <input type="text" name="model">
                <label>Battery Required</label>
                <input type="radio" name="battery" value="yes">Yes
                <input type="radio" name="battery" value="no">No
                <label>Processor Type</label>
                <select>
                    <option>---Select---</option>
                    <option>Intel</option>
                    <option>Apple</option>
                    <option>Amd</option>
                </select>
                <label>USB Type</label>
                <select>
                    <option>---Select---</option>
                    <option>3.0</option>
                    <option>2.0</option>
                </select>
                <label>Processor Speed</label>
                <select>
                    <option>---Select---</option>
                    <option>3.8</option>
                    <option>3.5</option>
                    <option>3.2</option>
                    <option>3.0</option>
                </select>
                <label>Display Size</label>
                <input type="text" name="display">
                <label>Color</label>
                <select>
                    <option>---select---</option>
                    <option>black</option>
                    <option>white</option>
                    <option>blue</option>
                    <option>red</option>
                </select>
                <label>Hard Disk Capacity</label>
                <input type="text" name="hdd">
                <label>RAM Size</label>
                <input type="text" name="ram">
                <label>Shipping Weight</label>
                <input type="text" name="sweight">
                <label>Accessory Type</label>
                <select>
                    <option>---select---</option>
                    <option>Charger</option>
                    <option>Battery</option>
                    <option>Lens</option>
                </select>
                <label>Compatible with</label>
                <select>
                    <option>---select---</option>
                </select> --><label>No Additional Attributes yet</label>
                
                <input style="float: right" type="button" name="next" class="next action-button" value="Next"/>
                <input style="float: right" type="button" name="previous" class="previous action-button-previous" value="Previous"/>
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Offers of Product</h2>
                <label>Currancy</label>
                <input type="text" name="currency">
                <label>Sponsered</label>
                <input type="text" name="sponsered">
                <label>Unit of Measurement</label>
                <input type="text" name="uom">
                <label>Available Quantity</label>
                <input type="text" name="quantity">
                <label>Unit Price</label>
                <input type="text" name="uprice">
                <label class="con" style="text-align: left;">Condition</label>
                <select name="cond" class="con">
                    <option style="color: #2C3E50;">List Of Value</option>
                    <option>New</option>
                    <option>Used</option>
                    <option>Open Packet</option>
                </select>
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right"/>
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right"/>
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <label>Choose Images</label>
                <input type="file" name="image" multiple="multiple">
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right;" />    
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right;"/>            

            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Description of Product</h2>
                <label>Product Description</label>
                <textarea name="pd" placeholder="Enter Product Description Here..."></textarea>
                <label>Key Product Features</label>
                    <input type="text" name="keyf1">
                    <input type="text" name="keyf2">
                    <input type="text" name="keyf3">
                    <input type="text" name="keyf4">
                    <input type="text" name="keyf5">
                <label>Additional Information</label>
                    <textarea name="ld" placeholder="Enter Legal Disclaimer Here..."></textarea>
                
                <input type="submit" name="Submit" class="action-button" value="Submit" style="float: right;" />
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right;"/>
            </fieldset  style="text-align: left;" >
        </form>
    
</div>
<!-- /.MultiStep Form -->



<div class="col-md-8" id="myform8c">
        <form id="msform" method="post" action="add_post" enctype='multipart/form-data'>
            <!-- progressbar -->
            <ul id="progressbar">
                <li class="active">Basic Info</li>
                <li>Additional</li>
                <li>Offers</li>
                <li>Images</li>
                <li>Description</li>
            </ul>
            <!-- fieldset  style="text-align: left;" s -->
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Basic Information Of Product</h2>
                <label class="hs2" style="text-align: center;">Pet Food and Supplies</label>
                <input type="hidden" name="Art" value="C24">
                <label>Sub-Category</label>
                <select>
                    <option value="SC24001">Pet and Animal Foods</option>
                    <option value="SC24002">Pet and Animal Supplies</option>
                </select>
                <label for="pid">Seller SKU</label>
                <input type="text" name="sku" id="sku">
                <label>Item Title</label>
                <input type="text" name="it" >
                <label>Item Code</label>
                <input type="text" name="ic">
                <label>Brand Name</label>
                <input type="text" name="bn">
                <label>Manufacturer</label>
                <input type="text" name="manuf">
                <label>Color</label>
                <select>
                    <option>White</option>
                    <option>Black</option>
                    <option>Blue</option>
                    <option>Red</option>
                </select>
                <label>Dimension</label>
                <input type="text" name="dimension">
                <label>Weight</label>
                <input type="text" name="weight">
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right">
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"  >
                <h2 class="fs-title">Additional Attributes</h2>
                <!-- <label>Is this an Accessory</label>
                <input type="radio" name="expiry" value="yes">Yes
                <input type="radio" name="expiry" value="no">No
                <label>Model</label>
                <input type="text" name="model">
                <label>Battery Required</label>
                <input type="radio" name="battery" value="yes">Yes
                <input type="radio" name="battery" value="no">No
                <label>Processor Type</label>
                <select>
                    <option>---Select---</option>
                    <option>Intel</option>
                    <option>Apple</option>
                    <option>Amd</option>
                </select>
                <label>USB Type</label>
                <select>
                    <option>---Select---</option>
                    <option>3.0</option>
                    <option>2.0</option>
                </select>
                <label>Processor Speed</label>
                <select>
                    <option>---Select---</option>
                    <option>3.8</option>
                    <option>3.5</option>
                    <option>3.2</option>
                    <option>3.0</option>
                </select>
                <label>Display Size</label>
                <input type="text" name="display">
                <label>Color</label>
                <select>
                    <option>---select---</option>
                    <option>black</option>
                    <option>white</option>
                    <option>blue</option>
                    <option>red</option>
                </select>
                <label>Hard Disk Capacity</label>
                <input type="text" name="hdd">
                <label>RAM Size</label>
                <input type="text" name="ram">
                <label>Shipping Weight</label>
                <input type="text" name="sweight">
                <label>Accessory Type</label>
                <select>
                    <option>---select---</option>
                    <option>Charger</option>
                    <option>Battery</option>
                    <option>Lens</option>
                </select>
                <label>Compatible with</label>
                <select>
                    <option>---select---</option>
                </select> --><label>No Additional Attributes yet</label>
                
                <input style="float: right" type="button" name="next" class="next action-button" value="Next"/>
                <input style="float: right" type="button" name="previous" class="previous action-button-previous" value="Previous"/>
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Offers of Product</h2>
                <label>Currancy</label>
                <input type="text" name="currency">
                <label>Sponsered</label>
                <input type="text" name="sponsered">
                <label>Unit of Measurement</label>
                <input type="text" name="uom">
                <label>Available Quantity</label>
                <input type="text" name="quantity">
                <label>Unit Price</label>
                <input type="text" name="uprice">
                <label class="con" style="text-align: left;">Condition</label>
                <select name="cond" class="con">
                    <option style="color: #2C3E50;">List Of Value</option>
                    <option>New</option>
                    <option>Used</option>
                    <option>Open Packet</option>
                </select>
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right"/>
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right"/>
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <label>Choose Images</label>
                <input type="file" name="image" multiple="multiple">
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right;" />    
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right;"/>            

            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Description of Product</h2>
                <label>Product Description</label>
                <textarea name="pd" placeholder="Enter Product Description Here..."></textarea>
                <label>Key Product Features</label>
                    <input type="text" name="keyf1">
                    <input type="text" name="keyf2">
                    <input type="text" name="keyf3">
                    <input type="text" name="keyf4">
                    <input type="text" name="keyf5">
                <label>Additional Information</label>
                    <textarea name="ld" placeholder="Enter Legal Disclaimer Here..."></textarea>
                
                <input type="submit" name="Submit" class="action-button" value="Submit" style="float: right;" />
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right;"/>
            </fieldset  style="text-align: left;" >
        </form>
    
</div>
<!-- /.MultiStep Form -->






<div class="col-md-8" id="myform9">
        <form id="msform" method="post" action="add_post" enctype='multipart/form-data'>
            <!-- progressbar -->
            <ul id="progressbar">
                <li class="active">Basic Info</li>
                <li>Additional</li>
                <li>Offers</li>
                <li>Images</li>
                <li>Description</li>
            </ul>
            <!-- fieldset  style="text-align: left;" s -->
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Basic Information Of Product</h2>
                <label class="hs2" style="text-align: center;">Health and Personal Care</label>
                <input type="hidden" name="Art" value="C14">
                <label>Sub-Category</label>
                <select>
                    <option value="SC14001">Body Massagers</option>
                    <option value="SC14002">Dental Care</option>
                    <option value="SC14003">Personal Care</option>
                    <option value="SC14004">Digital Fever Thermometers</option>
                    <option value="SC14005">Electric Shavers</option>
                    <option value="SC14006">Men's Grooming</option>
                    <option value="SC14007">Personal Scales</option>
                    <option value="SC14008">Small Medical Equipments</option>   
                </select>
                <label for="pid">Seller SKU</label>
                <input type="text" name="sku" id="sku">
                <label>Item Title</label>
                <input type="text" name="it" >
                <label>Item Code</label>
                <input type="text" name="ic">
                <label>Brand Name</label>
                <input type="text" name="bn">
                <label>Manufacturer</label>
                <input type="text" name="manuf">
                <label>Color</label>
                <select>
                    <option>White</option>
                    <option>Black</option>
                    <option>Blue</option>
                    <option>Red</option>
                </select>
                <label>Dimension</label>
                <input type="text" name="dimension">
                <label>Weight</label>
                <input type="text" name="weight">
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right">
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"  >
                <h2 class="fs-title">Additional Attributes</h2>
                <label>Battery required</label>
                <input type="radio" name="battery" value="yes">Yes
                <input type="radio" name="battery" value="no">No
                <label>Color</label>
                <select>
                    <option>---select---</option>
                    <option>black</option>
                    <option>white</option>
                    <option>blue</option>
                    <option>red</option>
                </select>
                <label>Item Type</label>
                <select>
                    <option>---select---</option>
                    <option>item1</option>
                    <option>item2</option>
                    <option>item3</option>
                    <option>item4</option>
                </select>
                
                <input style="float: right" type="button" name="next" class="next action-button" value="Next"/>
                <input style="float: right" type="button" name="previous" class="previous action-button-previous" value="Previous"/>
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Offers of Product</h2>
                <label>Currancy</label>
                <input type="text" name="currency">
                <label>Sponsered</label>
                <input type="text" name="sponsered">
                <label>Unit of Measurement</label>
                <input type="text" name="uom">
                <label>Available Quantity</label>
                <input type="text" name="quantity">
                <label>Unit Price</label>
                <input type="text" name="uprice">
                <label class="con" style="text-align: left;">Condition</label>
                <select name="cond" class="con">
                    <option style="color: #2C3E50;">List Of Value</option>
                    <option>New</option>
                    <option>Used</option>
                    <option>Open Packet</option>
                </select>
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right"/>
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right"/>
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <label>Choose Images</label>
                <input type="file" name="image" multiple="multiple">
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right;" />    
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right;"/>
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Description of Product</h2>
                <label>Product Description</label>
                <textarea name="pd" placeholder="Enter Product Description Here..."></textarea>
                <label>Key Product Features</label>
                    <input type="text" name="keyf1">
                    <input type="text" name="keyf2">
                    <input type="text" name="keyf3">
                    <input type="text" name="keyf4">
                    <input type="text" name="keyf5">
                <label>Additional Information</label>
                    <textarea name="ld" placeholder="Enter Legal Disclaimer Here..."></textarea>
                
                <input type="submit" name="Submit" class="action-button" value="Submit" style="float: right;" />
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right;"/>
            </fieldset  style="text-align: left;" >
        </form>
    
</div>
<!-- /.MultiStep Form -->




<div class="col-md-8" id="myform10">
        <form id="msform" method="post" action="add_post" enctype='multipart/form-data'>
            <!-- progressbar -->
            <ul id="progressbar">
                <li class="active">Basic Info</li>
                <li>Additional</li>
                <li>Offers</li>
                <li>Images</li>
                <li>Description</li>
            </ul>
            <!-- fieldset  style="text-align: left;" s -->
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Basic Information Of Product</h2>
                <label class="hs2" style="text-align: center;">Jewelry and Accessories</label>
                <input type="hidden" name="Art" value="C17">
                <label>Sub-Category</label>
                <select>
                    <option value="SC17001">Braclets</option>
                    <option value="SC17002">Earrings</option>
                    <option value="SC17003">Jewlry Accessories</option>
                    <option value="SC17004">Jewlry Sets</option>
                    <option value="SC17005">Loose Gemstones and Diamonds</option>
                    <option value="SC17006">Men's Jewelry</option>
                    <option value="SC17007">Necklaces</option>
                    <option value="SC17008">Pendants and Charms</option>
                    <option value="SC17009">Rings</option>
                </select>
                <label for="pid">Seller SKU</label>
                <input type="text" name="sku" id="sku">
                <label>Item Title</label>
                <input type="text" name="it" >
                <label>Item Code</label>
                <input type="text" name="ic">
                <label>Brand Name</label>
                <input type="text" name="bn">
                <label>Manufacturer</label>
                <input type="text" name="manuf">
                <label>Color</label>
                <select>
                    <option>White</option>
                    <option>Black</option>
                    <option>Blue</option>
                    <option>Red</option>
                </select>
                <label>Dimension</label>
                <input type="text" name="dimension">
                <label>Weight</label>
                <input type="text" name="weight">
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right">
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"  >
                <h2 class="fs-title">Additional Attributes</h2>
                <label>Number of Pieces</label>
                <input type="Number" name="piece">
                <label>Jewelry Type</label>
                <select>
                    <option>---select---</option>
                    <option>black</option>
                    <option>white</option>
                    <option>blue</option>
                    <option>red</option>
                </select>
                <label>Meterial Type</label>
                <input type="text" name="material">
                <label>Target Audience Sex</label>
                <select>
                    <option>---select---</option>
                    <option>Male</option>
                    <option>Female</option>
                    <option>Both</option>
                </select>
                <label>Target Audience Age</label>
                <select>
                    <option>---select---</option>
                    <option>less than 20 years</option>
                    <option>20-50 years</option>
                    <option>greater then 50 years</option>
                </select>
                
                <input style="float: right" type="button" name="next" class="next action-button" value="Next"/>
                <input style="float: right" type="button" name="previous" class="previous action-button-previous" value="Previous"/>
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Offers of Product</h2>
                <label>Currancy</label>
                <input type="text" name="currency">
                <label>Sponsered</label>
                <input type="text" name="sponsered">
                <label>Unit of Measurement</label>
                <input type="text" name="uom">
                <label>Available Quantity</label>
                <input type="text" name="quantity">
                <label>Unit Price</label>
                <input type="text" name="uprice">
                <label class="con" style="text-align: left;">Condition</label>
                <select name="cond" class="con">
                    <option style="color: #2C3E50;">List Of Value</option>
                    <option>New</option>
                    <option>Used</option>
                    <option>Open Packet</option>
                </select>
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right"/>
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right"/>
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <label>Choose Images</label>
                <input type="file" name="image" multiple="multiple">
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right;" />    
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right;"/>
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Description of Product</h2>
                <label>Product Description</label>
                <textarea name="pd" placeholder="Enter Product Description Here..."></textarea>
                <label>Key Product Features</label>
                    <input type="text" name="keyf1">
                    <input type="text" name="keyf2">
                    <input type="text" name="keyf3">
                    <input type="text" name="keyf4">
                    <input type="text" name="keyf5">
                <label>Additional Information</label>
                    <textarea name="ld" placeholder="Enter Legal Disclaimer Here..."></textarea>
                
                <input type="submit" name="Submit" class="action-button" value="Submit" style="float: right;" />
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right;"/>
            </fieldset  style="text-align: left;" >
        </form>
    
</div>
<!-- /.MultiStep Form -->




<div class="col-md-8" id="myform11">
    <form id="msform" method="post" action="add_post" enctype='multipart/form-data'>
            <!-- progressbar -->
            <ul id="progressbar">
                <li class="active">Basic Info</li>
                <li>Additional</li>
                <li>Offers</li>
                <li>Images</li>
                <li>Description</li>
            </ul>
            <!-- fieldset  style="text-align: left;" s -->
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Basic Information Of Product</h2>
                <label class="hs2" style="text-align: center;">Kitchen Appliances</label>
                <input type="hidden" name="Art" value="C18">
                <label>Sub-Category</label>
                <select>
                    <option value="SC18001">Blender and Mixers</option>
                    <option value="SC18002">Coffee Makers</option>
                    <option value="SC18003">Dishwashers</option>
                    <option value="SC18004">Electric Meat Grinders</option>
                    <option value="SC18005">Ice Cream Makers</option>
                    <option value="SC18006">Juicers</option>
                    <option value="SC18007">Kettles</option>
                    <option value="SC18008">Microwaves</option>
                    <option value="SC18009">Ovens, ranges and Stoves</option>
                    <option value="SC18010">Refigrators and Freezers</option>
                    <option value="SC18011">Rice Cookers</option>
                    <option value="SC18012">Sandwich makers</option>
                    <option value="SC18013">Special Kitchen Appliances</option>
                    <option value="SC18014">Toasters</option>
                    <option value="SC18015">Water Cooler and Dispensers</option>
                </select>
                <label for="pid">Seller SKU</label>
                <input type="text" name="sku" id="sku">
                <label>Item Title</label>
                <input type="text" name="it" >
                <label>Item Code</label>
                <input type="text" name="ic">
                <label>Brand Name</label>
                <input type="text" name="bn">
                <label>Manufacturer</label>
                <input type="text" name="manuf">
                <label>Color</label>
                <select>
                    <option>White</option>
                    <option>Black</option>
                    <option>Blue</option>
                    <option>Red</option>
                </select>
                <label>Dimension</label>
                <input type="text" name="dimension">
                <label>Weight</label>
                <input type="text" name="weight">
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right">
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"  >
                <h2 class="fs-title">Additional Attributes</h2>
                <label>Battery Required</label>
                <input type="radio" name="battery" value="yes">Yes
                <input type="radio" name="battery" value="no">No
                <label>Model</label>
                <input type="text" name="model">
                <label>Number of pieces</label>
                <input type="Number" name="piece">
                <label>Type</label>
                <select>
                    <option>---select---</option>
                    <option>black</option>
                    <option>white</option>
                    <option>blue</option>
                    <option>red</option>
                </select>
                <label>Shipping Weight</label>
                <input type="text" name="weight">
                <label>Power Source</label>
                <select>
                    <option>---select---</option>
                    <option>source1</option>
                    <option>source2</option>
                    <option>source3</option>
                </select>
                
                <input style="float: right" type="button" name="next" class="next action-button" value="Next"/>
                <input style="float: right" type="button" name="previous" class="previous action-button-previous" value="Previous"/>
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Offers of Product</h2>
                <label>Currancy</label>
                <input type="text" name="currency">
                <label>Sponsered</label>
                <input type="text" name="sponsered">
                <label>Unit of Measurement</label>
                <input type="text" name="uom">
                <label>Available Quantity</label>
                <input type="text" name="quantity">
                <label>Unit Price</label>
                <input type="text" name="uprice">
                <label class="con" style="text-align: left;">Condition</label>
                <select name="cond" class="con">
                    <option style="color: #2C3E50;">List Of Value</option>
                    <option>New</option>
                    <option>Used</option>
                    <option>Open Packet</option>
                </select>
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right"/>
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right"/>
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <label>Choose Images</label>
                <input type="file" name="image" multiple="multiple">
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right;" />    
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right;"/>
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Description of Product</h2>
                <label>Product Description</label>
                <textarea name="pd" placeholder="Enter Product Description Here..."></textarea>
                <label>Key Product Features</label>
                    <input type="text" name="keyf1">
                    <input type="text" name="keyf2">
                    <input type="text" name="keyf3">
                    <input type="text" name="keyf4">
                    <input type="text" name="keyf5">
                <label>Additional Information</label>
                    <textarea name="ld" placeholder="Enter Legal Disclaimer Here..."></textarea>
                
                <input type="submit" name="Submit" class="action-button" value="Submit" style="float: right;" />
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right;"/>
            </fieldset  style="text-align: left;" >
        </form>
    
</div>
<!-- /.MultiStep Form -->




<div class="col-md-8" id="myform12">
        <form id="msform" method="post" action="add_post" enctype='multipart/form-data'>
            <!-- progressbar -->
            <ul id="progressbar">
                <li class="active">Basic Info</li>
                <li>Additional</li>
                <li>Offers</li>
                <li>Images</li>
                <li>Description</li>
            </ul>
            <!-- fieldset  style="text-align: left;" s -->
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Basic Information Of Product</h2>
                <label class="hs2" style="text-align: center;">Mobile Phones, Tablets and Accessories</label>
                <input type="hidden" name="Art" value="C20">
                <label>Sub-Category</label>
                <select>
                    <option value="SC20001">Mobile Phones</option>
                    <option value="SC20002">Screen Protectors</option>
                    <option value="SC20003">Skins and Decals</option>
                    <option value="SC20004">Smart Watches</option>
                    <option value="SC20005">Tablets</option>
                    <option value="SC20006">VR Gadgets</option>
                </select>
                <label for="pid">Seller SKU</label>
                <input type="text" name="sku" id="sku">
                <label>Item Title</label>
                <input type="text" name="it" >
                <label>Item Code</label>
                <input type="text" name="ic">
                <label>Brand Name</label>
                <input type="text" name="bn">
                <label>Manufacturer</label>
                <input type="text" name="manuf">
                <label>Color</label>
                <select>
                    <option>White</option>
                    <option>Black</option>
                    <option>Blue</option>
                    <option>Red</option>
                </select>
                <label>Dimension</label>
                <input type="text" name="dimension">
                <label>Weight</label>
                <input type="text" name="weight">
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right">
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"  >
                <h2 class="fs-title">Additional Attributes</h2>
                <label>Is this an Accessory</label>
                <input type="radio" name="expiry" value="yes">Yes
                <input type="radio" name="expiry" value="no">No
                <label>Type</label>
                <select>
                    <option>---select---</option>
                    <option>type1</option>
                    <option>type2</option>
                    <option>type3</option>
                </select>
                <label>Operating System</label>
                <select>
                    <option>---select---</option>
                    <option>Windows</option>
                    <option>Mac</option>
                    <option>Android</option>
                </select>
                <label>Chipset Manufacturer</label>
                <select>
                    <option>---select---</option>
                    <option>Intel</option>
                    <option>Apple</option>
                    <option>AMD</option>
                </select>
                <label>Battery Capacity</label>
                <select>
                    <option>---select---</option>
                    <option>4800 mah</option>
                    <option>4000 mah</option>
                    <option>3200 mah</option>
                </select>
                <label>Display Size</label>
                <select>
                    <option>---select---</option>
                    <option>4.0 inches</option>
                    <option>4.5 inches</option>
                    <option>5.0 inches</option>
                </select>
                <label>Model Number</label>
                <input type="text" name="model">
                <label>Battery Required</label>
                <input type="radio" name="battery" value="yes">Yes
                <input type="radio" name="battery" value="no">No
                <label>Storage Capacity</label>
                <input type="text" name="capacity">
                <label>Memory RAM</label>
                <input type="text" name="ram">
                <label>Accessory Type</label>
                <input type="text" name="type">
                <label>Compatible with</label>
                <input type="text" name="compatible">
                <label>Color</label>
                <select>
                    <option>---select---</option>
                    <option>White</option>
                    <option>Black</option>
                    <option>Blue</option>
                    <option>Red</option>
                </select>
                
                <input style="float: right" type="button" name="next" class="next action-button" value="Next"/>
                <input style="float: right" type="button" name="previous" class="previous action-button-previous" value="Previous"/>
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Offers of Product</h2>
                <label>Currancy</label>
                <input type="text" name="currency">
                <label>Sponsered</label>
                <input type="text" name="sponsered">
                <label>Unit of Measurement</label>
                <input type="text" name="uom">
                <label>Available Quantity</label>
                <input type="text" name="quantity">
                <label>Unit Price</label>
                <input type="text" name="uprice">
                <label class="con" style="text-align: left;">Condition</label>
                <select name="cond" class="con">
                    <option style="color: #2C3E50;">List Of Value</option>
                    <option>New</option>
                    <option>Used</option>
                    <option>Open Packet</option>
                </select>
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right"/>
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right"/>
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <label>Choose Images</label>
                <input type="file" name="image" multiple="multiple">
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right;" />    
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right;"/>            

            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Description of Product</h2>
                <label>Product Description</label>
                <textarea name="pd" placeholder="Enter Product Description Here..."></textarea>
                <label>Key Product Features</label>
                    <input type="text" name="keyf1">
                    <input type="text" name="keyf2">
                    <input type="text" name="keyf3">
                    <input type="text" name="keyf4">
                    <input type="text" name="keyf5">
                <label>Additional Information</label>
                    <textarea name="ld" placeholder="Enter Legal Disclaimer Here..."></textarea>
                
                <input type="submit" name="Submit" class="action-button" value="Submit" style="float: right;" />
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right;"/>
            </fieldset  style="text-align: left;" >
        </form>
    
</div>
<!-- /.MultiStep Form -->




<div class="col-md-8" id="myform13">
        <form id="msform" method="post" action="add_post" enctype='multipart/form-data'>
            <!-- progressbar -->
            <ul id="progressbar">
                <li class="active">Basic Info</li>
                <li>Additional</li>
                <li>Offers</li>
                <li>Images</li>
                <li>Description</li>
            </ul>
            <!-- fieldset  style="text-align: left;" s -->
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Basic Information Of Product</h2>
                <label class="hs2" style="text-align: center;">Office Products and Supplies</label>
                <input type="hidden" name="Art" value="C22">
                <label>Sub-Category</label>
                <select>
                    <option value="SC22001">Fax Machines</option>
                    <option value="SC22002">Printers</option>
                    <option value="SC22003">Office Equipments</option>
                    <option value="SC22004">Office Supplies</option>
                    <option value="SC22005">Printers</option>
                    <option value="SC22006">Stationary</option>
                </select>
                <label for="pid">Seller SKU</label>
                <input type="text" name="sku" id="sku">
                <label>Item Title</label>
                <input type="text" name="it" >
                <label>Item Code</label>
                <input type="text" name="ic">
                <label>Brand Name</label>
                <input type="text" name="bn">
                <label>Manufacturer</label>
                <input type="text" name="manuf">
                <label>Color</label>
                <select>
                    <option>White</option>
                    <option>Black</option>
                    <option>Blue</option>
                    <option>Red</option>
                </select>
                <label>Dimension</label>
                <input type="text" name="dimension">
                <label>Weight</label>
                <input type="text" name="weight">
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right">
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"  >
                <h2 class="fs-title">Additional Attributes</h2>
                <label>Battery Required</label>
                <input type="radio" name="battery" value="yes">Yes
                <input type="radio" name="battery" value="no">No
                <label>Office Product Type</label>
                <select>
                    <option>---select---</option>
                    <option>black</option>
                    <option>white</option>
                    <option>blue</option>
                    <option>red</option>
                </select>
                <label>Color</label>
                <select>
                    <option>---select---</option>
                    <option>black</option>
                    <option>white</option>
                    <option>brown</option>
                </select>
                
                <input style="float: right" type="button" name="next" class="next action-button" value="Next"/>
                <input style="float: right" type="button" name="previous" class="previous action-button-previous" value="Previous"/>
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Offers of Product</h2>
                <label>Currancy</label>
                <input type="text" name="currency">
                <label>Sponsered</label>
                <input type="text" name="sponsered">
                <label>Unit of Measurement</label>
                <input type="text" name="uom">
                <label>Available Quantity</label>
                <input type="text" name="quantity">
                <label>Unit Price</label>
                <input type="text" name="uprice">
                <label class="con" style="text-align: left;">Condition</label>
                <select name="cond" class="con">
                    <option style="color: #2C3E50;">List Of Value</option>
                    <option>New</option>
                    <option>Used</option>
                    <option>Open Packet</option>
                </select>
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right"/>
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right"/>
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <label>Choose Images</label>
                <input type="file" name="image" multiple="multiple">
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right;" />    
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right;"/>
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Description of Product</h2>
                <label>Product Description</label>
                <textarea name="pd" placeholder="Enter Product Description Here..."></textarea>
                <label>Key Product Features</label>
                    <input type="text" name="keyf1">
                    <input type="text" name="keyf2">
                    <input type="text" name="keyf3">
                    <input type="text" name="keyf4">
                    <input type="text" name="keyf5">
                <label>Additional Information</label>
                    <textarea name="ld" placeholder="Enter Legal Disclaimer Here..."></textarea>
                
                <input type="submit" name="Submit" class="action-button" value="Submit" style="float: right;" />
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right;"/>
            </fieldset  style="text-align: left;" >
        </form>
    
</div>
<!-- /.MultiStep Form -->




<div class="col-md-8" id="myform14">
        <form id="msform" method="post" action="add_post" enctype='multipart/form-data'>
            <!-- progressbar -->
            <ul id="progressbar">
                <li class="active">Basic Info</li>
                <li>Additional</li>
                <li>Offers</li>
                <li>Images</li>
                <li>Description</li>
            </ul>
            <!-- fieldset  style="text-align: left;" s -->
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Basic Information Of Product</h2>
                <label class="hs2" style="text-align: center;">Sports and Fitness</label>
                <input type="hidden" name="Art" value="C25">
                <label>Sub-Category</label>
                <select>
                    <option value="SC25001">Athletic Shoes</option>
                    <option value="SC25002">Balls</option>
                    <option value="SC25003">Bikes and Bicycles</option>
                    <option value="SC25004">Cycling Goods</option>
                    <option value="SC25005">Exercise Bikes</option>
                    <option value="SC25006">Flash Lights</option>
                    <option value="SC25007">Outdoor Play</option>
                    <option value="SC25008">Protective Gear</option>
                    <option value="SC25009">Rackets</option>
                    <option value="SC25010">Scooter and Ride ons</option>
                    <option value="SC25011">Sport Gloves</option>
                    <option value="SC25012">Sporting Goods</option>
                    <option value="SC25013">Sport Equipments</option>
                    <option value="SC25014">Sport Watches</option>
                    <option value="SC25015">Treadmills</option>
                    <option value="SC25016">Weights and Dumbles</option>
                </select>
                <label for="pid">Seller SKU</label>
                <input type="text" name="sku" id="sku">
                <label>Item Title</label>
                <input type="text" name="it" >
                <label>Item Code</label>
                <input type="text" name="ic">
                <label>Brand Name</label>
                <input type="text" name="bn">
                <label>Manufacturer</label>
                <input type="text" name="manuf">
                <label>Color</label>
                <select>
                    <option>White</option>
                    <option>Black</option>
                    <option>Blue</option>
                    <option>Red</option>
                </select>
                <label>Dimension</label>
                <input type="text" name="dimension">
                <label>Weight</label>
                <input type="text" name="weight">
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right">
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"  >
                <h2 class="fs-title">Additional Attributes</h2>
                <label>Battery Required</label>
                <input type="radio" name="battery" value="yes">Yes
                <input type="radio" name="battery" value="no">No
                <label>Equipment Type</label>
                <select>
                    <option>---select---</option>
                    <option>black</option>
                    <option>white</option>
                    <option>blue</option>
                    <option>red</option>
                </select>
                <label>Shipping Weight</label>
                <input type="text" name="sweight">
                
                <input style="float: right" type="button" name="next" class="next action-button" value="Next"/>
                <input style="float: right" type="button" name="previous" class="previous action-button-previous" value="Previous"/>
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Offers of Product</h2>
                <label>Currancy</label>
                <input type="text" name="currency">
                <label>Sponsered</label>
                <input type="text" name="sponsered">
                <label>Unit of Measurement</label>
                <input type="text" name="uom">
                <label>Available Quantity</label>
                <input type="text" name="quantity">
                <label>Unit Price</label>
                <input type="text" name="uprice">
                <label class="con" style="text-align: left;">Condition</label>
                <select name="cond" class="con">
                    <option style="color: #2C3E50;">List Of Value</option>
                    <option>New</option>
                    <option>Used</option>
                    <option>Open Packet</option>
                </select>
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right"/>
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right"/>
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <label>Choose Images</label>
                <input type="file" name="image" multiple="multiple">
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right;" />    
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right;"/>
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Description of Product</h2>
                <label>Product Description</label>
                <textarea name="pd" placeholder="Enter Product Description Here..."></textarea>
                <label>Key Product Features</label>
                    <input type="text" name="keyf1">
                    <input type="text" name="keyf2">
                    <input type="text" name="keyf3">
                    <input type="text" name="keyf4">
                    <input type="text" name="keyf5">
                <label>Additional Information</label>
                    <textarea name="ld" placeholder="Enter Legal Disclaimer Here..."></textarea>
                
                <input type="submit" name="Submit" class="action-button" value="Submit" style="float: right;" />
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right;"/>
            </fieldset  style="text-align: left;" >
        </form>
    
</div>
<!-- /.MultiStep Form -->




<div class="col-md-8" id="myform15">
        <form id="msform" method="post" action="add_post" enctype='multipart/form-data'>
            <!-- progressbar -->
            <ul id="progressbar">
                <li class="active">Basic Info</li>
                <li>Additional</li>
                <li>Offers</li>
                <li>Images</li>
                <li>Description</li>
            </ul>
            <!-- fieldset  style="text-align: left;" s -->
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Basic Information Of Product</h2>
                <label class="hs2" style="text-align: center;">Tools and Home Improvements</label>
                <input type="hidden" name="Art" value="C26">
                <label>Sub-Category</label>
                <select>
                    <option value="SC26001">Drills</option>
                    <option value="SC26002">Electrical and Electronic Accessories</option>
                    <option value="SC26003">Hand Tools</option>
                    <option value="SC26004">Measuring and layout Tools</option>
                    <option value="SC26005">Nails, Screws and Fixings</option>
                    <option value="SC26006">Paint and Supplies</option>
                    <option value="SC26007">Power and Hand Tools Accessories</option>
                    <option value="SC26008">Power Tools</option>
                    <option value="SC26009">Safety and Work Wear Products</option>
                </select>
                <label for="pid">Seller SKU</label>
                <input type="text" name="sku" id="sku">
                <label>Item Title</label>
                <input type="text" name="it" >
                <label>Item Code</label>
                <input type="text" name="ic">
                <label>Brand Name</label>
                <input type="text" name="bn">
                <label>Manufacturer</label>
                <input type="text" name="manuf">
                <label>Color</label>
                <select>
                    <option>White</option>
                    <option>Black</option>
                    <option>Blue</option>
                    <option>Red</option>
                </select>
                <label>Dimension</label>
                <input type="text" name="dimension">
                <label>Weight</label>
                <input type="text" name="weight">
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right">
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"  >
                <h2 class="fs-title">Additional Attributes</h2>
                <label>Battery Required</label>
                <input type="radio" name="battery" value="yes">Yes
                <input type="radio" name="battery" value="no">No
                <label>Model</label>
                <input type="text" name="model">
                <label>Tools Type</label>
                <select>
                    <option>---select---</option>
                    <option>black</option>
                    <option>white</option>
                    <option>blue</option>
                    <option>red</option>
                </select>
                <label>Power Source</label>
                <select>
                    <option>---select---</option>
                    <option>black</option>
                    <option>white</option>
                    <option>brown</option>
                </select>
                <label>Shipping Weight</label>
                <input type="text" name="sweight">
                
                <input style="float: right" type="button" name="next" class="next action-button" value="Next"/>
                <input style="float: right" type="button" name="previous" class="previous action-button-previous" value="Previous"/>
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Offers of Product</h2>
                <label>Currancy</label>
                <input type="text" name="currency">
                <label>Sponsered</label>
                <input type="text" name="sponsered">
                <label>Unit of Measurement</label>
                <input type="text" name="uom">
                <label>Available Quantity</label>
                <input type="text" name="quantity">
                <label>Unit Price</label>
                <input type="text" name="uprice">
                <label class="con" style="text-align: left;">Condition</label>
                <select name="cond" class="con">
                    <option style="color: #2C3E50;">List Of Value</option>
                    <option>New</option>
                    <option>Used</option>
                    <option>Open Packet</option>
                </select>
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right"/>
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right"/>
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <label>Choose Images</label>
                <input type="file" name="image" multiple="multiple">
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right;" />    
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right;"/>
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Description of Product</h2>
                <label>Product Description</label>
                <textarea name="pd" placeholder="Enter Product Description Here..."></textarea>
                <label>Key Product Features</label>
                    <input type="text" name="keyf1">
                    <input type="text" name="keyf2">
                    <input type="text" name="keyf3">
                    <input type="text" name="keyf4">
                    <input type="text" name="keyf5">
                <label>Additional Information</label>
                    <textarea name="ld" placeholder="Enter Legal Disclaimer Here..."></textarea>
                
                <input type="submit" name="Submit" class="action-button" value="Submit" style="float: right;" />
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right;"/>
            </fieldset  style="text-align: left;" >
        </form>
    
</div>
<!-- /.MultiStep Form -->




<div class="col-md-8" id="myform16">
        <form id="msform" method="post" action="add_post" enctype='multipart/form-data'>
            <!-- progressbar -->
            <ul id="progressbar">
                <li class="active">Basic Info</li>
                <li>Additional</li>
                <li>Offers</li>
                <li>Images</li>
                <li>Description</li>
            </ul>
            <!-- fieldset  style="text-align: left;" s -->
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Basic Information Of Product</h2>
                <label class="hs2" style="text-align: center;">Toys</label>
                <input type="hidden" name="Art" value="C27">
                <label>Sub-Category</label>
                <select>
                    <option value="27001">Toys</option>
                </select>
                <label for="pid">Seller SKU</label>
                <input type="text" name="sku" id="sku">
                <label>Item Title</label>
                <input type="text" name="it" >
                <label>Item Code</label>
                <input type="text" name="ic">
                <label>Brand Name</label>
                <input type="text" name="bn">
                <label>Manufacturer</label>
                <input type="text" name="manuf">
                <label>Color</label>
                <select>
                    <option>White</option>
                    <option>Black</option>
                    <option>Blue</option>
                    <option>Red</option>
                </select>
                <label>Dimension</label>
                <input type="text" name="dimension">
                <label>Weight</label>
                <input type="text" name="weight">
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right">
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"  >
                <h2 class="fs-title">Additional Attributes</h2>
                <label>Battery Required</label>
                <input type="radio" name="battery" value="yes">Yes
                <input type="radio" name="battery" value="no">No
                <label>Toy Category</label>
                <select>
                    <option>---select---</option>
                    <option>black</option>
                    <option>white</option>
                    <option>blue</option>
                    <option>red</option>
                </select>
                <label>Target Audience Sex</label>
                <select>
                    <option>---select---</option>
                    <option>black</option>
                    <option>white</option>
                    <option>brown</option>
                </select>
                <label>Target Audience Age</label>
                <select>
                    <option>---select---</option>
                    <option>black</option>
                    <option>white</option>
                    <option>brown</option>
                </select>
                <label>Manufacturer recommended Age</label>
                <select>
                    <option>---select---</option>
                    <option>black</option>
                    <option>white</option>
                    <option>brown</option>
                </select>
                
                <input style="float: right" type="button" name="next" class="next action-button" value="Next"/>
                <input style="float: right" type="button" name="previous" class="previous action-button-previous" value="Previous"/>
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Offers of Product</h2>
                <label>Currancy</label>
                <input type="text" name="currency">
                <label>Sponsered</label>
                <input type="text" name="sponsered">
                <label>Unit of Measurement</label>
                <input type="text" name="uom">
                <label>Available Quantity</label>
                <input type="text" name="quantity">
                <label>Unit Price</label>
                <input type="text" name="uprice">
                <label class="con" style="text-align: left;">Condition</label>
                <select name="cond" class="con">
                    <option style="color: #2C3E50;">List Of Value</option>
                    <option>New</option>
                    <option>Used</option>
                    <option>Open Packet</option>
                </select>
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right"/>
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right"/>
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <label>Choose Images</label>
                <input type="file" name="image" multiple="multiple">
                
                <input type="button" name="next" class="next action-button" value="Next" style="float: right;" />    
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right;"/>
            </fieldset  style="text-align: left;" >
            <fieldset  style="text-align: left;"   style="text-align: left;">
                <h2 class="fs-title">Description of Product</h2>
                <label>Product Description</label>
                <textarea name="pd" placeholder="Enter Product Description Here..."></textarea>
                <label>Key Product Features</label>
                    <input type="text" name="keyf1">
                    <input type="text" name="keyf2">
                    <input type="text" name="keyf3">
                    <input type="text" name="keyf4">
                    <input type="text" name="keyf5">
                <label>Additional Information</label>
                    <textarea name="ld" placeholder="Enter Legal Disclaimer Here..."></textarea>
                
                <input type="submit" name="Submit" class="action-button" value="Submit" style="float: right;" />
                <input type="button" name="previous" class="previous action-button-previous" value="Previous" style="float: right;"/>
            </fieldset  style="text-align: left;" >
        </form>
    </div>
</div>
<!-- /.MultiStep Form -->
  <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js'></script>

  

    <script  src="<?= base_url(); ?>assets/tjs/index.js"></script>


   
    
<div class="footer" id="footer">
    
    <div class="footer-inner">
        
        <div class="container">
            
            <div class="row">
                
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    &copy; 2013 <a href="#">Carrovan | ilegend Technologies</a>.
                </div> <!-- /span12 -->
                
            </div> <!-- /row -->
            
        </div> <!-- /container -->
        
    </div> <!-- /footer-inner -->
    
</div> <!-- /footer -->
    
</body>

 </html>
<script>

$(document).ready(function() {  
    $("#return").click(function() { 
        if($('#cat').is(":not(:visible)") )
        {
            $('#cat').show();
            $('#myform1a').hide();
            $('#myform1b').hide();
            $('#myform1c').hide();
            $('#myform1d').hide();
            $('#myform2').hide();
            $('#myform3').hide();
            $('#myform4').hide();
            $('#myform5').hide();
            $('#myform5a').hide();
            $('#myform6').hide();
            $('#myform6a').hide();
            $('#myform6b').hide();
            $('#myform6c').hide();
            $('#myform7').hide();
            $('#myform8').hide();
            $('#myform8a').hide();
            $('#myform8b').hide();
            $('#myform8c').hide();
            $('#myform9').hide();
            $('#myform10').hide();
            $('#myform11').hide();
            $('#myform12').hide();
            $('#myform13').hide();
            $('#myform14').hide();
            $('#myform15').hide();
            $('#myform16').hide();
            $('#myform1').hide(); 
        }
        else
        {
        }     
    });  
});

    $(document).ready(function() {  
    $("#mylink1").click(function() { 
        if($('#myform1').is(":not(:visible)") )
        {
            $('#cat').hide();
            $('#myform1a').hide();
            $('#myform1b').hide();
            $('#myform1c').hide();
            $('#myform1d').hide();
            $('#myform2').hide();
            $('#myform3').hide();
            $('#myform4').hide();
            $('#myform5').hide();
            $('#myform5a').hide();
            $('#myform6').hide();
            $('#myform6a').hide();
            $('#myform6b').hide();
            $('#myform6c').hide();
            $('#myform7').hide();
            $('#myform8').hide();
            $('#myform8a').hide();
            $('#myform8b').hide();
            $('#myform8c').hide();
            $('#myform9').hide();
            $('#myform10').hide();
            $('#myform11').hide();
            $('#myform12').hide();
            $('#myform13').hide();
            $('#myform14').hide();
            $('#myform15').hide();
            $('#myform16').hide();
            $('#myform1').show(); 
        }
        else
        {
        }     
    });  
});
$(document).ready(function() {  
    $("#mylink1a").click(function() { 
        if($('#myform1a').is(":not(:visible)") )
        {
            $('#cat').hide();
            $('#myform1').hide();
            $('#myform1b').hide();
            $('#myform1c').hide();
            $('#myform1d').hide();
            $('#myform2').hide();
            $('#myform3').hide();
            $('#myform4').hide();
            $('#myform5').hide();
            $('#myform5a').hide();
            $('#myform6').hide();
            $('#myform6a').hide();
            $('#myform6b').hide();
            $('#myform6c').hide();
            $('#myform7').hide();
            $('#myform8').hide();
            $('#myform8a').hide();
            $('#myform8b').hide();
            $('#myform8c').hide();
            $('#myform9').hide();
            $('#myform10').hide();
            $('#myform11').hide();
            $('#myform12').hide();
            $('#myform13').hide();
            $('#myform14').hide();
            $('#myform15').hide();
            $('#myform16').hide();
            $('#myform1a').show(); 
        }
        else
        {
         $('#myform1a').hide(); 
        }     
    });  
});
$(document).ready(function() {  
    $("#mylink1b").click(function() { 
        if($('#myform1b').is(":not(:visible)") )
        {
            $('#cat').hide();
            $('#myform1').hide();
            $('#myform1a').hide();
            $('#myform1c').hide();
            $('#myform1d').hide();
            $('#myform2').hide();
            $('#myform3').hide();
            $('#myform4').hide();
            $('#myform5').hide();
            $('#myform5a').hide();
            $('#myform6').hide();
            $('#myform6a').hide();
            $('#myform6b').hide();
            $('#myform6c').hide();
            $('#myform7').hide();
            $('#myform8').hide();
            $('#myform8a').hide();
            $('#myform8b').hide();
            $('#myform8c').hide();
            $('#myform9').hide();
            $('#myform10').hide();
            $('#myform11').hide();
            $('#myform12').hide();
            $('#myform13').hide();
            $('#myform14').hide();
            $('#myform15').hide();
            $('#myform16').hide();
            $('#myform1b').show(); 
        }
        else
        {
         $('#myform1b').hide(); 
        }     
    });  
});
$(document).ready(function() {  
    $("#mylink1c").click(function() { 
        if($('#myform1c').is(":not(:visible)") )
        {
            $('#cat').hide();
            $('#myform1').hide();
            $('#myform1a').hide();
            $('#myform1b').hide();
            $('#myform1d').hide();
            $('#myform2').hide();
            $('#myform3').hide();
            $('#myform4').hide();
            $('#myform5').hide();
            $('#myform5a').hide();
            $('#myform6').hide();
            $('#myform6a').hide();
            $('#myform6b').hide();
            $('#myform6c').hide();
            $('#myform7').hide();
            $('#myform8').hide();
            $('#myform8a').hide();
            $('#myform8b').hide();
            $('#myform8c').hide();
            $('#myform9').hide();
            $('#myform10').hide();
            $('#myform11').hide();
            $('#myform12').hide();
            $('#myform13').hide();
            $('#myform14').hide();
            $('#myform15').hide();
            $('#myform16').hide();
            $('#myform1c').show(); 
        }
        else
        {
         $('#myform1c').hide(); 
        }     
    });  
});
$(document).ready(function() {  
    $("#mylink1d").click(function() { 
        if($('#myform1d').is(":not(:visible)") )
        {
            $('#cat').hide();
            $('#myform1').hide();
            $('#myform1a').hide();
            $('#myform1b').hide();
            $('#myform1c').hide();
            $('#myform2').hide();
            $('#myform3').hide();
            $('#myform4').hide();
            $('#myform5').hide();
            $('#myform5a').hide();
            $('#myform6').hide();
            $('#myform6a').hide();
            $('#myform6b').hide();
            $('#myform6c').hide();
            $('#myform7').hide();
            $('#myform8').hide();
            $('#myform8a').hide();
            $('#myform8b').hide();
            $('#myform8c').hide();
            $('#myform9').hide();
            $('#myform10').hide();
            $('#myform11').hide();
            $('#myform12').hide();
            $('#myform13').hide();
            $('#myform14').hide();
            $('#myform15').hide();
            $('#myform16').hide();
            $('#myform1d').show(); 
        }
        else
        {
         $('#myform1d').hide(); 
        }     
    });  
});
     $(document).ready(function() {  
    $("#mylink2").click(function() { 
        if($('#myform2').is(":not(:visible)") )
        {
            $('#cat').hide();
            $('#myform1').hide();
            $('#myform1a').hide();
            $('#myform1b').hide();
            $('#myform1c').hide();
            $('#myform1d').hide();
            $('#myform3').hide();
            $('#myform4').hide();
            $('#myform5').hide();
            $('#myform5a').hide();
            $('#myform6').hide();
            $('#myform6a').hide();
            $('#myform6b').hide();
            $('#myform6c').hide();
            $('#myform7').hide();
            $('#myform8').hide();
            $('#myform8a').hide();
            $('#myform8b').hide();
            $('#myform8c').hide();
            $('#myform9').hide();
            $('#myform10').hide();
            $('#myform11').hide();
            $('#myform12').hide();
            $('#myform13').hide();
            $('#myform14').hide();
            $('#myform15').hide();
            $('#myform16').hide();
            $('#myform2').show();  
        }
        else
        {
         $('#myform2').hide(); 
        }       
    });  
});
     $(document).ready(function() {  
    $("#mylink3").click(function() { 
        if($('#myform3').is(":not(:visible)") )
        {
            $('#cat').hide();
            $('#myform1').hide();
            $('#myform1a').hide();
            $('#myform1b').hide();
            $('#myform1c').hide();
            $('#myform1d').hide();
            $('#myform2').hide();
            $('#myform4').hide();
            $('#myform5').hide();
            $('#myform5a').hide();
            $('#myform6').hide();
            $('#myform6a').hide();
            $('#myform6b').hide();
            $('#myform6c').hide();
            $('#myform7').hide();
            $('#myform8').hide();
            $('#myform8a').hide();
            $('#myform8b').hide();
            $('#myform8c').hide();
            $('#myform9').hide();
            $('#myform10').hide();
            $('#myform11').hide();
            $('#myform12').hide();
            $('#myform13').hide();
            $('#myform14').hide();
            $('#myform15').hide();
            $('#myform16').hide();
            $('#myform3').show(); 
        }
        else
        {
         $('#myform3').hide(); 
        }           
    });  
});
     $(document).ready(function() {  
    $("#mylink4").click(function() { 
         if($('#myform4').is(":not(:visible)") )
        {
            $('#cat').hide();
            $('#myform1').hide();
            $('#myform1a').hide();
            $('#myform1b').hide();
            $('#myform1c').hide();
            $('#myform1d').hide();
            $('#myform2').hide();
            $('#myform3').hide();
            $('#myform5').hide();
            $('#myform5a').hide();
            $('#myform6').hide();
            $('#myform6a').hide();
            $('#myform6b').hide();
            $('#myform6c').hide();
            $('#myform7').hide();
            $('#myform8').hide();
            $('#myform8a').hide();
            $('#myform8b').hide();
            $('#myform8c').hide();
            $('#myform9').hide();
            $('#myform10').hide();
            $('#myform11').hide();
            $('#myform12').hide();
            $('#myform13').hide();
            $('#myform14').hide();
            $('#myform15').hide();
            $('#myform16').hide();
            $('#myform4').show();  
        }
        else
        {
         $('#myform4').hide(); 
        }           
    });  
});
     $(document).ready(function() {  
    $("#mylink5").click(function() { 
        if($('#myform5').is(":not(:visible)") )
        {
            $('#cat').hide();
            $('#myform1').hide();
            $('#myform1a').hide();
            $('#myform1b').hide();
            $('#myform1c').hide();
            $('#myform1d').hide();
            $('#myform2').hide();
            $('#myform3').hide();
            $('#myform4').hide();
            $('#myform5a').hide();
            $('#myform6').hide();
            $('#myform6a').hide();
            $('#myform6b').hide();
            $('#myform6c').hide();
            $('#myform7').hide();
            $('#myform8').hide();
            $('#myform8a').hide();
            $('#myform8b').hide();
            $('#myform8c').hide();
            $('#myform9').hide();
            $('#myform10').hide();
            $('#myform11').hide();
            $('#myform12').hide();
            $('#myform13').hide();
            $('#myform14').hide();
            $('#myform15').hide();
            $('#myform16').hide();
            $('#myform5').show();  
        }
        else
        {
         $('#myform5').hide(); 
        }           
    });  
});
      $(document).ready(function() {  
    $("#mylink5a").click(function() { 
        if($('#myform5a').is(":not(:visible)") )
        {
            $('#cat').hide();
            $('#myform1').hide();
            $('#myform1a').hide();
            $('#myform1b').hide();
            $('#myform1c').hide();
            $('#myform1d').hide();
            $('#myform2').hide();
            $('#myform3').hide();
            $('#myform4').hide();
            $('#myform5').hide();
            $('#myform6').hide();
            $('#myform6a').hide();
            $('#myform6b').hide();
            $('#myform6c').hide();
            $('#myform7').hide();
            $('#myform8').hide();
            $('#myform8a').hide();
            $('#myform8b').hide();
            $('#myform8c').hide();
            $('#myform9').hide();
            $('#myform10').hide();
            $('#myform11').hide();
            $('#myform12').hide();
            $('#myform13').hide();
            $('#myform14').hide();
            $('#myform15').hide();
            $('#myform16').hide();
            $('#myform5a').show();  
        }
        else
        {
         $('#myform5a').hide(); 
        }           
    });  
});
    $(document).ready(function() {  
    $("#mylink6").click(function() { 
        if($('#myform6').is(":not(:visible)") )
        {
            $('#cat').hide();
            $('#myform1').hide();
            $('#myform1a').hide();
            $('#myform1b').hide();
            $('#myform1c').hide();
            $('#myform1d').hide();
            $('#myform2').hide();
            $('#myform3').hide();
            $('#myform4').hide();
            $('#myform5').hide();
            $('#myform5a').hide();
            $('#myform6a').hide();
            $('#myform6b').hide();
            $('#myform6c').hide();
            $('#myform7').hide();
            $('#myform8').hide();
            $('#myform8a').hide();
            $('#myform8b').hide();
            $('#myform8c').hide();
            $('#myform9').hide();
            $('#myform10').hide();
            $('#myform11').hide();
            $('#myform12').hide();
            $('#myform13').hide();
            $('#myform14').hide();
            $('#myform15').hide();
            $('#myform16').hide();
            $('#myform6').show(); 
        }
        else
        {
         $('#myform6').hide(); 
        }         
    });  
});
    $(document).ready(function() {  
    $("#mylink6a").click(function() { 
        if($('#myform6a').is(":not(:visible)") )
        {
            $('#cat').hide();
            $('#myform1').hide();
            $('#myform1a').hide();
            $('#myform1b').hide();
            $('#myform1c').hide();
            $('#myform1d').hide();
            $('#myform2').hide();
            $('#myform3').hide();
            $('#myform4').hide();
            $('#myform5').hide();
            $('#myform5a').hide();
            $('#myform6').hide();
            $('#myform6b').hide();
            $('#myform6c').hide();
            $('#myform7').hide();
            $('#myform8').hide();
            $('#myform8a').hide();
            $('#myform8b').hide();
            $('#myform8c').hide();
            $('#myform9').hide();
            $('#myform10').hide();
            $('#myform11').hide();
            $('#myform12').hide();
            $('#myform13').hide();
            $('#myform14').hide();
            $('#myform15').hide();
            $('#myform16').hide();
            $('#myform6a').show(); 
        }
        else
        {
         $('#myform6a').hide(); 
        }         
    });  
});
    $(document).ready(function() {  
    $("#mylink6b").click(function() { 
        if($('#myform6b').is(":not(:visible)") )
        {
            $('#cat').hide();
            $('#myform1').hide();
            $('#myform1a').hide();
            $('#myform1b').hide();
            $('#myform1c').hide();
            $('#myform1d').hide();
            $('#myform2').hide();
            $('#myform3').hide();
            $('#myform4').hide();
            $('#myform5').hide();
            $('#myform5a').hide();
            $('#myform6').hide();
            $('#myform6a').hide();
            $('#myform6c').hide();
            $('#myform7').hide();
            $('#myform8').hide();
            $('#myform8a').hide();
            $('#myform8b').hide();
            $('#myform8c').hide();
            $('#myform9').hide();
            $('#myform10').hide();
            $('#myform11').hide();
            $('#myform12').hide();
            $('#myform13').hide();
            $('#myform14').hide();
            $('#myform15').hide();
            $('#myform16').hide();
            $('#myform6b').show(); 
        }
        else
        {
         $('#myform6b').hide(); 
        }         
    });  
});
    $(document).ready(function() {  
    $("#mylink6c").click(function() { 
        if($('#myform6c').is(":not(:visible)") )
        {
            $('#cat').hide();
            $('#myform1').hide();
            $('#myform1a').hide();
            $('#myform1b').hide();
            $('#myform1c').hide();
            $('#myform1d').hide();
            $('#myform2').hide();
            $('#myform3').hide();
            $('#myform4').hide();
            $('#myform5').hide();
            $('#myform5a').hide();
            $('#myform6').hide();
            $('#myform6a').hide();
            $('#myform6b').hide();
            $('#myform7').hide();
            $('#myform8').hide();
            $('#myform8a').hide();
            $('#myform8b').hide();
            $('#myform8c').hide();
            $('#myform9').hide();
            $('#myform10').hide();
            $('#myform11').hide();
            $('#myform12').hide();
            $('#myform13').hide();
            $('#myform14').hide();
            $('#myform15').hide();
            $('#myform16').hide();
            $('#myform6c').show(); 
        }
        else
        {
         $('#myform6c').hide(); 
        }         
    });  
});
     $(document).ready(function() {  
    $("#mylink7").click(function() { 
         if($('#myform7').is(":not(:visible)") )
        {
            $('#cat').hide();
            $('#myform1').hide();
            $('#myform1a').hide();
            $('#myform1b').hide();
            $('#myform1c').hide();
            $('#myform1d').hide();
            $('#myform2').hide();
            $('#myform3').hide();
            $('#myform4').hide();
            $('#myform5').hide();
            $('#myform5a').hide();
            $('#myform6').hide();
            $('#myform6a').hide();
            $('#myform6b').hide();
            $('#myform6c').hide();
            $('#myform8').hide();
            $('#myform8a').hide();
            $('#myform8b').hide();
            $('#myform8c').hide();
            $('#myform9').hide();
            $('#myform10').hide();
            $('#myform11').hide();
            $('#myform12').hide();
            $('#myform13').hide();
            $('#myform14').hide();
            $('#myform15').hide();
            $('#myform16').hide();
            $('#myform7').show();
        }
        else
        {
         $('#myform7').hide(); 
        }           
    });  
});
     $(document).ready(function() {  
    $("#mylink8").click(function() { 
         if($('#myform8').is(":not(:visible)") )
        {
            $('#cat').hide();
            $('#myform1').hide();
            $('#myform1a').hide();
            $('#myform1b').hide();
            $('#myform1c').hide();
            $('#myform1d').hide();
            $('#myform2').hide();
            $('#myform3').hide();
            $('#myform4').hide();
            $('#myform5').hide();
            $('#myform5a').hide();
            $('#myform6').hide();
            $('#myform6a').hide();
            $('#myform6b').hide();
            $('#myform6c').hide();
            $('#myform7').hide();
            $('#myform8a').hide();
            $('#myform8b').hide();
            $('#myform8c').hide();
            $('#myform9').hide();
            $('#myform10').hide();
            $('#myform11').hide();
            $('#myform12').hide();
            $('#myform13').hide();
            $('#myform14').hide();
            $('#myform15').hide();
            $('#myform16').hide();
            $('#myform8').show();
        }
        else
        {
         $('#myform8').hide(); 
        }             
    });  
});
     $(document).ready(function() {  
    $("#mylink8a").click(function() { 
         if($('#myform8a').is(":not(:visible)") )
        {
            $('#cat').hide();
            $('#myform1').hide();
            $('#myform1a').hide();
            $('#myform1b').hide();
            $('#myform1c').hide();
            $('#myform1d').hide();
            $('#myform2').hide();
            $('#myform3').hide();
            $('#myform4').hide();
            $('#myform5').hide();
            $('#myform5a').hide();
            $('#myform6').hide();
            $('#myform6a').hide();
            $('#myform6b').hide();
            $('#myform6c').hide();
            $('#myform7').hide();
            $('#myform8').hide();
            $('#myform8b').hide();
            $('#myform8c').hide();
            $('#myform9').hide();
            $('#myform10').hide();
            $('#myform11').hide();
            $('#myform12').hide();
            $('#myform13').hide();
            $('#myform14').hide();
            $('#myform15').hide();
            $('#myform16').hide();
            $('#myform8a').show();
        }
        else
        {
         $('#myform8a').hide(); 
        }             
    });  
});
     $(document).ready(function() {  
    $("#mylink8b").click(function() { 
         if($('#myform8b').is(":not(:visible)") )
        {
            $('#cat').hide();
            $('#myform1').hide();
            $('#myform1a').hide();
            $('#myform1b').hide();
            $('#myform1c').hide();
            $('#myform1d').hide();
            $('#myform2').hide();
            $('#myform3').hide();
            $('#myform4').hide();
            $('#myform5').hide();
            $('#myform5a').hide();
            $('#myform6').hide();
            $('#myform6a').hide();
            $('#myform6b').hide();
            $('#myform6c').hide();
            $('#myform7').hide();
            $('#myform8').hide();
            $('#myform8a').hide();
            $('#myform8c').hide();
            $('#myform9').hide();
            $('#myform10').hide();
            $('#myform11').hide();
            $('#myform12').hide();
            $('#myform13').hide();
            $('#myform14').hide();
            $('#myform15').hide();
            $('#myform16').hide();
            $('#myform8b').show();
        }
        else
        {
         $('#myform8b').hide(); 
        }             
    });  
});
     $(document).ready(function() {  
    $("#mylink8c").click(function() { 
         if($('#myform8c').is(":not(:visible)") )
        {
            $('#cat').hide();
            $('#myform1').hide();
            $('#myform1a').hide();
            $('#myform1b').hide();
            $('#myform1c').hide();
            $('#myform1d').hide();
            $('#myform2').hide();
            $('#myform3').hide();
            $('#myform4').hide();
            $('#myform5').hide();
            $('#myform5a').hide();
            $('#myform6').hide();
            $('#myform6a').hide();
            $('#myform6b').hide();
            $('#myform6c').hide();
            $('#myform7').hide();
            $('#myform8').hide();
            $('#myform8a').hide();
            $('#myform8b').hide();
            $('#myform9').hide();
            $('#myform10').hide();
            $('#myform11').hide();
            $('#myform12').hide();
            $('#myform13').hide();
            $('#myform14').hide();
            $('#myform15').hide();
            $('#myform16').hide();
            $('#myform8c').show();
        }
        else
        {
         $('#myform8c').hide(); 
        }             
    });  
});
     $(document).ready(function() {  
    $("#mylink9").click(function() { 
         if($('#myform9').is(":not(:visible)") )
        {
            $('#cat').hide();
            $('#myform1').hide();
            $('#myform1a').hide();
            $('#myform1b').hide();
            $('#myform1c').hide();
            $('#myform1d').hide();
            $('#myform2').hide();
            $('#myform3').hide();
            $('#myform4').hide();
            $('#myform5').hide();
            $('#myform5a').hide();
            $('#myform6').hide();
            $('#myform6a').hide();
            $('#myform6b').hide();
            $('#myform6c').hide();
            $('#myform7').hide();
            $('#myform8').hide();
            $('#myform8a').hide();
            $('#myform8b').hide();
            $('#myform8c').hide();
            $('#myform10').hide();
            $('#myform11').hide();
            $('#myform12').hide();
            $('#myform13').hide();
            $('#myform14').hide();
            $('#myform15').hide();
            $('#myform16').hide();
            $('#myform9').show(); 
        }
        else
        {
         $('#myform9').hide(); 
        }             
    });  
});
     $(document).ready(function() {  
    $("#mylink10").click(function() { 
         if($('#myform10').is(":not(:visible)") )
        {
            $('#cat').hide();
            $('#myform1').hide();
            $('#myform1a').hide();
            $('#myform1b').hide();
            $('#myform1c').hide();
            $('#myform1d').hide();
            $('#myform2').hide();
            $('#myform3').hide();
            $('#myform4').hide();
            $('#myform5').hide();
            $('#myform5a').hide();
            $('#myform6').hide();
            $('#myform6a').hide();
            $('#myform6b').hide();
            $('#myform6c').hide();
            $('#myform7').hide();
            $('#myform8').hide();
            $('#myform8a').hide();
            $('#myform8b').hide();
            $('#myform8c').hide();
            $('#myform9').hide();
            $('#myform11').hide();
            $('#myform12').hide();
            $('#myform13').hide();
            $('#myform14').hide();
            $('#myform15').hide();
            $('#myform16').hide();
            $('#myform10').show();
        }
        else
        {
         $('#myform10').hide(); 
        }             
    });  
});
     $(document).ready(function() {  
    $("#mylink11").click(function() { 
          if($('#myform11').is(":not(:visible)") )
        {
            $('#cat').hide();
            $('#myform1').hide();
            $('#myform1a').hide();
            $('#myform1b').hide();
            $('#myform1c').hide();
            $('#myform1d').hide();
            $('#myform2').hide();
            $('#myform3').hide();
            $('#myform4').hide();
            $('#myform5').hide();
            $('#myform5a').hide();
            $('#myform6').hide();
            $('#myform6a').hide();
            $('#myform6b').hide();
            $('#myform6c').hide();
            $('#myform7').hide();
            $('#myform8').hide();
            $('#myform8a').hide();
            $('#myform8b').hide();
            $('#myform8c').hide();
            $('#myform9').hide();
            $('#myform10').hide();
            $('#myform12').hide();
            $('#myform13').hide();
            $('#myform14').hide();
            $('#myform15').hide();
            $('#myform16').hide();
            $('#myform11').show(); 
        }
        else
        {
         $('#myform11').hide(); 
        }            
    });  
});
     $(document).ready(function() {  
    $("#mylink12").click(function() { 
          if($('#myform12').is(":not(:visible)") )
        {
            $('#cat').hide();
            $('#myform1').hide();
            $('#myform1a').hide();
            $('#myform1b').hide();
            $('#myform1c').hide();
            $('#myform1d').hide();
            $('#myform2').hide();
            $('#myform3').hide();
            $('#myform4').hide();
            $('#myform5').hide();
            $('#myform5a').hide();
            $('#myform6').hide();
            $('#myform6a').hide();
            $('#myform6b').hide();
            $('#myform6c').hide();
            $('#myform7').hide();
            $('#myform8').hide();
            $('#myform8a').hide();
            $('#myform8b').hide();
            $('#myform8c').hide();
            $('#myform9').hide();
            $('#myform10').hide();
            $('#myform11').hide();
            $('#myform13').hide();
            $('#myform14').hide();
            $('#myform15').hide();
            $('#myform16').hide();
            $('#myform12').show();
        }
        else
        {
         $('#myform12').hide(); 
        }           
    });  
});
     $(document).ready(function() {  
    $("#mylink13").click(function() { 
         if($('#myform13').is(":not(:visible)") )
        {
            $('#cat').hide();
            $('#myform1').hide();
            $('#myform1a').hide();
            $('#myform1b').hide();
            $('#myform1c').hide();
            $('#myform1d').hide();
            $('#myform2').hide();
            $('#myform3').hide();
            $('#myform4').hide();
            $('#myform5').hide();
            $('#myform5a').hide();
            $('#myform6').hide();
            $('#myform6a').hide();
            $('#myform6b').hide();
            $('#myform6c').hide();
            $('#myform7').hide();
            $('#myform8').hide();
            $('#myform8a').hide();
            $('#myform8b').hide();
            $('#myform8c').hide();
            $('#myform9').hide();
            $('#myform10').hide();
            $('#myform11').hide();
            $('#myform12').hide();
            $('#myform14').hide();
            $('#myform15').hide();
            $('#myform16').hide();
            $('#myform13').show();
        }
        else
        {
         $('#myform13').hide(); 
        }        
    });  
});
     $(document).ready(function() {  
    $("#mylink14").click(function() { 
          if($('#myform14').is(":not(:visible)") )
        {
            $('#cat').hide();
            $('#myform1').hide();
            $('#myform1a').hide();
            $('#myform1b').hide();
            $('#myform1c').hide();
            $('#myform1d').hide();
            $('#myform2').hide();
            $('#myform3').hide();
            $('#myform4').hide();
            $('#myform5').hide();
            $('#myform5a').hide();
            $('#myform6').hide();
            $('#myform6a').hide();
            $('#myform6b').hide();
            $('#myform6c').hide();
            $('#myform7').hide();
            $('#myform8').hide();
            $('#myform8a').hide();
            $('#myform8b').hide();
            $('#myform8c').hide();
            $('#myform9').hide();
            $('#myform10').hide();
            $('#myform11').hide();
            $('#myform12').hide();
            $('#myform13').hide();
            $('#myform15').hide();
            $('#myform16').hide();
            $('#myform14').show(); 
        }
        else
        {
         $('#myform14').hide(); 
        }            
    });  
});
     $(document).ready(function() {  
    $("#mylink15").click(function() { 
         if($('#myform15').is(":not(:visible)") )
        {
            $('#cat').hide();
            $('#myform1').hide();
            $('#myform1a').hide();
            $('#myform1b').hide();
            $('#myform1c').hide();
            $('#myform1d').hide();
            $('#myform2').hide();
            $('#myform3').hide();
            $('#myform4').hide();
            $('#myform5').hide();
            $('#myform5a').hide();
            $('#myform6').hide();
            $('#myform6a').hide();
            $('#myform6b').hide();
            $('#myform6c').hide();
            $('#myform7').hide();
            $('#myform8').hide();
            $('#myform8a').hide();
            $('#myform8b').hide();
            $('#myform8c').hide();
            $('#myform9').hide();
            $('#myform10').hide();
            $('#myform11').hide();
            $('#myform12').hide();
            $('#myform13').hide();
            $('#myform14').hide();
            $('#myform16').hide();
            $('#myform15').show(); 
        }
        else
        {
         $('#myform15').hide(); 
        }            
    });  
});
     $(document).ready(function() {  
    $("#mylink16").click(function() { 
         if($('#myform16').is(":not(:visible)") )
        {
            $('#cat').hide();
            $('#myform1').hide();
            $('#myform1a').hide();
            $('#myform1b').hide();
            $('#myform1c').hide();
            $('#myform1d').hide();
            $('#myform2').hide();
            $('#myform3').hide();
            $('#myform4').hide();
            $('#myform5').hide();
            $('#myform5a').hide();
            $('#myform6').hide();
            $('#myform6a').hide();
            $('#myform6b').hide();
            $('#myform6c').hide();
            $('#myform7').hide();
            $('#myform8').hide();
            $('#myform8a').hide();
            $('#myform8b').hide();
            $('#myform8c').hide();
            $('#myform9').hide();
            $('#myform10').hide();
            $('#myform11').hide();
            $('#myform12').hide();
            $('#myform13').hide();
            $('#myform14').hide();
            $('#myform15').hide();
            $('#myform16').show(); 
        }
        else
        {
         $('#myform16').hide(); 
        }           
    });  
});



function myFunction() {
    document.getElementById("myDropdown").classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {

    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}

</script>
<script>
           $(document).ready(function(){
               var div = "<?php echo $div; ?>";
               var expir = "<?php echo $results->expiry; ?>";
            var batter = "<?php echo $results->battery; ?>";
var er = "<?php echo $a1; ?>"
               if(div=='myform1'){
                //alert('this is in 1st if');
                   $("#myform1").show();
                   if(er == "a1")
                   {
                   $("#label1").show();
               }
                   if(expir =="yes")
                   {
                    $("#myradio1").prop('checked', true);
                   }
                   if(expir =="no")
                   {
                    $("#myradio2").prop('checked', true);
                   }
                    if(batter =="yes")
                   {
                    $("#myradio3").prop('checked', true);
                   }
                   if(batter =="no")
                   {
                    $("#myradio4").prop('checked', true);
                   }

               }
               
           })
           </script>
