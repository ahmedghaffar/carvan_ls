<div class="main">
    <div class="main-inner">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-2">
                    <div class="widget">
                        <div class="widget-header"> 
                            <h3>All Categories</h3>
                        </div>
                        <script type="text/javascript">$("#mybutton").click(function(){$("#myiframe").attr("src", "http://www.yahoo.com/")});</script>
                        <!-- /widget-header -->
                        <div class="widget-content">
                            <ul style="list-style-type: none; ">
                                <li><button data-target="#myform">Art Craft and Collectables</button></li>
                                <li><a href="#">Baby Items</li>
                                <li><a href="#">Beauty</li>
                                <li><a href="#">Bed and Bath</a></li>
                                <li><a href="#">Books</a></li>
                                <li><a href="#">Cameras</a></li>
                                <li><a href="#">Eyewear and Optics</a></li>
                                <li><a href="#">Computer IT and Networking</a></li>
                                <li><a href="#">Electronics</a></li>
                                <li><a href="#">Furniture</a></li>
                                <li><a href="#">Gaming</a></li>
                                <li><a href="#">Garden and Outdoors</a></li>
                                <li><a href="#">Grocery,Food and Beverages</a></li>
                                <li><a href="#">Health and Personal Care</a></li>
                                <li><a href="#">Home Appliances</a></li>
                                <li><a href="#">Home Decor and Furniture</a></li>
                                <li><a href="#">Jewellery and Accessories</a></li>
                                <li><a href="#">Kitchen Appliances</a></li>
                                <li><a href="#">Kitchen and Home Supplies</a></li>
                                <li><a href="#">Mobile Phone Tablet and Accessories</a></li>
                                <li><a href="#">Music and Movies</a></li>
                                <li><a href="#">Office Product and Supplies</a></li>
                                <li><a href="#">Perfume and Fragnances</a></li>
                                <li><a href="#">Pet Food and Supplies</a></li>
                                <li><a href="#">Sports and Fitness</a></li>
                                <li><a href="#">Tools and Home Improvements</a></li>
                                <li><a href="#">Toys</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-8">
                    <iframe src="sample" id="myform"></iframe>
                </div>
            </div>
        </div>
    </div>
</div>