<div class="main fs3">
  	<div class="main-inner">
    	<div class="container-fluid">
                <h1 class="hs1">Confirm Dispatch</h1>
      		<div class="row">
        		<div class="col-md-12 col-sm-12 col-xs-12">
          				<div class="widget widget-nopad">
          					<div class="widget-header">
              					<h3 class="hs2">Order ID: <a href="#">205-23432-324234</a></h3>
            				</div>
           					<div class="widget-content"><br>
                      <div class="widget-header">
                        <h3 class="hs2">Package 1 - <span style="color: red">UNSHIPPED ITEMS</span></h3>
                      </div>
                      <div class="row" style="border-bottom: 1px solid #D5D5D5">
                      <div class="col-md-4 col-sm-4 col-xs-12" style="text-align: center;">
                        <div class="fs2">Product Details</div>
                      </div>
                      <div class="col-md-3 col-sm-3 col-xs-12" style="text-align: center;">
                        <div class="fs2">Delivery Address</div>
                      </div>
                      <div class="col-md-2 col-sm-3 col-xs-12" style="text-align: center; border-left: 1px solid #D5D5D5; border-right: 1px solid #D5D5D5;">
                        <div class="fs2">Items to Ship</div>
                      </div>
                      <div class="col-md-3 col-sm-3 col-xs-12" style="text-align: center;">
                        <div class="fs2">Items in Package</div>
                      </div>
                      </div>

                      <div class="row">
                      <div class="col-md-4 col-sm-4 col-xs-12" style="line-height: 15px; padding: 5px">
                        <div class="fs2"><a href="#">H-Cube Furniture Thick Padded Divan Bed Base Headboard...</a></div>
                            <div><b>Quantity:</b> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span>1</span></div>
                            <div><b>SKU:</b>  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span class="fs3">H857J880</span></div>
                            <div><b>ASIN:</b>  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span>878B7878</span></div>
                            <div><b>Listing ID:</b>  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span>2347238746</span></div>
                            <div><b>Order item ID:</b>  &nbsp; <span>345934298</span></div>
                            <div><b>Condition:</b>  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span>New</span></div>
                        </div>
                      <div class="col-md-3 col-sm-3 col-xs-12" style="line-height: 15px; padding: 5px;">
                        <div>Michael Maggerty</div>
                        <div>2/1 9</div>
                        <div>Langrig Road</div>
                        <div>G21 4YW</div>
                        <div>United Kingdom</div><br><br>
                      </div>
                      <div class="col-md-2 col-sm-2 col-xs-12" style="text-align: center; border-right: 1px solid #D5D5D5; border-left: 1px solid #D5D5D5;">
                        <div  style="margin-top: 0.6em">1</div><br><br><br><br>
                      </div>
                      <div class="col-md-3 col-sm-3 col-xs-12" style="text-align: center; padding: 5px">
                        <div><select style="width: 50px">
                          <option>1</option>
                          <option>2</option>
                          <option>3</option>
                          <option>4</option>
                          <option>5</option>
                          <option>6</option>
                        </select></div>
                      </div>
                      </div>  

                      <div class="row" style="border: 1px solid #D5D5D5;">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                          <div class="fs2"> Shipping Details</div>
                        </div>
                      </div>
                        <div class="row" style="border-bottom: 1px solid #D5D5D5;">
                          <div class="col-md-6 col-sm-6 col-xs-6" style="border-right: 1px solid #D5D5D5">
                            <div  style="float: right; margin-right: 5px"><b>Dispatch Date</b></div><br><br><br>
                            <div  style="float: right; margin-right: 5px"><b>Delivery Methods</b></div><br><br><br>
                          </div>
                          <div class="col-md-6 col-sm-6 col-xs-6" style="margin: 0px">
                            <div  style="margin-left: 5px">
                            <div><input type="date" name="date"></div>
                            <label>Carrier:</label><select>
                              <option>Yodel</option>
                              <option>Yodel</option>
                              <option>Yodel</option>
                              <option>Yodel</option>
                            </select>
                            <label>Delivery Service:</label><input type="text" name="dlvry">
                          </div>
                          </div>
                        </div>

                        <div class="row">
                          <div class="col-md-6 col-sm-6 col-xs-6" style="border-right: 1px solid #D5D5D5">
                            <div  style="float: right; margin-right: 5px"><b>Tracking ID</b></div><br>  <br>                          
                          </div>
                          <div class="col-md-6 col-sm-6 col-xs-6" style="margin: 0px">
                            <div style="margin: 5px"><input type="text" name="track"></div>
                          </div>
                        </div>                   

                    </div>
                  </div>
            </div>
          </div><br>
          <div class="row" style="text-align: center;">
            <div class="col-md-12 col-sm-12 col-xs-12">
            <div><a href="#" class="btn btn-primary">Confirm Dispatch</a></div>
            </div>
          </div><br>

          <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="widget">
                <div class="widget-header">
                  <div class="fs2" style="margin-left: 5px">Your Notes</div>
                </div>
                <div class="widget-content" style="text-align: center;">
                  <div class="fs2">Seller memo:<textarea rows="3" style="width: 40%"></textarea></div>
                  <div class="fs1">The information you enter here is for your use only and will not be displayed to the buyer</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>