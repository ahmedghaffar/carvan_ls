<div class="main fs3">
  	<div class="main-inner">
    	<div class="container-fluid">
      		<div class="row">
        		<div class="col-md-12 col-sm-12 col-xs-12">
          			<h1 class="hs2" style="font-weight: 400 !important">Transfer of <span class="hs1">$1,526.56 </span>scheduled to initiate on <span class="hs1">12 Oct 2018*</span></h1>
                <div class="fs3"> Transfer can take 3-5 working days  Transfer can take 3-5 working days  Transfer can take 3-5 working days  Transfer can take 3-5 working days</div>
          			<div style="float: right;"><a href="#" class="btn btn-primary">Request transfer now</a></div>
           		</div>
          	</div><br>

            <div class="row">
              <div class="col-md-3 col-sm-3 col-xs-3">
                <div>Your statement for:</div><br><br>
                <div>How did this satetement begin:</div><br><br>
                <div>What events occured during the statement period</div><br><br><br><br><br><br><br><br><br><br><br>
                <div>What is the result?</div><br><br>
                <div>When will you be paid?</div>
              </div>

              <div class="col-md-9 col-sm-9 col-xs-9">
                <div>
                  <select class="drop">
                    <option>Sep 28, 2018 11:18 BST - Sep 30, 2018 15:38 BST (Open)</option>
                    <option>Sep 28, 2018 11:18 BST - Sep 30, 2018 15:38 BST (Open)</option>
                    <option>Sep 28, 2018 11:18 BST - Sep 30, 2018 15:38 BST (Open)</option>
                    <option>Sep 28, 2018 11:18 BST - Sep 30, 2018 15:38 BST (Open)</option>
                    <option>Sep 28, 2018 11:18 BST - Sep 30, 2018 15:38 BST (Open)</option>
                    <option>Sep 28, 2018 11:18 BST - Sep 30, 2018 15:38 BST (Open)</option>
                  </select>
                </div>
                <div><a href="#"><u>Previous</u></a></div>
                <div class="row">
                <div class="col-md-4 col-sm-4 col-xs-4">
                  <div class="fs2"> Beginning balance</div>
                </div>
                <div class="col-md-8 col-sm-8 col-xs-8">
                  <div class="fs3">Previous statement available balance <span style="float: right;">$2,987.31</span></div>
                  <div class="spna1" style="float: right; border-top: 1px solid gray">
                  <div>Subtotal &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; $2,987.31</div>
                  </div>
                </div>
                </div>
                <hr>

                <div class="row">
                <div class="col-md-4 col-sm-4 col-xs-4">
                  <div class="fs2"> Orders</div>
                </div>
                <div class="col-md-8 col-sm-8 col-xs-8">
                  <div class="fs3">Product Charges <span style="float: right;">$451.48</span></div>
                  <div class="fs3">Promo rebates <span style="float: right;">$0.00</span></div>
                  <div class="fs3">Amazon fees <span style="float: right;">$44.40</span></div>
                  <div class="fs3">Other (Shipping & gift wrap cahrges) <span style="float: right;">$49.34</span></div>
                  <div class="spna1" style="float: right; border-top: 1px solid gray">
                  <div>Subtotal &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; $251.55</div>
                  </div>
                </div>
                </div><br>

                <div class="row">
                <div class="col-md-4 col-sm-4 col-xs-4">
                  <div class="fs2"> Refunds</div>
                </div>
                <div class="col-md-8 col-sm-8 col-xs-8">
                  <div class="fs3">Product Charges <span style="float: right;">$451.48</span></div>
                  <div class="fs3">Amazon fees <span style="float: right;">$44.40</span></div>
                  <div class="fs3">Others <span style="float: right;">$49.34</span></div>
                  <div class="spna1" style="float: right; border-top: 1px solid gray">
                  <div>Subtotal &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; $251.55</div>
                  </div>
                </div>
                </div>

                <hr>

                <div class="row">
                <div class="col-md-4 col-sm-4 col-xs-4">
                  <div class="fs2"> Closing Balance</div>
                </div>
                <div class="col-md-8 col-sm-8 col-xs-8">
                  <div class="fs3">Total Balance <span style="float: right;">$451.48</span></div>
                  <div class="fs3">Unavailable balance <a href="#">What's this?</a> <span style="float: right;"><a href="#">View Reason</a> -$44.40</span></div>
                </div>
                </div>

                <hr>

                <div class="row">
                <div class="col-md-10 col-sm-10 col-xs-10">
                  <div class="fs2"> Transfer amount scheduled to initiate on 12 Oct 2018*</div>
                  <div class="fs3">
                    <div>It doesn't matter if you are shifting to a new house or redecorating the existing one, you can buy one of these headboards and rest assured that you made the right choice. Whether it is your room or the kids room, the available colors enable you to decorate it in multiple ways. The team at H-Cube strongly believes that these products will love up to your expectation. </div>
                  </div>
                </div>
                <div class="col-md-2 col-sm-2 col-xs-2">
                  <div style="float: right;">$34.54</div>
                  
                </div>

                </div>
                

                <div style="float: right;"><a href="#" class="btn btn-primary" >Request transfer now</a></div><br><br>
                
                <div style="float: right;"><a href="#"><i class="fa fa-print"></i> Print this page</a></div>
                <div style="float: right; margin-right: 10px"><a href="#">View transaction for this period</a></div>

              </div>
            </div>

        </div>
    </div>
</div>
