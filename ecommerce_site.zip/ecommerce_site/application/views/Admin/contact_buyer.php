
<div class="main fs3">
  	<div class="main-inner">
    	<div class="container-fluid">
      		<div class="row">
        		<div class="col-md-12 col-sm-12 col-xs-12">
          			<div class="hs1">Contact Customer > Anne Hutchison</div>
          				<div class="widget">
          					<div class="widget-header">
              					<h3 class="hs2"> Your email to Anne Hutchison</h3>
            				</div>
           					<div class="widget-content">
           						<div class="col-md-6 col-sm-6 col-xs-6" style="border-right: 1px solid gray">
           							<div class="fs3">To : <span class="fs2"> Anne Hutchison (example@gmail.com)</span></div>
           							<div class="fs3">From : <span class="fs2"> H-Cube  (example@gmail.com)</span></div>
           							<div class="fs3">Subject : <span class="fs2">
           							<select class=" drop">
           								<option>---Select a subject---</option>
           								<option>Subject1</option>
           								<option>Subject2</option>
           								<option>Subject3</option>
           							</select> </span></div>
           						</div>
           						<div class="col-md-6 col-sm-6 col-xs-6">
           							<div class="fs3" style="margin-left: 10px">Order ID : <span class="fs2"><a href="#"> <u>026-9079452-8611520</u> </a></span></div>
           							<ul>
           								<li class="fs3">
           									1 of H-Cube Furniture Alton Tri-Panel Padded Divan Bed Base Headboard Turin Fabric With Struts & Fixings (Black 5FT King Size 36) [Kitchen & Home] 
           								</li>
           							</ul>
           						</div>
           					</div>
           					<div class="widget-content">
           						<div class="fs3">Type your message in the box below. We will forward it to the buyer. Please do not include email addresses. HTML or links (URL) in your message. if you need to refer to an item on the Carrovan web site, include the product name and/or the ASIN/ISBN.</div>
           						<form>
           							<textarea rows="5" style="width: 100%"></textarea>
           							<input type="file" name="file" class="btn btn-primary" value="Add Attachement">
           						
           						<div class="ps3">Carrovan uses filtering technology to protect buyer and seller and to identify
           							<div style="float: right;"><a href="#" class="btn btn-primary">Cancel</a>
           							<a href="#" class="btn btn-primary">Send e-mail</a></div>
           						</div>
           					</div>
            			</div>
          			</div>
          		</div>
         	</div>
        </div>
    </div>
</div>
