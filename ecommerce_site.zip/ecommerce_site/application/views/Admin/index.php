
<div class="main fs3">
  	<div class="main-inner">
    	<div class="container-fluid">
      		<div class="row">
        		<div class="span3 col-md-3  col-sm-3 col-xs-12">
          			<div class="widget widget-nopad">
            			<div class="widget-header">
              				<h3 class="hs2"> Your Orders</h3>
            			</div>
            			<!-- /widget-header -->
            			<div class="widget-content">
              				<div class="widget big-stats-container">
                				<div class="widget-content">
                  					<ul class="aside1">
                  						<li> Pending</li><hr>
                  						<li> Unshipped</li><hr>
                  						<li> Return / Request</li><hr>
                  					</ul>
                  					<ul class="aside2">
                  						<li>Last Day</li>
                  						<li>Last Week</li>
                  						<li>Last Month</li><hr>
                  						<li style="font-size: 14px; text-align: center">View Orders</li>
                  					</ul>
                				</div>
                				<!-- /widget-content --> 
                        </div>
            			</div>
          	  	</div>
                <div class="widget widget-nopad" style="margin-top: 20px"> 
                  <div class="widget-header">
                      <h3 class="hs2"> Seller Performance</h3>
                  </div>
                  <!-- /widget-header -->
                  <div class="widget-content">
                      <div class="widget big-stats-container">
                        <div class="widget-content">
                            <ul class="aside1">
                              <li> Feedback</li><hr>
                              <li> Cancelled Orders</li><hr>
                              <li> Late Shipment</li><hr>
                              <li> Claims</li><hr>
                              <li> Returns</li><hr>
                            </ul>
                        </div>
                        <!-- /widget-content --> 
                        </div>
                  </div>
                </div>
          	  </div>
        			<div class="span7 col-md-6 col-sm-6 col-xs-12">
          				<div class="widget widget-nopad">
            				<div class="widget-header">
              					<h3 class="hs2"> Recent News</h3>
            				</div>
            				<!-- /widget-header -->
            				<div class="widget-content">
              					<ul class="news-items">
                					<li>
                  	                  	<div class="news-item-date"> 
                  	                  		<span class="news-item-day">29</span> <span class="news-item-month">Aug	</span> 
                  	                  	</div>
                  						<div class="news-item-detail"> 
                  							<a href="http://www.egrappler.com/thursday-roundup-40/" class="news-item-title fs2" target="_blank">Thursday Roundup # 40</a>
                    						<p class="news-item-preview fs3"> This is our web design and development news series where we share our favorite design/development related articles, resources, tutorials and awesome freebies. </p>
                  						</div>
                					</li>
                					<li>
                  						<div class="news-item-date"> 		
                  							<span class="news-item-day">15</span> 
                  							<span class="news-item-month">Jun</span> 
                  						</div>
                  						<div class="news-item-detail"> 
                  							<a href="http://www.egrappler.com/retina-ready-responsive-app-landing-page-website-template-app-landing/" class="news-item-title fs2" target="_blank">Retina Ready Responsive App Landing Page Website Template – App Landing</a>
                    						<p class="news-item-preview fs3"> App Landing is a retina ready responsive app landing page website template perfect for software and application developers and small business owners looking to promote their iPhone, iPad, Android Apps and software products.</p>
                  						</div>
                					</li>
                				<li>
                  					<div class="news-item-date"> 
                  						<span class="news-item-day">29</span> 
                  						<span class="news-item-month">Oct</span> 
                  					</div>
                  					<div class="news-item-detail"> 
                  						<a href="http://www.egrappler.com/open-source-jquery-php-ajax-contact-form-templates-with-captcha-formify/" class="news-item-title fs2" target="_blank">Open Source jQuery PHP Ajax Contact Form Templates With Captcha: Formify</a>
                    					<p class="news-item-preview fs3"> Formify is a contribution to lessen the pain of creating contact forms. The collection contains six different forms that are commonly used. These open source contact forms can be customized as well to suit the need for your website/application.</p>
                  					</div>
                				</li>
              				</ul>
            			</div>
            			<!-- /widget-content --> 
          			</div>
          			<!-- /widget -->
        		</div>
        		<!-- /span6 -->
        		<div class="span3 col-md-3 col-sm-3 col-xs-12">
          			<div class="widget widget-nopad">
            			<div class="widget-header"> 
                  	<h3 class="hs2"> Payments Summary</h3>
            			</div>
            			<!-- /widget-header -->
            			<div class="widget-content">
              				<div class="widget big-stats-container">
                				<div class="widget-content">
                  					<ul class="rside">
                  						<li> Balance <span style="margin-left: 50%;">$12,00</span></li><hr>
                  						<li> Last Payment <span style="margin-left: 38%;">$3,00</span></li>
                  					</ul>
                  				</div>
                				<!-- /widget-content --> 
                            </div>
            			</div>
          			</div>
          			<div class="widget widget-nopad" style="margin-top: 20px;">
            			<div class="widget-header">
              				<h3 class="hs2"> Business Summary</h3>
            			</div>
            			<!-- /widget-header -->
            			<div class="widget-content">
              				<div class="widget big-stats-container">
                				<div class="widget-content" style="margin-top: 20px; margin-bottom: 20px;">
                  					<div id="big_stats" class="cf">
                    					<div class="stat"> <span class="fs2">Today</span> </div>
                    					<!-- .stat --> 
                    					<div class="stat"> <span class="fs2">Sales Amount</span> </div>
                    					<!-- .stat -->
                                        <div class="stat"> <span class="fs2">Units</span> </div>
                    					<!-- .stat -->
                  					</div>
                  					<div id="big_stats" class="cf ">
                    					<div class="stat"> <span>7 days</span> </div>
                    					<!-- .stat --> 
                    					<div class="stat"> <span>170</span> </div>
                    					<!-- .stat -->
                                        <div class="stat"> <span>05</span> </div>
                    					<!-- .stat -->
                  					</div>
                  					<div id="big_stats" class="cf">
                    					<div class="stat"> <span>15 days</span> </div>
                    					<!-- .stat --> 
                    					<div class="stat"> <span>240</span> </div>
                    					<!-- .stat -->
                                        <div class="stat"> <span>09</span> </div>
                    					<!-- .stat -->
                  					</div>
                  					<div id="big_stats" class="cf">
                    					<div class="stat"> <span>30 days</span> </div>
                    					<!-- .stat --> 
                    					<div class="stat"> <span>410</span> </div>
                    					<!-- .stat -->
                                        <div class="stat"> <span>18</span> </div>
                    					<!-- .stat -->
                  					</div>
                				</div>
                				<!-- /widget-content --> 
                            </div>
            			</div>
          			</div>
          		</div>
        		 
      		</div>
      		<!-- /row --> 
    	</div>
    	<!-- /container --> 
  	</div>
  	<!-- /main-inner --> 
</div>
<!-- /main -->
<!-- 
<div class="extra">
  <div class="extra-inner">
    <div class="container">
      <div class="row">
                    <div class="span3">
                        <h4>
                            About Free Admin Template</h4>
                        <ul>
                            <li><a href="javascript:;">EGrappler.com</a></li>
                            <li><a href="javascript:;">Web Development Resources</a></li>
                            <li><a href="javascript:;">Responsive HTML5 Portfolio Templates</a></li>
                            <li><a href="javascript:;">Free Resources and Scripts</a></li>
                        </ul>
                    </div>
                    /span3 -->
                    <!--<div class="span3">
                        <h4>
                            Support</h4>
                        <ul>
                            <li><a href="javascript:;">Frequently Asked Questions</a></li>
                            <li><a href="javascript:;">Ask a Question</a></li>
                            <li><a href="javascript:;">Video Tutorial</a></li>
                            <li><a href="javascript:;">Feedback</a></li>
                        </ul>
                    </div>
                     /span3 --><!--
                    <div class="span3">
                        <h4>
                            Something Legal</h4>
                        <ul>
                            <li><a href="javascript:;">Read License</a></li>
                            <li><a href="javascript:;">Terms of Use</a></li>
                            <li><a href="javascript:;">Privacy Policy</a></li>
                        </ul>
                    </div>
                     /span3 --><!--
                    <div class="span3">
                        <h4>
                            Open Source jQuery Plugins</h4>
                        <ul>
                            <li><a href="">Open Source jQuery Plugins</a></li>
                            <li><a href="">HTML5 Responsive Tempaltes</a></li>
                            <li><a href="">Free Contact Form Plugin</a></li>
                            <li><a href="">Flat UI PSD</a></li>
                        </ul>
                    </div>
                     /span3 --><!--
                </div>
      
    </div>
     /container 
  </div>
   /extra-inner  
</div>
 /extra -->

