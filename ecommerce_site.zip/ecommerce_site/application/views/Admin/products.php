<!DOCTYPE html>
<html lang="en">
  
<head>
<meta charset="utf-8">
    <title>Carrovan: Products</title>
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="apple-mobile-web-app-capable" content="yes">    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<!--     <link href="<?= base_url(); ?>assets/css/bootstrap.min.css" rel="stylesheet">
 -->    <link href="<?= base_url(); ?>assets/css/bootstrap-responsive.min.css" rel="stylesheet">
    
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600" rel="stylesheet">
    <link href="<?= base_url(); ?>assets/css/font-awesome.css" rel="stylesheet">
    
    <link href="<?= base_url(); ?>assets/css/style.css" rel="stylesheet">
    
    <link rel="stylesheet" type="text/css" href="<?= base_url(); ?>assets/data/style.css">

    <!-- CORE CSS FRAMEWORK - START -->
<!--         <link href="<?= base_url(); ?>assets/data/bootstrap.min.css" rel="stylesheet" type="text/css"/>
 -->        <link href="<?= base_url(); ?>assets/data/font-awesome.css" rel="stylesheet" type="text/css"/>
        <link href="<?= base_url(); ?>assets/data/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" type="text/css"/>
        <!-- CORE CSS FRAMEWORK - END -->

    <link href="<?= base_url(); ?>assets/js/guidely/guidely.css" rel="stylesheet"> 

    <!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
  </head>

<body>

<div class="navbar">
	<div class="navbar-inner">
		<div class="container">
			
			<a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</a>
			
			<a class="brand" href="index.html">
				CARROVAN				
			</a>		
			
			<div class="nav-collapse">
				<ul class="nav pull-right">
					<li class="dropdown">						
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">
							<i class="icon-cog"></i>
							Account
							<b class="caret"></b>
						</a>
						
						<ul class="dropdown-menu">
							<li><a href="javascript:;">Settings</a></li>
							<li><a href="javascript:;">Help</a></li>
						</ul>						
					</li>
			
					<li class="dropdown">						
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">
							<i class="icon-user"></i> 
							Kamran
							<b class="caret"></b>
						</a>
						
						<ul class="dropdown-menu">
							<li><a href="javascript:;">Profile</a></li>
							<li><a href="javascript:;">Logout</a></li>
						</ul>						
					</li>
				</ul>
			
				<form class="navbar-search pull-right">
					<input type="text" class="search-query" placeholder="Search">
				</form>
				
			</div><!--/.nav-collapse -->	
	
		</div> <!-- /container -->
		
	</div> <!-- /navbar-inner -->
	
</div> <!-- /navbar -->
    



    
<div class="subnavbar">
  <div class="subnavbar-inner">
    <div class="container">
      <ul class="mainnav">
        <li><a href="index"><span>Dashboard</span> </a> </li>
        <li><a href="msg"><span>Messages</span> </a> </li>
        <li><a href="mang_orders"><span>Inventory</span> </a> </li>
        <li><a href="business_report"><span>Reports</span> </a></li>
        <li><a href="seller_performance"><span style="margin-top: 31%">Performance</span> </a> </li>
        <li  class="active"><a href="products"><span>Store</span> </a> </li>
			
			</ul>

		</div> <!-- /container -->
	
	</div> <!-- /subnavbar-inner -->

</div> <!-- /subnavbar -->
    
            <section>
                <section class="wrapper main-wrapper" style=''>

                    <div class='col-lg-12 col-md-12 col-sm-12 col-xs-12'>
                        <div class="page-title">

                            <div class="pull-left">
                                <h1 class="title">Products</h1>                            </div>

                            <div class="pull-right hidden-xs">
                                <ol class="breadcrumb">
                                    <li>
                                        <a href="index.html"><i class="fa fa-home"></i>Home</a>
                                    </li>
                                    <li>
                                        <a href="eco-products.html">Products</a>
                                    </li>
                                    <li class="active">
                                        <strong>All Products</strong>
                                    </li>
                                </ol>
                            </div>

                        </div>
                    </div>
                    <div class="clearfix"></div>

                    <div class="col-lg-12">
                        <section class="box nobox">
                            <div class="content-body">    <div class="row">

                                    <div class="col-md-9 col-sm-12 col-xs-12">

                                        <div class="input-group primary">
                                            <span class="input-group-addon">                
                                                <span class="arrow"></span>
                                                <i class="fa fa-search"></i>
                                            </span>
                                            <input type="text" class="form-control search-page-input" placeholder="Search Products" value="">
                                        </div><br>
                                    </div>
                                    <div class="col-md-3 col-sm-12 col-xs-12">
                                        <nav class='pull-right'>
                                            <!-- 								  <ul class="pager" style="margin:0px;">
                                                                                                                <li><a href="#"><i class='fa fa-arrow-left icon-xs icon-orange icon-secondary'></i></a></li>
                                                                                                                <li><a href="#"><i class='fa fa-arrow-right icon-xs icon-orange icon-secondary'></i></a></li>
                                                                                                              </ul> -->

                                            <ul class="pagination pull-right" style="margin:0px;">
                                                <li><a href="#">«</a></li>
                                                <li class="active"><a href="#">1</a></li>
                                                <li><a href="#">2</a></li>
                                                <li><a href="#">3</a></li>
                                                <li><a href="#">»</a></li>
                                            </ul>

                                        </nav>
                                    </div>

                                    <div class="clearfix"></div><br>

                                    <div class="col-md-12 col-sm-12 col-xs-12 ecommerce_product_search search_data">




                                        <ul class="nav nav-tabs vertical col-md-2 col-lg-2 col-sm-3 col-xs-3 left-aligned">
                                            <li class="active">
                                                <a href="#all-1" data-toggle="tab">
                                                    <i class="fa fa-home"></i> All Products
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#Electronics'" class="">Electronics</a>
                                            </li>
                                            <li>
                                                <a href="#shoes-1">Shoes</a>
                                            </li>
                                            <li>
                                                <a href="#clothes-1">Clothes</a>
                                            </li>
                                            <li>
                                                <a href="#mobile-1">Mobile Phones</a>
                                            </li>
                                            <li>
                                                <a href="#laptops-1">Laptops</a>
                                            </li>
                                            <li>
                                                <a href="#accessories-1">Accessories</a>
                                            </li>
                                            <li>
                                                <a href="#hardware-1">Hardware</a>
                                            </li>
                                            <li>
                                                <a href="#tools-1">Tools</a>
                                            </li>
                                            <li>
                                                <a href="#software-1">Software</a>
                                            </li>         
                                        </ul>					

                                        <div class="tab-content vertical col-md-10 col-lg-10 col-sm-9 col-xs-9 left-aligned">
                                            <div class="tab-pane fade in active" id="web-1">

                                                <div class="row">


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-1.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Nikon D5500 DSL...</a></h4>
                                                                <span>$886.98</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-2.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">HTC One M8 Andr...</a></h4>
                                                                <span>$143.60</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-3.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Portable Sound ...</a></h4>
                                                                <span>$249.29</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-4.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Custom T-Shirt...</a></h4>
                                                                <span>$608.92</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-5.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Leica T Mirrorl...</a></h4>
                                                                <span>$644.79</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-6.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Night Visions...</a></h4>
                                                                <span>$98.87</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-7.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Leica T Mirrorl...</a></h4>
                                                                <span>$887.96</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-8.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Obey Propaganda...</a></h4>
                                                                <span>$787.73</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-9.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Nikon D5500 DSL...</a></h4>
                                                                <span>$274.38</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-10.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Levi's 511 Jean...</a></h4>
                                                                <span>$143.77</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-11.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Nikon D5500 DSL...</a></h4>
                                                                <span>$475.93</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-12.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Nikon D5500 DSL...</a></h4>
                                                                <span>$477.29</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-13.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Portable Sound ...</a></h4>
                                                                <span>$187.31</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-14.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">HP Spectre XT P...</a></h4>
                                                                <span>$249.50</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-15.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">If You Wait...</a></h4>
                                                                <span>$909.39</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-16.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Fahrenheit 451 ...</a></h4>
                                                                <span>$88.10</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-17.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">First Prize Pie...</a></h4>
                                                                <span>$981.50</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-18.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Portable Sound ...</a></h4>
                                                                <span>$751.07</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-19.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Nikon D5500 DSL...</a></h4>
                                                                <span>$59.43</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-20.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Night Visions...</a></h4>
                                                                <span>$93.63</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-21.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Leica T Mirrorl...</a></h4>
                                                                <span>$795.52</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-22.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Portable Sound ...</a></h4>
                                                                <span>$887.41</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-23.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">HP Spectre XT P...</a></h4>
                                                                <span>$498.54</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-24.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Elegant Gemston...</a></h4>
                                                                <span>$511.07</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-25.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Digital Storm P...</a></h4>
                                                                <span>$776.47</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-1.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Nikon D5500 DSL...</a></h4>
                                                                <span>$886.98</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-2.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">HTC One M8 Andr...</a></h4>
                                                                <span>$143.60</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-3.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Portable Sound ...</a></h4>
                                                                <span>$249.29</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-4.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Custom T-Shirt...</a></h4>
                                                                <span>$608.92</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-5.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Leica T Mirrorl...</a></h4>
                                                                <span>$644.79</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-6.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Night Visions...</a></h4>
                                                                <span>$98.87</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-7.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Leica T Mirrorl...</a></h4>
                                                                <span>$887.96</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-8.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Obey Propaganda...</a></h4>
                                                                <span>$787.73</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-9.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Nikon D5500 DSL...</a></h4>
                                                                <span>$274.38</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-10.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Levi's 511 Jean...</a></h4>
                                                                <span>$143.77</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-11.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Nikon D5500 DSL...</a></h4>
                                                                <span>$475.93</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-12.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Nikon D5500 DSL...</a></h4>
                                                                <span>$477.29</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-13.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Portable Sound ...</a></h4>
                                                                <span>$187.31</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-14.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">HP Spectre XT P...</a></h4>
                                                                <span>$249.50</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-15.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">If You Wait...</a></h4>
                                                                <span>$909.39</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-16.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Fahrenheit 451 ...</a></h4>
                                                                <span>$88.10</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-17.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">First Prize Pie...</a></h4>
                                                                <span>$981.50</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-18.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Portable Sound ...</a></h4>
                                                                <span>$751.07</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-19.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Nikon D5500 DSL...</a></h4>
                                                                <span>$59.43</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-20.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Night Visions...</a></h4>
                                                                <span>$93.63</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-21.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Leica T Mirrorl...</a></h4>
                                                                <span>$795.52</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-22.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Portable Sound ...</a></h4>
                                                                <span>$887.41</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-23.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">HP Spectre XT P...</a></h4>
                                                                <span>$498.54</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-24.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Elegant Gemston...</a></h4>
                                                                <span>$511.07</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-25.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Digital Storm P...</a></h4>
                                                                <span>$776.47</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-1.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Nikon D5500 DSL...</a></h4>
                                                                <span>$886.98</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-2.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">HTC One M8 Andr...</a></h4>
                                                                <span>$143.60</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-3.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Portable Sound ...</a></h4>
                                                                <span>$249.29</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-4.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Custom T-Shirt...</a></h4>
                                                                <span>$608.92</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-5.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Leica T Mirrorl...</a></h4>
                                                                <span>$644.79</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-6.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Night Visions...</a></h4>
                                                                <span>$98.87</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-7.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Leica T Mirrorl...</a></h4>
                                                                <span>$887.96</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-8.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Obey Propaganda...</a></h4>
                                                                <span>$787.73</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-9.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Nikon D5500 DSL...</a></h4>
                                                                <span>$274.38</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-10.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Levi's 511 Jean...</a></h4>
                                                                <span>$143.77</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-11.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Nikon D5500 DSL...</a></h4>
                                                                <span>$475.93</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-12.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Nikon D5500 DSL...</a></h4>
                                                                <span>$477.29</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-13.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Portable Sound ...</a></h4>
                                                                <span>$187.31</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-14.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">HP Spectre XT P...</a></h4>
                                                                <span>$249.50</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-15.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">If You Wait...</a></h4>
                                                                <span>$909.39</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-16.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Fahrenheit 451 ...</a></h4>
                                                                <span>$88.10</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-17.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">First Prize Pie...</a></h4>
                                                                <span>$981.50</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-18.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Portable Sound ...</a></h4>
                                                                <span>$751.07</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-19.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Nikon D5500 DSL...</a></h4>
                                                                <span>$59.43</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-20.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Night Visions...</a></h4>
                                                                <span>$93.63</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-21.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Leica T Mirrorl...</a></h4>
                                                                <span>$795.52</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-22.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Portable Sound ...</a></h4>
                                                                <span>$887.41</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-23.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">HP Spectre XT P...</a></h4>
                                                                <span>$498.54</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-24.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Elegant Gemston...</a></h4>
                                                                <span>$511.07</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-25.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Digital Storm P...</a></h4>
                                                                <span>$776.47</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-1.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Nikon D5500 DSL...</a></h4>
                                                                <span>$886.98</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-2.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">HTC One M8 Andr...</a></h4>
                                                                <span>$143.60</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-3.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Portable Sound ...</a></h4>
                                                                <span>$249.29</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-4.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Custom T-Shirt...</a></h4>
                                                                <span>$608.92</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-5.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Leica T Mirrorl...</a></h4>
                                                                <span>$644.79</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-6.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Night Visions...</a></h4>
                                                                <span>$98.87</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-7.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Leica T Mirrorl...</a></h4>
                                                                <span>$887.96</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-8.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Obey Propaganda...</a></h4>
                                                                <span>$787.73</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-9.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Nikon D5500 DSL...</a></h4>
                                                                <span>$274.38</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-10.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Levi's 511 Jean...</a></h4>
                                                                <span>$143.77</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-11.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Nikon D5500 DSL...</a></h4>
                                                                <span>$475.93</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-12.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Nikon D5500 DSL...</a></h4>
                                                                <span>$477.29</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-13.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Portable Sound ...</a></h4>
                                                                <span>$187.31</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-14.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">HP Spectre XT P...</a></h4>
                                                                <span>$249.50</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-15.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">If You Wait...</a></h4>
                                                                <span>$909.39</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-16.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Fahrenheit 451 ...</a></h4>
                                                                <span>$88.10</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-17.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">First Prize Pie...</a></h4>
                                                                <span>$981.50</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-18.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Portable Sound ...</a></h4>
                                                                <span>$751.07</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-19.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Nikon D5500 DSL...</a></h4>
                                                                <span>$59.43</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-20.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Night Visions...</a></h4>
                                                                <span>$93.63</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-21.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Leica T Mirrorl...</a></h4>
                                                                <span>$795.52</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-22.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Portable Sound ...</a></h4>
                                                                <span>$887.41</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-23.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">HP Spectre XT P...</a></h4>
                                                                <span>$498.54</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-24.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Elegant Gemston...</a></h4>
                                                                <span>$511.07</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-25.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Digital Storm P...</a></h4>
                                                                <span>$776.47</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-1.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Nikon D5500 DSL...</a></h4>
                                                                <span>$886.98</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-2.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">HTC One M8 Andr...</a></h4>
                                                                <span>$143.60</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-3.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Portable Sound ...</a></h4>
                                                                <span>$249.29</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-4.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Custom T-Shirt...</a></h4>
                                                                <span>$608.92</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-5.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Leica T Mirrorl...</a></h4>
                                                                <span>$644.79</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-6.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Night Visions...</a></h4>
                                                                <span>$98.87</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-7.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Leica T Mirrorl...</a></h4>
                                                                <span>$887.96</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-8.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Obey Propaganda...</a></h4>
                                                                <span>$787.73</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-9.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Nikon D5500 DSL...</a></h4>
                                                                <span>$274.38</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-10.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Levi's 511 Jean...</a></h4>
                                                                <span>$143.77</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-11.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Nikon D5500 DSL...</a></h4>
                                                                <span>$475.93</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-12.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Nikon D5500 DSL...</a></h4>
                                                                <span>$477.29</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-13.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Portable Sound ...</a></h4>
                                                                <span>$187.31</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-14.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">HP Spectre XT P...</a></h4>
                                                                <span>$249.50</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-15.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">If You Wait...</a></h4>
                                                                <span>$909.39</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-16.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Fahrenheit 451 ...</a></h4>
                                                                <span>$88.10</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-17.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">First Prize Pie...</a></h4>
                                                                <span>$981.50</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-18.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Portable Sound ...</a></h4>
                                                                <span>$751.07</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-19.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Nikon D5500 DSL...</a></h4>
                                                                <span>$59.43</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-20.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Night Visions...</a></h4>
                                                                <span>$93.63</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-21.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Leica T Mirrorl...</a></h4>
                                                                <span>$795.52</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-22.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Portable Sound ...</a></h4>
                                                                <span>$887.41</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-23.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">HP Spectre XT P...</a></h4>
                                                                <span>$498.54</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-24.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Elegant Gemston...</a></h4>
                                                                <span>$511.07</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-3 col-sm-6 col-md-4 ecommerce_product">
                                                        <div class="team-member ">
                                                            <div class="team-img thumb ">
                                                                <img class="img-responsive" src="<?= base_url(); ?>assets/data/eco-products/product-25.jpg" alt="">
                                                                <div class="overlay">
                                                                    <a href="#"><i class="fa fa-shopping-cart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="team-info ">
                                                                <h4><a href="#">Digital Storm P...</a></h4>
                                                                <span>$776.47</span>
                                                            </div>

                                                            <p>
                                                        </div>
                                                    </div>
                                                </div>

                                            </div>
                                            <div class="tab-pane fade" id="images-1">

                                                <p class="col-md-12">Images Search Results</p>

                                            </div>
                                            <div class="tab-pane fade" id="contacts-1">

                                                <p>Contacts Search Results</p>


                                            </div>

                                            <div class="tab-pane fade" id="projects-1">
                                                <p>Projects Search Results</p>

                                            </div>

                                            <div class="tab-pane fade" id="map-1">
                                                <p>Location and Maps Search Results</p>
                                            </div>
                                            <div class="tab-pane fade" id="videos-1">
                                                <p>Videos Search Results</p>
                                            </div>
                                            <div class="tab-pane fade" id="messages-1">
                                                <p>Messages Search Results</p>
                                            </div>
                                            <div class="tab-pane fade" id="profile-1">
                                                <p>Profile Search Results</p>
                                            </div>



                                        </div>








                                    </div>
                                </div>
                            </div>
                        </section></div>


                </section>
            </section>
            <!-- END CONTENT -->


    
    
<div class="footer">
	
	<div class="footer-inner">
		
		<div class="container">
			
			<div class="row">
				
    			<div class="span12">
    				&copy; 2013 <a href="#">Bootstrap Responsive Admin Template</a>.
    			</div> <!-- /span12 -->
    			
    		</div> <!-- /row -->
    		
		</div> <!-- /container -->
		
	</div> <!-- /footer-inner -->
	
</div> <!-- /footer -->
    

<!-- Le javascript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="<?= base_url(); ?>assets/js/jquery-1.7.2.min.js"></script>

<script src="<?= base_url(); ?>assets/js/bootstrap.js"></script>
<script src="<?= base_url(); ?>assets/js/base.js"></script>


  </body>

</html>







<!-- CORE JS FRAMEWORK - START --> 
        <script src="<?= base_url(); ?>assets/data/js/jquery-1.11.2.min.js" type="text/javascript"></script> 
        <script src="<?= base_url(); ?>assets/data/js/jquery.easing.min.js" type="text/javascript"></script> 
        <script src="<?= base_url(); ?>assets/data/perfect-scrollbar/perfect-scrollbar.min.js" type="text/javascript"></script> 
        <script src="<?= base_url(); ?>assets/data/js/viewportchecker.js" type="text/javascript"></script>  
        <!-- CORE JS FRAMEWORK - END --> 


        <!-- OTHER SCRIPTS INCLUDED ON THIS PAGE - START --> 
        <!-- OTHER SCRIPTS INCLUDED ON THIS PAGE - END --> 


        <!-- CORE TEMPLATE JS - START --> 
        <script src="<?= base_url(); ?>assets/data/js/scripts.js" type="text/javascript"></script> 
        <!-- END CORE TEMPLATE JS - END --> 