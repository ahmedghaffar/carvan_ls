
<div class="main">
    <div class="main-inner">
      <div class="container-fluid">
          <div class="row">
              <!--<div class="span4">
                  <div class="widget widget-nopad">
                    <div class="widget-header">
                        <h3> Add Category </h3>
                    </div>
                    <-- /widget-header -->
                  <!--  <div class="widget-content">
                        
                        <form style="padding: 10px">
                          <div class="form-group">
                            <label for="cat">Category:</label>
                            <input type="text" class="form-control" placeholder="Enter category type" id="cat" style="padding: 15px; width: 100%">
                          </div>
                          <div class="form-group">
                            <label for="cat">Description:</label>
                            <textarea class="form-control" id="cat" placeholder="Enter description here" style="padding: 15px; width: 100%" cols="50" rows="5"></textarea>
                          </div>
                          <input type="submit" name="send" class="btn btn-primary" value="Submit">
                        </form>
                  </div>
                  <-- /widget-content --
                </div>
                <-- /widget --
            </div>
            <-- /span6 -->
            <div class="span9">
                <div class="widget widget-nopad">
                  <div class="widget-header"> 
                    <h3> All Categories</h3>
                  </div>
                  <!-- /widget-header -->
                  <div class="widget-content">
                      <div class="widget big-stats-container">
                        <div class="widget-content">
                            <table class="table table-striped">
                            <thead>
                              <tr>
                              <th style="width: 30%">Name</th>
                              <th style="width: 40%">Description</th>
                              <th style="width: 30%">Actions</th>
                              </tr>
                            </thead>
                            <tbody>
                              <tr>
                                <td>Shoes</td>
                                <td>Best shoes</td>
                                <td>
                                  <a href="#" class="btn btn-default">Edit</a>
                                  <a href="#" class="btn btn-default">Remove</a>
                                </td>
                              </tr>
                              <tr>
                                <td>Shoes</td>
                                <td>Best shoes</td>
                                <td>
                                  <a href="#" class="btn btn-default">Edit</a>
                                  <a href="#" class="btn btn-default">Remove</a>
                                </td>
                              </tr>
                              <tr>
                                <td>Shoes</td>
                                <td>Best shoes</td>
                                <td>
                                  <a href="#" class="btn btn-default">Edit</a>
                                  <a href="#" class="btn btn-default">Remove</a>
                                </td>
                              </tr>
                              <tr>
                                <td>Shoes</td>
                                <td>Best shoes</td>
                                <td>
                                  <a href="#" class="btn btn-default">Edit</a>
                                  <a href="#" class="btn btn-default">Remove</a>
                                </td>
                              </tr>
                              </tbody>
                            </table>
                          </div>
                        <!-- /widget-content --> 
                        </div>
                  </div>
                </div>
                    </div>
                  </div>
                </div>
              </div>
             
          </div>
          <!-- /row --> 
      </div>
      <!-- /container --> 
    </div>
    <!-- /main-inner --> 
</div>
<!-- /main -->
<!-- 
<div class="extra">
  <div class="extra-inner">
    <div class="container">
      <div class="row">
                    <div class="span3">
                        <h4>
                            About Free Admin Template</h4>
                        <ul>
                            <li><a href="javascript:;">EGrappler.com</a></li>
                            <li><a href="javascript:;">Web Development Resources</a></li>
                            <li><a href="javascript:;">Responsive HTML5 Portfolio Templates</a></li>
                            <li><a href="javascript:;">Free Resources and Scripts</a></li>
                        </ul>
                    </div>
                    /span3 -->
                    <!--<div class="span3">
                        <h4>
                            Support</h4>
                        <ul>
                            <li><a href="javascript:;">Frequently Asked Questions</a></li>
                            <li><a href="javascript:;">Ask a Question</a></li>
                            <li><a href="javascript:;">Video Tutorial</a></li>
                            <li><a href="javascript:;">Feedback</a></li>
                        </ul>
                    </div>
                     /span3 --><!--
                    <div class="span3">
                        <h4>
                            Something Legal</h4>
                        <ul>
                            <li><a href="javascript:;">Read License</a></li>
                            <li><a href="javascript:;">Terms of Use</a></li>
                            <li><a href="javascript:;">Privacy Policy</a></li>
                        </ul>
                    </div>
                     /span3 --><!--
                    <div class="span3">
                        <h4>
                            Open Source jQuery Plugins</h4>
                        <ul>
                            <li><a href="">Open Source jQuery Plugins</a></li>
                            <li><a href="">HTML5 Responsive Tempaltes</a></li>
                            <li><a href="">Free Contact Form Plugin</a></li>
                            <li><a href="">Flat UI PSD</a></li>
                        </ul>
                    </div>
                     /span3 --><!--
                </div>
      
    </div>
     /container 
  </div>
   /extra-inner  
</div>
 /extra -->
