
<div class="main fs3">
  	<div class="main-inner">
    	<div class="container-fluid">
      		<div class="row">
      			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
      				<p class="hs1">User Permissions</p>
      				<div>Add or edit permissions for hussain(husainhamdani.ynaut@gmail.com) in H-Cube</div>
      			</div>
      		</div>
          <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
              <div class="widget-content" style="padding: 0px">
                <table class="table table-striped" style="padding: 0px !important">
                  <thead>
                    
                  </thead>   
                  <tbody>
                    <tr>
                      <td>This is the primary account manager for H-Cube.</td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>Inventory</td>
                      <td><a href="#">None</a></td>
                      <td><a href="#">View</a></td>
                      <td><a href="#">View & Edit</a></td>
                      <td><a href="#">Admin</a></td>
                    </tr>
                    <tr>
                      <td><span style="float: right;">Inventory Planning</span></td>
                      <td><input type="radio" name="aa"></td>
                      <td></td>
                      <td><input type="radio" name="aa"></td>
                      <td></td>
                    </tr>
                    <tr>
                      <td><span style="float: right;">Manage Inventory/Add a Product</span></td>
                      <td><input type="radio" name="aa"></td>
                      <td></td>
                      <td><input type="radio" name="aa"></td>
                      <td></td>
                    </tr>

                    <tr>
                      <td><span style="float: right;">Upload Inventory</span></td>
                      <td><input type="radio" name="aa"></td>
                      <td></td>
                      <td><input type="radio" name="aa"></td>
                      <td></td>
                    </tr>
                  </tbody>
                  <tbody>
                    <tr>
                      <td>Pricing</td>
                      <td><a href="#">None</a></td>
                      <td><a href="#">View</a></td>
                      <td><a href="#">View & Edit</a></td>
                      <td><a href="#">Admin</a></td>
                    </tr>
                    <tr>
                      <td><span style="float: right;">Automate Pricing</span></td>
                      <td><input type="radio" name="bb"></td>
                      <td><input type="radio" name="bb"></td>
                      <td><input type="radio" name="bb"></td>
                      <td></td>
                    </tr>
                    <tr>
                      <td><span style="float: right;">Pricing</span></td>
                      <td><input type="radio" name="cc"></td>
                      <td><input type="radio" name="cc"></td>
                      <td></td>
                      <td></td>
                    </tr>
                  </tbody>
                  <tbody>
                    <tr>
                      <td>Advertising</td>
                      <td><a href="#">None</a></td>
                      <td><a href="#">View</a></td>
                      <td><a href="#">View & Edit</a></td>
                      <td><a href="#">Admin</a></td>
                    </tr>
                    <tr>
                      <td><span style="float: right;">Compaign Manager</span></td>
                      <td><input type="radio" name="aa"></td>
                      <td></td>
                      <td><input type="radio" name="aa"></td>
                      <td></td>
                    </tr>
                    <tr>
                      <td><span style="float: right;">Promotions</span></td>
                      <td><input type="radio" name="aa"></td>
                      <td><input type="radio" name="aa"></td>
                      <td><input type="radio" name="aa"></td>
                      <td><input type="radio" name="aa"></td>
                    </tr>
                    <tr>
                      <td><span style="float: right;">Register for Sponsored Products</span></td>
                      <td><input type="radio" name="aa"></td>
                      <td><input type="radio" name="aa"></td>
                      <td></td>
                      <td></td>
                    </tr>
                    <tr>
                      <td><span style="float: right;">Vouchers</span></td>
                      <td><input type="radio" name="aa"></td>
                      <td><input type="radio" name="aa"></td>
                      <td><input type="radio" name="aa"></td>
                      <td></td>
                    </tr>
                  </tbody>
                  <tbody>
                    <tr>
                      <td>Orders</td>
                      <td><a href="#">None</a></td>
                      <td><a href="#">View</a></td>
                      <td><a href="#">View & Edit</a></td>
                      <td><a href="#">Admin</a></td>
                    </tr>
                    <tr>
                      <td><span style="float: right;">Manage Orders</span></td>
                      <td><input type="radio" name="aa"></td>
                      <td><input type="radio" name="aa"></td>
                      <td><input type="radio" name="aa"></td>
                      <td></td>
                    </tr>
                    <tr>
                      <td><span style="float: right;">Manage Refunds</span></td>
                      <td><input type="radio" name="aa"></td>
                      <td></td>
                      <td><input type="radio" name="aa"></td>
                      <td></td>
                    </tr>
                    <tr>
                      <td><span style="float: right;">Manage Returns</span></td>
                      <td><input type="radio" name="aa"></td>
                      <td></td>
                      <td><input type="radio" name="aa"></td>
                      <td></td>
                    </tr>
                    <tr>
                      <td><span style="float: right;">Transactions</span></td>
                      <td><input type="radio" name="aa"></td>
                      <td></td>
                      <td><input type="radio" name="aa"></td>
                      <td></td>
                    </tr>
                  </tbody>
                  <tbody>
                    <tr>
                      <td>Store Design</td>
                      <td><a href="#">None</a></td>
                      <td><a href="#">View</a></td>
                      <td><a href="#">View & Edit</a></td>
                      <td><a href="#">Admin</a></td>
                    </tr>
                    <tr>
                      <td><span style="float: right;">Stores Builder</span></td>
                      <td><input type="radio" name="aa"></td>
                      <td><input type="radio" name="aa"></td>
                      <td><input type="radio" name="aa"></td>
                      <td></td>
                    </tr>
                    <tr>
                      <td><span style="float: right;">Your Info & Policies</span></td>
                      <td><input type="radio" name="aa"></td>
                      <td></td>
                      <td><input type="radio" name="aa"></td>
                      <td></td>
                    </tr>
                  </tbody>
                  <tbody>
                    <tr>
                      <td>Carrovan Pay</td>
                      <td><a href="#">None</a></td>
                      <td><a href="#">View</a></td>
                      <td><a href="#">View & Edit</a></td>
                      <td><a href="#">Admin</a></td>
                    </tr>
                    <tr>
                      <td><span style="float: right;">Manage Refunds</span></td>
                      <td><input type="radio" name="aa"></td>
                      <td><input type="radio" name="aa"></td>
                      <td><input type="radio" name="aa"></td>
                      <td></td>
                    </tr>
                  </tbody>
                  <tbody>
                    <tr>
                      <td>Reports</td>
                      <td><a href="#">None</a></td>
                      <td><a href="#">View</a></td>
                      <td><a href="#">View & Edit</a></td>
                      <td><a href="#">Admin</a></td>
                    </tr>
                    <tr>
                      <td><span style="float: right;">Carrovan Selling Coach</span></td>
                      <td><input type="radio" name="aa"></td>
                      <td><input type="radio" name="aa"></td>
                      <td></td>
                      <td></td>
                    </tr>
                    <tr>
                      <td><span style="float: right;">Business Reports, Sales Summary</span></td>
                      <td><input type="radio" name="aa"></td>
                      <td></td>
                      <td><input type="radio" name="aa"></td>
                      <td></td>
                    </tr>
                    <tr>
                      <td><span style="float: right;">Customer Metrics</span></td>
                      <td><input type="radio" name="aa"></td>
                      <td><input type="radio" name="aa"></td>
                      <td></td>
                      <td></td>
                    </tr>
                    <tr>
                      <td><span style="float: right;">Feedback</span></td>
                      <td><input type="radio" name="aa"></td>
                      <td><input type="radio" name="aa"></td>
                      <td><input type="radio" name="aa"></td>
                      <td></td>
                    </tr>
                    <tr>
                      <td><div style="text-align: right;">Operation Report<br>A-to-z Guarentee Claims</div></td>
                      <td><input type="radio" name="aa"></td>
                      <td><input type="radio" name="aa"></td>
                      <td></td>
                      <td></td>
                    </tr>
                    <tr>
                      <td><div style="text-align: right;">Payments<br>Enable access to Payments reports as well as the Payment summary section.</div></td>
                      <td><input type="radio" name="aa"></td>
                      <td></td>
                      <td><input type="radio" name="aa"></td>
                      <td></td>
                    </tr>
                    <tr>
                      <td><span style="float: right;">Product Ads Invoice History</span></td>
                      <td><input type="radio" name="aa"></td>
                      <td><input type="radio" name="aa"></td>
                      <td><input type="radio" name="aa"></td>
                      <td></td>
                    </tr>
                    <tr>
                      <td><span style="float: right;">Product Ads Performance Reports</span></td>
                      <td><input type="radio" name="aa"></td>
                      <td><input type="radio" name="aa"></td>
                      <td></td>
                      <td></td>
                    </tr>
                    <tr>
                      <td><span style="float: right;">Sell Globaly: Getting Started</span></td>
                      <td><input type="radio" name="aa"></td>
                      <td><input type="radio" name="aa"></td>
                      <td><input type="radio" name="aa"></td>
                      <td></td>
                    </tr>
                    <tr>
                      <td><span style="float: right;">Seller Fee Invoices</span></td>
                      <td><input type="radio" name="aa"></td>
                      <td></td>
                      <td><input type="radio" name="aa"></td>
                      <td></td>
                    </tr>
                  </tbody>
                  <tbody>
                    <tr>
                      <td>Settings</td>
                      <td><a href="#">None</a></td>
                      <td><a href="#">View</a></td>
                      <td><a href="#">View & Edit</a></td>
                      <td><a href="#">Admin</a></td>
                    </tr>
                    <tr>
                      <td width="45%"><div style="text-align: right;">Agreements/Amendments<br>Information about our customers is an important part of our business, and we are not in the business of selling it to others. We share customer information only as described below and with subsidiaries Amazon.com, Inc. controls that either are subject to this Privacy Notice or follow practices at least as protective as those described in this Privacy Notice.</div></td>
                      <td><input type="radio" name="aa"></td>
                      <td></td>
                      <td><input type="radio" name="aa"></td>
                      <td></td>
                    </tr>
                    <tr>
                      <td><span style="float: right;">B2B Edit Access</span></td>
                      <td><input type="radio" name="aa"></td>
                      <td></td>
                      <td><input type="radio" name="aa"></td>
                      <td></td>
                    </tr>
                    <tr>
                      <td><span style="float: right;">Gift Oprions</span></td>
                      <td><input type="radio" name="aa"></td>
                      <td><input type="radio" name="aa"></td>
                      <td><input type="radio" name="aa"></td>
                      <td></td>
                    </tr>
                    <tr>
                      <td><span style="float: right;">Manage Your Cases</span></td>
                      <td><input type="radio" name="aa"></td>
                      <td><input type="radio" name="aa"></td>
                      <td><input type="radio" name="aa"></td>
                      <td></td>
                    </tr>
                    <tr>
                      <td><span style="float: right;">Seller Configuration</span></td>
                      <td><input type="radio" name="aa"></td>
                      <td><input type="radio" name="aa"></td>
                      <td><input type="radio" name="aa"></td>
                      <td></td>
                    </tr>
                    <tr>
                      <td><span style="float: right;">Shipping Settings</span></td>
                      <td><input type="radio" name="aa"></td>
                      <td><input type="radio" name="aa"></td>
                      <td><input type="radio" name="aa"></td>
                      <td></td>
                    </tr>
                    <tr>
                      <td><span style="float: right;">Tax Settings</span></td>
                      <td><input type="radio" name="aa"></td>
                      <td></td>
                      <td><input type="radio" name="aa"></td>
                      <td></td>
                    </tr>
                    <tr>
                      <td><div style="text-align: center">User Permissions<br>Warning: by granting this right you are making this user a superuser.</div></td>
                      <td><input type="radio" name="aa"></td>
                      <td></td>
                      <td><input type="radio" name="aa"></td>
                      <td></td>
                    </tr>
                  </tbody>
                  <tbody>
                    <tr>
                      <td>Media Upload</td>
                      <td><a href="#">None</a></td>
                      <td><a href="#">View</a></td>
                      <td><a href="#">View & Edit</a></td>
                      <td><a href="#">Admin</a></td>
                    </tr>
                    <tr>
                      <td><span style="float: right;">Image Uploading</span></td>
                      <td><input type="radio" name="aa"></td>
                      <td><input type="radio" name="aa"></td>
                      <td><input type="radio" name="aa"></td>
                      <td></td>
                    </tr>
                  </tbody>
                  <tbody>
                    <tr>
                      <td>Internel Administrative Tools</td>
                      <td><a href="#">None</a></td>
                      <td><a href="#">View</a></td>
                      <td><a href="#">View & Edit</a></td>
                      <td><a href="#">Admin</a></td>
                    </tr>
                    <tr>
                      <td><span style="float: right;">Merchant Account Termination</span></td>
                      <td><input type="radio" name="aa"></td>
                      <td></td>
                      <td></td>
                      <td><input type="radio" name="aa"></td>
                    </tr>
                    <tr>
                      <td><span style="float: right;">Upgrade/Downgrade</span></td>
                      <td><input type="radio" name="aa"></td>
                      <td></td>
                      <td><input type="radio" name="aa"></td>
                      <td></td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <div style="text-align: center;">Return to <a href="#">User Permissions</a> main page.</div>
            </div>
          </div>
      	</div>
    </div>
</div>