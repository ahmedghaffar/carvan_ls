
<div class="main">
  	<div class="main-inner">
    	<div class="container-fluid">
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12" style="margin-bottom: 20px; padding: 10px 6% 5px 18px; border: 1px solid #d6d6d6; background: #fff">
            <div class="cntr">
    <label for="rdo-1" class="btn-radio">
      <input type="radio" id="rdo-1" name="radio-grp">
      <svg width="20px" height="20px" viewBox="0 0 20 20"></svg>
      <span>Filter :</span>
    </label>
    <label for="rdo-2" class="btn-radio">
      <input type="radio" id="rdo-2" name="radio-grp">
      <svg width="20px" height="20px" viewBox="0 0 20 20">
        <circle cx="10" cy="10" r="9"></circle>
        <path d="M10,7 C8.34314575,7 7,8.34314575 7,10 C7,11.6568542 8.34314575,13 10,13 C11.6568542,13 13,11.6568542 13,10 C13,8.34314575 11.6568542,7 10,7 Z" class="inner"></path>
        <path d="M10,1 L10,1 L10,1 C14.9705627,1 19,5.02943725 19,10 L19,10 L19,10 C19,14.9705627 14.9705627,19 10,19 L10,19 L10,19 C5.02943725,19 1,14.9705627 1,10 L1,10 L1,10 C1,5.02943725 5.02943725,1 10,1 L10,1 Z" class="outer"></path>
      </svg>
      <span>Response Needed</span>
    </label>
    <label for="rdo-3" class="btn-radio">
      <input type="radio" id="rdo-3" name="radio-grp">
      <svg width="20px" height="20px" viewBox="0 0 20 20">
        <circle cx="10" cy="10" r="9"></circle>
        <path d="M10,7 C8.34314575,7 7,8.34314575 7,10 C7,11.6568542 8.34314575,13 10,13 C11.6568542,13 13,11.6568542 13,10 C13,8.34314575 11.6568542,7 10,7 Z" class="inner"></path>
        <path d="M10,1 L10,1 L10,1 C14.9705627,1 19,5.02943725 19,10 L19,10 L19,10 C19,14.9705627 14.9705627,19 10,19 L10,19 L10,19 C5.02943725,19 1,14.9705627 1,10 L1,10 L1,10 C1,5.02943725 5.02943725,1 10,1 L10,1 Z" class="outer"></path>
      </svg>
      <span>All Messages</span>
    </label>
  </div>
         <div style="display: inline-flex; float: right;">
  Filter By Date:
  <input type="date" name="bday">
</div>
          </div>
        </div>
      		<div class="row">
              <div class="col-md-3 col-sm-3 col-xs-12" style="border-radius: 0px">
                <div class="widget">
                  <div class="widget-header"> 
                    <h3>All Messages</h3>
                  </div>
                  <!-- /widget-header -->
                  <div class="widget-content">
                          <p><a class="name">John Smith</a> <span class="time" style="float: right;">03:16pm</span><br>
                           As an interesting side note, as a head without a body, I envy the dead. There's one way and only one way to determine if an animal is intelligent. Dissect its brain! Man, I'm sore all over.</p> 
                  </div>

                  <div class="widget-content">
                          <p><a class="name">John Smith</a> <span class="time" style="float: right;">03:16pm</span><br>
                           As an interesting side note, as a head without a body, I envy the dead. There's one way and only one way to determine if an animal is intelligent. Dissect its brain! Man, I'm sore all over.</p> 
                  </div>

                  <div class="widget-content">
                          <p><a class="name">John Smith</a> <span class="time" style="float: right;">03:16pm</span><br>
                           As an interesting side note, as a head without a body, I envy the dead. There's one way and only one way to determine if an animal is intelligent. Dissect its brain! Man, I'm sore all over.</p> 
                  </div>

                  <div class="widget-content">
                          <p><a class="name">John Smith</a> <span class="time" style="float: right;">03:16pm</span><br>
                           As an interesting side note, as a head without a body, I envy the dead. There's one way and only one way to determine if an animal is intelligent. Dissect its brain! Man, I'm sore all over.</p> 
                  </div>
                </div>
              </div>
        			<div class="col-md-6 col-sm-6 col-xs-12">
          				<div class="widget">
            				<div class="widget-header">
              					<h3 style="display: inline;"> Customer Name <span style="margin-left: 20%"></span> Subject:</h3>
            				</div>
            				<!-- /widget-header -->
            				<div class="widget-content">
              			
                
              <ul class="messages_layout">
                <li class="from_user left"> 
                  <div class="message_wrap"> <span class="ar.row-fluid"></span>
                    <div class="info"> <a class="name">John Smith</a> <span class="time">1 hour ago</span>
                      <div class="options_ar.row-fluid">
                        <div class="dropdown pull-right"> <a class="dropdown-toggle " id="dLabel" role="button" data-toggle="dropdown" data-target="#" href="#"> <i class=" icon-caret-down"></i> </a>
                          <ul class="dropdown-menu " role="menu" aria-labelledby="dLabel">
                            <li><a href="#"><i class=" icon-share-alt icon-large"></i> Reply</a></li>
                            <li><a href="#"><i class=" icon-trash icon-large"></i> Delete</a></li>
                            <li><a href="#"><i class=" icon-share icon-large"></i> Share</a></li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div class="text"> As an interesting side note, as a head without a body, I envy the dead. There's one way and only one way to determine if an animal is intelligent. Dissect its brain! Man, I'm sore all over. I feel like I just went ten rounds with mighty Thor. </div>
                  </div>
                </li>
                <li class="by_myself right">
                  <div class="message_wrap"> <span class="ar.row-fluid"></span>
                    <div class="info"> <a class="name">Bender (myself) </a> <span class="time">4 hours ago</span>
                      <div class="options_ar.row-fluid">
                        <div class="dropdown pull-right"> <a class="dropdown-toggle " id="dLabel" role="button" data-toggle="dropdown" data-target="#" href="#"> <i class=" icon-caret-down"></i> </a>
                          <ul class="dropdown-menu " role="menu" aria-labelledby="dLabel">
                            <li><a href="#"><i class=" icon-share-alt icon-large"></i> Reply</a></li>
                            <li><a href="#"><i class=" icon-trash icon-large"></i> Delete</a></li>
                            <li><a href="#"><i class=" icon-share icon-large"></i> Share</a></li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div class="text"> All I want is to be a monkey of moderate intelligence who wears a suit… that's why I'm transferring to business school! I had more, but you go ahead. Man, I'm sore all over. I feel like I just went ten rounds with mighty Thor. File not found. </div>
                  </div>
                </li>
                <li class="from_user left">
                  <div class="message_wrap"> <span class="ar.row-fluid"></span>
                    <div class="info"> <a class="name">Celeste Holm </a> <span class="time">1 Day ago</span>
                      <div class="options_ar.row-fluid">
                        <div class="dropdown pull-right"> <a class="dropdown-toggle " id="dLabel" role="button" data-toggle="dropdown" data-target="#" href="#"> <i class=" icon-caret-down"></i> </a>
                          <ul class="dropdown-menu " role="menu" aria-labelledby="dLabel">
                            <li><a href="#"><i class=" icon-share-alt icon-large"></i> Reply</a></li>
                            <li><a href="#"><i class=" icon-trash icon-large"></i> Delete</a></li>
                            <li><a href="#"><i class=" icon-share icon-large"></i> Share</a></li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div class="text"> And I'd do it again! And perhaps a third time! But that would be it. Are you crazy? I can't swallow that. And I'm his friend Jesus. No, I'm Santa Claus! And from now on you're all named Bender Jr. </div>
                  </div>
                </li>
                <li class="from_user left">
                  <div class="message_wrap"> <span class="ar.row-fluid"></span>
                    <div class="info"> <a class="name">Mark Jobs </a> <span class="time">2 Days ago</span>
                      <div class="options_ar.row-fluid">
                        <div class="dropdown pull-right"> <a class="dropdown-toggle " id="dLabel" role="button" data-toggle="dropdown" data-target="#" href="#"> <i class=" icon-caret-down"></i> </a>
                          <ul class="dropdown-menu " role="menu" aria-labelledby="dLabel">
                            <li><a href="#"><i class=" icon-share-alt icon-large"></i> Reply</a></li>
                            <li><a href="#"><i class=" icon-trash icon-large"></i> Delete</a></li>
                            <li><a href="#"><i class=" icon-share icon-large"></i> Share</a></li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div class="text"> That's the ONLY thing about being a slave. Now, now. Perfectly symmetrical violence never solved anything. Uh, is the puppy mechanical in any way? As an interesting side note, as a head without a body, I envy the dead. </div>
                  </div>
                </li>
              </ul>
              <form><input type="text" name="search" placeholder="Enter your response here..." style="padding: 15px; width: 100%"></form>
                 <a href="#" class="btn btn-primary">Attach File</a>
                 <a href="#" class="btn btn-primary">No Reasponse Needed</a>
                 <a href="#" class="btn btn-primary">Send</a>
                </div>
            			<!-- /widget-content --> 
                </div>
          			<!-- /widget -->
        		</div>
        		<!-- /span6 -->
        		<div class="col-md-3 col-sm-3 col-xs-12">
          			<div class="widget widget-nopad">
            			<div class="widget-header"> 
                  	<h3> Heading</h3>
            			</div>
            			<!-- /widget-header -->
            			<div class="widget-content">
              				<div class="widget big-stats-container">
                				<div class="widget-content">
                  					<ul class="rside">
                  						<li> Order ID </li><hr>
                  						<li> Prchase Date </li>
                              <li> 04/08/2018 </li><hr>
                              <li> Delivery Date </li>
                              <li> 04/08/2018 </li><hr>
                              <li> Tracking ID </li><hr>
                              <li> Dispatch Date </li><hr>
                              <li> Product Title & Details </li><hr>
                  					</ul>
                  				</div>
                				<!-- /widget-content --> 
                        </div>
            			</div>
          			</div>
               	    </div>
             			</div>
          			</div>
          		</div>
        		 
      		</div>
      		<!-- /.row-fluid --> 
    	</div>
    	<!-- /container --> 
  	</div>
  	<!-- /main-inner --> 
</div>
<!-- /main -->
<!-- 
<div class="extra">
  <div class="extra-inner">
    <div class="container">
      <div class=".row-fluid">
                    <div class="span3">
                        <h4>
                            About Free Admin Template</h4>
                        <ul>
                            <li><a href="javascript:;">EGrappler.com</a></li>
                            <li><a href="javascript:;">Web Development Resources</a></li>
                            <li><a href="javascript:;">Responsive HTML5 Portfolio Templates</a></li>
                            <li><a href="javascript:;">Free Resources and Scripts</a></li>
                        </ul>
                    </div>
                    /span3 -->
                    <!--<div class="span3">
                        <h4>
                            Support</h4>
                        <ul>
                            <li><a href="javascript:;">Frequently Asked Questions</a></li>
                            <li><a href="javascript:;">Ask a Question</a></li>
                            <li><a href="javascript:;">Video Tutorial</a></li>
                            <li><a href="javascript:;">Feedback</a></li>
                        </ul>
                    </div>
                     /span3 --><!--
                    <div class="span3">
                        <h4>
                            Something Legal</h4>
                        <ul>
                            <li><a href="javascript:;">Read License</a></li>
                            <li><a href="javascript:;">Terms of Use</a></li>
                            <li><a href="javascript:;">Privacy Policy</a></li>
                        </ul>
                    </div>
                     /span3 --><!--
                    <div class="span3">
                        <h4>
                            Open Source jQuery Plugins</h4>
                        <ul>
                            <li><a href="">Open Source jQuery Plugins</a></li>
                            <li><a href="">HTML5 Responsive Tempaltes</a></li>
                            <li><a href="">Free Contact Form Plugin</a></li>
                            <li><a href="">Flat UI PSD</a></li>
                        </ul>
                    </div>
                     /span3 --><!--
                </div>
      
    </div>
     /container 
  </div>
   /extra-inner  
</div>
 /extra -->
