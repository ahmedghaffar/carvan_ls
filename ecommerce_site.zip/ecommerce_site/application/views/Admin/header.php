<!DOCTYPE html>
<html lang="en" style="min-height: 100% !important; position: relative !important; ">
<head>
<meta charset="utf-8">
<title>Carrovan</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="apple-mobile-web-app-capable" content="yes">
<link href="<?= base_url(); ?>assets/css/bootstrap.min.css" rel="stylesheet">
<link href="<?= base_url(); ?>assets/css/bootstrap-responsive.min.css" rel="stylesheet">
<link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600"
        rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="<?= base_url(); ?>assets/css/font-awesome.css" rel="stylesheet">
<link href="<?= base_url(); ?>assets/css/style.css" rel="stylesheet">
<link href="<?= base_url(); ?>assets/css/pages/dashboard.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?= base_url(); ?>assets/data/style.css">
<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
<!-- OTHER SCRIPTS INCLUDED ON THIS PAGE - START --> 
        <link href="<?= base_url(); ?>assets/data/jquery.dataTables.css" rel="stylesheet" type="text/css" media="screen"/>
        <link href="<?= base_url(); ?>assets/data/dataTables.tableTools.min.css" rel="stylesheet" type="text/css" media="screen"/>
        <link href="<?= base_url(); ?>assets/data/dataTables.responsive.css" rel="stylesheet" type="text/css" media="screen"/>
        <link href="<?= base_url(); ?>assets/data/dataTables.bootstrap.css" rel="stylesheet" type="text/css" media="screen"/>       
         <!-- OTHER SCRIPTS INCLUDED ON THIS PAGE - END --> 

    <!-- CORE CSS FRAMEWORK - START -->
        <link href="<?= base_url(); ?>assets/data/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="<?= base_url(); ?>assets/data/font-awesome.css" rel="stylesheet" type="text/css"/>
        <link href="<?= base_url(); ?>assets/data/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" type="text/css"/>
        <!-- CORE CSS FRAMEWORK - END -->

    <link href="<?= base_url(); ?>assets/js/guidely/guidely.css" rel="stylesheet"> 



    <style type="text/css">
      @media (min-width:768px){
      #msform{
      width: 70% !important;
      margin-left: 15% !important;
    }
  }
  /*---------------radio button--------------*/


.btn-radio {
  cursor: pointer;
  display: inline-block;
  float: left;
  -webkit-user-select: none;
  user-select: none;
}
.btn-radio:not(:first-child) {
  margin-left: 20px;
}
@media screen and (max-width: 480px) {
  .btn-radio {
    display: block;
    float: none;
  }
  .btn-radio:not(:first-child) {
    margin-left: 0;
    margin-top: 15px;
  }
}
.btn-radio svg {
  fill: none;
  vertical-align: middle;
}
.btn-radio svg circle {
  stroke-width: 2;
  stroke: #C8CCD4;
}
.btn-radio svg path {
  stroke: #008FFF;
}
.btn-radio svg path.inner {
  stroke-width: 6;
  stroke-dasharray: 19;
  stroke-dashoffset: 19;
}
.btn-radio svg path.outer {
  stroke-width: 2;
  stroke-dasharray: 57;
  stroke-dashoffset: 57;
}
.btn-radio input {
  display: none;
}
.btn-radio input:checked + svg path {
  transition: all 0.2s ease;
}
.btn-radio input:checked + svg path.inner {
  stroke-dashoffset: 38;
  transition-delay: 0.1s;
}
.btn-radio input:checked + svg path.outer {
  stroke-dashoffset: 0;
}
.btn-radio span {
  display: inline-block;
  vertical-align: middle;
}


/*---------------radio button--------------*/

.drop button{
  background-color: #fed007;
  border: 0px;
  font-size: 16px;
  padding: 15px 25px;
  color: white;
  font-family: calibri;

}

    </style>
</head>
<body>
<div class="navbar">
  <div class="navbar-inner">
    <div class="container">
                   <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse"><span
                    class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span> </a><a class="brand" href="index.php">Carrovan</a>
      <!-- <ul class="nav" style="margin-left: 20%; transform: translateX(30%);">
            <li><a href="#" style="font-size: 18px">MarketPlace</a></li>
        </ul> -->
<!--       <span>
        <div class="dropdown market">
  <button class="dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    MarketPlace
  </button> 
  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
    <a class="dropdown-item" href="#">United Kingdom</a>
    <a class="dropdown-item" href="#">Dubae</a>
    <a class="dropdown-item" href="#">Pakistan</a>
  </div>
</div>
</span> -->
        <div class="nav-collapse">
        <ul class="nav pull-right">
          <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown"><i
                            class="icon-cog"></i> Account <b class="caret"></b></a>
            <ul class="dropdown-menu">
              <li><a href="javascript:;">Settings</a></li>
              <li><a href="javascript:;">Help</a></li>
            </ul>
          </li>
          <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown"><i
                            class="icon-user"></i> Kamran <b class="caret"></b></a>
            <ul class="dropdown-menu">
              <li><a href="javascript:;">Profile</a></li>
              <li><a href="javascript:;">Logout</a></li>
            </ul>
          </li>
        </ul>
        <form class="navbar-search pull-right">
          <input type="text" class="search-query" placeholder="Search">
        </form>
      </div>
      <!--/.nav-collapse --> 
    </div>
    <!-- /container --> 
  </div>
  <!-- /navbar-inner --> 
</div>
<!-- /navbar -->
<div class="subnavbar">
  <div class="subnavbar-inner">
    <div class="container">
      <ul class="mainnav">
        <li class="active"><a href="index"><span>Dashboard</span> </a> </li>
        <li><a href="msg"><span>Messages</span> </a> </li><!-- 
        <li><a href="mang_orders"><span>Inventory</span> </a> </li> -->
        <li class="dropdown"><a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown"><span>Inventory</span> <b class="caret"></b></a>
          <ul class="dropdown-menu">
            <li><a href="inventory">Manage Inventory</a></li>
            <li><a href="#">Inventory Planning</a></li>
            <li><a href="sample">Add a Product</a></li>
            <li><a href="product_upload">Add Products via Upload</a></li>
            <li><a href="#">Inventory Reports</a></li>
            <li><a href="#">Manage Promotions</a></li>
          </ul>
        </li>
        <li><a href="business_report"><span>Reports</span> </a></li>
        <li><a href="seller_performance"><span style="margin-top: 31%">Performance</span> </a> </li>
        <li><a href="products"><span>Store</span> </a> </li>
      </ul>
    </div>
    <!-- /container --> 
  </div>
  <!-- /subnavbar-inner --> 
</div>
<!-- /subnavbar -->