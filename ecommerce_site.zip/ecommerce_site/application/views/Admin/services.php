<div class="main fs3">
  	<div class="main-inner">
    	<div class="container">
      		<div class="row">
        		<div class="col-md-12 col-sm-12 col-xs-12">
          			<h1 class="hs1">Carrovan Services</h1>
          			<div class="widget">
          				<div class="widget-header">
          					<h3 class="fs2"> PhoneSoap 2.0 Black UV-C disinfection device for Smartphones <a href="#"> (View carrovan detail page)</a></h3>
          				</div>
          				<div class="widget-content" class="fs3">
          					<div class="col-md-6 col-sm-6 col-xs-6">
          						<img src="<?= base_url(); ?>/image/cache/catalog/demo/product_08-199x201.jpg" alt="iPod Classic" class="img-responsive" />
          					</div>
          					<div class="col-md-6 col-sm-6 col-xs-6" style="line-height: normal;">
          						<div class="fs2">ASIN: <span class="fs3">B1JIDH2J</span></div>
          						<div class="fs2">Product Name: <span class="fs3">PhoneSoap 2.0 Black UV-C disinfection device for Smartphones</span></div>
          						<div class="fs2">Brand: <span class="fs3">PhoneSoap</span></div>
          						<div class="fs2">Manufacturer: <span class="fs3">PhoneSoap</span></div>
          						<div class="fs2">Manufacturer Part Number: <span class="fs3">PhoneSoap 2.0 Black</span></div><br>
          						<div class="fs2">Marketplace: <span class="fs3">GB</span></div><br>
          						<div class="fs2">List Price: <span class="fs3">$54.13</span></div><br>
          						<div class="fs2">Competing Marketplace Offers </div><div class="fs3"><a href="#">1 New </a>from $64.95 + $0.00 delivery</div>
          						<div class="fs2">Carrovan Sales Rank: <span class="fs3">222,529</span></div>
          					</div>
          				</div>
          			</div>
          		</div>
          	</div>
          	<div class="row">
        		<div class="col-md-12 col-sm-12 col-xs-12" style="margin-top: 20px">
          			<div class="widget">
          				<div class="widget-header">
          					<h3 class="fs2"> Offers</h3>
          				</div>
          				<div class="widget-content" class="fs3">
          					<table style="width: 100%">
          						<thead>
          							<tr>
          								<th style="float: right;"></th>
          								<th style="width: 70%"></th>
          							</tr>
          						</thead>
          						<tbody>
          							<tr>
          								<td style="float: right; padding: 5px">Seller SKU</td>
          								<td style=" padding: 5px"><input type="text" name="sku" placeholder="Ex: 1020242" style="width: 50%"></td>
          							</tr>
          							<tr>
          								<td style="float: right; padding: 5px">* Condition</td>
          								<td style=" padding: 5px">
          									<select>
          										<option>-Select-</option>
          										<option>New</option>
          										<option>Used</option>
          									</select>
          								</td>
          							</tr>
          							<tr>
          								<td style="float: right; padding: 5px">* Your price</td>
          								<td style=" padding: 5px">
          									<span style="display: inline-flex;"><i class="fa fa-usd" style=" background-color: #d5d5d5; padding: 6px; position: absolute;"></i><input type="text" name="asdf" placeholder="Ex: 50.00" style="width: 125px; padding-left: 20px"></span>
          								</td>
          							</tr>
          							<tr>
          								<td style="float: right; padding: 5px">* Quantity</td>
          								<td style=" padding: 5px"><input type="text" name="quantity"></td>
          							</tr>
          						</tbody>
          					</table>
          				</div>
          			</div>
          			<h1 class="fs3" style="text-align: center;">
          				<a href="#" class="btn btn-default">Cancel</a>
          				<a href="#" class="btn btn-primary">Save and Finish</a>
          			</h1>
          		</div>
          	</div>
        </div>
    </div>
</div>