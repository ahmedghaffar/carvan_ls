<div class="main fs3">
  	<div class="main-inner">
    	<div class="container-fluid">
      		<div class="row" style="color: black !important">
			    <div class="col-md-12 col-sm-12 col-xs-12">
			    	<div class="fs1">Dispatch to:</div>
			    		<div style="color: black">
			    		<div class="hs1">Michael Haggerty</div>
			    		<div class="hs1">2/1 9</div>
			    		<div class="hs1">LANGRIG ROAD</div>
			    		<div class="hs1">GLASGOW</div>
			    		<div class="hs1">G21 4YW</div>
			    		<div class="hs1">United Kingdom</div>
			    	</div>
			    	<div>........................................................................................................................................................................................................................................................................................................................................................................................................................................................</div>
			    	<div class="hs2">Order ID: 205-345345-5343</div>
			    	<div class="fs1">Thank you for buying from H-Cube on Carrovan Marketplace</div>
			    	<div class="widget widget-nopad" style="border: 1px solid black">
			    		<div class="widget-content fs3">
			    			<div class="col-md-4 col-sm-4 col-xs-4">
			    				<div><b>Delivery Address:</b></div>
			    				<div>Michael Haggerty</div>
			    				<div>2/1 9</div>
			    				<div>LANGRIG ROAD</div>
			    				<div>GLASGOW</div>
			    				<div>G21 4YW</div>
			    				<div>United Kingdom</div>
			    			</div>
			    			<div class="col-md-4 col-sm-4 col-xs-4">
			    				<div>Order Date:</div>
			    				<div>Delivery Service:</div>
			    				<div>Buyer Name:</div>
			    				<div>Sellter Name:</div>
			    			</div>
			    			<div class="col-md-4 col-sm-4 col-xs-4">
			    				<div>Sat, Sep 29, 2018</div>
			    				<div>Standard</div>
			    				<div>Mr Michael Haggerty</div>
			    				<div>H-Cube</div>
			    			</div>
			    		</div>
			    	</div>
			    </div>
			</div>
			<div class="row" style="color: black !important; margin-top: 10px">
				<div class="col-md-12 col-sm-12 col-xs-12">
					<table style=" width: 100%">
						<thead><tr>
							<th style="border: 1px solid black;">Quantity</th>
							<th style="border: 1px solid black;">Product details</th>
							<th style="border: 1px solid black;">Unit Price</th>
							<th style="border: 1px solid black;">Order Totals</th></tr>
						</thead>
						<tbody>
							<tr>
								<td style="border: 1px solid black; text-align: center">1</td>
								<td style="border: 1px solid black;">	
									<div>H-Cube Furniture Thick Padded Divan Bed Base Headboard Turin Fabric Thickness 3 Inches (Approx) With Struts & Fixings (Navy Blue - 4FT6 Double-26)</div>
									<div><b>SKU: </b><span>347238</span></div> 
									<div><b>ASIN: </b><span>41234B23</span></div>
									<div><b>Condition: </b><span>New</span></div>
									<div><b>Lisitng ID: </b><span>24314-23423-234</span></div>
									<div><b>Order item ID: </b><span>2343249832</span></div>
								</td>
								<td style="border: 1px solid black; text-align: center;">$72.99</td>
								<td style="border: 1px solid black; text-align: center; padding: 5px">
									<div style="float: right;" class="fs1">Included VAT</div><br>
									<div style="border-bottom: 1px solid black; float: right;">Item subtotal &nbsp; $72.99 <span class="fs1">$12.75</span></div><br>
									<div style="border-bottom: 1px solid black; float: right;">Item total &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; $72.99 <span class="fs1">$12.75</span></div>
								</td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12 col-sm-12 col-xs-12">
				<div style="float: right; color: black">Grand total: $72.99</div><br>
				<div>Our customers include hotels and lodges as we can prepare bulk orders. Therefore, if you want to decorate your commercial property, H-Cube Furniture will gladly assist you for your project.</div>
				<div style="color: black">........................................................................................................................................................................................................................................................................................................................................................................................................................................................</div>
			</div></div>
		</div>
	</div>
</div>