<!DOCTYPE html>
<html lang="en" style="min-height: 100% !important; position: relative !important; ">
<head>
<meta charset="utf-8">
<title>Carrovan</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="apple-mobile-web-app-capable" content="yes">
<link href="<?= base_url(); ?>assets/css/bootstrap.min.css" rel="stylesheet">
<link href="<?= base_url(); ?>assets/css/bootstrap-responsive.min.css" rel="stylesheet">
<link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600"
        rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="<?= base_url(); ?>assets/css/font-awesome.css" rel="stylesheet">
<link href="<?= base_url(); ?>assets/css/style.css" rel="stylesheet">
<link href="<?= base_url(); ?>assets/css/pages/dashboard.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?= base_url(); ?>assets/data/style.css">
<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
<!-- OTHER SCRIPTS INCLUDED ON THIS PAGE - START --> 
        <link href="<?= base_url(); ?>assets/data/jquery.dataTables.css" rel="stylesheet" type="text/css" media="screen"/>
        <link href="<?= base_url(); ?>assets/data/dataTables.tableTools.min.css" rel="stylesheet" type="text/css" media="screen"/>
        <link href="<?= base_url(); ?>assets/data/dataTables.responsive.css" rel="stylesheet" type="text/css" media="screen"/>
        <link href="<?= base_url(); ?>assets/data/dataTables.bootstrap.css" rel="stylesheet" type="text/css" media="screen"/>       
         <!-- OTHER SCRIPTS INCLUDED ON THIS PAGE - END --> 

    <!-- CORE CSS FRAMEWORK - START -->
        <link href="<?= base_url(); ?>assets/data/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="<?= base_url(); ?>assets/data/font-awesome.css" rel="stylesheet" type="text/css"/>
        <link href="<?= base_url(); ?>assets/data/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" type="text/css"/>
        <!-- CORE CSS FRAMEWORK - END -->

    <link href="<?= base_url(); ?>assets/js/guidely/guidely.css" rel="stylesheet"> 



    <style type="text/css">
      @media (min-width:768px){
      #msform{
      width: 70% !important;
      margin-left: 15% !important;
    }
  }
  /*---------------radio button--------------*/


.btn-radio {
  cursor: pointer;
  display: inline-block;
  float: left;
  -webkit-user-select: none;
  user-select: none;
}
.btn-radio:not(:first-child) {
  margin-left: 20px;
}
@media screen and (max-width: 480px) {
  .btn-radio {
    display: block;
    float: none;
  }
  .btn-radio:not(:first-child) {
    margin-left: 0;
    margin-top: 15px;
  }
}
.btn-radio svg {
  fill: none;
  vertical-align: middle;
}
.btn-radio svg circle {
  stroke-width: 2;
  stroke: #C8CCD4;
}
.btn-radio svg path {
  stroke: #008FFF;
}
.btn-radio svg path.inner {
  stroke-width: 6;
  stroke-dasharray: 19;
  stroke-dashoffset: 19;
}
.btn-radio svg path.outer {
  stroke-width: 2;
  stroke-dasharray: 57;
  stroke-dashoffset: 57;
}
.btn-radio input {
  display: none;
}
.btn-radio input:checked + svg path {
  transition: all 0.2s ease;
}
.btn-radio input:checked + svg path.inner {
  stroke-dashoffset: 38;
  transition-delay: 0.1s;
}
.btn-radio input:checked + svg path.outer {
  stroke-dashoffset: 0;
}
.btn-radio span {
  display: inline-block;
  vertical-align: middle;
}


/*---------------radio button--------------*/

.drop button{
  background-color: #fed007;
  border: 0px;
  font-size: 16px;
  padding: 15px 25px;
  color: white;
  font-family: calibri;

}

    </style>
</head>
<body>
<div class="navbar">
  <div class="navbar-inner">
    <div class="container">
                   <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse"><span
                    class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span> </a><a class="brand" href="index.php">Carrovan</a>
      <!-- <ul class="nav" style="margin-left: 20%; transform: translateX(30%);">
            <li><a href="#" style="font-size: 18px">MarketPlace</a></li>
        </ul> -->
<!--       <span>
        <div class="dropdown market">
  <button class="dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    MarketPlace
  </button> 
  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
    <a class="dropdown-item" href="#">United Kingdom</a>
    <a class="dropdown-item" href="#">Dubae</a>
    <a class="dropdown-item" href="#">Pakistan</a>
  </div>
</div>
</span> -->
        <div class="nav-collapse">
        <ul class="nav pull-right">
          <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown"><i
                            class="icon-cog"></i> Account <b class="caret"></b></a>
            <ul class="dropdown-menu">
              <li><a href="javascript:;">Settings</a></li>
              <li><a href="javascript:;">Help</a></li>
            </ul>
          </li>
          <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown"><i
                            class="icon-user"></i> Kamran <b class="caret"></b></a>
            <ul class="dropdown-menu">
              <li><a href="javascript:;">Profile</a></li>
              <li><a href="javascript:;">Logout</a></li>
            </ul>
          </li>
        </ul>
        <form class="navbar-search pull-right">
          <input type="text" class="search-query" placeholder="Search">
        </form>
      </div>
      <!--/.nav-collapse --> 
    </div>
    <!-- /container --> 
  </div>
  <!-- /navbar-inner --> 
</div>
<!-- /navbar -->
<div class="subnavbar">
  <div class="subnavbar-inner">
    <div class="container">
      <ul class="mainnav">
        <li class="active"><a href="index"><span>Dashboard</span> </a> </li>
        <li><a href="msg"><span>Messages</span> </a> </li><!-- 
        <li><a href="mang_orders"><span>Inventory</span> </a> </li> -->
        <li class="dropdown"><a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown"><span>Inventory</span> <b class="caret"></b></a>
          <ul class="dropdown-menu">
            <li><a href="inventory">Manage Inventory</a></li>
            <li><a href="#">Inventory Planning</a></li>
            <li><a href="sample">Add a Product</a></li>
            <li><a href="product_upload">Add Products via Upload</a></li>
            <li><a href="#">Inventory Reports</a></li>
            <li><a href="#">Manage Promotions</a></li>
          </ul>
        </li>
        <li><a href="business_report"><span>Reports</span> </a></li>
        <li><a href="seller_performance"><span style="margin-top: 31%">Performance</span> </a> </li>
        <li><a href="products"><span>Store</span> </a> </li>
      </ul>
    </div>
    <!-- /container --> 
  </div>
  <!-- /subnavbar-inner --> 
</div>
<!-- /subnavbar -->

<div class="main">
    <div class="main-inner">
      <div class="container-fluid">
          <div class="row">
            <div class>
          <!-- START CONTENT -->
            <section id="main-content">
                <section class="wrapper main-wrapper">

                    <div class='col-lg-12 col-md-12 col-sm-12 col-xs-12'>
                        <div class="page-title">
                           <h1 class="hs1">Manage Inventory <span class="fs3"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="#">Learn more</a></span></h1>
                            <div class="pull-left">
                              
                            </div>

                            <!-- <div class="pull-right hidden-xs">
                                <ol class="breadcrumb">
                                    <li>
                                        <a href="index.html"><i class="fa fa-home"></i>Home</a>
                                    </li>
                                    <li>
                                        <a href="eco-orders.html">Orders</a>
                                    </li>
                                    <li class="active">
                                        <strong>All Orders</strong>
                                    </li>
                                </ol>
                            </div> -->

                        </div>
                    </div>
                    
                      <div class="panel panel-default panel_header">
                        <div class="col-lg-3 col-md-3 col-sm-3 col-xs-5">
                          <select class="drop">
                            <option>Action on 0 selected</option>
                            <option>Action 1</option>
                            <option>Action 2</option>
                            <option>Action 3</option>
                            <option>Action 4</option>
                            <option>Action 5</option>
                            <option>Action 6</option>
                          </select>
                        </div>
                        <div class="col-lg-9 col-md-9 col-sm-9 col-xs-9">
                          <input type="text" name="search" class="search-bar"><a href="#" class=" btn btn-primary" style="margin-left: 5px">Search</a>
                        </div>
                      </div>
                        <div>
                                        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12" style="margin-top: 10px">
                                          <form style="padding: 10px 10px 0px 10px; margin-bottom: 0px !important;background-color: #f5f5f5; border: 1px solid #d6d6d6">
                                            <div class="cntr" style="display:inline">
  <span style="float:left">Filter : 
  </span>   <span> Listing Status</span> <label for="rdo-1" class="btn-radio">
      <input type="radio" id="rdo-1" name="radio-grp">
      <svg width="20px" height="20px" viewBox="0 0 20 20">
        <circle cx="10" cy="10" r="9"></circle>
        <path d="M10,7 C8.34314575,7 7,8.34314575 7,10 C7,11.6568542 8.34314575,13 10,13 C11.6568542,13 13,11.6568542 13,10 C13,8.34314575 11.6568542,7 10,7 Z" class="inner"></path>
        <path d="M10,1 L10,1 L10,1 C14.9705627,1 19,5.02943725 19,10 L19,10 L19,10 C19,14.9705627 14.9705627,19 10,19 L10,19 L10,19 C5.02943725,19 1,14.9705627 1,10 L1,10 L1,10 C1,5.02943725 5.02943725,1 10,1 L10,1 Z" class="outer"></path>
      </svg>
      <span>New Orders</span>
    </label>
    <label for="rdo-2" class="btn-radio">
      <input type="radio" id="rdo-2" name="radio-grp">
      <svg width="20px" height="20px" viewBox="0 0 20 20">
        <circle cx="10" cy="10" r="9"></circle>
        <path d="M10,7 C8.34314575,7 7,8.34314575 7,10 C7,11.6568542 8.34314575,13 10,13 C11.6568542,13 13,11.6568542 13,10 C13,8.34314575 11.6568542,7 10,7 Z" class="inner"></path>
        <path d="M10,1 L10,1 L10,1 C14.9705627,1 19,5.02943725 19,10 L19,10 L19,10 C19,14.9705627 14.9705627,19 10,19 L10,19 L10,19 C5.02943725,19 1,14.9705627 1,10 L1,10 L1,10 C1,5.02943725 5.02943725,1 10,1 L10,1 Z" class="outer"></path>
      </svg>
      <span>Respond Orders</span>
    </label>
    <label for="rdo-3" class="btn-radio">
      <input type="radio" id="rdo-3" name="radio-grp">
      <svg width="20px" height="20px" viewBox="0 0 20 20">
        <circle cx="10" cy="10" r="9"></circle>
        <path d="M10,7 C8.34314575,7 7,8.34314575 7,10 C7,11.6568542 8.34314575,13 10,13 C11.6568542,13 13,11.6568542 13,10 C13,8.34314575 11.6568542,7 10,7 Z" class="inner"></path>
        <path d="M10,1 L10,1 L10,1 C14.9705627,1 19,5.02943725 19,10 L19,10 L19,10 C19,14.9705627 14.9705627,19 10,19 L10,19 L10,19 C5.02943725,19 1,14.9705627 1,10 L1,10 L1,10 C1,5.02943725 5.02943725,1 10,1 L10,1 Z" class="outer"></path>
      </svg>
      <span>Orders</span>
    </label>
  </div>
                                          </form>
                                      </div>
                                    </div>
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <section class="box">
                            <!-- <header class="panel_header">
                                <h2 class="title pull-left">All Orders</h2>
                                <div class="actions panel_actions pull-right">
                                    <i class="box_toggle fa fa-chevron-down"></i>
                                    <i class="box_setting fa fa-cog" data-toggle="modal" href="#section-settings"></i>
                                    <i class="box_close fa fa-times"></i>
                                </div>
                            </header> -->    
                         

                                        <!-- ********************************************** -->

                            <div class="content-body">
                              <div class="row">
                                    <div class="col-md-12 col-sm-12 col-xs-12">
                                        <table id="example" class="display table table-hover table-condensed" cellspacing="0" width="100%">
                                            <thead style="background: #f5f5f5">
                                                <tr>
                                                  <th rowspan="3"><input type="checkbox" name="check"></th>
                                                    <th rowspan="3" class="fs2"><a href="#"><label><i class="fa fa-chevron-right"></i>Status</label></a></th>
                                                    <th rowspan="3" class="fs2">Image</th>
                                                    <th rowspan="3"><a href="#" class="fs2">SKU</a><br>
                                                        <div class="fs1">Condition</div></th>
                                                    <th rowspan="3" style="width: 30%"><a href="#" class="fs2">Product Name</a><br><div class="fs1">ASIN</div> </th>
                                                    <th rowspan="3"><a href="#" class="fs2">Date Created</a><br><div class="fs1">Status Changed date</div></th>
                                                    <th rowspan="3"><a href="#" class="fs2">Available</a></th>
                                                    <th rowspan="3" class="fs2">Fee Preview</th>
                                                    <th rowspan="3"><a href="#" class="fs2">Price</a><br><div class="fs1"><i class="fa fa-caret-right"></i>Postage</div></th>
                                                    <th rowspan="3" class="fs2"> Business Price<br><div class="fs1"><i class="fa fa-caret-right"></i>Postage</div></th>
                                                    <th rowspan="3" class="fs2">Lowest<br> Price<br><div class="fs1"><i class="fa fa-caret-right"></i>Postage</div></th>
                                                </tr>
                                                    <tr></tr>
                                                    <tr></tr>
                                            </thead>

                                            <tbody>
                                            <?php $i = 1; foreach ($results as $result) { ?>
                                                <tr>
                                                <input type="hidden" value="<?= $result->id; ?>">
                                                  <td><input type="checkbox" name="check1"></td><td><label><i class="fa fa-chevron-right"></i>Variations(174)</label></td><td><img style="width: 50px; height: 50px" src="<?= base_url();?>/uploads/<?= $result->image; ?>" alt=""/></td><td><?= $result->sku ?>
                                                     <br>
                                                        <?= $result->cond ?>
                                                    </td><td><a href="#"><?= $result->title; ?></a><br>B07G567F65</td><td>30/08/2018 17:57:27<br>30/08/2018 17:57:27</td><td><?= $result->quantity; ?></td><td></td><td><?= $result->uprice; ?></td><td><a href="#" class="fs2">Add Quantity<br>Dsicounts<td><!-- <?= $result->s_price; ?> --></td><!--  <i class="fa fa-caret-down"> --></i></a></td>
                                                </tr>
                                                <?php } ?>
                                             <!--    <tr>
                                                  <td><input type="checkbox" name="check1"></td><td><label><i class="fa fa-chevron-right"></i>Variations(174)</label></td><td><img style="width: 50px; height: 50px" src="<?= base_url(); ?>/image/cache/catalog/demo/product_04-199x201.jpg" alt="iPod Shuffle"/></td><td>HCBEC-01</td><td><a href="#">H-Cube Furniture Chesterfield Upholstered Tufted Divan Bed Base Headboard Crushed Velvet - Matching/Diamante Buttons</a><br>B07G567F65</td><td>30/08/2018 17:57:27<br>30/08/2018 17:57:27</td><td></td><td>-</td><td></td><td><a href="#" class="fs2">Add Quantity<br>Dsicounts <i class="fa fa-caret-down"></i></a></td><td></td><td><a href="#" class="btn btn-primary" style="float: right;">Edit</a> </td>
                                                </tr> -->
                                                                                         </tbody>
                                        </table>
                                        <!-- ********************************************** -->




                                    </div>
                                </div>
                            </div>
                        </section></div>






                </section>
            </section>
            <!-- END CONTENT -->
            <div class="page-chatapi hideit">

                <div class="search-bar">
                    <input type="text" placeholder="Search" class="form-control">
                </div>

                <div class="chat-wrapper">
                    <h4 class="group-head">Groups</h4>
                    <ul class="group-list list-unstyled">
                        <li class="group-row">
                            <div class="group-status available">
                                <i class="fa fa-circle"></i>
                            </div>
                            <div class="group-info">
                                <h4><a href="#">Work</a></h4>
                            </div>
                        </li>
                        <li class="group-row">
                            <div class="group-status away">
                                <i class="fa fa-circle"></i>
                            </div>
                            <div class="group-info">
                                <h4><a href="#">Friends</a></h4>
                            </div>
                        </li>

                    </ul>


                    <h4 class="group-head">Favourites</h4>
                    <ul class="contact-list">

                        <li class="user-row" id='chat_user_1' data-user-id='1'>
                            <div class="user-img">
                                <a href="#"><img src="data/profile/avatar-1.png" alt=""></a>
                            </div>
                            <div class="user-info">
                                <h4><a href="#">Clarine Vassar</a></h4>
                                <span class="status available" data-status="available"> Available</span>
                            </div>
                            <div class="user-status available">
                                <i class="fa fa-circle"></i>
                            </div>
                        </li>
                        <li class="user-row" id='chat_user_2' data-user-id='2'>
                            <div class="user-img">
                                <a href="#"><img src="data/profile/avatar-2.png" alt=""></a>
                            </div>
                            <div class="user-info">
                                <h4><a href="#">Brooks Latshaw</a></h4>
                                <span class="status away" data-status="away"> Away</span>
                            </div>
                            <div class="user-status away">
                                <i class="fa fa-circle"></i>
                            </div>
                        </li>
                        <li class="user-row" id='chat_user_3' data-user-id='3'>
                            <div class="user-img">
                                <a href="#"><img src="data/profile/avatar-3.png" alt=""></a>
                            </div>
                            <div class="user-info">
                                <h4><a href="#">Clementina Brodeur</a></h4>
                                <span class="status busy" data-status="busy"> Busy</span>
                            </div>
                            <div class="user-status busy">
                                <i class="fa fa-circle"></i>
                            </div>
                        </li>

                    </ul>


                    <h4 class="group-head">More Contacts</h4>
                    <ul class="contact-list">

                        <li class="user-row" id='chat_user_4' data-user-id='4'>
                            <div class="user-img">
                                <a href="#"><img src="data/profile/avatar-4.png" alt=""></a>
                            </div>
                            <div class="user-info">
                                <h4><a href="#">Carri Busey</a></h4>
                                <span class="status offline" data-status="offline"> Offline</span>
                            </div>
                            <div class="user-status offline">
                                <i class="fa fa-circle"></i>
                            </div>
                        </li>
                        <li class="user-row" id='chat_user_5' data-user-id='5'>
                            <div class="user-img">
                                <a href="#"><img src="data/profile/avatar-5.png" alt=""></a>
                            </div>
                            <div class="user-info">
                                <h4><a href="#">Melissa Dock</a></h4>
                                <span class="status offline" data-status="offline"> Offline</span>
                            </div>
                            <div class="user-status offline">
                                <i class="fa fa-circle"></i>
                            </div>
                        </li>
                        <li class="user-row" id='chat_user_6' data-user-id='6'>
                            <div class="user-img">
                                <a href="#"><img src="data/profile/avatar-1.png" alt=""></a>
                            </div>
                            <div class="user-info">
                                <h4><a href="#">Verdell Rea</a></h4>
                                <span class="status available" data-status="available"> Available</span>
                            </div>
                            <div class="user-status available">
                                <i class="fa fa-circle"></i>
                            </div>
                        </li>
                        <li class="user-row" id='chat_user_7' data-user-id='7'>
                            <div class="user-img">
                                <a href="#"><img src="data/profile/avatar-2.png" alt=""></a>
                            </div>
                            <div class="user-info">
                                <h4><a href="#">Linette Lheureux</a></h4>
                                <span class="status busy" data-status="busy"> Busy</span>
                            </div>
                            <div class="user-status busy">
                                <i class="fa fa-circle"></i>
                            </div>
                        </li>
                        <li class="user-row" id='chat_user_8' data-user-id='8'>
                            <div class="user-img">
                                <a href="#"><img src="data/profile/avatar-3.png" alt=""></a>
                            </div>
                            <div class="user-info">
                                <h4><a href="#">Araceli Boatright</a></h4>
                                <span class="status away" data-status="away"> Away</span>
                            </div>
                            <div class="user-status away">
                                <i class="fa fa-circle"></i>
                            </div>
                        </li>
                        <li class="user-row" id='chat_user_9' data-user-id='9'>
                            <div class="user-img">
                                <a href="#"><img src="data/profile/avatar-4.png" alt=""></a>
                            </div>
                            <div class="user-info">
                                <h4><a href="#">Clay Peskin</a></h4>
                                <span class="status busy" data-status="busy"> Busy</span>
                            </div>
                            <div class="user-status busy">
                                <i class="fa fa-circle"></i>
                            </div>
                        </li>
                        <li class="user-row" id='chat_user_10' data-user-id='10'>
                            <div class="user-img">
                                <a href="#"><img src="data/profile/avatar-5.png" alt=""></a>
                            </div>
                            <div class="user-info">
                                <h4><a href="#">Loni Tindall</a></h4>
                                <span class="status away" data-status="away"> Away</span>
                            </div>
                            <div class="user-status away">
                                <i class="fa fa-circle"></i>
                            </div>
                        </li>
                        <li class="user-row" id='chat_user_11' data-user-id='11'>
                            <div class="user-img">
                                <a href="#"><img src="data/profile/avatar-1.png" alt=""></a>
                            </div>
                            <div class="user-info">
                                <h4><a href="#">Tanisha Kimbro</a></h4>
                                <span class="status idle" data-status="idle"> Idle</span>
                            </div>
                            <div class="user-status idle">
                                <i class="fa fa-circle"></i>
                            </div>
                        </li>
                        <li class="user-row" id='chat_user_12' data-user-id='12'>
                            <div class="user-img">
                                <a href="#"><img src="data/profile/avatar-2.png" alt=""></a>
                            </div>
                            <div class="user-info">
                                <h4><a href="#">Jovita Tisdale</a></h4>
                                <span class="status idle" data-status="idle"> Idle</span>
                            </div>
                            <div class="user-status idle">
                                <i class="fa fa-circle"></i>
                            </div>
                        </li>

                    </ul>
                </div>

            </div>


            <div class="chatapi-windows ">


            </div>    </div>
          </div>
          <!-- /row --> 
      </div>
      <!-- /container --> 
    </div>
    <!-- /main-inner --> 
</div>
<!-- /main -->





<div class="footer">
  <div class="footer-inner">
    <div class="container">
      <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"> &copy; 2018 <a href="#">Carrovan By IlegendTech</a>. </div>
        <!-- /span12 --> 
      </div>
      <!-- /row --> 
    </div>
    <!-- /container --> 
  </div>
  <!-- /footer-inner --> 
</div>
<!-- /footer --> 
<!-- Le javascript
================================================== --> 
<!-- Placed at the end of the document so the pages load faster --> 
<script src="<?= base_url(); ?>assets/js/jquery-1.7.2.min.js"></script> 
<script src="<?= base_url(); ?>assets/js/excanvas.min.js"></script> 
<script src="<?= base_url(); ?>assets/js/chart.min.js" type="text/javascript"></script> 
<script src="<?= base_url(); ?>assets/js/bootstrap.js"></script>
<script language="javascript" type="text/javascript" src="<?= base_url(); ?>assets/js/full-calendar/fullcalendar.min.js"></script>
 
<script src="<?= base_url(); ?>assets/js/base.js"></script>

  <!-- OTHER SCRIPTS INCLUDED ON THIS PAGE - START --> 
        <script src="<?= base_url(); ?>assets/data/js/jquery.dataTables.min.js" type="text/javascript"></script>
        <script src="<?= base_url(); ?>assets/data/js/dataTables.tableTools.min.js" type="text/javascript"></script>
        <script src="<?= base_url(); ?>assets/data/js/dataTables.responsive.min.js" type="text/javascript"></script>
        <script src="<?= base_url(); ?>assets/data/js/dataTables.bootstrap.js" type="text/javascript"></script><!-- OTHER SCRIPTS INCLUDED ON THIS PAGE - END --> 


        <!-- CORE TEMPLATE JS - START --> 
        <script src="<?= base_url(); ?>assets/data/js/scripts.js" type="text/javascript"></script> 
        <!-- END CORE TEMPLATE JS - END --> 

        <!-- CORE JS FRAMEWORK - START --> 
        <script src="<?= base_url(); ?>assets/data/js/jquery-1.11.2.min.js" type="text/javascript"></script> 
        <script src="<?= base_url(); ?>assets/data/js/jquery.easing.min.js" type="text/javascript"></script> 
        <script src="<?= base_url(); ?>assets/data/js/bootstrap.min.js" type="text/javascript"></script>  
        <script src="<?= base_url(); ?>assets/data/perfect-scrollbar/perfect-scrollbar.min.js" type="text/javascript"></script> 
        <script src="<?= base_url(); ?>assets/data/js/viewportchecker.js" type="text/javascript"></script>  
        <!-- CORE JS FRAMEWORK - END --> 

<script>     

        var lineChartData = {
            labels: ["January", "February", "March", "April", "May", "June", "July"],
            datasets: [
        {
            fillColor: "rgba(220,220,220,0.5)",
            strokeColor: "rgba(220,220,220,1)",
            pointColor: "rgba(220,220,220,1)",
            pointStrokeColor: "#fff",
            data: [65, 59, 90, 81, 56, 55, 40]
        },
        {
            fillColor: "rgba(151,187,205,0.5)",
            strokeColor: "rgba(151,187,205,1)",
            pointColor: "rgba(151,187,205,1)",
            pointStrokeColor: "#fff",
            data: [28, 48, 40, 19, 96, 27, 100]
        }
      ]

        }

        var myLine = new Chart(document.getElementById("area-chart").getContext("2d")).Line(lineChartData);


        var barChartData = {
            labels: ["January", "February", "March", "April", "May", "June", "July"],
            datasets: [
        {
            fillColor: "rgba(220,220,220,0.5)",
            strokeColor: "rgba(220,220,220,1)",
            data: [65, 59, 90, 81, 56, 55, 40]
        },
        {
            fillColor: "rgba(151,187,205,0.5)",
            strokeColor: "rgba(151,187,205,1)",
            data: [28, 48, 40, 19, 96, 27, 100]
        }
      ]

        }    

        $(document).ready(function() {
        var date = new Date();
        var d = date.getDate();
        var m = date.getMonth();
        var y = date.getFullYear();
        var calendar = $('#calendar').fullCalendar({
          header: {
            left: 'prev,next today',
            center: 'title',
            right: 'month,agendaWeek,agendaDay'
          },
          selectable: true,
          selectHelper: true,
          select: function(start, end, allDay) {
            var title = prompt('Event Title:');
            if (title) {
              calendar.fullCalendar('renderEvent',
                {
                  title: title,
                  start: start,
                  end: end,
                  allDay: allDay
                },
                true // make the event "stick"
              );
            }
            calendar.fullCalendar('unselect');
          },
          editable: true,
          events: [
            {
              title: 'All Day Event',
              start: new Date(y, m, 1)
            },
            {
              title: 'Long Event',
              start: new Date(y, m, d+5),
              end: new Date(y, m, d+7)
            },
            {
              id: 999,
              title: 'Repeating Event',
              start: new Date(y, m, d-3, 16, 0),
              allDay: false
            },
            {
              id: 999,
              title: 'Repeating Event',
              start: new Date(y, m, d+4, 16, 0),
              allDay: false
            },
            {
              title: 'Meeting',
              start: new Date(y, m, d, 10, 30),
              allDay: false
            },
            {
              title: 'Lunch',
              start: new Date(y, m, d, 12, 0),
              end: new Date(y, m, d, 14, 0),
              allDay: false
            },
            {
              title: 'Birthday Party',
              start: new Date(y, m, d+1, 19, 0),
              end: new Date(y, m, d+1, 22, 30),
              allDay: false
            },
            {
              title: 'EGrappler.com',
              start: new Date(y, m, 28),
              end: new Date(y, m, 29),
              url: 'http://EGrappler.com/'
            }
          ]
        });
      });
    </script><!-- /Calendar -->

    
<script>

$(function () {
  
  guidely.add ({
    attachTo: '#target-1'
    , anchor: 'top-left'
    , title: 'Guide Title'
    , text: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut.'
  });
  
  guidely.add ({
    attachTo: '#target-2'
    , anchor: 'top-right'
    , title: 'Guide Title'
    , text: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut.'
  });
  
  guidely.add ({
    attachTo: '#target-3'
    , anchor: 'middle-middle'
    , title: 'Guide Title'
    , text: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut.'
  });
  
  guidely.add ({
    attachTo: '#target-4'
    , anchor: 'top-right'
    , title: 'Guide Title'
    , text: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut.'
  });
  
  guidely.init ({ welcome: true, startTrigger: false });


});

</script>


</body>
</html>
