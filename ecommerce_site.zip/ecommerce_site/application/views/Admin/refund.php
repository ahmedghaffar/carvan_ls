<div class="main fs3">
  	<div class="main-inner">
    	<div class="container-fluid">
      		<div class="row">
                        <div class="col-md-12 col-sm-12 col-xs-12">

                        <div class="col-md-9 col-sm-9 col-xs-9">
                              <div class="row">
      			<div class="col-md-12 col-sm-12 col-xs-12">
      				<h1 class="hs1">Refund Order <span class="fs2"><a href="#">Learn more</a></span></h1>
      				<div class="widget widget-nopad">
      					<div class="widget-content">
      						<table class="table" style="width: 100%">
      							<thead style="background: #d5d5d5">
      								<tr>
      									<td><img src="<?= base_url(); ?>/image/cache/catalog/demo/download.jpg" style="width: 100px; height: 100px"></td>
      									<td colspan="2"><a href="#">H-Cube Furniture Thick Padded Divan Bed Base Headboard Turin Fabric Thickness 3 Inches (Approx) With Struts & Fixings (Navy Blue - 4FT6 Double-26) </a><div><b>Return Quantity:</b> 1 | <b>Return Reason:</b> No longer needed</div><div><b>Customer Comment: </b>Too small</div></td>
      									<td colspan="2"><b>Reason for refund:</b><select class="drop">
      										<option>Customer refund</option>
      										<option>Customer refund</option>
      										<option>Customer refund</option>
      										<option>Customer refund</option>
      									</select></td>
      								</tr>
      								<tr>
      									<td></td>
      									<td>Order Amount</td>
      									<td>Prior refund</td>
      									<td>Amount to refund</td>
      									<td><input type="checkbox" name="check">Refund full amount</td>
      								</tr>
      							</thead>
      							<tbody>
      								<tr>
      									<td>Product</td>
      									<td>$56.75</td>
      									<td>$0.00</td>
      									<td><span style="display: inline-flex;"><i class="fa fa-usd" style=" background-color: #d5d5d5; padding: 6px; position: absolute;"></i><input type="text" name="asdf" placeholder="0.00" value="0.00" disabled style="width: 125px; padding-left: 20px"></span></td>
      									<td>Max $53.32</td>
      								</tr>
      								<tr>
      									<td>Product</td>
      									<td>$56.75</td>
      									<td>$0.00</td>
      									<td><span style="display: inline-flex;"><i class="fa fa-usd" style=" background-color: #d5d5d5; padding: 6px; position: absolute;"></i><input type="text" name="asdf" placeholder="0.00" value="0.00" disabled style="width: 125px; padding-left: 20px"></span></td>
      									<td>Max $53.32</td>
      								</tr>
      								<tr>
      									<td>Product</td>
      									<td>$56.75</td>
      									<td>$0.00</td>
      									<td><span style="display: inline-flex;"><i class="fa fa-usd" style=" background-color: #d5d5d5; padding: 6px; position: absolute;"></i><input type="text" name="asdf" placeholder="0.00" value="0.00" disabled style="width: 125px; padding-left: 20px"></span></td>
      									<td>Max $53.32</td>
      								</tr>
      								<tr>
      									<td>Product</td>
      									<td>$56.75</td>
      									<td>$0.00</td>
      									<td><span style="display: inline-flex;"><i class="fa fa-usd" style=" background-color: #d5d5d5; padding: 6px; position: absolute;"></i><input type="text" name="asdf" placeholder="0.00" value="0.00" disabled style="width: 125px; padding-left: 20px"></span></td>
      									<td>Max $53.32</td>
      								</tr>
      								<tr>
      									<td><b>TOTAL</b></td>
      									<td><b>$63.87</b></td>
      									<td><b>$0.00</b></td>
      									<td colspan="2"><b>$0.00</b></td>
      								</tr>
      							</tbody>
      						</table>
      					</div>
      				</div>
                        </div>
                        <div class="col-md-12 col-sm-12 col-xs-12">
                                          <div>
                                          <br>  Note to yourself:
                                          </div><textarea rows="3" style="width: 100%"></textarea>
                        
                  </div>
            </div>
      </div>
                        <div class="col-md-3 col-sm-3 col-xs-12">
                        <div class="col-md-12 col-sm-12 col-xs-12" style="margin-top: 66px">
                              <div class="widget">
                                    <div class="widget-header">
                                          <div class="hs2">&nbsp;&nbsp; RETURN REQUEST SUMMARY</div>
                                    </div>
                                    <div class="widget-content">
                                          <div>Customer: Anne Hutchison</div>
                                          <div>Order ID: <a href="#">205-3452-234234</a></div>
                                          <div><a href="#">Message History</a></div><br>
                                          <div>Ordered: 19 days ago</div>
                                          <div>Requested: 4 days ago</div>
                                    </div>
                              </div>
                        </div>
                        <div class="col-md-12 col-sm-12 col-xs-12" style="margin-top: 20px">
                              <div class="widget">
                                    <div class="widget-header">
                                          <div class="hs2">&nbsp;&nbsp; REFUND SUMMARY</div>
                                    </div>
                                    <div class="widget-content">
                                          <div><b>Ammount to refund:</b> <span style="float: right;"> $0.00</div>
                                          <div><b>Prior refund:</b> <span style="float: right;"> $0.00</div>
                                          <div><b>Refund ammount:</b> <span style="float: right;"> $0.00</div><br>
                                          <div>
                                                Note to the buyer:
                                          </div><textarea rows="3" style="width: 100%"></textarea>
                                    </div>
                              </div>
                              <br>
                                          <a href="#" class="btn btn-primary" style="padding:5px 30px ">Cancel</a>
                                          <a href="#" class="btn btn-primary" style="padding:5px 53px ">Submit refund</a>
                        </div>
                        </div>

      </div>
      	</div>
      </div>
  </div>
