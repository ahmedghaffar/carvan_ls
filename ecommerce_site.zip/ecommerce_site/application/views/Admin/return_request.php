<div class="main fs3">
  	<div class="main-inner">
    	<div class="container-fluid">
      		<div class="row">
        		<div class="col-md-12 col-sm-12 col-xs-12">
              <h1 class="hs1">Deny Request</h1>
          			<div class="widget widget-nopad">
            			<div class="widget-header">
                    <div class="col-md-4 col-sm-4 col-xs-4">
                      <ul style="list-style-type: none;">
                      <li class="fs3">Requested: <span class="fs2">4 days ago</span></li>
                      <li class="fs3">Ordered: <span class="fs2">9 days ago</span></li>
                      </ul>
                    </div>
                    <div class="col-md-4 col-sm-4 col-xs-4">
                      <ul style="list-style-type: none">
                      <li class="fs3">Buyer: <span class="fs2">Anne Hutchison</span></li>
                      <li><a href="#">Communication History</a></li>
                     </ul>
                    </div>
                    <div class="col-md-4 col-sm-4 col-xs-4">
                      <ul style="list-style-type: none">
                      <li class="fs3">Order ID: <span class="fs2"><a href="#">026-9734298-87348</a></span></li>
                      <li class="fs3">RMA: <span class="fs2">RMA will be generated once authorised</span></li>
                      </ul>
                    </div>
                    
            			</div>
            			<!-- /widget-header -->
            			<div class="widget-content">
                    <div class="col-md-3 col-sm-3 col-xs-3">
                      <div class="fs3">Return Reason: <span class="fs2">No longer needed</span></div>
                      <img src="<?= base_url(); ?>/image/cache/catalog/demo/product_12-199x201.jpg" alt="MacBook" class="img-responsive" />
                    </div>
                    <div class="col-md-7 col-sm-7 col-xs-7">
                      <p>H-Cube Furniture Cube Design Divan Bed Base Headboard Turin/Linen Fabric Matching/Buttons - (Grey - 5FT) </p>
                      <div>Return Quantity: <span class="fs2">1</span></div>
                      <div>Buyer Comment: <span class="fs2">Too small</span></div>
                    </div>
                  </div>
                  <div class="hs2">Reason for not authorising this return request</div>
                  <div>
                    <select class="drop">
                      <option>Choose a Reason</option>
                      <option>1</option>
                      <option>2</option>
                      <option>3</option>
                    </select>
                </div>
                <h1 class="hs2">Message to Buyer</h1>
                <p class="fs1">Plain text only. HTML tags not allowed</p>
                <textarea rows="5" style="width: 100%"></textarea>
                <div style="text-align: center; margin-top: 1%">
                  <form>
                  <a href="#" class="btn btn-primary">Cancel</a>
                  <a href="#" class="btn btn-primary">Deny Request</a>
                </form>
                </div>
            </div>
          </div>
      </div>
    </div>
</div>