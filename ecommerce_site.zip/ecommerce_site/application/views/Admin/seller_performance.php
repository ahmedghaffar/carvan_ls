<div class="main fs3">
  	<div class="main-inner">
    	<div class="container-fluid">
      		<div class="row">
			      		
      			<div class="col-md-4 col-sm-4 col-xs-12">
      				<h1 class="hs1">Account Health <span class="fs2"><a href="#">Leave feedback</a></span></h1>
	      			<div class="widget">
	      				<div class="widget-header">
	      					<div class="hs2"  style="margin-left: 5px"> Customer Service Performance</div>
	      				</div>
	      				
			      		<div class="widget-content">
              <table class="table table-striped">
                <thead>
                  <tr>
                    <th> </th>
                    <th>Seller Fullfiled</th>
                    <th>Carrovan's Fullfilled </th>
                  </tr>
                </thead>
                <tbody>
                  <tr style="background: #d5d5d5">
                    <td> <div class="hs2">Order Defect Rate</div>
			      				<div class="fs1">Target<span class="fs3">Under 1%</span> </div> </td>
                    <td> <div class="hs2">0.7%</div><div>1 of 43 orders</div><div>90 days</div> </td>
                    <td>N/A</td>
                  </tr>
                  <tr>
                    <td class="fs2" colspan="3"> Order Defect Rate consists of three different metrices:</td>
                  </tr>
                  <tr>
                    <td><ul>
                    	<li><a href="#">Negative Feedback</a></li>
                    </ul></td>
                    <td><div class="hs2">0%</div><div>0 of 43 orders</div></td>
                    <td>N/A</td>
                  </tr>
                  <tr>
                    <td><ul>
                    	<li><a href="#">A-Z Guarentee claims</a></li>
                    </ul></td>
                    <td><div class="hs2">0.7%%</div><div>1 of 43 orders</div></td>
                    <td>N/A</td>
                  </tr>
                  <tr>
                    <td><ul>
                    	<li><a href="#">Charge Back Claims</a></li>
                    </ul></td>
                    <td><div class="hs2">0%</div><div>0 of 43 orders</div></td>
                    <td>N/A</td>
                  </tr>
                 
                
                </tbody>
              </table>

               <br><br><hr>
              <div style="text-align: center;">
              <a href="#">View details</a>
          </div>
            </div>
			      		
		      		</div> <!-- /widget-content -->
		      		
	      		</div> <!-- /widget -->
	      		
      		    		
      			<div class="col-md-4 col-sm-4 col-xs-12" style="margin-top: 67px">
	      			<div class="widget">
	      				<div class="widget-header">
	      					<div class="hs2" style="margin-left: 5px"> Product Policy Compliance</div>
	      				</div>
	      				
			      		<div class="widget-content">
              <table class="table table-striped">
                <thead>
                  <tr>
                  	<th></th>
                    <th colspan="2" style="float: right;">Fullfilled by Seller and Carrovan</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td><a href="#">Antilectual property complaints</a><div class="fs1">Target<span class="fs3">0 compliants</span> </div></td>
                    <td>  </td>
                    <td>0</td>
                  </tr>
                  <tr>
                    <td><a href="#">Antilectual property complaints</a><div class="fs1">Target<span class="fs3">0 compliants</span> </div></td>
                    <td>  </td>
                    <td>0</td>
                  </tr><tr>
                    <td><a href="#">Antilectual property complaints</a><div class="fs1">Target<span class="fs3">0 compliants</span> </div></td>
                    <td>  </td>
                    <td>0</td>
                  </tr><tr>
                    <td><a href="#">Antilectual property complaints</a><div class="fs1">Target<span class="fs3">0 compliants</span> </div></td>
                    <td>  </td>
                    <td>0</td>
                  </tr>
                 
                
                </tbody>
              </table>

               <br><br><hr>
              <div style="text-align: center;">
              <a href="#">View details</a>
          </div>
            </div>
			      		
		      		</div> <!-- /widget-content -->
		      		
	      		</div> <!-- /widget -->
	      		
      		    		
      			<div class="col-md-4 col-sm-4 col-xs-12" style="margin-top: 67px">
	      			<div class="widget">
	      				<div class="widget-header">
	      					<div class="hs2" style="margin-left: 5px"> Delivery Performance</div>
	      				</div>
	      				
			      		<div class="widget-content">
              <table class="table table-striped">
                <thead>
                   <tr>
                  	<th></th><th></th>
                    <th colspan="2" style="float: right;">Seller fullfilled</th>
                  </tr>
                </thead>
             
                <tbody>
                  <tr>
                    <td><a href="#">Late Dispatch Rate</a><div class="fs1">Target<span class="fs3">under 4%</span> </div></td>
                    <td>  </td><td>  </td>
                    <td><div class="hs2">4.08%</div><div>2 of 49 orders</div><div>10 days</div> </td>
                  </tr>
                  <tr>
                    <td><a href="#">Late Dispatch Rate</a><div class="fs1">Target<span class="fs3">under 4%</span> </div></td>
                    <td>  </td><td>  </td>
                    <td><div class="hs2">4.08%</div><div>2 of 49 orders</div><div>10 days</div> </td>
                  </tr><tr>
                    <td>  </td>
                    <td>  </td>
                    <td colspan="3"><a href="#">View delivery eligibilities here</a></td>
                  </tr>
                 
                
                </tbody>
              </table>

              <br><br><hr>
              <div style="text-align: center;">
              <a href="#">View details</a>
          </div>
            </div>
			      		
		      		</div> <!-- /widget-content -->
		      		
	      		</div> <!-- /widget -->
	      		
      		


      		</div>
      	</div>
    </div>
</div>