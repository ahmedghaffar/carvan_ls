<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Carrovan</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="apple-mobile-web-app-capable" content="yes">
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/bootstrap-responsive.min.css" rel="stylesheet">
<link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600"
        rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="css/font-awesome.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link href="css/pages/bootstrap.css" rel="stylesheet">

<link href="css/custom.min.css" rel="stylesheet">
<link href="css/pages/dashboard.css" rel="stylesheet">
<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->


</head>
<body>

    <div class="navbar navbar-fixed-top">
  <div class="navbar-inner">
    <div class="container">
                   <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse"><span
                    class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span> </a><a class="brand" href="index.php">CARROVAN </a>
      <!-- <ul class="nav" style="margin-left: 20%; transform: translateX(30%);">
            <li><a href="#" style="font-size: 18px">MarketPlace</a></li>
        </ul> -->
      <span>
        <div class="dropdown market">
  <button class="dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    MarketPlace
  </button>
  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
    <a class="dropdown-item" href="#">United Kingdom</a>
    <a class="dropdown-item" href="#">Dubae</a>
    <a class="dropdown-item" href="#">Pakistan</a>
  </div>
</div>
</span>
        <div class="nav-collapse">
        <ul class="nav pull-right">
          <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown"><i
                            class="icon-cog"></i> Account <b class="caret"></b></a>
            <ul class="dropdown-menu">
              <li><a href="javascript:;">Settings</a></li>
              <li><a href="javascript:;">Help</a></li>
            </ul>
          </li>
          <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown"><i
                            class="icon-user"></i> Kamran <b class="caret"></b></a>
            <ul class="dropdown-menu">
              <li><a href="javascript:;">Profile</a></li>
              <li><a href="javascript:;">Logout</a></li>
            </ul>
          </li>
        </ul>
        <form class="navbar-search pull-right">
          <input type="text" class="search-query" placeholder="Search">
        </form>
      </div>
      <!--/.nav-collapse --> 
    </div>
    <!-- /container --> 
  </div>
  <!-- /navbar-inner --> 
</div>
<!-- /navbar -->
<div class="subnavbar">
  <div class="subnavbar-inner">
    <div class="container">
      <ul class="mainnav">
        <li class="active"><a href="index.php"><span>Dashboard</span> </a> </li>
        <li class="dropdown">         
      <a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown">
        <span>Employee</span>
        <b class="caret"></b>
      </a>  
      <ul class="dropdown-menu">
                <li><a href="add_employee.php">Add Employee</a></li>
        <li><a href="manage_employee.php">All Employee</a></li>
            </ul>           
    </li>
    <li class="dropdown">         
      <a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown">
        <span>Supplier</span>
        <b class="caret"></b>
      </a>  
      <ul class="dropdown-menu">
                <li><a href="add_suppliers.php">Add Supplier</a></li>
        <li><a href="manage_suppliers.php">All Supplier</a></li>
            </ul>           
    </li>
        <li><a href="msg.php"><span>Messages</span> </a> </li>
        <li><a href="Inventory.php"><span>Inventory</span> </a> </li>
        <li><a href="reports.php"><span>Reports</span> </a></li>
        <li><a href="orders.php"><span style="margin-top: 28%">Performance</span> </a> </li>
        <li><a href="products.php"><span>Store</span> </a> </li>
        <!-- <li class="dropdown"><a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown"> <i class="icon-long-arrow-down"></i><span>MarketPlace</span> <b class="caret"></b></a>
          <ul class="dropdown-menu">
            <li><a href="#">United Kingdom</a></li>
            <li><a href="#">United Arab Emirates</a></li>
            <li><a href="#">Pakistan</a></li>
            <li><a href="#">America</a></li>
            <li><a href="#">China</a></li>
            <li><a href="#">India</a></li>
          </ul>
        </li> -->
      </ul>
    </div>
    <!-- /container --> 
  </div>
  <!-- /subnavbar-inner --> 
</div>



<div class="main">
  	<div class="main-inner">
    	<div class="container-fluid">


        		<div class="right_col" role="main">
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3>All Suppliers</h3>
            </div>
        </div>
        <div class="clearfix"></div>
        <hr>
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_title">
                        <h2>Add a new Suppliers</h2>
                        <ul class="nav navbar-right panel_toolbox">
                            <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                            <li><a class="close-link"><i class="fa fa-close"></i></a></li>
                        </ul>
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                        <form method="post">
                            <fieldset>
                                <div class="form-group">
                                    Email : <input class="form-control" placeholder="E-mail" name="u_email" id="username" type="email" onBlur="checkAvailability()" ><span id="user-availability-status"></span>
                                </div>
                                <div class="form-group">
                                    Password : <input class="form-control" placeholder="Password" name="u_pass" type="password" >
                                </div>
                                <div class="form-group">
                                    First Name : <input class="form-control" placeholder="First Name" name="f_name" type="text"  >
                                </div>
                                <div class="form-group">
                                    Last Name : <input class="form-control" placeholder="Last Name" name="l_name" type="text" >
                                </div>
                                <div class="form-group">
                                    Mobile : <input class="form-control" placeholder="Mobile" name="u_mobile" type="number"  >
                                </div>
                                <div class="form-group">
                                    Position : <input class="form-control" placeholder="Position" name="u_position" type="text" >
                                </div>
                                <div class="form-group">
                                    Gender : <input type="radio" name="u_gender" value="male"> Male
                                    <input type="radio" name="u_gender" value="female"> Female
                                </div>
                                <div class="form-group">
                                    Date of Birth:<input type="date" name="u_bday">
                                </div>
                                <div class="form-group">
                                    Address: <textarea rows="3" cols="10" class="form-control"  name="u_address"></textarea>
                                </div>
                                <div class="form-group">
                                    User Type:
                                    <input type="radio" name="u_type" value="admin"> Admin
                                    <input type="radio" name="u_type" value="employee"> Employee
                                    <input type="radio" name="u_type" value="employee"> Drivers
                                </div>
                                <br/>
                                <input type="submit" name="buttonSubmit" value="Comfirm" class="btn btn-success" />
                            </fieldset>
                        </form>
                    </div> <!-- /content --> 
                </div><!-- /x-panel --> 
            </div> <!-- /col -->
    </div>
</div> 
      		</div>
      		<!-- /row --> 
    	</div>
    	<!-- /container --> 
  	</div>
  	<!-- /main-inner --> 
</div>


<!-- Le javascript
================================================== --> 

<script>
      $(document).ready(function(){
        $('.dropdown-submenu a.test').on("click", function(e){
          $(this).next('ul').toggle();
          e.stopPropagation();
          e.preventDefault();
        });
    });
</script>

<!-- Placed at the end of the document so the pages load faster --> 
<script src="js/jquery-1.7.2.min.js"></script> 
<script src="js/excanvas.min.js"></script> 
<script src="js/chart.min.js" type="text/javascript"></script> 
<script src="js/bootstrap.js"></script>
<script language="javascript" type="text/javascript" src="js/full-calendar/fullcalendar.min.js"></script>
 
<script src="js/base.js"></script> 

</body>
</html>
