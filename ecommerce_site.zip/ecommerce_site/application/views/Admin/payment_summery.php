<div class="main fs3">
  	<div class="main-inner">
    	<div class="container-fluid">
      		<div class="row">
        		<div class="col-md-12 col-sm-12 col-xs-12">
          			<h1 class="hs1">Payment Summary</h1>
          			<div class="widget widget-nopad">
          				<div class="widget-header">
              				<div class="fs2" style="margin: 0 10px">Total Balance <span class="hs2" style="float: right;">$4,649.44</span></div>
            			</div>
            		</div>
           		</div>
          	</div><br>

            <div class="row">
              <div class="col-md-6 col-sm-6 col-xs-12">
                <hr>
                <div>Available balance<span style="float: right; color: rgba(31, 181, 172, 1);">$4,649.44</span></div>
                <hr>
              </div>

              <div class="col-md-6 col-sm-6 col-xs-12">
                <hr>
                <div class="fs2">Next payment</div>
                <div class="fs3">12 Oct 2018<span style="float: right; color: rgba(31, 181, 172, 1);">$4,649.44</span></div>
                <hr><br>
                <hr>
                <div class="fs2">Most recent payment</div>
                <div class="fs3">28 Sep 2018<span style="float: right; color: rgba(31, 181, 172, 1);">$55.96</span></div>
                <hr>
              </div>
            </div>

        </div>
    </div>
</div>
