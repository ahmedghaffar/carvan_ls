<div class="main">
  <div class="main-inner">
   	<div class="container-fluid">
       <h1 class="hs1">Cancel order</h1>
          <p class="hs2">Order ID: #<span class="fs2"><a href="#"> 2057746509-0566748</a></span></p>
     	<div class="row">
     		<div class="span9 col-md-9 col-sm-9 col-xs-12">
     			<div class="widget">
            <div class="widget-header"> 
              <div class="col-md-2 col-sm-2 col-xs-4">Quantity Ordered</div>
              <div class=" col-md-10 col-sm-10 col-xs-4">Product Details</div>
            
            </div>
            <!-- /widget-header -->
            <div class="widget-content">
               <div class="row">
              <div class="col-md-2 col-sm-2 col-xs-2"><p style="text-align: center;"> 1</p></div>
              <div class="col-md-10 col-sm-10 col-xs-10">H-Cube Furniture Cube Design Divan Bed Base Headboard Turin/Linen Fabric Matching/Buttons - (Grey - 5FT) 
                <div class="row">
                  <div class="col-md-2 col-sm-2 col-xs-4">
                <img src="<?= base_url(); ?>/image/cache/catalog/demo/product_06-80x82.jpg" alt="iPhone" class="img-responsive" /></div>
                  <div class="col-md-4 col-sm-4 col-xs-8">
                  <div class="fs3">SKU: <span class="fs2">HSHB-CCV-309</span></div>
                  <div class="fs3">ASIN: <span class="fs2">B0799405W261</span></div>
                  <div class="fs3">Condition: <span class="fs2">New</span></div>
                  <div class="fs3"><a href="#"><u>Show more</u></a></div>
                </div>
              </div>
                </div>
              </div>
              </div>
            </div>
     		 </div>
        <div class="span3 col-md-3 col-sm-3 col-xs-12">
          <div class="widget">
            <div class="widget-header">
              <div class="col-md-12"> Reason for Cancellation:</div>
            </div>
            <div class="widget-content">
              <select class="drop">
                <option>Select reason for cancel</option>
                <option>Reason1</option>
                <option>Reason2</option>
                <option>Reason3</option>
                <option>Reason4</option>
              </select>
              <div style="margin: 8%; float: right;"><a href="#" class="btn btn-primary">Cancel Order</a></div>
            </div>
          </div>
        </div>
      </div>

      <div class="row">
        <div class="span9 col-md-9 col-sm-9 col-xs-12">
          <h1 class="hs1">Seller Notes</h1>
          <div class="fs1">For your records only, will not be displayed to the buyer</h1>
          <textarea rows="5" style="width: 100%"></textarea>
          <div class="fs3" style="margin-top: 1%; float: right;"><a href="#" class="btn btn-primary">Save</a></div>
        </div>
      </div>
    </div>
  </div>
</div>