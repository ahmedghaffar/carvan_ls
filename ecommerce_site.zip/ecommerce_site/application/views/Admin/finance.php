<!DOCTYPE html>
<html lang="en" style="min-height: 100% !important; position: relative !important; ">
<head>
<meta charset="utf-8">
<title>Carrovan</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="apple-mobile-web-app-capable" content="yes">
<link href="<?= base_url(); ?>assets/css/bootstrap.min.css" rel="stylesheet">
<link href="<?= base_url(); ?>assets/css/bootstrap-responsive.min.css" rel="stylesheet">
<link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600"
        rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="<?= base_url(); ?>assets/css/font-awesome.css" rel="stylesheet">
<link href="<?= base_url(); ?>assets/css/style.css" rel="stylesheet">
<link href="<?= base_url(); ?>assets/css/pages/dashboard.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?= base_url(); ?>assets/data/style.css">
<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
<!-- OTHER SCRIPTS INCLUDED ON THIS PAGE - START --> 
        <link href="<?= base_url(); ?>assets/data/jquery.dataTables.css" rel="stylesheet" type="text/css" media="screen"/>
        <link href="<?= base_url(); ?>assets/data/dataTables.tableTools.min.css" rel="stylesheet" type="text/css" media="screen"/>
        <link href="<?= base_url(); ?>assets/data/dataTables.responsive.css" rel="stylesheet" type="text/css" media="screen"/>
        <link href="<?= base_url(); ?>assets/data/dataTables.bootstrap.css" rel="stylesheet" type="text/css" media="screen"/>       
         <!-- OTHER SCRIPTS INCLUDED ON THIS PAGE - END --> 

    <!-- CORE CSS FRAMEWORK - START -->
        <link href="<?= base_url(); ?>assets/data/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="<?= base_url(); ?>assets/data/font-awesome.css" rel="stylesheet" type="text/css"/>
        <link href="<?= base_url(); ?>assets/data/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" type="text/css"/>
        <!-- CORE CSS FRAMEWORK - END -->

    <link href="<?= base_url(); ?>assets/js/guidely/guidely.css" rel="stylesheet"> 



    <style type="text/css">
      @media (min-width:768px){
      #msform{
      width: 70% !important;
      margin-left: 15% !important;
    }
  }
  /*---------------radio button--------------*/


.btn-radio {
  cursor: pointer;
  display: inline-block;
  float: left;
  -webkit-user-select: none;
  user-select: none;
}
.btn-radio:not(:first-child) {
  margin-left: 20px;
}
@media screen and (max-width: 480px) {
  .btn-radio {
    display: block;
    float: none;
  }
  .btn-radio:not(:first-child) {
    margin-left: 0;
    margin-top: 15px;
  }
}
.btn-radio svg {
  fill: none;
  vertical-align: middle;
}
.btn-radio svg circle {
  stroke-width: 2;
  stroke: #C8CCD4;
}
.btn-radio svg path {
  stroke: #008FFF;
}
.btn-radio svg path.inner {
  stroke-width: 6;
  stroke-dasharray: 19;
  stroke-dashoffset: 19;
}
.btn-radio svg path.outer {
  stroke-width: 2;
  stroke-dasharray: 57;
  stroke-dashoffset: 57;
}
.btn-radio input {
  display: none;
}
.btn-radio input:checked + svg path {
  transition: all 0.2s ease;
}
.btn-radio input:checked + svg path.inner {
  stroke-dashoffset: 38;
  transition-delay: 0.1s;
}
.btn-radio input:checked + svg path.outer {
  stroke-dashoffset: 0;
}
.btn-radio span {
  display: inline-block;
  vertical-align: middle;
}


/*---------------radio button--------------*/

.drop button{
  background-color: #fed007;
  border: 0px;
  font-size: 16px;
  padding: 15px 25px;
  color: white;
  font-family: calibri;

}

    </style>
</head>
<body>
<div class="navbar">
  <div class="navbar-inner">
    <div class="container">
                   <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse"><span
                    class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span> </a><a class="brand" href="index.php">Carrovan</a>
      <!-- <ul class="nav" style="margin-left: 20%; transform: translateX(30%);">
            <li><a href="#" style="font-size: 18px">MarketPlace</a></li>
        </ul> -->
<!--       <span>
        <div class="dropdown market">
  <button class="dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    MarketPlace
  </button> 
  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
    <a class="dropdown-item" href="#">United Kingdom</a>
    <a class="dropdown-item" href="#">Dubae</a>
    <a class="dropdown-item" href="#">Pakistan</a>
  </div>
</div>
</span> -->
        <div class="nav-collapse">
        <ul class="nav pull-right">
          <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown"><i
                            class="icon-cog"></i> Account <b class="caret"></b></a>
            <ul class="dropdown-menu">
              <li><a href="javascript:;">Settings</a></li>
              <li><a href="javascript:;">Help</a></li>
            </ul>
          </li>
          <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown"><i
                            class="icon-user"></i> Kamran <b class="caret"></b></a>
            <ul class="dropdown-menu">
              <li><a href="javascript:;">Profile</a></li>
              <li><a href="javascript:;">Logout</a></li>
            </ul>
          </li>
        </ul>
        <form class="navbar-search pull-right">
          <input type="text" class="search-query" placeholder="Search">
        </form>
      </div>
      <!--/.nav-collapse --> 
    </div>
    <!-- /container --> 
  </div>
  <!-- /navbar-inner --> 
</div>
<!-- /navbar -->
<div class="subnavbar">
  <div class="subnavbar-inner">
    <div class="container">
      <ul class="mainnav">
        <li class="active"><a href="finance"><span>Finance</span> </a> </li>
        <li><a href="msg"><span>Messages</span> </a> </li><!-- 
        <li><a href="mang_orders"><span>Inventory</span> </a> </li> -->
        <li class="dropdown"><a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown"><span>Inventory</span> <b class="caret"></b></a>
          <ul class="dropdown-menu">
            <li><a href="inventory_read">Manage Inventory</a></li>
            <li><a href="#">Inventory Planning</a></li>
            <li><a href="#">Add a Product</a></li>
            <li><a href="#">Add Products via Upload</a></li>
            <li><a href="#">Inventory Reports</a></li>
            <li><a href="#">Manage Promotions</a></li>
          </ul>
        </li>
        <li><a href="business_report"><span>Reports</span> </a></li><!-- 
        <li><a href="seller_performance"><span style="margin-top: 31%">Performance</span> </a> </li> -->
        <li><a href="order_read"><span>Orders</span> </a> </li>
      </ul>
    </div>
    <!-- /container --> 
  </div>
  <!-- /subnavbar-inner --> 
</div>
<!-- /subnavbar -->
<div class="main fs3">
    <div class="main-inner">
      <div class="container-fluid">
          <div class="row">
                
            <div class="col-md-4 col-sm-4 col-xs-12">
              <h1 class="hs1">Account Health <span class="fs2"><a href="#">Leave feedback</a></span></h1>
              <div class="widget">
                <div class="widget-header">
                  <div class="hs2"  style="margin-left: 5px"> Customer Service Performance</div>
                </div>
                
                <div class="widget-content">
              <table class="table table-striped">
                <thead>
                  <tr>
                    <th> </th>
                    <th>Seller Fullfiled</th>
                    <th>Carrovan's Fullfilled </th>
                  </tr>
                </thead>
                <tbody>
                  <tr style="background: #d5d5d5">
                    <td> <div class="hs2">Order Defect Rate</div>
                    <div class="fs1">Target<span class="fs3">Under 1%</span> </div> </td>
                    <td> <div class="hs2">0.7%</div><div>1 of 43 orders</div><div>90 days</div> </td>
                    <td>N/A</td>
                  </tr>
                  <tr>
                    <td class="fs2" colspan="3"> Order Defect Rate consists of three different metrices:</td>
                  </tr>
                  <tr>
                    <td><ul>
                      <li><a href="#">Negative Feedback</a></li>
                    </ul></td>
                    <td><div class="hs2">0%</div><div>0 of 43 orders</div></td>
                    <td>N/A</td>
                  </tr>
                  <tr>
                    <td><ul>
                      <li><a href="#">A-Z Guarentee claims</a></li>
                    </ul></td>
                    <td><div class="hs2">0.7%%</div><div>1 of 43 orders</div></td>
                    <td>N/A</td>
                  </tr>
                  <tr>
                    <td><ul>
                      <li><a href="#">Charge Back Claims</a></li>
                    </ul></td>
                    <td><div class="hs2">0%</div><div>0 of 43 orders</div></td>
                    <td>N/A</td>
                  </tr>
                 
                
                </tbody>
              </table>

               <br><br><hr>
              <div style="text-align: center;">
              <a href="#">View details</a>
          </div>
            </div>
                
              </div> <!-- /widget-content -->
              
            </div> <!-- /widget -->
            
                  
            <div class="col-md-4 col-sm-4 col-xs-12" style="margin-top: 67px">
              <div class="widget">
                <div class="widget-header">
                  <div class="hs2" style="margin-left: 5px"> Product Policy Compliance</div>
                </div>
                
                <div class="widget-content">
              <table class="table table-striped">
                <thead>
                  <tr>
                    <th></th>
                    <th colspan="2" style="float: right;">Fullfilled by Seller and Carrovan</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td><a href="#">Antilectual property complaints</a><div class="fs1">Target<span class="fs3">0 compliants</span> </div></td>
                    <td>  </td>
                    <td>0</td>
                  </tr>
                  <tr>
                    <td><a href="#">Antilectual property complaints</a><div class="fs1">Target<span class="fs3">0 compliants</span> </div></td>
                    <td>  </td>
                    <td>0</td>
                  </tr><tr>
                    <td><a href="#">Antilectual property complaints</a><div class="fs1">Target<span class="fs3">0 compliants</span> </div></td>
                    <td>  </td>
                    <td>0</td>
                  </tr><tr>
                    <td><a href="#">Antilectual property complaints</a><div class="fs1">Target<span class="fs3">0 compliants</span> </div></td>
                    <td>  </td>
                    <td>0</td>
                  </tr>
                 
                
                </tbody>
              </table>

               <br><br><hr>
              <div style="text-align: center;">
              <a href="#">View details</a>
          </div>
            </div>
                
              </div> <!-- /widget-content -->
              
            </div> <!-- /widget -->
            
                  
            <div class="col-md-4 col-sm-4 col-xs-12" style="margin-top: 67px">
              <div class="widget">
                <div class="widget-header">
                  <div class="hs2" style="margin-left: 5px"> Delivery Performance</div>
                </div>
                
                <div class="widget-content">
              <table class="table table-striped">
                <thead>
                   <tr>
                    <th></th><th></th>
                    <th colspan="2" style="float: right;">Seller fullfilled</th>
                  </tr>
                </thead>
             
                <tbody>
                  <tr>
                    <td><a href="#">Late Dispatch Rate</a><div class="fs1">Target<span class="fs3">under 4%</span> </div></td>
                    <td>  </td><td>  </td>
                    <td><div class="hs2">4.08%</div><div>2 of 49 orders</div><div>10 days</div> </td>
                  </tr>
                  <tr>
                    <td><a href="#">Late Dispatch Rate</a><div class="fs1">Target<span class="fs3">under 4%</span> </div></td>
                    <td>  </td><td>  </td>
                    <td><div class="hs2">4.08%</div><div>2 of 49 orders</div><div>10 days</div> </td>
                  </tr><tr>
                    <td>  </td>
                    <td>  </td>
                    <td colspan="3"><a href="#">View delivery eligibilities here</a></td>
                  </tr>
                 
                
                </tbody>
              </table>

              <br><br><hr>
              <div style="text-align: center;">
              <a href="#">View details</a>
          </div>
            </div>
                
              </div> <!-- /widget-content -->
              
            </div> <!-- /widget -->
            
          


          </div>
        </div>
    </div>
</div>

<div class="footer">
  <div class="footer-inner">
    <div class="container">
      <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"> &copy; 2018 <a href="#">Carrovan By IlegendTech</a>. </div>
        <!-- /span12 --> 
      </div>
      <!-- /row --> 
    </div>
    <!-- /container --> 
  </div>
  <!-- /footer-inner --> 
</div>
<!-- /footer --> 
<!-- Le javascript
================================================== --> 
<!-- Placed at the end of the document so the pages load faster --> 
<script src="<?= base_url(); ?>assets/js/jquery-1.7.2.min.js"></script> 
<script src="<?= base_url(); ?>assets/js/excanvas.min.js"></script> 
<script src="<?= base_url(); ?>assets/js/chart.min.js" type="text/javascript"></script> 
<script src="<?= base_url(); ?>assets/js/bootstrap.js"></script>
<script language="javascript" type="text/javascript" src="<?= base_url(); ?>assets/js/full-calendar/fullcalendar.min.js"></script>
 
<script src="<?= base_url(); ?>assets/js/base.js"></script>

  <!-- OTHER SCRIPTS INCLUDED ON THIS PAGE - START --> 
        <script src="<?= base_url(); ?>assets/data/js/jquery.dataTables.min.js" type="text/javascript"></script>
        <script src="<?= base_url(); ?>assets/data/js/dataTables.tableTools.min.js" type="text/javascript"></script>
        <script src="<?= base_url(); ?>assets/data/js/dataTables.responsive.min.js" type="text/javascript"></script>
        <script src="<?= base_url(); ?>assets/data/js/dataTables.bootstrap.js" type="text/javascript"></script><!-- OTHER SCRIPTS INCLUDED ON THIS PAGE - END --> 


        <!-- CORE TEMPLATE JS - START --> 
        <script src="<?= base_url(); ?>assets/data/js/scripts.js" type="text/javascript"></script> 
        <!-- END CORE TEMPLATE JS - END --> 

        <!-- CORE JS FRAMEWORK - START --> 
        <script src="<?= base_url(); ?>assets/data/js/jquery-1.11.2.min.js" type="text/javascript"></script> 
        <script src="<?= base_url(); ?>assets/data/js/jquery.easing.min.js" type="text/javascript"></script> 
        <script src="<?= base_url(); ?>assets/data/js/bootstrap.min.js" type="text/javascript"></script>  
        <script src="<?= base_url(); ?>assets/data/perfect-scrollbar/perfect-scrollbar.min.js" type="text/javascript"></script> 
        <script src="<?= base_url(); ?>assets/data/js/viewportchecker.js" type="text/javascript"></script>  
        <!-- CORE JS FRAMEWORK - END --> 

<script>     

        var lineChartData = {
            labels: ["January", "February", "March", "April", "May", "June", "July"],
            datasets: [
        {
            fillColor: "rgba(220,220,220,0.5)",
            strokeColor: "rgba(220,220,220,1)",
            pointColor: "rgba(220,220,220,1)",
            pointStrokeColor: "#fff",
            data: [65, 59, 90, 81, 56, 55, 40]
        },
        {
            fillColor: "rgba(151,187,205,0.5)",
            strokeColor: "rgba(151,187,205,1)",
            pointColor: "rgba(151,187,205,1)",
            pointStrokeColor: "#fff",
            data: [28, 48, 40, 19, 96, 27, 100]
        }
      ]

        }

        var myLine = new Chart(document.getElementById("area-chart").getContext("2d")).Line(lineChartData);


        var barChartData = {
            labels: ["January", "February", "March", "April", "May", "June", "July"],
            datasets: [
        {
            fillColor: "rgba(220,220,220,0.5)",
            strokeColor: "rgba(220,220,220,1)",
            data: [65, 59, 90, 81, 56, 55, 40]
        },
        {
            fillColor: "rgba(151,187,205,0.5)",
            strokeColor: "rgba(151,187,205,1)",
            data: [28, 48, 40, 19, 96, 27, 100]
        }
      ]

        }    

        $(document).ready(function() {
        var date = new Date();
        var d = date.getDate();
        var m = date.getMonth();
        var y = date.getFullYear();
        var calendar = $('#calendar').fullCalendar({
          header: {
            left: 'prev,next today',
            center: 'title',
            right: 'month,agendaWeek,agendaDay'
          },
          selectable: true,
          selectHelper: true,
          select: function(start, end, allDay) {
            var title = prompt('Event Title:');
            if (title) {
              calendar.fullCalendar('renderEvent',
                {
                  title: title,
                  start: start,
                  end: end,
                  allDay: allDay
                },
                true // make the event "stick"
              );
            }
            calendar.fullCalendar('unselect');
          },
          editable: true,
          events: [
            {
              title: 'All Day Event',
              start: new Date(y, m, 1)
            },
            {
              title: 'Long Event',
              start: new Date(y, m, d+5),
              end: new Date(y, m, d+7)
            },
            {
              id: 999,
              title: 'Repeating Event',
              start: new Date(y, m, d-3, 16, 0),
              allDay: false
            },
            {
              id: 999,
              title: 'Repeating Event',
              start: new Date(y, m, d+4, 16, 0),
              allDay: false
            },
            {
              title: 'Meeting',
              start: new Date(y, m, d, 10, 30),
              allDay: false
            },
            {
              title: 'Lunch',
              start: new Date(y, m, d, 12, 0),
              end: new Date(y, m, d, 14, 0),
              allDay: false
            },
            {
              title: 'Birthday Party',
              start: new Date(y, m, d+1, 19, 0),
              end: new Date(y, m, d+1, 22, 30),
              allDay: false
            },
            {
              title: 'EGrappler.com',
              start: new Date(y, m, 28),
              end: new Date(y, m, 29),
              url: 'http://EGrappler.com/'
            }
          ]
        });
      });
    </script><!-- /Calendar -->

    
<script>

$(function () {
  
  guidely.add ({
    attachTo: '#target-1'
    , anchor: 'top-left'
    , title: 'Guide Title'
    , text: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut.'
  });
  
  guidely.add ({
    attachTo: '#target-2'
    , anchor: 'top-right'
    , title: 'Guide Title'
    , text: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut.'
  });
  
  guidely.add ({
    attachTo: '#target-3'
    , anchor: 'middle-middle'
    , title: 'Guide Title'
    , text: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut.'
  });
  
  guidely.add ({
    attachTo: '#target-4'
    , anchor: 'top-right'
    , title: 'Guide Title'
    , text: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut.'
  });
  
  guidely.init ({ welcome: true, startTrigger: false });


});

</script>


</body>
</html>
