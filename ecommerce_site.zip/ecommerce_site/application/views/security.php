<div class="container">
	<div class="col-md-offset-2 col-md-8" >
		<div class="header">
			<h1 class="hs1" style="margin-top: 5%">Login & Security</h1>
		</div>
		<form>
			<table class="table table-bordered">
				<tbody>
					<tr>
						<td>
							<div class="fs1">Name:</div>
							<div class="fs3">Husnain</div>
						</td>
						<td><button class="btn btn-primary" style="float: right;">Edit</button></td>
					</tr>
					<tr>
						<td>
							<div class="fs1">Emial:</div>
							<div class="fs3">Husnainhamdani.ynaut@gmail.com</div>
						</td>
						<td><button class="btn btn-primary" style="float: right;">Edit</button></td>
					</tr>
					<tr>
						<td>
							<div class="fs1">Mobile Phone Number:</div>
							<div class="fs3" style="margin-left: 5px">Why add a mobile number?</div>
						</td>
						<td><button class="btn btn-primary" style="float: right;">Add</button></td>
					</tr>
					<tr>
						<td>
							<div class="fs1">Password:</div>
							<div class="fs1">*******</div>
						</td>
						<td><button class="btn btn-primary" style="float: right;">Edit</button></td>
					</tr>
					<tr>
						<td>
							<div class="fs1">Communication Preference:</div>
							<div class="fs3">Husnainhamdani.ynaut@gmail.com</div>
						</td>
						<td><button class="btn btn-primary" style="float: right;">Edit</button></td>
					</tr>
				</tbody>
			</table>
			<input type="submit" name="done" value="Done" class="btn btn-primary">
		</form>
	</div>
</div>