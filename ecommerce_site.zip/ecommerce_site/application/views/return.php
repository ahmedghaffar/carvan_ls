<div class="container">
	<div class="header" style="margin-top: 20px">
		<div class="hs1">Select items to report</div>
	</div>
	<div class="row">
		<div class="panel panel-default">
		<div class="panel-body">
		<div class="col-md-2">
			<div class="custom-control custom-checkbox" style="display: inline-flex;">
    			<input type="checkbox" class="custom-control-input" id="defaultUnchecked" style="margin-top: -5%">
    			<label class="custom-control-label" for="defaultUnchecked">
    				<img src="<?= base_url(); ?>/image/cache/catalog/demo/product_10-80x82.jpg" alt="MacBook" class="img-responsive" />
    			</label>
			</div>
		</div>
		<div class="col-md-7">
			<div class="hs2">H-cube furniture Headboard<br> Diven Bed Base Hink</div>
			<div class="fs2">Order # <a href="#">362-96-12345</a></div>
			<div class="fs2">Sold By : H-cube</div>
			<div class="fs2"><a href="#"><u> Seller Return Policy</u></a></div>
			<div class="fs2">Quantity : 1</div>
		</div>
		<div class="col-md-3">
			<div><a href="#" class="btn btn-primary" style="width: 90%; margin-top:10px">Choose Reason</a></div>
			<div><a href="#" class="btn btn-primary" style="width: 90%; margin-top:10px">Return</a></div>
		</div>
		</div>
		</div>
	</div>
	<div class="row">
		<label class="hs2">
			Breifly Describe the Issue
		</label>
		<textarea rows="5" class="form-control" style="width: 100%"></textarea>
	</div>
	<div class="fs2">
		Note: Kindly assure to Carrovan's communication policy while writing comments.
		<a href="#"><u>Communication Policy</u></a>
	</div>
	<div class="row" style="margin-bottom: 10px">
		<div class="col-md-4 col-md-offset-8">
			Attach Pictures:(Optional) <label class="btn btn-default btn-file" style="width: 50%">
        		Browse <input type="file" style="display: none;"><br>
        	</label>
        	<div class="fs2">Note: Attaching pictures helps the seller understand the issues and problems better</div>
        	<div class="text-center" style="margin-left: 29%; margin-top: 10px"><a href="#" class="btn btn-primary" style="width: 70%">Return</a></div>
		</div>
	</div>
</div>