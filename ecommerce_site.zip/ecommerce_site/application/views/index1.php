

<!-- sys-notification -->
<div id="sys-notification">
  <div class="container">
    <div id="notification"></div>
  </div>
</div>
<!-- /sys-notification -->






  
<div class="container-full" style="margin-top: 0px;">
  <div class="row"> 
  
   <div id="sidebar-main" class="col-md-12">
   	<div id="content">
<div id="pav-homebuilder575708142" class="homebuilder clearfix">
	
 		    	        <div class="" >
	        	<div class="pav-inner" style="margin-top: 0px">
	      
	    <div class="row row-level-1 "><div class="row-inner  clearfix" >
	        	            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 "><div class="col-inner " style="margin-top: -18px">
	                	                		                     		<div class="layerslider-wrapper" >
			<div class="bannercontainer banner-boxed" style="padding: 0;margin: 18px 0 ;">
					<div id="sliderlayer7905635" class="rev_slider boxedbanner" style="width:100%;max-height:263px; " >
						
						 
						<ul>
														
								<li   data-masterspeed="200"  data-transition="random" data-slotamount="7" data-thumb="image/catalog/demo/layerslider/bg_slider_home2.jpg">

																					
											<img src="<?= base_url(); ?>/image/catalog/demo/layerslider/bg_slider_home2.jpg"  alt=""/>
																				
											
										
										 
												<!-- THE MAIN IMAGE IN THE SLIDE -->
												
											
										<div class="caption tp-caption large_text sfl 
											easeOutExpo   easeOutExpo 
											"
											 data-x="60"
											 data-y="126"
											 data-speed="300"
											 data-start="400"
											 data-easing="easeOutExpo"  >
											 												 	last chance											 	
											</div>
										
											
										
										 
												<!-- THE MAIN IMAGE IN THE SLIDE -->
												
											
										<div class="caption tp-caption big_blue sfl 
											easeOutExpo   easeOutExpo 
											"
											 data-x="56"
											 data-y="188"
											 data-speed="300"
											 data-start="800"
											 data-easing="easeOutExpo"  >
											 												 	bigest sale											 	
											</div>
										
											
										
										 
												<!-- THE MAIN IMAGE IN THE SLIDE -->
												
											
										<div class="caption tp-caption medium_text sfl 
											easeOutExpo   easeOutExpo 
											"
											 data-x="60"
											 data-y="250"
											 data-speed="300"
											 data-start="1200"
											 data-easing="easeOutExpo"  >
											 												 	Women"s One Shoulder Shirred Bust Long Dress											 	
											</div>
										
											
										
										 
												<!-- THE MAIN IMAGE IN THE SLIDE -->
												
											
										<div class="caption btn btn-primary sfl 
											easeOutExpo   easeOutExpo 
											"
											 data-x="60"
											 data-y="306"
											 data-speed="300"
											 data-start="1600"
											 data-easing="easeOutExpo"  >
											 												 	view collection											 	
											</div>
										
												
							</li>			
										 
						 
													
								<li   data-masterspeed="200"  data-transition="random" data-slotamount="7" data-thumb="image/catalog/demo/layerslider/bg_slider2.png">

																					
											<img src="<?= base_url(); ?>/image/catalog/demo/layerslider/bg_slider2.png"  alt=""/>
																				
											
										
										 
												<!-- THE MAIN IMAGE IN THE SLIDE -->
												
											
										<div class="caption tp-caption large_text sfl 
											easeOutExpo   easeOutExpo 
											"
											 data-x="60"
											 data-y="126"
											 data-speed="300"
											 data-start="400"
											 data-easing="easeOutExpo"  >
											 												 	last chance											 	
											</div>
										
											
										
										 
												<!-- THE MAIN IMAGE IN THE SLIDE -->
												
											
										<div class="caption tp-caption big_blue sfl 
											easeOutExpo   easeOutExpo 
											"
											 data-x="56"
											 data-y="188"
											 data-speed="300"
											 data-start="800"
											 data-easing="easeOutExpo"  >
											 												 	bigest sale											 	
											</div>
										
											
										
										 
												<!-- THE MAIN IMAGE IN THE SLIDE -->
												
											
										<div class="caption tp-caption medium_text sfl 
											easeOutExpo   easeOutExpo 
											"
											 data-x="60"
											 data-y="250"
											 data-speed="300"
											 data-start="1200"
											 data-easing="easeOutExpo"  >
											 												 	Women"s One Shoulder Shirred Bust Long Dress											 	
											</div>
										
											
										
										 
												<!-- THE MAIN IMAGE IN THE SLIDE -->
												
											
										<div class="caption btn btn-primary sfl 
											easeOutExpo   easeOutExpo 
											"
											 data-x="60"
											 data-y="306"
											 data-speed="300"
											 data-start="1600"
											 data-easing="easeOutExpo"  >
											 												 	view collection											 	
											</div>
										
											
										
										 
												<!-- THE MAIN IMAGE IN THE SLIDE -->
												
											
										<div class="caption  sft 
											easeOutExpo   easeOutExpo 
											"
											 data-x="614"
											 data-y="7"
											 data-speed="300"
											 data-start="2000"
											 data-easing="easeOutExpo"  >
											 	 
											 	<img src="<?= base_url(); ?>/image/catalog/demo/layerslider/icon.png" alt="" />
												 	
											</div>
										
											
										
										 
												<!-- THE MAIN IMAGE IN THE SLIDE -->
												
											
										<div class="caption  sft 
											easeOutExpo   easeOutExpo 
											"
											 data-x="704"
											 data-y="31"
											 data-speed="300"
											 data-start="2400"
											 data-easing="easeOutExpo"  >
											 	 
											 	<img src="<?= base_url(); ?>/image/catalog/demo/layerslider/img_slider2.png" alt="" />
												 	
											</div>
										
												
							</li>			
															<li   data-masterspeed="200"  data-transition="random" data-slotamount="7" data-thumb="image/catalog/demo/layerslider/bg_slider1.png">

																					
											<img src="<?= base_url(); ?>/image/catalog/demo/layerslider/bg_slider1.png"  alt=""/>
																				
											
										
										 
												<!-- THE MAIN IMAGE IN THE SLIDE -->
												
											
										<div class="caption tp-caption large_text sfl 
											easeOutExpo   easeOutExpo 
											"
											 data-x="60"
											 data-y="126"
											 data-speed="300"
											 data-start="400"
											 data-easing="easeOutExpo"  >
											 												 	last chance											 	
											</div>
										
											
										
										 
												<!-- THE MAIN IMAGE IN THE SLIDE -->
												
											
										<div class="caption tp-caption big_blue sfl 
											easeOutExpo   easeOutExpo 
											"
											 data-x="56"
											 data-y="188"
											 data-speed="300"
											 data-start="800"
											 data-easing="easeOutExpo"  >
											 												 	bigest sale											 	
											</div>
										
											
										
										 
												<!-- THE MAIN IMAGE IN THE SLIDE -->
												
											
										<div class="caption tp-caption medium_text sfl 
											easeOutExpo   easeOutExpo 
											"
											 data-x="60"
											 data-y="250"
											 data-speed="300"
											 data-start="1200"
											 data-easing="easeOutExpo"  >
											 												 	Women"s One Shoulder Shirred Bust Long Dress											 	
											</div>
										
											
										
										 
												<!-- THE MAIN IMAGE IN THE SLIDE -->
												
											
										<div class="caption btn btn-primary sfl 
											easeOutExpo   easeOutExpo 
											"
											 data-x="60"
											 data-y="306"
											 data-speed="300"
											 data-start="1600"
											 data-easing="easeOutExpo"  >
											 												 	view collection											 	
											</div>
										
												
							</li>
										 
						 
										 	
										 
						 
							 
						</ul>
											</div>
				</div>

 
 </div>
 

			<!--
			##############################
			 - ACTIVATE THE BANNER HERE -
			##############################
			-->
			<script type="text/javascript">

				var tpj=jQuery;
				 

			

				if (tpj.fn.cssOriginal!=undefined)
					tpj.fn.css = tpj.fn.cssOriginal;

					tpj('#sliderlayer7905635').revolution(
						{
							delay:9000,
							startheight:463,
							startwidth:1170,


							hideThumbs:0,

							thumbWidth:100,						
							thumbHeight:50,
							thumbAmount:5,

							navigationType:"bullet",				
							navigationArrows:"verticalcentered",				
														navigationStyle:"round",			 
							 					
							navOffsetHorizontal:0,
							navOffsetVertical:20, 	

							touchenabled:"on",			
							onHoverStop:"on",						
							shuffle:"off",	
							stopAtSlide:-1,						
							stopAfterLoops:-1,						

							hideCaptionAtLimit:0,				
							hideAllCaptionAtLilmit:0,				
							hideSliderAtLimit:0,			
							fullWidth:"off",
							shadow:0	 
							 				 


						});



				

			</script>
                   			                	                	            </div></div>
	        	    </div></div>
	    	            </div>
	        </div>

<div class="container-fluid " >
 	<div class="pav-inner" >
	    <div class="row row-level-1 ">
	    	<div class="row-inner  clearfix" >
	            <div class="col-lg-10 col-md-10 col-sm-12 col-xs-12 ">
	            	<div class="col-inner  ">
	                	<div class="prefix box box-highlighted nopadding productcarousel" id="module31">
							<div class="box-heading">
								<span class="icon-heading"><!-- &nbsp;</span><span>Best Seller</span> -->
							</div>
							<div class="slide carousel" data-ride="carousel" id="productcarousel31">
								<div class="carousel-inner product-grid">		
									<div class="item active">
										<div class="row products-row last">									
										<?php foreach ($results as $result) {
											# code...
									?>	
											<div class="col-md-3 col-sm-6 col-xs-12  product-col">
												<div class="product-block item-default" itemtype="http://schema.org/Product" itemscope>
													<div class="image">
			      										<a class="img" href="pd/<?= $result->id; ?>"><img src="<?= base_url();?>/uploads/<?= $result->image; ?>" alt="iMac" class="img-responsive" /></a>
													</div>
												</div>
											</div>
                                         <?php } ?>
											<!-- <div class="col-md-3 col-sm-6 col-xs-12  product-col">
												<div class="product-block item-default" itemtype="http://schema.org/Product" itemscope>
													<div class="image">
			      										<a class="img" href="psample"><img src="<?= base_url(); ?>/image/cache/catalog/demo/product_08-199x201.jpg" alt="iPod Classic" class="img-responsive" /></a>
													</div>
												</div>
											</div>
											<div class="col-md-3 col-sm-6 col-xs-12  product-col">
												<div class="product-block item-default" itemtype="http://schema.org/Product" itemscope>
													<div class="image">
			      										<a class="img" href="psample"><img src="<?= base_url(); ?>/image/cache/catalog/demo/product_12-199x201.jpg" alt="MacBook" class="img-responsive" /></a>
													</div>
												</div>
											</div>
											<div class="col-md-3 col-sm-6 col-xs-12 last product-col">
												<div class="product-block item-default" itemtype="http://schema.org/Product" itemscope>
													<div class="image">
			      										<a class="img" href="psample"><img src="<?= base_url(); ?>/image/cache/catalog/demo/product_11-199x201.jpg" alt="iPod Touch" class="img-responsive" /></a>
													</div>
												</div>
											</div>
										</div>			
									</div>
							  		<div class="item ">
										<div class="row products-row ">												<div class="col-md-3 col-sm-6 col-xs-12  product-col">
												<div class="product-block item-default" itemtype="http://schema.org/Product" itemscope>
													<div class="image">
			      										<a class="img" href="psample"><img src="<?= base_url(); ?>/image/cache/catalog/demo/product_10-199x201.jpg" alt="iPod Shuffle" class="img-responsive" /></a>
													</div>
												</div>
-->											</div>
 										</div>												
									</div>
						  		</div>
						  		<a class="left carousel-control" href="#productcarousel31"   data-slide="prev" style="z-index: 1"><i class="fa fa-chevron-left"></i></a>
								<a class="right carousel-control" href="#productcarousel31"  data-slide="next" style="z-index: 1"><i class="fa fa-chevron-right"></i></a>
							</div>
						</div>
<script type="text/javascript">
    $(document).ready(function() {
    	  $('.slide').on('slid.bs.carousel', function () {
	        $(this).removeClass('ohidden');
	    });

	    $('.slide').on('slide.bs.carousel', function () {
	        $(this).addClass('ohidden');
	    });
	});
</script>
<script>
$('#productcarousel31').carousel({interval:false});
</script>

   		<div class="pts-bannerbuilder clearfix ">
	        <div class="" >        
	        	<div class="pts-inner">
				    <div class="row row-level-1">
	                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
	                    	<div class="col-inner">
	                        	<div class="banner-wrapper">
	                           		<a href="<?= base_url(); ?>/#"><img alt="img" src="<?= base_url(); ?>/image/catalog/demo/banners/banner-app.png" class="img-responsive" style="width: 100%"></a>
                      			</div>
                        	</div>
                    	</div>
	        		</div>
	    		</div>  
	    	</div>
		</div>
	    <div class="prefix box box-highlighted nopadding productcarousel" id="module311">
							<div class="box-heading">
								<span class="icon-heading"><!-- &nbsp;</span><span>Best Seller</span> -->
							</div>
							<div class="slide carousel" data-ride="carousel" id="productcarousel311">
								<div class="carousel-inner product-grid">		
									<div class="item active">
										<div class="row products-row last">											<div class="col-md-3 col-sm-6 col-xs-12  product-col">
												<div class="product-block item-default" itemtype="http://schema.org/Product" itemscope>
													<div class="image">
			      										<a class="img" href="psample"><img src="<?= base_url(); ?>/image/cache/catalog/demo/product_05-199x201.jpg" alt="iMac" class="img-responsive" /></a>
													</div>
												</div>
											</div>
											<div class="col-md-3 col-sm-6 col-xs-12  product-col">
												<div class="product-block item-default" itemtype="http://schema.org/Product" itemscope>
													<div class="image">
			      										<a class="img" href="psample"><img src="<?= base_url(); ?>/image/cache/catalog/demo/product_08-199x201.jpg" alt="iPod Classic" class="img-responsive" /></a>
													</div>
												</div>
											</div>
											<div class="col-md-3 col-sm-6 col-xs-12  product-col">
												<div class="product-block item-default" itemtype="http://schema.org/Product" itemscope>
													<div class="image">
			      										<a class="img" href="psample"><img src="<?= base_url(); ?>/image/cache/catalog/demo/product_12-199x201.jpg" alt="MacBook" class="img-responsive" /></a>
													</div>
												</div>
											</div>
											<div class="col-md-3 col-sm-6 col-xs-12 last product-col">
												<div class="product-block item-default" itemtype="http://schema.org/Product" itemscope>
													<div class="image">
			      										<a class="img" href="psample"><img src="<?= base_url(); ?>/image/cache/catalog/demo/product_11-199x201.jpg" alt="iPod Touch" class="img-responsive" /></a>
													</div>
												</div>
											</div>
										</div>			
									</div>
							  		<div class="item ">
										<div class="row products-row ">												<div class="col-md-3 col-sm-6 col-xs-12  product-col">
												<div class="product-block item-default" itemtype="http://schema.org/Product" itemscope>
													<div class="image">
			      										<a class="img" href="psample"><img src="<?= base_url(); ?>/image/cache/catalog/demo/product_10-199x201.jpg" alt="iPod Shuffle" class="img-responsive" /></a>
													</div>
												</div>
											</div>
										</div>												
									</div>
						  		</div>
						  		<a class="left carousel-control" href="#productcarousel311"   data-slide="prev" style="z-index: 1"><i class="fa fa-chevron-left"></i></a>
								<a class="right carousel-control" href="#productcarousel311"  data-slide="next" style="z-index: 1"><i class="fa fa-chevron-right"></i></a>
							</div>
						</div>
<script>
$('#productcarousel311').carousel({interval:false});
</script>						

<div class="prefix box box-highlighted nopadding productcarousel" id="module312">
							<div class="box-heading">
								<span class="icon-heading"><!-- &nbsp;</span><span>Best Seller</span> -->
							</div>
							<div class="slide carousel" data-ride="carousel" id="productcarousel312">
								<div class="carousel-inner product-grid">		
									<div class="item active">
										<div class="row products-row last">											<div class="col-md-3 col-sm-6 col-xs-12  product-col">
												<div class="product-block item-default" itemtype="http://schema.org/Product" itemscope>
													<div class="image">
			      										<a class="img" href="psample"><img src="<?= base_url(); ?>/image/cache/catalog/demo/product_05-199x201.jpg" alt="iMac" class="img-responsive" /></a>
													</div>
												</div>
											</div>
											<div class="col-md-3 col-sm-6 col-xs-12  product-col">
												<div class="product-block item-default" itemtype="http://schema.org/Product" itemscope>
													<div class="image">
			      										<a class="img" href="psample"><img src="<?= base_url(); ?>/image/cache/catalog/demo/product_08-199x201.jpg" alt="iPod Classic" class="img-responsive" /></a>
													</div>
												</div>
											</div>
											<div class="col-md-3 col-sm-6 col-xs-12  product-col">
												<div class="product-block item-default" itemtype="http://schema.org/Product" itemscope>
													<div class="image">
			      										<a class="img" href="psample"><img src="<?= base_url(); ?>/image/cache/catalog/demo/product_12-199x201.jpg" alt="MacBook" class="img-responsive" /></a>
													</div>
												</div>
											</div>
											<div class="col-md-3 col-sm-6 col-xs-12 last product-col">
												<div class="product-block item-default" itemtype="http://schema.org/Product" itemscope>
													<div class="image">
			      										<a class="img" href="psample"><img src="<?= base_url(); ?>/image/cache/catalog/demo/product_11-199x201.jpg" alt="iPod Touch" class="img-responsive" /></a>
													</div>
												</div>
											</div>
										</div>			
									</div>
							  		<div class="item ">
										<div class="row products-row ">												<div class="col-md-3 col-sm-6 col-xs-12  product-col">
												<div class="product-block item-default" itemtype="http://schema.org/Product" itemscope>
													<div class="image">
			      										<a class="img" href="psample"><img src="<?= base_url(); ?>/image/cache/catalog/demo/product_10-199x201.jpg" alt="iPod Shuffle" class="img-responsive" /></a>
													</div>
												</div>
											</div>
										</div>												
									</div>
						  		</div>
						  		<a class="left carousel-control" href="#productcarousel312"   data-slide="prev" style="z-index: 1"><i class="fa fa-chevron-left"></i></a>
								<a class="right carousel-control" href="#productcarousel312"  data-slide="next" style="z-index: 1"><i class="fa fa-chevron-right"></i></a>
							</div>
						</div>
<script>
$('#productcarousel312').carousel({interval:false});
</script>
                   			                	                		                     		<div class="pts-bannerbuilder clearfix ">
	
 		    	        <div class="pts-container " >        
	        	<div class="pts-inner">
	      
	    <div class="row row-level-1">
	        	            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"><div class="col-inner">
	                	                		                    <div class="banner-wrapper">
	                    	                        	<a href="<?= base_url(); ?>/#"><img alt="img" src="<?= base_url(); ?>/image/catalog/demo/banners/banner-bottom.png" class="img-responsive" style="width: 100%"></a>
                        	                   		</div>
                   			                	                	            </div></div>
	        	    </div>
	    	            </div>  </div>
    

	        </div>
	                   			                	                	            </div></div>
	        	            <div class="col-lg-2 col-md-2carousel col-sm-12 col-xs-12 " style="margin-top: 15px"><div class="col-inner  sidebar-right">


                              <div class="pts-bannerbuilder clearfix hidden-sm hidden-xs">
	
 		    	        <div class="pts-container " >        
	        	<div class="pts-inner">
	      
	    <div class="row row-level-1">
	        	            <div class="col-lg-12 col-md-12 col-sm-6 col-xs-12"><div class="col-inner">
	                	                		                    <div class="banner-wrapper">
	                    	                        	<a href="desktop"><img alt="img" src="<?= base_url(); ?>image/catalog/demo/banners/banner4.jpg" class="img-responsive"></a>
                        	                   		</div>
                   			                	                	            </div></div>
	        	    </div>
	        	    </div>
	        	    </div>
                     </div>
                     

	      <!--           	                		                     		<div class=" box box-danger productdeals nopadding">
	<div class="box-heading"><i class="fa fa-star-o">&nbsp;</i><span>Latest Deals</span></div>
	<div class="box-content-deals" >
 		<div class="box-products slide carousel" id="pavdeals7">
									<div class="carousel-controls">
				<a class="carousel-control left fa fa-angle-left" href="<?= base_url(); ?>/#pavdeals7"   data-slide="prev"></a>
				<a class="carousel-control right fa fa-angle-right" href="<?= base_url(); ?>/#pavdeals7"  data-slide="next"></a>
			</div>
						<div class="carousel-inner ">		
						
				<div class="item active">
										 <div class="row product-items"> 
						<div class="product-cols col-sm-12 col-xs-12">
							<div class="product-block">
								<div class="image">
									<a href="psample">
										<img src="<?= base_url(); ?>/image/cache/catalog/demo/product_01-196x198.jpg" alt="Apple Cinema 30&quot;" title="Apple Cinema 30&quot;" class="img-responsive" />
									</a>
								</div>
								<div class="product-meta clearfix">
									<div class="left">
										<h4 class="name"><a href="psample">Apple Cinema 30&quot;</a></h4>
																		          <div class="rating">
								            								            								            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
								            								            								            								            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
								            								            								            								            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
								            								            								            								            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
								            								            								            								            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
								            								            								          </div>
								         																				<div class="price">
																						<span class="price-new">$110.00</span> <span class="price-old">$122.00</span>
																																	<span class="price-tax">Ex Tax: $90.00</span>
																					</div>
																			</div>
									<div class="right">
										<p class="description">
	The 30-inch Apple Cinema HD Display delivers an amazing 2560 x 1600 pixel resolution. Designed specifically for the creative professional, this display provides more space for easier access to all the tools and palettes needed to edit, format and composite your work. Combine this display with a Mac Pro, MacBook Pro, or PowerMac G5 and there's no limit to what you can achieve. 
	
	The Cinema HD features an active-matrix liquid crystal display that produces flicker-free images that deliver twice the brightness, twice the sharpness and twice the contrast ratio of a typical CRT display. Unlike other flat panels, it's designed with a pure digital interface to deliver distortion-free images that never need adjusting. With over 4 million digital pixels, the display is uniquely suited for scientific and technical applications such as visualizing molecular structures or analyzing geological data. 
	
	Offering accurate, brilliant color performance, the Cinema HD delivers up to 16.7 million colors across a wide gamut allowing you to see subtle nuances between colors from soft pastels to rich jewel tones. A wide viewing angle ensures uniform color from edge to edge. Apple's ColorSync technology allows you to create custom profiles to maintain consistent color onscreen and in print. The result: You can confidently use this display in all your color-critical applications. 
	
	Housed in a new aluminum design, the display has a very thin bezel that enhances visual accuracy. Each display features two FireWire 400 ports and two USB 2.0 ports, making attachment of desktop peripherals, such as iSight, iPod, digital and still cameras, hard drives, printers and scanners, even more accessible and convenient. Taking advantage of the much thinner and lighter footprint of an LCD, the new displays support the VESA (Video Electronics Standards Association) mounting interface standard. Customers with the optional Cinema Display VESA Mount Adapter kit gain the flexibility to mount their display in locations most appropriate for their work environment. 
	
	The Cinema HD features a single cable design with elegant breakout for the USB 2.0, FireWire 400 and a pure digital connection using the industry standard Digital Video Interface (DVI) interface. The DVI connection allows for a direct pure-digital connection.
	

	Features:

	Unrivaled display performance

	
		30-inch (viewable) active-matrix liquid crystal display provides breathtaking image quality and vivid, richly saturated color.
	
		Support for 2560-by-1600 pixel resolution for display of high definition still and video imagery.
	
		Wide-format design for simultaneous display of two full pages of text and graphics.
	
		Industry standard DVI connector for direct attachment to Mac- and Windows-based desktops and notebooks
	
		Incredibly wide (170 degree) horizontal and vertical viewing angle for maximum visibility and color performance.
	
		Lightning-fast pixel response for full-motion digital video playback.
	
		Support for 16.7 million saturated colors, for use in all graphics-intensive applications.


	Simple setup and operation

	
		Single cable with elegant breakout for connection to DVI, USB and FireWire ports
	
		Built-in two-port USB 2.0 hub for easy connection of desktop peripheral devices.
	
		Two FireWire 400 ports to support iSight and other desktop peripherals


	Sleek, elegant design

	
		Huge virtual workspace, very small footprint.
	
		Narrow Bezel design to minimize visual impact of using dual displays
	
		Unique hinge design for effortless adjustment
	
		Support for VESA mounting solutions (Apple Cinema Display VESA Mount Adapter sold separately)


	Technical specifications

	Screen size (diagonal viewable image size)

	
		Apple Cinema HD Display: 30 inches (29.7-inch viewable)


	Screen type

	
		Thin film transistor (TFT) active-matrix liquid crystal display (AMLCD)


	Resolutions

	
		2560 x 1600 pixels (optimum resolution)
	
		2048 x 1280
	
		1920 x 1200
	
		1280 x 800
	
		1024 x 640


	Display colors (maximum)

	
		16.7 million


	Viewing angle (typical)

	
		170° horizontal; 170° vertical


	Brightness (typical)

	
		30-inch Cinema HD Display: 400 cd/m2


	Contrast ratio (typical)

	
		700:1


	Response time (typical)

	
		16 ms


	Pixel pitch

	
		30-inch Cinema HD Display: 0.250 mm


	Screen treatment

	
		Antiglare hardcoat


	User controls (hardware and software)

	
		Display Power,
	
		System sleep, wake
	
		Brightness
	
		Monitor tilt


	Connectors and cables
	Cable

	
		DVI (Digital Visual Interface)
	
		FireWire 400
	
		USB 2.0
	
		DC power (24 V)


	Connectors

	
		Two-port, self-powered USB 2.0 hub
	
		Two FireWire 400 ports
	
		Kensington security port


	VESA mount adapter
	Requires optional Cinema Display VESA Mount Adapter (M9649G/A)

	
		Compatible with VESA FDMI (MIS-D, 100, C) compliant mounting solutions


	Electrical requirements

	
		Input voltage: 100-240 VAC 50-60Hz
	
		Maximum power when operating: 150W
	
		Energy saver mode: 3W or less


	Environmental requirements

	
		Operating temperature: 50° to 95° F (10° to 35° C)
	
		Storage temperature: -40° to 116° F (-40° to 47° C)
	
		Operating humidity: 20% to 40% noncondensing
	
		Maximum operating altitude: 10,000 feet


	Agency approvals

	
		FCC Part 15 Class B
	
		EN55022 Class B
	
		EN55024
	
		VCCI Class B
	
		AS/NZS 3548 Class B
	
		CNS 13438 Class B
	
		ICES-003 Class B
	
		ISO 13406 part 2
	
		MPR II
	
		IEC 60950
	
		UL 60950
	
		CSA 60950
	
		EN60950
	
		ENERGY STAR
	
		TCO '03


	Size and weight
	30-inch Apple Cinema HD Display

	
		Height: 21.3 inches (54.3 cm)
	
		Width: 27.2 inches (68.8 cm)
	
		Depth: 8.46 inches (21.5 cm)
	
		Weight: 27.5 pounds (12.5 kg)


	System Requirements

	
		Mac Pro, all graphic options
	
		MacBook Pro
	
		Power Mac G5 (PCI-X) with ATI Radeon 9650 or better or NVIDIA GeForce 6800 GT DDL or better
	
		Power Mac G5 (PCI Express), all graphics options
	
		PowerBook G4 with dual-link DVI support
	
		Windows PC and graphics card that supports DVI ports with dual-link digital bandwidth and VESA DDC standard for plug-and-play setup
..</p>									
									</div>
								</div>
								<div class="deal_detail hide">
									<ul>
										<li>
											<span>Discount</span>
											<span class="deal_detail_num">10%</span>
										</li>
										<li>
											<span>You save</span>
											<span class="deal_detail_num"><span class="price">$14.00</span></span>
										</li>
										<li>
											<span> Bought</span>
											<span class="deal_detail_num">0</span>
										</li>
									</ul>
								</div>

								<div>										
								<!-- count down -->
								<!-- <div class="deal-qty-box hidden">
									Hurry, just <span class="deal-qty">990 items</span> left!								</div>

								<div class="item-detail hidden">
									<div class="timer-explain">(30/07/2017)</div>
								</div>

								<div id="item0countdown_42" class="item-countdown"></div>
								<script type="text/javascript">
									jQuery(document).ready(function($){
										$("#item0countdown_42").lofCountDown({
											formatStyle:2,
											TargetDate:"07/30/2017 0:00:00",
											DisplayFormat:"<ul><li>%%D%% <div>Day</div></li><li> %%H%% <div>Hrs</div></li><li> %%M%% <div>Mins</div></li><li> %%S%% <div>Secs</div></li></ul>",
											FinishMessage: "Expired"
										});
									});
								</script>
								</div>
							</div>
						</div>

					 </div> 									</div>  

			
				<div class="item ">
										 <div class="row product-items"> 
						<div class="product-cols col-sm-12 col-xs-12">
							<div class="product-block">
								<div class="image">
									<a href="psample">
										<img src="<?= base_url(); ?>/image/cache/catalog/demo/product_02-196x198.jpg" alt="Canon EOS 5D" title="Canon EOS 5D" class="img-responsive" />
									</a>
								</div>
								<div class="product-meta clearfix">
									<div class="left">
										<h4 class="name"><a href="psample">Canon EOS 5D</a></h4>
																		          <div class="rating">
								            								            								            <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i>
								            </span>
								            								            								            								            <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i>
								            </span>
								            								            								            								            <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i>
								            </span>
								            								            								            								            <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i>
								            </span>
								            								            								            								            <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i>
								            </span>
								            								            								          </div>
								         																				<div class="price">
																						<span class="price-new">$110.00</span> <span class="price-old">$122.00</span>
																																	<span class="price-tax">Ex Tax: $90.00</span>
																					</div>
																			</div>
									<div class="right">
										<p class="description">
	Canon's press material for the EOS 5D states that it 'defines (a) new D-SLR category', while we're not typically too concerned with marketing talk this particular statement is clearly pretty accurate. The EOS 5D is unlike any previous digital SLR in that it combines a full-frame (35 mm sized) high resolution sensor (12.8 megapixels) with a relatively compact body (slightly larger than the EOS 20D, although in your hand it feels noticeably 'chunkier'). The EOS 5D is aimed to slot in between the EOS 20D and the EOS-1D professional digital SLR's, an important difference when compared to the latter is that the EOS 5D doesn't have any environmental seals. While Canon don't specifically refer to the EOS 5D as a 'professional' digital SLR it will have obvious appeal to professionals who want a high quality digital SLR in a body lighter than the EOS-1D. It will also no doubt appeal to current EOS 20D owners (although lets hope they've not bought too many EF-S lenses...) äë..</p>									
									</div>
								</div>
								<div class="deal_detail hide">
									<ul>
										<li>
											<span>Discount</span>
											<span class="deal_detail_num">10%</span>
										</li>
										<li>
											<span>You save</span>
											<span class="deal_detail_num"><span class="price">$14.00</span></span>
										</li>
										<li>
											<span> Bought</span>
											<span class="deal_detail_num">0</span>
										</li>
									</ul>
								</div>

								<div>										
								<!-- count down -->
		<!-- 						<div class="deal-qty-box hidden">
									Hurry, just <span class="deal-qty">7 items</span> left!								</div>

								<div class="item-detail hidden">
									<div class="timer-explain">(29/04/2017)</div>
								</div>

								<div id="item0countdown_30" class="item-countdown"></div>
								<script type="text/javascript">
									jQuery(document).ready(function($){
										$("#item0countdown_30").lofCountDown({
											formatStyle:2,
											TargetDate:"04/29/2017 0:00:00",
											DisplayFormat:"<ul><li>%%D%% <div>Day</div></li><li> %%H%% <div>Hrs</div></li><li> %%M%% <div>Mins</div></li><li> %%S%% <div>Secs</div></li></ul>",
											FinishMessage: "Expired"
										});
									});
								</script>
								</div>
							</div>
						</div>

					 </div> 									</div>  

			
				<div class="item ">
										 <div class="row product-items"> 
						<div class="product-cols col-sm-12 col-xs-12">
							<div class="product-block">
								<div class="image">
									<a href="psample">
										<img src="<?= base_url(); ?>/image/cache/catalog/demo/product_04-196x198.jpg" alt="HTC Touch HD" title="HTC Touch HD" class="img-responsive" />
									</a>
								</div>
								<div class="product-meta clearfix">
									<div class="left">
										<h4 class="name"><a href="psample">HTC Touch HD</a></h4>
																		          <div class="rating">
								            								            								            <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i>
								            </span>
								            								            								            								            <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i>
								            </span>
								            								            								            								            <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i>
								            </span>
								            								            								            								            <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i>
								            </span>
								            								            								            								            <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i>
								            </span>
								            								            								          </div>
								         																				<div class="price">
																						<span class="price-new">$98.00</span> <span class="price-old">$122.00</span>
																																	<span class="price-tax">Ex Tax: $80.00</span>
																					</div>
																			</div>
									<div class="right">
										<p class="description">
	HTC Touch - in High Definition. Watch music videos and streaming content in awe-inspiring high definition clarity for a mobile experience you never thought possible. Seductively sleek, the HTC Touch HD provides the next generation of mobile functionality, all at a simple touch. Fully integrated with Windows Mobile Professional 6.1, ultrafast 3.5G, GPS, 5MP camera, plus lots more - all delivered on a breathtakingly crisp 3.8" WVGA touchscreen - you can take control of your mobile world with the HTC Touch HD.

	Features

	
		Processor Qualcomm® MSM 7201A™ 528 MHz
	
		Windows Mobile® 6.1 Professional Operating System
	
		Memory: 512 MB ROM, 288 MB RAM
	
		Dimensions: 115 mm x 62.8 mm x 12 mm / 146.4 grams
	
		3.8-inch TFT-LCD flat touch-sensitive screen with 480 x 800 WVGA resolution
	
		HSDPA/WCDMA: Europe/Asia: 900/2100 MHz; Up to 2 Mbps up-link and 7.2 Mbps down-link speeds
	
		Quad-band GSM/GPRS/EDGE: Europe/Asia: 850/900/1800/1900 MHz (Band frequency, HSUPA availability, and data speed are operator dependent.)
	
		Device Control via HTC TouchFLO™ 3D &amp; Touch-sensitive front panel buttons
	
		GPS and A-GPS ready
	
		Bluetooth® 2.0 with Enhanced Data Rate and A2DP for wireless stereo headsets
	
		Wi-Fi®: IEEE 802.11 b/g
	
		HTC ExtUSB™ (11-pin mini-USB 2.0)
	
		5 megapixel color camera with auto focus
	
		VGA CMOS color camera
	
		Built-in 3.5 mm audio jack, microphone, speaker, and FM radio
	
		Ring tone formats: AAC, AAC+, eAAC+, AMR-NB, AMR-WB, QCP, MP3, WMA, WAV
	
		40 polyphonic and standard MIDI format 0 and 1 (SMF)/SP MIDI
	
		Rechargeable Lithium-ion or Lithium-ion polymer 1350 mAh battery
	
		Expansion Slot: microSD™ memory card (SD 2.0 compatible)
	
		AC Adapter Voltage range/frequency: 100 ~ 240V AC, 50/60 Hz DC output: 5V and 1A
	
		Special Features: FM Radio, G-Sensor
..</p>									
									</div>
								</div>
								<div class="deal_detail hide">
									<ul>
										<li>
											<span>Discount</span>
											<span class="deal_detail_num">20%</span>
										</li>
										<li>
											<span>You save</span>
											<span class="deal_detail_num"><span class="price">$26.00</span></span>
										</li>
										<li>
											<span> Bought</span>
											<span class="deal_detail_num">0</span>
										</li>
									</ul>
								</div>

								<div>										
								<!-- count down -->
<!-- 								<div class="deal-qty-box hidden">
									Hurry, just <span class="deal-qty">939 items</span> left!								</div>

								<div class="item-detail hidden">
									<div class="timer-explain">(22/10/2017)</div>
								</div>

								<div id="item0countdown_28" class="item-countdown"></div>
								<script type="text/javascript">
									jQuery(document).ready(function($){
										$("#item0countdown_28").lofCountDown({
											formatStyle:2,
											TargetDate:"10/22/2017 0:00:00",
											DisplayFormat:"<ul><li>%%D%% <div>Day</div></li><li> %%H%% <div>Hrs</div></li><li> %%M%% <div>Mins</div></li><li> %%S%% <div>Secs</div></li></ul>",
											FinishMessage: "Expired"
										});
									});
								</script>
								</div>
							</div>
						</div>

					 </div> 									</div>  

						</div>  
		</div>
	</div> 
</div>


<script type="text/javascript">
$('#pavdeals7').carousel({interval:false,auto:false,pause:'hover'});
</script>  -->           			                	                		                	                		                     		<div class="pts-bannerbuilder clearfix hidden-sm hidden-xs">
	
 		    	        <div class="pts-container " >        
	        	<div class="pts-inner">
	      
	    <div class="row row-level-1">
	        	            <div class="col-lg-12 col-md-12 col-sm-6 col-xs-12"><div class="col-inner">
	                	                		                    <div class="banner-wrapper">
	                    	                        	<a href="desktop"><img alt="img" src="<?= base_url(); ?>image/catalog/demo/banners/banner4.jpg" class="img-responsive"></a>
                        	                   		</div>
                   			                	                	            </div></div>
	        	    </div>
	        	    <div class="row row-level-1">
	        	            <div class="col-lg-12 col-md-12 col-sm-6 col-xs-12"><div class="col-inner">
	                	                		                    <div class="banner-wrapper">
	                    	                        	<a href="desktop"><img alt="img" src="<?= base_url(); ?>image/catalog/demo/banners/banner4.jpg" class="img-responsive"></a>
                        	                   		</div>
                   			                	                	            </div></div>
	        	    </div>
	        	    <div class="row row-level-1">
	        	            <div class="col-lg-12 col-md-12 col-sm-6 col-xs-12"><div class="col-inner">
	                	                		                    <div class="banner-wrapper">
	                    	                        	<a href="desktop"><img alt="img" src="<?= base_url(); ?>image/catalog/demo/banners/banner4.jpg" class="img-responsive"></a>
                        	                   		</div>
                   			                	                	            </div></div>
	        	    </div>
	    	            </div>  </div>
	        </div>
	     


	                   			                	                		                     		<div class="box">
	<!-- <div class="facebook-wrapper" style="width:270" >
			<script>(function(d, s, id) {
		var js, fjs = d.getElementsByTagName(s)[0];
		if (d.getElementById(id)) return;
		js = d.createElement(s); js.id = id;
		js.src = "../../../../../connect.facebook.net/en/all.js#xfbml=1";
		fjs.parentNode.insertBefore(js, fjs);
		}(document, 'script', 'facebook-jssdk'));</script>
		
	<div class="fb-like-box" data-href="<?= base_url(); ?>/https://www.facebook.com/themelexus?fref=ts" data-colorscheme="light" data-height="290" data-width="270" data-show-faces="true" data-stream="false" data-show-border="false" data-header="true"></div>
</div> -->
</div>                   			                	                	            </div></div>
	        	    </div></div>
	    	            </div>
	        </div>
	    	    	        <div class="container " >
	        	<div class="pav-inner" >
	      
	    <div class="row row-level-1 "><div class="row-inner  clearfix" >
	        	            <!-- <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 "><div class="col-inner  ">
	                	                		                     			   <div id="pavtestimonial888875425" class="carousel slide pavtestimonial">
   		<div class="box-heading">
			<span>What Peopel Say</span>
		</div>
		<div class="carousel-inner">
			 				<div class="item active">
	 				<div class="testimonial-item">
												<div class="testimonial">
							<div><p><br></p></div>
						</div>
												<div class="t-avatar pull-left"><img  alt="&nbsp;Lorem Ipsum proin gravida nibh vel velit auctor aliquet aenean sollicitudin, lorem quis sem nibh id elit. duis sed odio sit amet nibh vulputate amet mauris elita cumsan velit.&nbsp;Person 1 AAAA dist - BBBB city" src="<?= base_url(); ?>/image/cache/catalog/demo/banners/avatar-142x149.png" class="img-circle"/></div>
												<div class="profile">
							<div><p><i class="fa fa-quote-left fa-fw">&nbsp;</i>Lorem Ipsum proin gravida nibh vel velit auctor aliquet aenean sollicitudin, lorem quis sem nibh id elit. duis sed odio sit amet nibh vulputate amet mauris elita cumsan velit.<i class="fa fa-quote-right fa-fw">&nbsp;</i></p><p>Person 1 AAAA dist - BBBB city</p></div>
						</div>
																	</div>
				</div>
							<div class="item ">
	 				<div class="testimonial-item">
												<div class="testimonial">
							<div><p><br></p></div>
						</div>
												<div class="t-avatar pull-left"><img  alt="&nbsp;Lorem Ipsum proin gravida nibh vel velit auctor aliquet aenean sollicitudin, lorem quis sem nibh id elit. duis sed odio sit amet nibh vulputate amet mauris elita cumsan velit.&nbsp;Person 1 AAAA dist - BBBB city" src="<?= base_url(); ?>/image/cache/catalog/demo/banners/avatar01-142x149.png" class="img-circle"/></div>
												<div class="profile">
							<div><p><i class="fa fa-quote-left fa-fw">&nbsp;</i>Lorem Ipsum proin gravida nibh vel velit auctor aliquet aenean sollicitudin, lorem quis sem nibh id elit. duis sed odio sit amet nibh vulputate amet mauris elita cumsan velit.<i class="fa fa-quote-right fa-fw">&nbsp;</i></p><p>Person 1 AAAA dist - BBBB city</p></div>
						</div>
																	</div>
				</div>
					</div>
	 		
				<div class="carousel-controls">
			<a class="carousel-control left fa fa-angle-left" href="<?= base_url(); ?>/#pavtestimonial888875425" data-slide="prev"></a>
			<a class="carousel-control right fa fa-angle-right" href="<?= base_url(); ?>/#pavtestimonial888875425" data-slide="next"></a>	
		</div>	
		    </div>
		<script type="text/javascript">
	<!--
		$('#pavtestimonial888875425').carousel({interval:8000,auto:true,pause:'hover'});
	-->
	<!-- </script>
		<script type="text/javascript"><!--
		$(document).ready(function() {
		  $('.colorbox-t').magnificPopup({iframe:true, innerWidth:640, innerHeight:390});
		});
</script>//
                   			                	                	            </div></div> -->
	        	            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 "><div class="col-inner  ">
	                	                		                     		<div id="pavcarousel1" class="carousel slide pavcarousel">
	<div class="box-heading">
		<span>Top Brand</span>
	</div> 

	<div class="carousel-inner">
		
				<div class="item active">
									<div class="row">
				
				<div class="col-md-4 col-xs-4 col-sm-4">
					<div class="item-inner">
												<a href="#"><img src="<?= base_url(); ?>/image/cache/catalog/demo/manufacturer/nintendo-180x79.png" alt="demo" class="img-responsive" /></a>
											</div>
				</div>

										
				<div class="col-md-4 col-xs-4 col-sm-4">
					<div class="item-inner">
												<a href="#"><img src="<?= base_url(); ?>/image/cache/catalog/demo/manufacturer/starbucks-180x79.png" alt="demo" class="img-responsive" /></a>
											</div>
				</div>

										
				<div class="col-md-4 col-xs-4 col-sm-4">
					<div class="item-inner">
												<a href="#"><img src="<?= base_url(); ?>/image/cache/catalog/demo/manufacturer/disney-180x79.png" alt="demo" class="img-responsive" /></a>
											</div>
				</div>

							</div>
												<div class="row">
				
				<div class="col-md-4 col-xs-4 col-sm-4">
					<div class="item-inner">
												<a href="#"><img src="<?= base_url(); ?>/image/cache/catalog/demo/manufacturer/dell-180x79.png" alt="demo" class="img-responsive" /></a>
											</div>
				</div>

										
				<div class="col-md-4 col-xs-4 col-sm-4">
					<div class="item-inner">
												<a href="#"><img src="<?= base_url(); ?>/image/cache/catalog/demo/manufacturer/harley-180x79.png" alt="demo" class="img-responsive" /></a>
											</div>
				</div>

										
				<div class="col-md-4 col-xs-4 col-sm-4">
					<div class="item-inner">
												<a href="#"><img src="<?= base_url(); ?>/image/cache/catalog/demo/manufacturer/nfl-180x79.png" alt="demo" class="img-responsive" /></a>
											</div>
				</div>

							</div>
								</div>
				<div class="item ">
									<div class="row">
				
				<div class="col-md-4 col-xs-4 col-sm-4">
					<div class="item-inner">
												<a href="#"><img src="<?= base_url(); ?>/image/cache/catalog/demo/manufacturer/redbull-180x79.png" alt="demo" class="img-responsive" /></a>
											</div>
				</div>

										
				<div class="col-md-4 col-xs-4 col-sm-4">
					<div class="item-inner">
												<a href="#"><img src="<?= base_url(); ?>/image/cache/catalog/demo/manufacturer/cocacola-180x79.png" alt="demo" class="img-responsive" /></a>
											</div>
				</div>

										
				<div class="col-md-4 col-xs-4 col-sm-4">
					<div class="item-inner">
												<a href="#"><img src="<?= base_url(); ?>/image/cache/catalog/demo/manufacturer/sony-180x79.png" alt="demo" class="img-responsive" /></a>
											</div>
				</div>

							</div>
							<div class="row">
				
				<div class="col-md-4 col-xs-4 col-sm-4">
					<div class="item-inner">
												<a href="#"><img src="<?= base_url(); ?>/image/cache/catalog/demo/manufacturer/burgerking-180x79.png" alt="demo" class="img-responsive" /></a>
											</div>
				</div>

										
				<div class="col-md-4 col-xs-4 col-sm-4">
					<div class="item-inner">
												<a href="#"><img src="<?= base_url(); ?>/image/cache/catalog/demo/manufacturer/canon-180x79.png" alt="demo" class="img-responsive" /></a>
											</div>
				</div>

							</div>
								</div>
			
	</div>

		
		<a style="top: 54% !important;" class="carousel-control left fa fa-angle-left" href="<?= base_url(); ?>/#pavcarousel1" data-slide="prev"></a>
		<a style="top: 54% !important;" class="carousel-control right fa fa-angle-right" href="<?= base_url(); ?>/#pavcarousel1" data-slide="next"></a>	
	
	 

</div>
<script type="text/javascript">
$('#pavcarousel1').carousel({interval:false});
</script>

                   			                	                	            </div></div>
	        	    </div></div>
	    	            </div>
	        </div>
<!-- 	    	    	        <div class="container" >
	        	<div class="pav-inner" >
	      
	    <div class="row row-level-1 "><div class="row-inner  clearfix" >
	        	            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 "><div class="col-inner  ">
	                	                		                     				<div class="box-module-pavreassurances ">
				<div class="row box-outer">
																			<div class="col-md-4 col-sm-4 col-xs-12 column">
								<div class="reassurances-center">
									<span class="icon-name fa fa fa-truck"></span>
									<div class="description">
										<h4>Free shipping today</h4>
										<p>On Orders Over $99</p>										<!-- Button trigger modal -->
										<!-- <button type="button" class="arrow" data-toggle="modal" data-target="#myModal1"><i class="fa fa-long-arrow-right"></i></button>
										<div class="mask" style="display:none;">
											<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. </p>										</div>
									</div>
								</div>
								<!-- Modal --><!-- 
							<div class="modal fadepsample <div class="modal-dialog">
								    <div class="modal-content">
								      <div class="modal-header">							        
								        <span class="icon-name fa fa fa-truck"></span>
								        <div class="description">
									        <h4>Free shipping today</h4>
									        <p>On Orders Over $99</p>									    </div>
								      </div>
								      <div class="modal-body">
								       		<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. </p>								      </div>
								      <div class="modal-footer">
								        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
								      </div>
								    </div>
								  </div>
								</div>
							</div>
							
																				<div class="col-md-4 col-sm-4 col-xs-12 column">
								<div class="reassurances-center">
									<span class="icon-name fa fa fa-gift"></span>
									<div class="description">
										<h4>Extra saving in stores</h4>
										<p>Give The Perfect Gift</p> -->										<!-- Button trigger modal -->
										<!-- <button type="button" class="arrow" data-toggle="modal" data-target="#myModal2"><i class="fa fa-long-arrow-right"></i></button>
										<div class="mask" style="display:none;">
											<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. </p>										</div>
									</div>
								</div> -->
								<!-- Modal -->
					<!-- 		<div class="modal fadepsample <div class="modal-dialog">
								    <div class="modal-content">
								      <div class="modal-header">							        
								        <span class="icon-name fa fa fa-gift"></span>
								        <div class="description">
									        <h4>Extra saving in stores</h4>
									        <p>Give The Perfect Gift</p>									    </div>
								      </div>
								      <div class="modal-body">
								       		<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. </p>								      </div>
								      <div class="modal-footer">
								        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
								      </div>
								    </div>
								  </div>
								</div>
							</div>
							
																				<div class="col-md-4 col-sm-4 col-xs-12 column">
								<div class="reassurances-center">
									<span class="icon-name fa fa fa-phone"></span>
									<div class="description">
										<h4>24/24 online support</h4>
										<p>Anywhere worldwide</p> -->										<!-- Button trigger modal -->
										<!-- <button type="button" class="arrow" data-toggle="modal" data-target="#myModal3"><i class="fa fa-long-arrow-right"></i></button>
										<div class="mask" style="display:none;">
											<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; </p>										</div>
									</div>
								</div> -->
								<!-- Modal -->
							<!-- <div class="modal fadepsample <div class="modal-dialog">
								    <div class="modal-content">
								      <div class="modal-header">							        
								        <span class="icon-name fa fa fa-phone"></span>
								        <div class="description">
									        <h4>24/24 online support</h4>
									        <p>Anywhere worldwide</p>									    </div>
								      </div>
								      <div class="modal-body">
								       		<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; </p>								      </div>
								      <div class="modal-footer">
								        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
								      </div>
								    </div>
								  </div>
								</div>
							</div>
							
																	</div>
		</div>
	                   			                	                	            </div>
	                   			                	                	            </div>
	        	    </div>  -->
	        	    </div>
	        	    </div>
	        	    </div>
	        	    </div>
	        	    </div>

	<!--         	    </div>
	    	            </div>
	        </div>
	     


	
   	</div>
   </div> 
</div>
</div>
</div> -->
 
<!-- 
  $ospans: allow overrides width of colupsamplem 1->12]
 -->



