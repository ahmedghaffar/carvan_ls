
<div class="container" style="margin-top: 5%">
<div class="header">
<h1 class="hs1">Payment Options</h1>
</div>
<div class="row">
<div class="col-md-6">
  
  <div class="panel panel-default text-center" style="padding: 4%">
  <a class="text-center" data-toggle="collapse" href="#multiCollapseExample1" role="button" aria-expanded="false" aria-controls="multiCollapseExample1"><i class="fa fa-plus fa-4x"></i><br>Add New Card</a>
  </div>

</div>
<div class="col-md-6">
  
  <div class="panel panel-default">
  	<div class="panel-heading text-center hs2">Default</div>
  	<div class="panel-body">
  		<p><i class="fa fa-cc-visa"></i> Visa ending in 2334</p>
  		<p>expires : 01/2021</p>
  	</div>
  </div>

</div>

<div class="row" style="margin-top: 10%">
  <div class="col-md-12">
    <div class="collapse multi-collapse" id="multiCollapseExample1">
      <div class="card card-body">
        <h1 class="hs2">Enter Your Card Information</h1>
        <form>
        	<div class="form-group required">
                  <div class="col-md-3">
                  	Name on Card
                  	<input type="text" name="cardname" class="form-control">
                  </div>
                  <div class="col-md-3">
                  	Card Number<br>
                  	<input type="text" name="cardno" class="form-control">
                  </div>
                  <div class="col-md-3">
                  	Expiration Date<br>
                  	<div  style="margin-top: 4px">
                  	<select class="drop">
                  		<option>01</option>
                  		<option>02</option>                  		
                  		<option>03</option>
                  		<option>04</option>
                  		<option>05</option>
                  		<option>06</option>
                  		<option>07</option>
                  		<option>08</option>
                  		<option>09</option>
                  		<option>10</option>
                  		<option>11</option>
                  		<option>12</option>
                  	</select>
                  	<select class="drop">
                  		<option>2018</option>
                  		<option>2019</option>                  		
                  		<option>2020</option>
                  		<option>2021</option>
                  		<option>2022</option>
                  		<option>2023</option>
                  		<option>2024</option>
                  		<option>2025</option>
                  		<option>2026</option>
                  		<option>2027</option>
                  		<option>2028</option>
                  		<option>2029</option>
                  		<option>2030</option>
                  	</select>	
                  </div>
                  </div>
                  <div class="col-md-3" style="padding: 23px">
                  	<button class="btn btn-primary">Add Your Card</button>
                  </div>
                </div>
        </form>
      </div>
    </div>
  </div>
</div>


</div>
</div>
