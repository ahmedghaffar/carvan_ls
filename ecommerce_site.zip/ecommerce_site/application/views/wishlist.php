<div class="container">
	<div class="header">
        <h1 class="hs1" style="margin-top: 5%">Your Wishlist</h1>
    </div>
    <div class="row">
        <div class="col-md-12">
        	<div class="panel panel-default">
  				<div class="panel-body">
    				<div class="row">
    					<div class="col-md-3">
    						<div class="image">
			      				<a class="img" href="psample"><img src="<?= base_url(); ?>/image/cache/catalog/demo/product_05-199x201.jpg" alt="iPod Classic" class="img-responsive" /></a>
							</div>
    					</div>
    					<div class="col-md-6">
    						<p class="hs2">New Electric Juice Cup Mini Portable <br>Fruit & Vegetable Blender BX 600G - GLASS BLENDER<br> WITH GRINDER AND MINCER CHOPPER</p>
    						<p class="fs2">$20</p>
    						<div class="fs2">Qiantity<select class="drop">
    							<option>1</option>
    							<option>2</option>
    							<option>3</option>
    							<option>4</option>
    							<option>5</option>
    							<option>6</option>
    							<option>7</option>
    						</select></div>
    					</div>
    					<div class="col-md-3">
    						<button class="btn btn-primary" style="width: 90%; margin-top: 5px">Add to Basket</button>
    						<button class="btn btn-primary" style="width: 90%; margin-top: 5px">Purchase & Checkout</button>
    						<button class="btn btn-primary" style="width: 90%; margin-top: 5px">Remove</button>
    					</div>
    				</div>
  				</div>
			</div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
        	<div class="panel panel-default">
  				<div class="panel-body">
    				<div class="row">
    					<div class="col-md-3">
    						<div class="image">
			      				<a class="img" href="psample"><img src="<?= base_url(); ?>/image/cache/catalog/demo/product_06-199x201.jpg" alt="iPod Classic" class="img-responsive" /></a>
							</div>
    					</div>
    					<div class="col-md-6">
    						<p class="hs2">New Electric Juice Cup Mini Portable <br>Fruit & Vegetable Blender BX 600G - GLASS BLENDER<br> WITH GRINDER AND MINCER CHOPPER</p>
    						<p class="fs2">$20</p>
    						<div class="fs2">Qiantity<select class="drop">
    							<option>1</option>
    							<option>2</option>
    							<option>3</option>
    							<option>4</option>
    							<option>5</option>
    							<option>6</option>
    							<option>7</option>
    						</select></div>
    					</div>
    					<div class="col-md-3">
    						<button class="btn btn-primary" style="width: 90%; margin-top: 5px">Add to Basket</button>
    						<button class="btn btn-primary" style="width: 90%; margin-top: 5px">Purchase & Checkout</button>
    						<button class="btn btn-primary" style="width: 90%; margin-top: 5px">Remove</button>
    					</div>
    				</div>
  				</div>
			</div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
        	<div class="panel panel-default">
  				<div class="panel-body">
    				<div class="row">
    					<div class="col-md-3">
    						<div class="image">
			      				<a class="img" href="psample"><img src="<?= base_url(); ?>/image/cache/catalog/demo/product_09-199x201.jpg" alt="iPod Classic" class="img-responsive" /></a>
							</div>
    					</div>
    					<div class="col-md-6">
    						<p class="hs2">New Electric Juice Cup Mini Portable <br>Fruit & Vegetable Blender BX 600G - GLASS BLENDER<br> WITH GRINDER AND MINCER CHOPPER</p>
    						<p class="fs2">$20</p>
    						<div class="fs2">Qiantity<select class="drop">
    							<option>1</option>
    							<option>2</option>
    							<option>3</option>
    							<option>4</option>
    							<option>5</option>
    							<option>6</option>
    							<option>7</option>
    						</select></div>
    					</div>
    					<div class="col-md-3">
    						<button class="btn btn-primary" style="width: 90%; margin-top: 5px">Add to Basket</button>
    						<button class="btn btn-primary" style="width: 90%; margin-top: 5px">Purchase & Checkout</button>
    						<button class="btn btn-primary" style="width: 90%; margin-top: 5px">Remove</button>
    					</div>
    				</div>
  				</div>
			</div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
        	<div class="panel panel-default">
  				<div class="panel-body">
    				<div class="row">
    					<div class="col-md-3">
    						<div class="image">
			      				<a class="img" href="psample"><img src="<?= base_url(); ?>/image/cache/catalog/demo/product_08-199x201.jpg" alt="iPod Classic" class="img-responsive" /></a>
							</div>
    					</div>
    					<div class="col-md-6">
    						<p class="hs2">New Electric Juice Cup Mini Portable <br>Fruit & Vegetable Blender BX 600G - GLASS BLENDER<br> WITH GRINDER AND MINCER CHOPPER</p>
    						<p class="fs2">$20</p>
    						<div class="fs2">Qiantity<select class="drop">
    							<option>1</option>
    							<option>2</option>
    							<option>3</option>
    							<option>4</option>
    							<option>5</option>
    							<option>6</option>
    							<option>7</option>
    						</select></div>
    					</div>
    					<div class="col-md-3">
    						<button class="btn btn-primary" style="width: 90%; margin-top: 5px">Add to Basket</button>
    						<button class="btn btn-primary" style="width: 90%; margin-top: 5px">Purchase & Checkout</button>
    						<button class="btn btn-primary" style="width: 90%; margin-top: 5px">Remove</button>
    					</div>
    				</div>
  				</div>
			</div>
        </div>
    </div>
</div>