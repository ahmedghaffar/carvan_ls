

<div class="container">
	<div class="row">
	  <div class="header" style="padding: 20px; margin-top: 35px" >
	   <h3>Your Account</h3>
	  </div>
		<div class="col-md-4 col-sm-4 col-xs-12">
		 <div class="panel panel default">
			<a style="display: flex;" href="#"><img class="img-responsive" src="<?= base_url(); ?>/assets/img/orders.png" alt="demo"  style="padding: 10px; width: 130px; height: 100px" />
			<span style="padding: 10px; margin-top: 20px"><p><b>Your Orders</b><br>
			Track, return, or buy things again</p></span><br>
			</a>
		 </div>
		</div>
		<div class="col-md-4 col-sm-4 col-xs-12">
		 <div class="panel panel default">
			<a style="display: flex;" href="#"><img src="<?= base_url(); ?>/assets/img/Lock.png" alt="demo" class="img-responsive"   style="padding: 10px; width: 130px; height: 100px" />
			<span style="padding: 10px; margin-top: 15px"><p><b>Login & security</b><br>
			Edit login, name, and mobile number</p></span>
			</a>
		 </div>
		</div>
		<div class="col-md-4 col-sm-4 col-xs-12">
		 <div class="panel panel default">
			<a style="display: flex;" href="#"><img src="<?= base_url(); ?>/assets/img/benefits.png" alt="demo" class="img-responsive" style="padding: 10px; width: 130px; height: 100px"/>
			<span style="padding: 10px; margin-top: 20px"><p><b>Prime</b><br>
			View benefits and payment settings</p></span>
			</a>
		 </div>
		</div>
		</div>

		<div class="row">
		<div class="col-md-4 col-sm-4 col-xs-12">
		 <div class="panel panel default">
			<a style="display: flex;" href="#"><img src="<?= base_url(); ?>/assets/img/location.png" alt="demo" class="img-responsive" style="padding: 10px; width: 130px; height: 100px"/>
			<span style="padding: 10px; margin-top: 10px"><p><b>Your Address</b><br>
			Edit address and delivery prefereneces for orders and gifts</p></span>
			</a>
		 </div>
		</div>
		<div class="col-md-4 col-sm-4 col-xs-12">
		 <div class="panel panel default">
			<a style="display: flex;" href="#"><img src="<?= base_url(); ?>/assets/img/payment.png" alt="demo" class="img-responsive" style="padding: 10px; width: 130px; height: 100px" />
			<span style="padding: 10px; margin-top: 20px"><p><b>Payments options</b><br>
			Edit or add payment methods</p></span>
			</a>
		 </div>
		</div>
		<div class="col-md-4 col-sm-4 col-xs-12">
		 <div class="panel panel default">
			<a style="display: flex;" href="#"><img src="<?= base_url(); ?>/assets/img/gift-card.png" alt="demo" class="img-responsive" style="padding: 10px; width: 130px; height: 100px" />
			<span style="padding: 10px; margin-top: 20px"><p><b>Gift Cards & Top Up</b><br>
			View balance or redeem a card</p></span>
			</a>
		 </div>
		</div>
	</div>


	<hr>


	<div class="row">
		<div class="col-md-4 col-sm-4 col-xs-12">
		 <div class="panel panel default">
		 	<div style="padding: 10px">
				<ul style="line-height: 2">
					<li><h3>Digital content and devices</h3></li>
					<li><a href="#">Carrovan Drive</a></li>
					<li><a href="#">Apps and more</a></li>
					<li><a href="#">Audible settings</a></li>
					<li><a href="#">Content and devices</a></li>
					<li><a href="#">Games and software</a></li>
					<li><a href="#">Music settings</a></li>
					<li><a href="#">Video settings</a></li>
					<li><a href="#">Digital and device forum</a></li>
				</ul>
			</div>
		 </div>
		</div>
		<div class="col-md-4 col-sm-4 col-xs-12">
		 <div class="panel panel default">
			<div style="padding: 10px">
				<ul style="line-height: 2">
					<li><h3>E-mail alerts, messages, and ads</h3></li>
					<li><a href="#">Advertising preferences</a></li>
					<li><a href="#">Communication preferences</a></li>
					<li><a href="#">Text tracking numbers (UK +44 numbers)</a></li>
					<li><a href="#">Message centre</a></li>
					<li><br></li>
					<li><br></li>
					<li><br></li>
					<li><br></li>
				</ul>
			</div>
		 </div>
		</div>
		<div class="col-md-4 col-sm-4 col-xs-12">
		 <div class="panel panel default">
		 	<div style="padding: 10px">
		 	 <h4><b>More ways to pay</b></h4>
				<ul style="line-height: 2; color: blue">
					<li><a href="#">1-Click settings</a></li>
					<li><a href="#">Carrovan money store</a></li>
					<li><a href="#">Carrovan Pay</a></li>
					<li><a href="#">Carrovan Coins</a></li>
					<li><a href="#">Coupons</a></li>
					<li><a href="#">Shop with points</a></li>
					<li><br></li>
					<li><br></li>
				</ul>
			</div>
		 </div>
		</div>
	</div>

</div>