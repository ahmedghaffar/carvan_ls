<DOCTYPE html>
<!--[if IE]><![endif]-->
<!--[if IE 8 ]><html dir="ltr" lang="en" class="ie8"><![endif]-->
<!--[if IE 9 ]><html dir="ltr" lang="en" class="ie9"><![endif]-->
<!--[if (gt IE 9)|!(IE)]><!-->
<html dir="ltr" class="ltr" lang="en">
<!--<![endif]-->

<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>Carrovan</title>
<base  />
<meta name="description" content="My Store" />
<link href="<?= base_url(); ?>/image/catalog/cart.png" rel="icon" />
<link href="<?= base_url(); ?>/catalog/view/theme/lexus_shopping/stylesheet/bootstrap.css" rel="stylesheet" />
<link href="<?= base_url(); ?>/catalog/view/theme/lexus_shopping/stylesheet/product.css" rel="stylesheet" />

<link href="<?= base_url(); ?>/catalog/view/theme/lexus_shopping/stylesheet/stylesheet.css" rel="stylesheet" />
<link href="<?= base_url(); ?>/catalog/view/theme/lexus_shopping/stylesheet/font.css" rel="stylesheet" />
<link href="<?= base_url(); ?>/catalog/view/theme/lexus_shopping/stylesheet/paneltool.css" rel="stylesheet" />
<link href="<?= base_url(); ?>/catalog/view/javascript/jquery/colorpicker/css/colorpicker.css" rel="stylesheet" />
<link href="<?= base_url(); ?>/catalog/view/javascript/font-awesome/css/font-awesome.min.css" rel="stylesheet" />
<link href="<?= base_url(); ?>/catalog/view/javascript/jquery/magnific/magnific-popup.css" rel="stylesheet" />
<link href="<?= base_url(); ?>/catalog/view/theme/lexus_shopping/stylesheet/homebuilder.css" rel="stylesheet" />
<link href="<?= base_url(); ?>/catalog/view/theme/lexus_shopping/stylesheet/sliderlayer/css/typo.css" rel="stylesheet" />
<link href="<?= base_url(); ?>/catalog/view/theme/lexus_shopping/stylesheet/pavproductcarousel.css" rel="stylesheet" />
<link href="<?= base_url(); ?>/catalog/view/theme/lexus_shopping/stylesheet/pavcategorytabs.css" rel="stylesheet" />
<link href="<?= base_url(); ?>/catalog/view/theme/lexus_shopping/stylesheet/pavdeals.css" rel="stylesheet" />
<link href="<?= base_url(); ?>/catalog/view/theme/lexus_shopping/stylesheet/pavtestimonial.css" rel="stylesheet" />
<link href="<?= base_url(); ?>/catalog/view/theme/lexus_shopping/stylesheet/pavcarousel.css" rel="stylesheet" />
<link href="<?= base_url(); ?>/catalog/view/theme/lexus_shopping/stylesheet/pavreassurance.css" rel="stylesheet" />
<link href="<?= base_url(); ?>/catalog/view/theme/lexus_shopping/stylesheet/pavnewsletter.css" rel="stylesheet" />
<link href="<?= base_url(); ?>/catalog/view/theme/lexus_shopping/stylesheet/cd-style.css" rel="stylesheet" />
<script type="text/javascript" src="<?= base_url(); ?>/catalog/view/javascript/jquery/jquery-2.1.1.min.js"></script>
<script type="text/javascript" src="<?= base_url(); ?>/catalog/view/javascript/jquery/magnific/jquery.magnific-popup.min.js"></script>
<script type="text/javascript" src="<?= base_url(); ?>/catalog/view/javascript/bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="<?= base_url(); ?>/catalog/view/javascript/jquery.menu-aim.js"></script>
<script type="text/javascript" src="<?= base_url(); ?>/catalog/view/javascript/main.js"></script>
<script type="text/javascript" src="<?= base_url(); ?>/catalog/view/javascript/modernizr.js"></script>
<script type="text/javascript" src="<?= base_url(); ?>/catalog/view/javascript/common.js"></script>
<script type="text/javascript" src="<?= base_url(); ?>/catalog/view/theme/lexus_shopping/javascript/common.js"></script>
<script type="text/javascript" src="<?= base_url(); ?>/catalog/view/javascript/jquery/colorpicker/js/colorpicker.js"></script>
<script type="text/javascript" src="<?= base_url(); ?>/catalog/view/javascript/layerslider/jquery.themepunch.plugins.min.js"></script>
<script type="text/javascript" src="<?= base_url(); ?>/catalog/view/javascript/layerslider/jquery.themepunch.revolution.min.js"></script>
<script type="text/javascript" src="<?= base_url(); ?>/catalog/view/javascript/pavdeals/countdown.js"></script>


<!-- CUSTOM FONT -->
<!-- <style>
body {
  display: flex;
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
  flex-direction: column;
  min-height: 100vh;
}


</style> -->

<style>

body {
  display: flex;
  margin: 0;
  font-family: Calibri !important;
  flex-direction: column;
  min-height: 100vh;
}

div.product-meta
{
  text-align: center;
}

#footer {
  margin: auto 0 0 0;
}

@media screen and (max-width: 600px) {
  .footer
  {
    flex-shrink: 0;
  }
 }

#round {
    width: 100%;
    border-radius: 15px;
}
#round1{ 
	width: 100%;
	border-radius: 0px 15px 15px 0px;
	}
#footer {
  margin: auto 0 0 0;
}

.topnav {
  background-color: #232f3e;
  color: white;
}
#btn {
  background:#CCCCCC;
  }
/*.topnav a {
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 5px 16px !important;
  text-decoration: none;
  font-size: 17px;
}*/

.topnav a:hover {
  color: #009bcb;
}


.topnav .icon {
  display: none;
}

@media screen and (max-width: 600px) {
  .topnav a:not(:first-child) {display: none;}
  .topnav a.icon {
    display: block;
  }
}
@media screen and (max-width: 600px) 
 {
  .topnav.responsive {position: relative;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
  .footer
  {
  	flex-shrink: 0;
  }
 }
}

</style>

<!-- CUSTOM FONT -->



</head>
<body class="common-home page-home layout-fullwidth">
  

 
<header id="header-main" class="menu-search">
	<div class="row">	
		<div class="col-md-12" style="margin-top: -15px">
			<div class="col-md-2 col-sm-2 col-xs-6 logo inner">					
				<div id="logo" class="logo-store">
					<a href="index1">
						<img src="<?= base_url(); ?>/image/catalog/123.png" title="Your Store" alt="Your Store" class="img-responsive" style="margin-top: -8px" />
					</a>					
				</div>
			</div>
			<div class="col-md-6 col-sm-5 col-xs-6 box-search inner">
				<div id="search" class="input-group">
				  <input type="text" name="search" value="" placeholder="search..." class="form-control input-lg" id="round" />
				  <span class="input-group-btn">
				    <button type="button" class="btn btn-default btn-lg" id="round1" style="margin-left: -100%;z-index: 2;"><i class="fa fa-search"></i></button>
				  </span>
				</div>
			</div>
		
		    <div class="col-md-4 col-sm-3 col-xs-6 logo inner">					
				<div id="logo" class="logo-store">
					<a href="index9328.html?route=common/home">
						<img src="<?= base_url(); ?>/image/catalog/22.png" title="Your Store" alt="Your Store" class="img-responsive" />
					</a>					
				</div>
		    </div>
		</div>
	</div>
</header>
<!-- menu --> 
<!-- <div class="pav-mainnav">
<div class="topnav col-md-12 megamenu" id="myTopnav" role="navigation">
<div class="navbar-header">
 <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" id="btn">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar" style="background:#999999"></span>
                        <span class="icon-bar" style="background:#999999"></span>
                        <span class="icon-bar" style="background:#999999"></span>
                      </button>
</div>
<div class="collapse megamenu navbar-collapse" id="bs-example-navbar-collapse-1">
<ul class="nav navbar-nav navbar-right">

<li class=" aligned-fullwidth parent dropdown " >
  <a href="index98dc.html?route=product/category&amp;path=20" class="dropdown-toggle" data-toggle="dropdown">
    <span class="menu-title">Desktops</span>
    <b class="caret"></b>
  </a>
  <div class="dropdown-menu"  style="width:971px" >
    <div class="dropdown-menu-inner">
      <div class="row">
        <div class="mega-col col-xs-12 col-sm-12 col-md-2 " > 
          <div class="mega-col-inner">
            <div class="pavo-widget" id="pavowid-155b1281b3caa87">
              <div class="pavo-widget" id="pavowid-412330880">    
                <h3 class="menu-title"><span>Category</span></h3>
    
                <div class="">
                  <ul>
                    <li><a href="index98dc.html?route=product/category&amp;path=20"><span class="title">Desktops</span></a></li>
                    <li><a href="index68ea.html?route=product/category&amp;path=33"><span class="title">Cameras</span></a></li>
                    <li><a href="index70a9.html?route=product/category&amp;path=57"><span class="title">Tablets</span></a></li>
                    <li><a href="index7fa3.html?route=product/category&amp;path=18"><span class="title">Laptops &amp; Notebooks</span></a></li>
                    <li><a href="index1647.html?route=product/category&amp;path=25"><span class="title">Components</span></a></li>
                    <li><a href="indexb152.html?route=product/category&amp;path=17"><span class="title">Software</span></a></li>
                    <li><a href="indexc957.html?route=product/category&amp;path=24"><span class="title">Phones &amp; PDAs</span></a></li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</li>
<li><a href="#"><span class="menu-title" style="font-size: 13px"><b>Hot Deals</b></span></a></li>
<li><a href="#"><span class="menu-title" style="font-size: 13px"><b>Start Sale</b></span></a></li>
<li><a href="#"><span class="menu-title" style="font-size: 13px"><b>Help</b></span></a></li>
<li><a href="#"><i class="fa fa-shopping-cart icon-cart" style="margin: 0 7px;"></i><span class="menu-title" style="font-size: 13px"><b>Basket</b></span></a></li>
 
<li>
	<a href="<?= base_url(); ?>index.php/Account/Login"><i class="fa fa-user" style="margin: 0 7px;"></i><span class="menu-title" style="font-size: 13px"><b>LogIn</b></span></a>			
</li>

</ul>
</div>
</div>
</div> -->


  
<div id="pav-mainnav" class="topnav col-md-12">
  <div>
    <div class="">      
      <button data-toggle="offcanvas" id="#bs-megamenu" class="btn btn-default canvas-menu hidden-lg hidden-md hidden-sm" type="button"><span class="fa fa-bars"></span> Menu</button>
      <div class="hidden-xs">
        <div class="nav navbar-nav navbar-right">
          <div id="mainmenutop" class="" role="navigation">
            <div class="navbar-header">
              <div id="" class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav ">
                  <li class="menu-title">
                 <div class="cd-dropdown-wrapper">
      <a class="cd-dropdown-trigger" href="#0">Shop By Categories</a>
      <nav class="cd-dropdown">
        <h2>Title</h2>
        <a href="#0" class="cd-close">Close</a>
        <ul class="cd-dropdown-content">
          <li class="has-children">
            <a href="http://codyhouse.co/?p=748">Art Craft and Collectables</a>

            <ul class="cd-secondary-dropdown is-hidden">
              <li class="go-back"><a href="#0">Menu</a></li>
              <li class="has-children">
                <a href="http://codyhouse.co/?p=748">All Art Craft and Collectables</a>

                 <ul class="is-hidden">
                  
                  <li><a href="Antiques1">Antiques</a></li>
                  <li><a href="Drawing">Drawing and Paintings</a></li>
                  <li><a href="Handcrafts">Handcrafts, Scupture and Carvings</a></li>
                  <li><a href="Islamic">Islamic</a></li>
                  <li><a href="Prints">Prints and Posters</a></li>
                </ul>
              </li>
            </ul> <!-- .cd-secondary-dropdown -->
          </li> <!-- .has-children -->
          <li class="has-children">
            <a href="http://codyhouse.co/?p=748">Baby Items</a>

            <ul class="cd-secondary-dropdown is-hidden">
              <li class="go-back"><a href="#0">Menu</a></li>
              <li class="has-children">
                <a href="http://codyhouse.co/?p=748">All Baby Items</a>

                 <ul class="is-hidden">
                  
                  <li><a href="http://codyhouse.co/?p=748">Baby Accessories</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Baby Bags</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Baby Bath and Skin Care</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Baby Clothing and Shoes</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Baby Gear</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Baby Gift Sets</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Baby Safety and Health</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Baby Toys and Accessories</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Diapers</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Feeding</a></li>
                </ul>
              </li>
            </ul> <!-- .cd-secondary-dropdown -->
          </li> <!-- .has-children -->

          <li class="has-children">
            <a href="http://codyhouse.co/?p=748">Beauty</a>

            <ul class="cd-secondary-dropdown is-hidden">
              <li class="go-back"><a href="#0">Menu</a></li>
              <li class="has-children">
                <a href="http://codyhouse.co/?p=748">All Beauty</a>

                 <ul class="is-hidden">
                  
                  <li><a href="http://codyhouse.co/?p=748">Beauty Gift Sets</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Beauty Tools and Accessories</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Hair Care tools and Accessories</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Makeup</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Mirrors</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Skin Care</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Wigs</a></li>
                </ul>
              </li>
            </ul> <!-- .cd-secondary-dropdown -->
          </li> <!-- .has-children -->

          <li class="has-children">
            <a href="http://codyhouse.co/?p=748">Bed and Baths</a>

            <ul class="cd-secondary-dropdown is-hidden">
              <li class="go-back"><a href="#0">Menu</a></li>
              <li class="has-children">
                <a href="http://codyhouse.co/?p=748">All Bed and Baths</a>

                 <ul class="is-hidden">
                  
                  <li><a href="http://codyhouse.co/?p=748">Bathroom Equipments</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Bedding</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Blankets</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Curtains</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Mattresses</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Pillows</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Showers and Shower Heads</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Storage and Organization</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Towels</a></li>
                </ul>
              </li>
            </ul> <!-- .cd-secondary-dropdown -->
          </li> <!-- .has-children -->

          <li class="has-children">
            <a href="http://codyhouse.co/?p=748">Books</a>

            <ul class="cd-secondary-dropdown is-hidden">
              <li class="go-back"><a href="#0">Menu</a></li>
              <li class="has-children">
                <a href="http://codyhouse.co/?p=748">All Books</a>

                 <ul class="is-hidden">
                  
                  <li><a href="http://codyhouse.co/?p=748">Business and Trade Books</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Children's Books</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Comics and Graphic Novels</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Educataion, Learning and Self Help Books</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Life Style Books</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Literature and Fiction</a></li>
                </ul>
              </li>
            </ul> <!-- .cd-secondary-dropdown -->
          </li> <!-- .has-children -->

          
          <li class="has-children">
            <a href="http://codyhouse.co/?p=748">Cameras</a>

            <ul class="cd-secondary-dropdown is-hidden">
              <li class="go-back"><a href="#0">Menu</a></li>
              <li class="has-children">
                <a href="http://codyhouse.co/?p=748">All Cameras</a>

                 <ul class="is-hidden">
                  
                  <li><a href="http://codyhouse.co/?p=748">Analogue Camera</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Batteries</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Camcoders</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Cables</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Camera  Bags</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Camera and Camcoder Accessories</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Chargers</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Digital Cameras</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Digital Photo Frames</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Elecctronic Flashes</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Interchangable Lenses</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Memory Cards</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Screen Protectors</a></li>
                </ul>
              </li>
            </ul> <!-- .cd-secondary-dropdown -->
          </li> <!-- .has-children -->


          <li class="has-children">
            <a href="http://codyhouse.co/?p=748">Eyewear and Optics</a>

            <ul class="cd-secondary-dropdown is-hidden">
              <li class="go-back"><a href="#0">Menu</a></li>
              <li class="has-children">
                <a href="http://codyhouse.co/?p=748">All Eyewear and Optics</a>

                 <ul class="is-hidden">
                  
                  <li><a href="http://codyhouse.co/?p=748">Contact Lenses</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Eyewear</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Eyewear Accessories</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Glasses Frames</a></li>
                </ul>
              </li>
            </ul> <!-- .cd-secondary-dropdown -->
          </li> <!-- .has-children -->


          <li class="has-children">
            <a href="http://codyhouse.co/?p=748">Computer, IT and Networking</a>

            <ul class="cd-secondary-dropdown is-hidden">
              <li class="go-back"><a href="#0">Menu</a></li>
              <li class="has-children">
                <a href="http://codyhouse.co/?p=748">All Computer, IT and Networking</a>

                 <ul class="is-hidden">
                  
                  <li><a href="http://codyhouse.co/?p=748">Computer and Laptop Accessories</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Computer parts and Components</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Computer and Servers</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Networking and Accessories</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Printer, Scanners, Hardware and Acessories</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Software</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Laptop and Netbooks</a></li>
                  <li><a href="http://codyhouse.co/?p=748">VR Gadgets</a></li>
                </ul>
              </li>
            </ul> <!-- .cd-secondary-dropdown -->
          </li> <!-- .has-children -->

          <li class="has-children">
            <a href="http://codyhouse.co/?p=748">Electronics</a>

            <ul class="cd-secondary-dropdown is-hidden">
              <li class="go-back"><a href="#0">Menu</a></li>
              <li class="has-children">
                <a href="http://codyhouse.co/?p=748">All Electronics</a>

                 <ul class="is-hidden">
                  
                  <li><a href="http://codyhouse.co/?p=748">Audio and Accessories</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Batteries</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Binoculars and Telecscopes</a></li>
                  <li><a href="http://codyhouse.co/?p=748">CD Recording Media</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Clock Radios</a></li>
                  <li><a href="http://codyhouse.co/?p=748">E-Book Readers</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Home and Office Electronics</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Home Theater Systems</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Power Banks</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Projectors and Accessories</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Recording and Studio Equipments</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Security and Survelliance Systems</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Smart Watches</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Stereo System and Equilizers</a></li>
                  <li><a href="http://codyhouse.co/?p=748">VCD, VCP and VCR  Players</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Webcams</a></li>
                </ul>
              </li>
            </ul> <!-- .cd-secondary-dropdown -->
          </li> <!-- .has-children -->

          <li class="has-children">
            <a href="http://codyhouse.co/?p=748">Furniture</a>

            <ul class="cd-secondary-dropdown is-hidden">
              <li class="go-back"><a href="#0">Menu</a></li>
              <li class="has-children">
                <a href="http://codyhouse.co/?p=748">All Furniture</a>

                 <ul class="is-hidden">
                  
                  <li><a href="http://codyhouse.co/?p=748">Bedroom Sets</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Bed and Bed Frames</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Chair and Benches</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Garden Furniture</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Kitchen and Dinning room sets</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Living Room Sets</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Office Furniture</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Sofas and Bean bags</a></li>
                  <li><a href="http://codyhouse.co/?p=748">Tables</a></li>
                </ul>
              </li>
            </ul> <!-- .cd-secondary-dropdown -->
          </li> <!-- .has-children -->

          <li class="has-children">
            <a href="http://codyhouse.co/?p=748">Gaming</a>

            <ul class="cd-secondary-dropdown is-hidden">
              <li class="go-back"><a href="#0">Menu</a></li>
              <li class="has-children">
                <a href="http://codyhouse.co/?p=748">All Gaming</a>

                 <ul class="is-hidden">
                  
                  <li><a href="#">Gaming Consoles</a></li>
                  <li><a href="#">Video Games</a></li>
                  <li><a href="#">Games gadgets and Accessories</a></li>
                  <li><a href="#">VR Gadgets</a></li>
                </ul>
              </li>
            </ul> <!-- .cd-secondary-dropdown -->
          </li> <!-- .has-children -->


          <li class="has-children">
            <a href="http://codyhouse.co/?p=748">Garden and outdoors</a>

            <ul class="cd-secondary-dropdown is-hidden">
              <li class="go-back"><a href="#0">Menu</a></li>
              <li class="has-children">
                <a href="http://codyhouse.co/?p=748">All Garden and outdoors</a>

                 <ul class="is-hidden">
                  
                  <li><a href="#">Barbecue Tools and Accessories</a></li>
                  <li><a href="#">Flowers</a></li>
                  <li><a href="#">Garder Decoration</a></li>
                  <li><a href="#">Grills and Smokers</a></li>
                  <li><a href="#">Gardening and Water Supplies</a></li>
                </ul>
              </li>
            </ul> <!-- .cd-secondary-dropdown -->
          </li> <!-- .has-children -->

          <li class="has-children">
            <a href="http://codyhouse.co/?p=748">Grocery, Food and Beverages</a>

            <ul class="cd-secondary-dropdown is-hidden">
              <li class="go-back"><a href="#0">Menu</a></li>
              <li class="has-children">
                <a href="http://codyhouse.co/?p=748">All Grocery, Food and Beverages</a>

                 <ul class="is-hidden">
                  
                  <li><a href="#">Air Freshners</a></li>
                  <li><a href="#">Baby Food</a></li>
                  <li><a href="#">Bakery Items</a></li>
                  <li><a href="#">Beverages</a></li>
                  <li><a href="#">Cereals and Grains</a></li>
                  <li><a href="#">Cleaning Products</a></li>
                  <li><a href="#">Dairy Products</a></li>
                  <li><a href="#">Dry Food</a></li>
                  <li><a href="#">Fruits and Vegetables</a></li>
                  <li><a href="#">Meat and Chicken</a></li>
                  <li><a href="#">Pet Food</a></li>
                  <li><a href="#">Seafood</a></li>
                  <li><a href="#">Seasoning, Spices and Preservatives</a></li>
                </ul>
              </li>
            </ul> <!-- .cd-secondary-dropdown -->
          </li> <!-- .has-children -->

          <li class="has-children">
            <a href="http://codyhouse.co/?p=748">Health and Personal Care</a>

            <ul class="cd-secondary-dropdown is-hidden">
              <li class="go-back"><a href="#0">Menu</a></li>
              <li class="has-children">
                <a href="http://codyhouse.co/?p=748">All Health and Personal Care</a>

                 <ul class="is-hidden">
                  
                  <li><a href="#">Body Massagers</a></li>
                  <li><a href="#">Dental Care</a></li>
                  <li><a href="#">Personal Care</a></li>
                  <li><a href="#">Digital Fever Thermometers</a></li>
                  <li><a href="#">Electric Shavers</a></li>
                  <li><a href="#">Men's Grooming</a></li>
                  <li><a href="#">Personal Scales</a></li>
                  <li><a href="#">Small Medical Equipments</a></li>
                </ul>
              </li>
            </ul> <!-- .cd-secondary-dropdown -->
          </li> <!-- .has-children -->

          <li class="has-children">
            <a href="http://codyhouse.co/?p=748">Home Appliances</a>

            <ul class="cd-secondary-dropdown is-hidden">
              <li class="go-back"><a href="#0">Menu</a></li>
              <li class="has-children">
                <a href="http://codyhouse.co/?p=748">All Home Appliances</a>

                 <ul class="is-hidden">
                  
                  <li><a href="#">Heating and Cooling Equipments</a></li>
                  <li><a href="#">Irons and Streamers</a></li>
                  <li><a href="#">Televisions</a></li>
                  <li><a href="#">Parts and Accessories</a></li>
                </ul>
              </li>
            </ul> <!-- .cd-secondary-dropdown -->
          </li> <!-- .has-children -->

          <li class="has-children">
            <a href="http://codyhouse.co/?p=748">Home Décor and Furniture</a>

            <ul class="cd-secondary-dropdown is-hidden">
              <li class="go-back"><a href="#0">Menu</a></li>
              <li class="has-children">
                <a href="http://codyhouse.co/?p=748">All Home Décor and Furniture</a>

                 <ul class="is-hidden">
                  
                  <li><a href="#">Home décor</a></li>
                  <li><a href="#">Lamps and Lightenings</a></li>
                  <li><a href="#">Small Furniture</a></li>
                </ul>
              </li>
            </ul> <!-- .cd-secondary-dropdown -->
          </li> <!-- .has-children -->

          <li class="has-children">
            <a href="http://codyhouse.co/?p=748">Jewelry and Accessories</a>

            <ul class="cd-secondary-dropdown is-hidden">
              <li class="go-back"><a href="#0">Menu</a></li>
              <li class="has-children">
                <a href="http://codyhouse.co/?p=748">All Jewelry and Accessories</a>

                 <ul class="is-hidden">
                  
                  <li><a href="#">Braclets</a></li>
                  <li><a href="#">Earrings</a></li>
                  <li><a href="#">Jewlry Accessories</a></li>
                  <li><a href="#">Jewlry Sets</a></li>
                  <li><a href="#">Loose Gemstones and Diamonds</a></li>
                  <li><a href="#">Men's Jewelry</a></li>
                  <li><a href="#">Necklaces</a></li>
                  <li><a href="#">Pendants and Charms</a></li>
                  <li><a href="#">Rings</a></li>
                </ul>
              </li>
            </ul> <!-- .cd-secondary-dropdown -->
          </li> <!-- .has-children -->

          <li class="has-children">
            <a href="http://codyhouse.co/?p=748">Kitchen Appliances</a>

            <ul class="cd-secondary-dropdown is-hidden">
              <li class="go-back"><a href="#0">Menu</a></li>
              <li class="has-children">
                <a href="http://codyhouse.co/?p=748">All Kitchen Appliances</a>

                 <ul class="is-hidden">
                  
                  <li><a href="#">Blender and Mixers</a></li>
                  <li><a href="#">Coffee Makers</a></li>
                  <li><a href="#">Dishwashers</a></li>
                  <li><a href="#">Electric Meat Grinders</a></li>
                  <li><a href="#">Ice Cream Makers</a></li>
                  <li><a href="#">Juicers</a></li>
                  <li><a href="#">Kettles</a></li>
                  <li><a href="#">Microwaves</a></li>
                  <li><a href="#">Ovens, ranges and Stoves</a></li>
                  <li><a href="#">Refigrators and Freezers</a></li>
                  <li><a href="#">Rice Cookers</a></li>
                  <li><a href="#">Sandwich makers</a></li>
                  <li><a href="#">Special Kitchen Appliances</a></li>
                  <li><a href="#">Toasters</a></li>
                  <li><a href="#">Water Cooler and Dispensers</a></li>
                </ul>
              </li>
            </ul> <!-- .cd-secondary-dropdown -->
          </li> <!-- .has-children -->

          <li class="has-children">
            <a href="http://codyhouse.co/?p=748">Kitchen and Home Supplies</a>

            <ul class="cd-secondary-dropdown is-hidden">
              <li class="go-back"><a href="#0">Menu</a></li>
              <li class="has-children">
                <a href="http://codyhouse.co/?p=748">All Kitchen and Home Supplies</a>

                 <ul class="is-hidden">
                  
                  <li><a href="#">Bakeware and Accessories</a></li>
                  <li><a href="#">Cooking Utensils</a></li>
                  <li><a href="#">Cookware and Bakeware</a></li>
                  <li><a href="#">Cutlery and Flatware Sets</a></li>
                  <li><a href="#">Dinnerware and Serveware</a></li>
                  <li><a href="#">Drinkware</a></li>
                  <li><a href="#">Home Supplies</a></li>
                  <li><a href="#">Kitchen Accessories</a></li>
                  <li><a href="#">Kitchen Measuring Tools</a></li>
                  <li><a href="#">Kitchen Storage</a></li>
                  <li><a href="#">Table linens</a></li>
                </ul>
              </li>
            </ul> <!-- .cd-secondary-dropdown -->
          </li> <!-- .has-children -->

          <li class="has-children">
            <a href="http://codyhouse.co/?p=748">Mobile Phones, Tablets and Accessories</a>

            <ul class="cd-secondary-dropdown is-hidden">
              <li class="go-back"><a href="#0">Menu</a></li>
              <li class="has-children">
                <a href="http://codyhouse.co/?p=748">All Mobile Phones, Tablets and Accessories</a>

                 <ul class="is-hidden">
                  
                  <li><a href="#">Mobile Phones</a></li>
                  <li><a href="#">Screen Protectors</a></li>
                  <li><a href="#">Skins and Decals</a></li>
                  <li><a href="#">Smart Watches</a></li>
                  <li><a href="#">Tablets</a></li>
                  <li><a href="#">VR Gadgets</a></li>
                </ul>
              </li>
            </ul> <!-- .cd-secondary-dropdown -->
          </li> <!-- .has-children -->

          <li class="has-children">
            <a href="http://codyhouse.co/?p=748">Music and Movies</a>

            <ul class="cd-secondary-dropdown is-hidden">
              <li class="go-back"><a href="#0">Menu</a></li>
              <li class="has-children">
                <a href="http://codyhouse.co/?p=748">All Music and Movies</a>

                 <ul class="is-hidden">
                  
                  <li><a href="#">Guitars</a></li>
                  <li><a href="#">Movies, Play and Series</a></li>
                  <li><a href="#">Music CDs</a></li>
                  <li><a href="#">Musical Instruments</a></li>
                  <li><a href="#">Musical Instruments parts and Accessories</a></li>
                  <li><a href="#">Music Keyboards</a></li>
                  <li><a href="#">Tuners</a></li>
                </ul>
              </li>
            </ul> <!-- .cd-secondary-dropdown -->
          </li> <!-- .has-children -->

          <li class="has-children">
            <a href="http://codyhouse.co/?p=748">Office Products and Supplies</a>

            <ul class="cd-secondary-dropdown is-hidden">
              <li class="go-back"><a href="#0">Menu</a></li>
              <li class="has-children">
                <a href="http://codyhouse.co/?p=748">All Office Products and Supplies</a>

                 <ul class="is-hidden">
                  
                  <li><a href="#">Fax Machines</a></li>
                  <li><a href="#">Printers</a></li>
                  <li><a href="#">Office Equipments</a></li>
                  <li><a href="#">Office Supplies</a></li>
                  <li><a href="#">Printers</a></li>
                  <li><a href="#">Stationary</a></li>
                </ul>
              </li>
            </ul> <!-- .cd-secondary-dropdown -->
          </li> <!-- .has-children -->

          <li class="has-children">
            <a href="http://codyhouse.co/?p=748">Perfume and Fragnances</a>

            <ul class="cd-secondary-dropdown is-hidden">
              <li class="go-back"><a href="#0">Menu</a></li>
              <li class="has-children">
                <a href="http://codyhouse.co/?p=748">All Perfume and Fragnances</a>

                 <ul class="is-hidden">
                  
                  <li><a href="#">Perfume and Fragnances</a></li>
                  <li><a href="#">Perfume Gift Sets</a></li>
                </ul>
              </li>
            </ul> <!-- .cd-secondary-dropdown -->
          </li> <!-- .has-children -->

          <li class="has-children">
            <a href="http://codyhouse.co/?p=748">Pet Food and Supplies</a>

            <ul class="cd-secondary-dropdown is-hidden">
              <li class="go-back"><a href="#0">Menu</a></li>
              <li class="has-children">
                <a href="http://codyhouse.co/?p=748">All Pet Food and Supplies</a>

                 <ul class="is-hidden">
                  
                  <li><a href="#">Pet and Animal Foods</a></li>
                  <li><a href="#">Pet and Animal Supplies</a></li>
                </ul>
              </li>
            </ul> <!-- .cd-secondary-dropdown -->
          </li> <!-- .has-children -->

          <li class="has-children">
            <a href="http://codyhouse.co/?p=748">Sports and Fitness</a>

            <ul class="cd-secondary-dropdown is-hidden">
              <li class="go-back"><a href="#0">Menu</a></li>
              <li class="has-children">
                <a href="http://codyhouse.co/?p=748">All Sports and Fitness</a>

                 <ul class="is-hidden">
                  
                  <li><a href="#">Athletic Shoes</a></li>
                  <li><a href="#">Balls</a></li>
                  <li><a href="#">Bikes and Bicycles</a></li>
                  <li><a href="#">Cycling Goods</a></li>
                  <li><a href="#">Exercise Bikes</a></li>
                  <li><a href="#">Flash Lights</a></li>
                  <li><a href="#">Outdoor Play</a></li>
                  <li><a href="#">Protective Gear</a></li>
                  <li><a href="#">Rackets</a></li>
                  <li><a href="#">Scooter and Ride ons</a></li>
                  <li><a href="#">Sport Gloves</a></li>
                  <li><a href="#">Sporting Goods</a></li>
                  <li><a href="#">Sport Equipments</a></li>
                  <li><a href="#">Sport Watches</a></li>
                  <li><a href="#">Treadmills</a></li>
                  <li><a href="#">Weights and Dumbles</a></li>
                </ul>
              </li>
            </ul> <!-- .cd-secondary-dropdown -->
          </li> <!-- .has-children -->

          <li class="has-children">
            <a href="http://codyhouse.co/?p=748">Tools and Home Improvements</a>

            <ul class="cd-secondary-dropdown is-hidden">
              <li class="go-back"><a href="#0">Menu</a></li>
              <li class="has-children">
                <a href="http://codyhouse.co/?p=748">All Tools and Home Improvements</a>

                 <ul class="is-hidden">
                  
                  <li><a href="#">Drills</a></li>
                  <li><a href="#">Electrical and Electronic Accessories</a></li>
                  <li><a href="#">Hand Tools</a></li>
                  <li><a href="#">Measuring and layout Tools</a></li>
                  <li><a href="#">Nails, Screws and Fixings</a></li>
                  <li><a href="#">Paint and Supplies</a></li>
                  <li><a href="#">Power and Hand Tools Accessories</a></li>
                  <li><a href="#">Power Tools</a></li>
                  <li><a href="#">Safety and Work Wear Products</a></li>
                </ul>
              </li>
            </ul> <!-- .cd-secondary-dropdown -->
          </li> <!-- .has-children -->

          <li class="has-children">
            <a href="http://codyhouse.co/?p=748">Toys</a>

            <ul class="cd-secondary-dropdown is-hidden">
              <li class="go-back"><a href="#0">Menu</a></li>
              <li class="has-children">
                <a href="http://codyhouse.co/?p=748">All Toys</a>

                 <ul class="is-hidden">
                  
                  <li><a href="#">Toys</a></li>
                </ul>
              </li>
            </ul> <!-- .cd-secondary-dropdown -->
          </li> <!-- .has-children -->


        </ul> <!-- .cd-dropdown-content -->
      </nav> <!-- .cd-dropdown -->
    </div></li><li class="" ><a href="index388d.html?route=pavdeals/deals"><span class="menu-title">Hot Deals</span></a></li><li class="" ><a href="indexe903.html?route=pavblog/blogs"><span class="menu-title">Start Sale</span></a></li><li class="" ><a href="index2724.html?route=information/contact"><span class="menu-title">Help</span></a></li>
<li><a href="#"><i class="fa fa-shopping-cart icon-cart" style="margin: 0 7px;"></i><span class="menu-title" style="font-size: 13px"><b>Basket</b></span></a></li>
 
<li>
  <a href="<?= base_url(); ?>index.php/Account/Login"><i class="fa fa-user" style="margin: 0 7px;"></i><span class="menu-title" style="font-size: 13px"><b>LogIn</b></span></a>     
</li></ul>      </div>
       </div>
    </div>
  </div>
</div>       

          </div>
  </div>
</div>






<script type="text/javascript">
  
(function($) {

    $.fn.menuAim = function(opts) {
        // Initialize menu-aim for all elements in jQuery collection
        this.each(function() {
            init.call(this, opts);
        });

        return this;
    };

    function init(opts) {
        var $menu = $(this),
            activeRow = null,
            mouseLocs = [],
            lastDelayLoc = null,
            timeoutId = null,
            options = $.extend({
                rowSelector: "> li",
                submenuSelector: "*",
                submenuDirection: "right",
                tolerance: 75,  // bigger = more forgivey when entering submenu
                enter: $.noop,
                exit: $.noop,
                activate: $.noop,
                deactivate: $.noop,
                exitMenu: $.noop
            }, opts);

        var MOUSE_LOCS_TRACKED = 3,  // number of past mouse locations to track
            DELAY = 300;  // ms delay when user appears to be entering submenu

        /**
         * Keep track of the last few locations of the mouse.
         */
        var mousemoveDocument = function(e) {
                mouseLocs.push({x: e.pageX, y: e.pageY});

                if (mouseLocs.length > MOUSE_LOCS_TRACKED) {
                    mouseLocs.shift();
                }
            };

        /**
         * Cancel possible row activations when leaving the menu entirely
         */
        var mouseleaveMenu = function() {
                if (timeoutId) {
                    clearTimeout(timeoutId);
                }

                // If exitMenu is supplied and returns true, deactivate the
                // currently active row on menu exit.
                if (options.exitMenu(this)) {
                    if (activeRow) {
                        options.deactivate(activeRow);
                    }

                    activeRow = null;
                }
            };

        /**
         * Trigger a possible row activation whenever entering a new row.
         */
        var mouseenterRow = function() {
                if (timeoutId) {
                    // Cancel any previous activation delays
                    clearTimeout(timeoutId);
                }

                options.enter(this);
                possiblyActivate(this);
            },
            mouseleaveRow = function() {
                options.exit(this);
            };

        /*
         * Immediately activate a row if the user clicks on it.
         */
        var clickRow = function() {
                activate(this);
            };

        /**
         * Activate a menu row.
         */
        var activate = function(row) {
                if (row == activeRow) {
                    return;
                }

                if (activeRow) {
                    options.deactivate(activeRow);
                }

                options.activate(row);
                activeRow = row;
            };

        /**
         * Possibly activate a menu row. If mouse movement indicates that we
         * shouldn't activate yet because user may be trying to enter
         * a submenu's content, then delay and check again later.
         */
        var possiblyActivate = function(row) {
                var delay = activationDelay();

                if (delay) {
                    timeoutId = setTimeout(function() {
                        possiblyActivate(row);
                    }, delay);
                } else {
                    activate(row);
                }
            };

        /**
         * Return the amount of time that should be used as a delay before the
         * currently hovered row is activated.
         *
         * Returns 0 if the activation should happen immediately. Otherwise,
         * returns the number of milliseconds that should be delayed before
         * checking again to see if the row should be activated.
         */
        var activationDelay = function() {
                if (!activeRow || !$(activeRow).is(options.submenuSelector)) {
                    // If there is no other submenu row already active, then
                    // go ahead and activate immediately.
                    return 0;
                }

                var offset = $menu.offset(),
                    upperLeft = {
                        x: offset.left,
                        y: offset.top - options.tolerance
                    },
                    upperRight = {
                        x: offset.left + $menu.outerWidth(),
                        y: upperLeft.y
                    },
                    lowerLeft = {
                        x: offset.left,
                        y: offset.top + $menu.outerHeight() + options.tolerance
                    },
                    lowerRight = {
                        x: offset.left + $menu.outerWidth(),
                        y: lowerLeft.y
                    },
                    loc = mouseLocs[mouseLocs.length - 1],
                    prevLoc = mouseLocs[0];

                if (!loc) {
                    return 0;
                }

                if (!prevLoc) {
                    prevLoc = loc;
                }

                if (prevLoc.x < offset.left || prevLoc.x > lowerRight.x ||
                    prevLoc.y < offset.top || prevLoc.y > lowerRight.y) {
                    // If the previous mouse location was outside of the entire
                    // menu's bounds, immediately activate.
                    return 0;
                }

                if (lastDelayLoc &&
                        loc.x == lastDelayLoc.x && loc.y == lastDelayLoc.y) {
                    // If the mouse hasn't moved since the last time we checked
                    // for activation status, immediately activate.
                    return 0;
                }

                // Detect if the user is moving towards the currently activated
                // submenu.
                //
                // If the mouse is heading relatively clearly towards
                // the submenu's content, we should wait and give the user more
                // time before activating a new row. If the mouse is heading
                // elsewhere, we can immediately activate a new row.
                //
                // We detect this by calculating the slope formed between the
                // current mouse location and the upper/lower right points of
                // the menu. We do the same for the previous mouse location.
                // If the current mouse location's slopes are
                // increasing/decreasing appropriately compared to the
                // previous's, we know the user is moving toward the submenu.
                //
                // Note that since the y-axis increases as the cursor moves
                // down the screen, we are looking for the slope between the
                // cursor and the upper right corner to decrease over time, not
                // increase (somewhat counterintuitively).
                function slope(a, b) {
                    return (b.y - a.y) / (b.x - a.x);
                };

                var decreasingCorner = upperRight,
                    increasingCorner = lowerRight;

                // Our expectations for decreasing or increasing slope values
                // depends on which direction the submenu opens relative to the
                // main menu. By default, if the menu opens on the right, we
                // expect the slope between the cursor and the upper right
                // corner to decrease over time, as explained above. If the
                // submenu opens in a different direction, we change our slope
                // expectations.
                if (options.submenuDirection == "left") {
                    decreasingCorner = lowerLeft;
                    increasingCorner = upperLeft;
                } else if (options.submenuDirection == "below") {
                    decreasingCorner = lowerRight;
                    increasingCorner = lowerLeft;
                } else if (options.submenuDirection == "above") {
                    decreasingCorner = upperLeft;
                    increasingCorner = upperRight;
                }

                var decreasingSlope = slope(loc, decreasingCorner),
                    increasingSlope = slope(loc, increasingCorner),
                    prevDecreasingSlope = slope(prevLoc, decreasingCorner),
                    prevIncreasingSlope = slope(prevLoc, increasingCorner);

                if (decreasingSlope < prevDecreasingSlope &&
                        increasingSlope > prevIncreasingSlope) {
                    // Mouse is moving from previous location towards the
                    // currently activated submenu. Delay before activating a
                    // new menu row, because user may be moving into submenu.
                    lastDelayLoc = loc;
                    return DELAY;
                }

                lastDelayLoc = null;
                return 0;
            };

        /**
         * Hook up initial menu events
         */
        $menu
            .mouseleave(mouseleaveMenu)
            .find(options.rowSelector)
                .mouseenter(mouseenterRow)
                .mouseleave(mouseleaveRow)
                .click(clickRow);

        $(document).mousemove(mousemoveDocument);

    };
})(jQuery);


</script>