



  
<div class="container ">
  <div class="pav-inner" >
    <div class="row row-level-1 ">
      <div class="row-inner  clearfix" >
        <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12 " style="margin-top: 20px !important">
          <div class="col-inner  ">
            <div class="prefix box box-highlighted nopadding productcarousel" id="module31" style=" border-top: 1px solid #dbdbdb;border-right: 1px solid #dbdbdb !important;">
              <div class="box-heading" style="margin-right: 0px !important;"><span class="icon-heading" style="background: none !important;">&nbsp;</span><span class="hs1">Your Basket</span>
              </div>
              <table id="cart" class="table table-hover table-condensed">
                <thead>
                  <tr>
                    <th style="width:40%" class="hs2">Products</th>
                    <th style="width:15%" class="hs2">Price</th>
                    <th style="width:8%" class="hs2">Quantity</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td data-th="Product">
                      <div class="row">
                        <div class="col-sm-2 hidden-xs"><img src="<?= base_url(); ?>image/catalog/demo/product_10.jpg" alt="..." class="img-responsive"/></div>
                        <div class="col-sm-10">
                          <h4 class="nomargin"><a href="psample"> HP LP3065</a></h4>
                          <input name="Field" class="field login-checkbox" type="checkbox"><span style="margin-left: 10px;" class="fs2">Gift Wrap</span><br>
                          <a href="#" class="fs2">Delete</a> |
                          <a href="#" class="fs2">Add to wish list</a> |
                          <a href="#" class="fs2">Save for later</a> 
                        </div>
                      </div>
                    </td>
                    <td data-th="Price" class="fs2">$1.99</td>
                    <td data-th="Quantity">
                      <select class="drop">
                        <option>1</option>
                        <option>2</option>
                        <option>3</option>
                        <option>4</option>
                        <option>5</option>
                        <option>6</option>
                        <option>7</option>
                        <option>8</option>
                        <option>9</option>
                        <option>10</option>
                      </select>
                    </td>
                  </tr>
                  <tr>
                    <td data-th="Product">
                      <div class="row">
                        <div class="col-sm-2 hidden-xs"><img src="<?= base_url(); ?>image/catalog/demo/product_04.jpg" alt="..." class="img-responsive"/></div>
                        <div class="col-sm-10">
                          <h4 class="nomargin"><a href="psample">T-Shirt</a></h4>
                          <input name="Field" class="field login-checkbox" type="checkbox"><span style="margin-left: 10px;" class="fs2">Gift Wrap</span><br>
                          <a href="#" class="fs2">Delete</a> |
                          <a href="#" class="fs2">Add to wish list</a> |
                          <a href="#" class="fs2">Save for later</a> 
                        </div>
                      </div>
                    </td>
                    <td data-th="Price" class="fs2">$1.99</td>
                    <td data-th="Quantity">
                      <select class="drop">
                        <option>1</option>
                        <option>2</option>
                        <option>3</option>
                        <option>4</option>
                        <option>5</option>
                        <option>6</option>
                        <option>7</option>
                        <option>8</option>
                        <option>9</option>
                        <option>10</option>
                      </select>
                    </td>
                  </tr>
                </tbody>
                <tfoot>
                  <tr class="visible-xs">
                    <td class="text-center hs2"><strong>Total(2 items) 3.98</strong></td>
                  </tr>
                  <tr>
                    <td></td>
                    <td class="hidden-xs hs2"><strong>Total(2 items) $3.98</strong></td>
                    <td></td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>
        </div>


        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 text-center"  style="margin-top: 20px !important;">
          <div class="col-inner  ">
            <div class="prefix box box-highlighted nopadding productcarousel" id="module31" style=" border-top: 1px solid #dbdbdb;border-right: 1px solid #dbdbdb !important;">
              <div class="box-heading" style="margin-right: 0px !important;"><span class="icon-heading" style="background: none !important;">&nbsp;</span><span class="hs1">Customer Information</span>
              </div>
              <ul style="padding: 10px">
                <li class="fs3"> Delivery Address: <br> <p>Askari II, Lahore Cantt</p>
                  <a href="#">Change</a><br>
                </li><hr style="width: 90% !important;">
                <li class="fs3"> Total Price : 3.98 </li>
                <li style="margin-top: 5%"><button type="button" id="button-cart" data-loading-text="Loading..." class="btn btn-default">
                  Proceed to Checkout</button>
                </li>
              </ul>
            </div>
          </div>
        </div>

        <!-- <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12 " style="margin-top: 15px">
          <div class="col-inner  sidebar-right">
            <div class="pts-bannerbuilder clearfix hidden-sm hidden-xs">
              <div class="pts-container ">        
               <div class="pts-inner">
                <div class="row row-level-1">
                  <div class="col-lg-12 col-md-12 col-sm-6 col-xs-12"><div class="col-inner">
                    <div class="banner-wrapper">
                      <a href="desktop"><img alt="img" src="http://carrovan.ilegendtech.com/carrovan/image/catalog/demo/banners/banner4.jpg"  class="img-responsive">
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="pts-bannerbuilder clearfix hidden-sm hidden-xs">
          <div class="pts-container ">        
            <div class="pts-inner">
              <div class="row row-level-1">
                <div class="col-lg-12 col-md-12 col-sm-6 col-xs-12"><div class="col-inner">
                  <div class="banner-wrapper">
                    <a href="desktop"><img alt="img" src="http://carrovan.ilegendtech.com/carrovan/image/catalog/demo/banners/banner4.jpg"    class="img-responsive">
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div> -->
      </div>
    </div>
  </div>
</div> </div></div></div>                           
                                                              




                               