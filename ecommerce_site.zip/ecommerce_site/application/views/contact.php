<!-- sys-notification -->
<div id="sys-notification">
  <div class="container">
    <div id="notification"></div>
  </div>
</div>
<!-- /sys-notification -->






    <div class="container">
    
  
  <div class="row"> 
  
   <section id="sidebar-main" class="col-md-12"><div id="content">     
      <div class="wrapper">
      <div class="contact-location hidden-xs">
        <div id="contact-map"></div>
      </div>

      
      <form action="#" method="post" enctype="multipart/form-data" class="form-horizontal ">
        <div class="row contact-content">
        <!--                     <fieldset class="col-lg-4 col-md-4 col-sm-12 hidden-xs">
                <div class="contact-info">
                   <h3>Contact Us</h3>
                    <div class="contact-customhtml">
                      <div class="content">
                                                     <div class="panel-contact-custom">  
                            <p><br></p>                           </div>
                           
                          <div class="panel-contact-info">
                            <div class="panel-body">
                              <div class="row">
                                                     
                                    <div class="media">
                                      <div class="media-icon pull-left"><span class="fa fa-home fa-3x"></span></div>
                                      <div class="media-body">
                                        <div class="media-heading"><strong>Your Store</strong></div>
                                             <address>
                                            Address 1                                            </address>
                                                                                  </div>
                                    </div>

                                    <div class="media">
                                      <div class="media-icon pull-left"><span class="fa fa-phone fa-3x"></span></div>
                                      <div class="media-body">
                                        <div class="media-heading"><strong>Telephone</strong></div>
                                            123456789<br />
                                            <br />
                                                                                  </div>
                                    </div>
                                                                
                                   
                              </div>
                            </div>
                          </div>
                        
                        </div>
                      </div>
                    </div>
              </fieldset> -->
              <fieldset class="col-md-offset-2 col-lg-8 col-md-8 col-sm-12">
                <h3>Contact Form</h3>
                <div class="form-group required">
                  <label class="col-sm-2 control-label" for="input-name">Your Name</label>
                  <div class="col-sm-10">
                    <input type="text" name="name" value="" id="input-name" class="form-control" />
                                      </div>
                </div>
                <div class="form-group required">
                  <label class="col-sm-2 control-label" for="input-email">E-Mail Address</label>
                  <div class="col-sm-10">
                    <input type="text" name="email" value="" id="input-email" class="form-control" />
                                      </div>
                </div>
                <div class="form-group required">
                  <label class="col-sm-2 control-label" for="input-enquiry">Enquiry</label>
                  <div class="col-sm-10">
                    <textarea name="enquiry" rows="10" id="input-enquiry" class="form-control"></textarea>
                                      </div>
                </div><!-- 
                <fieldset>
  <legend>Captcha</legend>
  <div class="form-group required">
        <label class="col-sm-2 control-label" for="input-captcha">Enter the code in the box below</label>
    <div class="col-sm-10">
      <input type="text" name="captcha" id="input-captcha" class="form-control" />
      <img src="index24c7.jpg?route=extension/captcha/basic_captcha/captcha" alt="" />
          </div>
      </div>
</fieldset> -->
                 <div class="buttons">
                  <div class="pull-right">
                    <input class="btn btn-primary" type="submit" value="Submit" />
                  </div>
                </div>
              </fieldset>
        </div>      
       
      </form>
    </div>
      </div>
   </section> 
</div>

    <!--  <script type="text/javascript" src="catalog/view/javascript/gmap/gmap3.min.js"></script>
    <script type="text/javascript" src="catalog/view/javascript/gmap/gmap3.infobox.js"></script>
    <script type="text/javascript">
        var mapDiv, map, infobox;
        var lat = 40.705423;
        var lon = -74.008616;
        jQuery(document).ready(function($) {
            mapDiv = $("#contact-map");
            mapDiv.height(400).gmap3({
                map:{
                    options:{
                        center:[lat,lon],
                        zoom: 15
                    }
                },
                marker:{
                    values:[
                        {latLng:[lat, lon], data:"79-99 Beaver Street, New York, NY 10005, USA"},
                    ],
                    options:{
                        draggable: false
                    },
                    events:{
                          mouseover: function(marker, event, context){
                            var map = $(this).gmap3("get"),
                                infowindow = $(this).gmap3({get:{name:"infowindow"}});
                            if (infowindow){
                                infowindow.open(map, marker);
                                infowindow.setContent(context.data);
                            } else {
                                $(this).gmap3({
                                infowindow:{
                                    anchor:marker, 
                                    options:{content: context.data}
                                }
                              });
                            }
                        },
                        mouseout: function(){
                            var infowindow = $(this).gmap3({get:{name:"infowindow"}});
                            if (infowindow){
                                infowindow.close();
                            }
                        }
                    }
                }
            });
        });
    </script> -->
    </div>
 