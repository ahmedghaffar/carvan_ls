  
<!-- main body -->
  <div class="container">

  
  
<!-- <ul class="breadcrumb">
<li><a href="index9328.html?route=common/home"><i class="fa fa-home"></i></a></li>
<li><a href="index98dc.html?route=product/category&amp;path=20">Example</a></li>
</ul> -->

  <div class="row"> 
  
   <section id="sidebar-main" class="col-md-12"><div id="content">    <!--   <h1>Smart Phones</h1> -->
            <div class="category-info clearfix hidden-xs hidden-sm">
                        <div class="description">
</div>
              </div>
      
     <!--   	   <div class="subcategories box box-primary refine-search clearfix">
			<div class="box-heading">
			  <span>Refine Search </span>
		   </div> 
			  <div class="category-list clearfix box-content">  
 
					                        <ul>
                                <li class="category-item">
      							      							<a href="indexd9fe.html?route=product/category&amp;path=20_26">PC</a>
      						</li>
              					                              <li class="category-item">
      							      							<a href="indexf345.html?route=product/category&amp;path=20_27">Mac</a>
      						</li>
                          </ul>
            						 
          
        </div>
        </div>  -->
                   
 <!--      <div class="product-filter clearfix">
  <div class="display">
    <span class="pull-left">Display</span>
    <div class="btn-group group-switch">
      <button type="button" id="list-view" class="btn btn-switch" data-toggle="tooltip" title="List"><i class="fa fa-th-list"></i></button>
      <button type="button" id="grid-view" class="btn btn-switch active" data-toggle="tooltip" title="Grid"><i class="fa fa-th"></i></button>
    </div>
  </div>    
  <div class="filter-right">
     <div class="product-compare pull-right"><a href="index6431.html?route=product/compare" class="btn btn-outline btn-sm" id="compare-total">Product Compare (0)</a></div>
      <div class="sort pull-right">
        <span>Sort By:</span>
        <select class="form-control" id="input-sort" onchange="location = this.value;">
                              <option value="http://www.themelexus.com/demo/opencart/shopping/demo1/index.php?route=product/category&amp;path=20&amp;sort=p.sort_order&amp;order=ASC" selected="selected">Default</option>
                                        <option value="index9a01.html?route=product/category&amp;path=20&amp;sort=pd.name&amp;order=ASC">Name (A - Z)</option>
                                        <option value="index5b66.html?route=product/category&amp;path=20&amp;sort=pd.name&amp;order=DESC">Name (Z - A)</option>
                                        <option value="index6bd7.html?route=product/category&amp;path=20&amp;sort=p.price&amp;order=ASC">Price (Low &gt; High)</option>
                                        <option value="indexa03c.html?route=product/category&amp;path=20&amp;sort=p.price&amp;order=DESC">Price (High &gt; Low)</option>
                                        <option value="index9a4f.html?route=product/category&amp;path=20&amp;sort=rating&amp;order=DESC">Rating (Highest)</option>
                                        <option value="indexb953.html?route=product/category&amp;path=20&amp;sort=rating&amp;order=ASC">Rating (Lowest)</option>
                                        <option value="indexa5ae.html?route=product/category&amp;path=20&amp;sort=p.model&amp;order=ASC">Model (A - Z)</option>
                                        <option value="index8e93.html?route=product/category&amp;path=20&amp;sort=p.model&amp;order=DESC">Model (Z - A)</option>
                            </select>
      </div>
     
      <div class="limit pull-right">
        <span>Show:</span>
        <select id="input-limit" class="form-control" onchange="location = this.value;">
                              <option value="http://www.themelexus.com/demo/opencart/shopping/demo1/index.php?route=product/category&amp;path=20&amp;limit=15" selected="selected">15</option>
                                        <option value="index9c6c.html?route=product/category&amp;path=20&amp;limit=25">25</option>
                                        <option value="index0f50.html?route=product/category&amp;path=20&amp;limit=50">50</option>
                                        <option value="indexf053.html?route=product/category&amp;path=20&amp;limit=75">75</option>
                                        <option value="index545c.html?route=product/category&amp;path=20&amp;limit=100">100</option>
                            </select>
      </div>
     </div> 
   
</div> 
  -->
	
<div id="products" class=""> 
 	<h1><?= $sub; ?></h1>
 	<?php 
 if (!$results){ ?> 

<h1>No product found</h1>
	
		<?php } ?>
	<div class="">
		<?php foreach ($results as $result) {
			
			?>	
		<div class="row ">
			<div class="col-md-2 col-sm-4 col-xs-12 product-col">
					
				<div class="product-block item-default" itemtype="http://schema.org/Product" itemscope>
					                                                <input type="hidden" value="<?= $result->id; ?>">
					<div class="image">
			    		<a class="img" href="pd/<?= $result->id; ?>"><img src="<?= base_url();?>/uploads/<?= $result->image; ?>" alt="Apple Cinema 30&quot;" class="img-responsive" /></a>
					</div>
					<div class="product-meta">
						<div class="warp-info">
							<h3 class="name"><a href="psample">
								<?= $result->title; ?>
								</a>
							</h3>			
				          	<div class="rating">
	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	        </div>
	         				<div class="price" itemtype="http://schema.org/Offer" itemscope itemprop="offers">
								<span class="special-price"><?= $result->uprice; ?></span>
								<meta content="122.00" itemprop="price">
								<meta content="" itemprop="priceCurrency">
							</div>
							<div class="description" itemprop="description">
								<?= $result->pd ;?> 
							</div>
						</div>
					</div>
				</div>
			</div>
			<?php } ?>
<!-- 			
			<div class="col-md-2 col-sm-4 col-xs-12 product-col">			
				<div class="product-block item-default" itemtype="http://schema.org/Product" itemscope>
					<div class="image">
			    		<a class="img" href="psample"><img src="<?= base_url(); ?>/image/cache/catalog/demo/product_01-199x201.jpg" alt="Apple Cinema 30&quot;" class="img-responsive" /></a>
					</div>
					<div class="product-meta">
						<div class="warp-info">
							<h3 class="name"><a href="psample">
								Apple Cinema 30&quot;</a>
							</h3>			
				          	<div class="rating">
	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	        </div>
	         				<div class="price" itemtype="http://schema.org/Offer" itemscope itemprop="offers">
								<span class="special-price">$122.00</span>
								<meta content="122.00" itemprop="price">
								<meta content="" itemprop="priceCurrency">
							</div>
							<div class="description" itemprop="description">
								The 30-inch Apple Cinema HD Display delivers an amazing 2560 x 1600 pixel resolution. Designed sp.....
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-2 col-sm-4 col-xs-12 product-col">			
				<div class="product-block item-default" itemtype="http://schema.org/Product" itemscope>
					<div class="image">
			    		<a class="img" href="psample"><img src="<?= base_url(); ?>/image/cache/catalog/demo/product_01-199x201.jpg" alt="Apple Cinema 30&quot;" class="img-responsive" /></a>
					</div>
					<div class="product-meta">
						<div class="warp-info">
							<h3 class="name"><a href="psample">
								Apple Cinema 30&quot;</a>
							</h3>			
				          	<div class="rating">
	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	        </div>
	         				<div class="price" itemtype="http://schema.org/Offer" itemscope itemprop="offers">
								<span class="special-price">$122.00</span>
								<meta content="122.00" itemprop="price">
								<meta content="" itemprop="priceCurrency">
							</div>
							<div class="description" itemprop="description">
								The 30-inch Apple Cinema HD Display delivers an amazing 2560 x 1600 pixel resolution. Designed sp.....
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-2 col-sm-4 col-xs-12 product-col">			
				<div class="product-block item-default" itemtype="http://schema.org/Product" itemscope>

	<div class="image">
			      					<a class="img" href="index8bbb.html?route=product/product&amp;path=20&amp;product_id=30"><img src="<?= base_url(); ?>/image/cache/catalog/demo/product_02-199x201.jpg" alt="Canon EOS 5D" class="img-responsive" /></a>
				
		</a>
			</div>
	
	<div class="product-meta">
		<div class="warp-info">
			<h3 class="name"><a href="index8bbb.html?route=product/product&amp;path=20&amp;product_id=30">Canon EOS 5D</a></h3>			
				          <div class="rating">
	            	            	            <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i>
	            </span>
	            	            	            	            <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i>
	            </span>
	            	            	            	            <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i>
	            </span>
	            	            	            	            <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i>
	            </span>
	            	            	            	            <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i>
	            </span>
	            	            	          </div>
	         						<div class="price" itemtype="http://schema.org/Offer" itemscope itemprop="offers">
									<span class="special-price">$122.00</span>
					 
					<meta content="122.00" itemprop="price">
													<meta content="" itemprop="priceCurrency">
			</div>
				
			 
				<div class="description" itemprop="description">
	Canon's press material for the EOS 5D states that it 'defines (a) new D-SLR category', while we'r.....</div>
					
		</div>

	</div>

</div>





   	
		</div>
		
						
								<div class="col-md-2 col-sm-4 col-xs-12 product-col">			
			
<div class="product-block item-default" itemtype="http://schema.org/Product" itemscope>

	<div class="image">
			      					<a class="img" href="index6f63.html?route=product/product&amp;path=20&amp;product_id=47"><img src="<?= base_url(); ?>/image/cache/catalog/demo/product_03-199x201.jpg" alt="HP LP3065" class="img-responsive" /></a>
				
			</div>
	
	<div class="product-meta">
		<div class="warp-info">
			<h3 class="name"><a href="index6f63.html?route=product/product&amp;path=20&amp;product_id=47">HP LP3065</a></h3>			
				          <div class="rating">
	            	            	            <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i>
	            </span>
	            	            	            	            <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i>
	            </span>
	            	            	            	            <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i>
	            </span>
	            	            	            	            <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i>
	            </span>
	            	            	            	            <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i>
	            </span>
	            	            	          </div>
	         						<div class="price" itemtype="http://schema.org/Offer" itemscope itemprop="offers">
									<span class="special-price">$122.00</span>
					 
					<meta content="122.00" itemprop="price">
													<meta content="" itemprop="priceCurrency">
			</div>
				
			 
				<div class="description" itemprop="description">
	Stop your co-workers in their tracks with the stunning new 30-inch diagonal HP LP3065 Flat Panel .....</div>
					
		</div>
	</div>

</div>





   	
		</div>
		
						
								<div class="col-md-2 col-sm-4 col-xs-12 product-col">			
			
<div class="product-block item-default" itemtype="http://schema.org/Product" itemscope>

	<div class="image">
			      					<a class="img" href="index17bf.html?route=product/product&amp;path=20&amp;product_id=28"><img src="<?= base_url(); ?>/image/cache/catalog/demo/product_04-199x201.jpg" alt="HTC Touch HD" class="img-responsive" /></a>
				
		</a>
			</div>
	
	<div class="product-meta">
		<div class="warp-info">
			<h3 class="name"><a href="index17bf.html?route=product/product&amp;path=20&amp;product_id=28">HTC Touch HD</a></h3>			
				          <div class="rating">
	            	            	            <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i>
	            </span>
	            	            	            	            <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i>
	            </span>
	            	            	            	            <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i>
	            </span>
	            	            	            	            <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i>
	            </span>
	            	            	            	            <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i>
	            </span>
	            	            	          </div>
	         						<div class="price" itemtype="http://schema.org/Offer" itemscope itemprop="offers">
									<span class="special-price">$122.00</span>
					 
					<meta content="122.00" itemprop="price">
													<meta content="" itemprop="priceCurrency">
			</div>
				
			 
				<div class="description" itemprop="description">
	HTC Touch - in High Definition. Watch music videos and streaming content in awe-inspiring high de.....</div>
					
		</div>

	</div>

</div>





   	
		</div>
		
				</div>
						
						<div class="row ">
							<div class="col-md-2 col-sm-4 col-xs-12 product-col">			
				<div class="product-block item-default" itemtype="http://schema.org/Product" itemscope>
					<div class="image">
			    		<a class="img" href="psample"><img src="<?= base_url(); ?>/image/cache/catalog/demo/product_01-199x201.jpg" alt="Apple Cinema 30&quot;" class="img-responsive" /></a>
					</div>
					<div class="product-meta">
						<div class="warp-info">
							<h3 class="name"><a href="psample">
								Apple Cinema 30&quot;</a>
							</h3>			
				          	<div class="rating">
	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	        </div>
	         				<div class="price" itemtype="http://schema.org/Offer" itemscope itemprop="offers">
								<span class="special-price">$122.00</span>
								<meta content="122.00" itemprop="price">
								<meta content="" itemprop="priceCurrency">
							</div>
							<div class="description" itemprop="description">
								The 30-inch Apple Cinema HD Display delivers an amazing 2560 x 1600 pixel resolution. Designed sp.....
							</div>
						</div>
					</div>
				</div>
			</div>
						<div class="col-md-2 col-sm-4 col-xs-12 product-col">			
			
<div class="product-block item-default" itemtype="http://schema.org/Product" itemscope>

	<div class="image">
			      					<a class="img" href="indexdc9b.html?route=product/product&amp;path=20&amp;product_id=41"><img src="<?= base_url(); ?>/image/cache/catalog/demo/product_05-199x201.jpg" alt="iMac" class="img-responsive" /></a>
				
			</div>
	
	<div class="product-meta">
		<div class="warp-info">
			<h3 class="name"><a href="indexdc9b.html?route=product/product&amp;path=20&amp;product_id=41">iMac</a></h3>			
				          <div class="rating">
	            	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            	          </div>
	         						<div class="price" itemtype="http://schema.org/Offer" itemscope itemprop="offers">
									<span class="special-price">$122.00</span>
					 
					<meta content="122.00" itemprop="price">
													<meta content="" itemprop="priceCurrency">
			</div>
				
			 
				<div class="description" itemprop="description">
	Just when you thought iMac had everything, now there´s even more. More powerful Intel Core 2 Duo .....</div>
					
		</div>

	</div>

</div>





   	
		</div>
		
						
								<div class="col-md-2 col-sm-4 col-xs-12 product-col">			
			
<div class="product-block item-default" itemtype="http://schema.org/Product" itemscope>

	<div class="image">
			      					<a class="img" href="index9bb0.html?route=product/product&amp;path=20&amp;product_id=40"><img src="<?= base_url(); ?>/image/cache/catalog/demo/product_06-199x201.jpg" alt="iPhone" class="img-responsive" /></a>
				
			</div>
	
	<div class="product-meta">
		<div class="warp-info">
			<h3 class="name"><a href="index9bb0.html?route=product/product&amp;path=20&amp;product_id=40">iPhone</a></h3>			
				          <div class="rating">
	            	            	            <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i>
	            </span>
	            	            	            	            <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i>
	            </span>
	            	            	            	            <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i>
	            </span>
	            	            	            	            <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i>
	            </span>
	            	            	            	            <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i>
	            </span>
	            	            	          </div>
	         						<div class="price" itemtype="http://schema.org/Offer" itemscope itemprop="offers">
									<span class="special-price">$123.20</span>
					 
					<meta content="123.20" itemprop="price">
													<meta content="" itemprop="priceCurrency">
			</div>
				
			 
				<div class="description" itemprop="description">
	iPhone is a revolutionary new mobile phone that allows you to make a call by simply tapping a nam.....</div>
					
		</div>

	</div>

</div>





   	
		</div>
		
						
								<div class="col-md-2 col-sm-4 col-xs-12 product-col">			
			
<div class="product-block item-default" itemtype="http://schema.org/Product" itemscope>

	<div class="image">
			      					<a class="img" href="indexccba.html?route=product/product&amp;path=20&amp;product_id=48"><img src="<?= base_url(); ?>/image/cache/catalog/demo/product_08-199x201.jpg" alt="iPod Classic" class="img-responsive" /></a>
				
			</div>
	
	<div class="product-meta">
		<div class="warp-info">
			<h3 class="name"><a href="indexccba.html?route=product/product&amp;path=20&amp;product_id=48">iPod Classic</a></h3>			
				          <div class="rating">
	            	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            	          </div>
	         						<div class="price" itemtype="http://schema.org/Offer" itemscope itemprop="offers">
									<span class="special-price">$122.00</span>
					 
					<meta content="122.00" itemprop="price">
													<meta content="" itemprop="priceCurrency">
			</div>
				
			 
				<div class="description" itemprop="description">
	
		
			More room to move.
		
			With 80GB or 160GB of storage and up to 40 hours of battery l.....</div>
					
		</div>
	</div>

</div>





   	
		</div>
		
						<div class="col-md-2 col-sm-4 col-xs-12 product-col">			
				<div class="product-block item-default" itemtype="http://schema.org/Product" itemscope>
					<div class="image">
			    		<a class="img" href="psample"><img src="<?= base_url(); ?>/image/cache/catalog/demo/product_01-199x201.jpg" alt="Apple Cinema 30&quot;" class="img-responsive" /></a>
					</div>
					<div class="product-meta">
						<div class="warp-info">
							<h3 class="name"><a href="psample">
								Apple Cinema 30&quot;</a>
							</h3>			
				          	<div class="rating">
	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	        </div>
	         				<div class="price" itemtype="http://schema.org/Offer" itemscope itemprop="offers">
								<span class="special-price">$122.00</span>
								<meta content="122.00" itemprop="price">
								<meta content="" itemprop="priceCurrency">
							</div>
							<div class="description" itemprop="description">
								The 30-inch Apple Cinema HD Display delivers an amazing 2560 x 1600 pixel resolution. Designed sp.....
							</div>
						</div>
					</div>
				</div>
			</div>
								<div class="col-md-2 col-sm-4 col-xs-12 product-col">			
			
<div class="product-block item-default" itemtype="http://schema.org/Product" itemscope>

	<div class="image">
			      					<a class="img" href="index3f41.html?route=product/product&amp;path=20&amp;product_id=44"><img src="<?= base_url(); ?>/image/cache/catalog/demo/product_13-199x201.jpg" alt="MacBook Air" class="img-responsive" /></a>
				
			</div>
	
	<div class="product-meta">
		<div class="warp-info">
			<h3 class="name"><a href="index3f41.html?route=product/product&amp;path=20&amp;product_id=44">MacBook Air</a></h3>			
				          <div class="rating">
	            	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            	          </div>
	         						<div class="price" itemtype="http://schema.org/Offer" itemscope itemprop="offers">
									<span class="special-price">$1,202.00</span>
					 
					<meta content="1,202" itemprop="price">
													<meta content="" itemprop="priceCurrency">
			</div>
				
			 
				<div class="description" itemprop="description">
	MacBook Air is ultrathin, ultraportable, and ultra unlike anything else. But you don’t lose inche.....</div>
					
		</div>

	</div>

</div>





   	
		</div>
		
				</div>
						
						<div class="row">
							<div class="col-md-2 col-sm-4 col-xs-12 product-col">			
				<div class="product-block item-default" itemtype="http://schema.org/Product" itemscope>
					<div class="image">
			    		<a class="img" href="psample"><img src="<?= base_url(); ?>/image/cache/catalog/demo/product_01-199x201.jpg" alt="Apple Cinema 30&quot;" class="img-responsive" /></a>
					</div>
					<div class="product-meta">
						<div class="warp-info">
							<h3 class="name"><a href="psample">
								Apple Cinema 30&quot;</a>
							</h3>			
				          	<div class="rating">
	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	        </div>
	         				<div class="price" itemtype="http://schema.org/Offer" itemscope itemprop="offers">
								<span class="special-price">$122.00</span>
								<meta content="122.00" itemprop="price">
								<meta content="" itemprop="priceCurrency">
							</div>
							<div class="description" itemprop="description">
								The 30-inch Apple Cinema HD Display delivers an amazing 2560 x 1600 pixel resolution. Designed sp.....
							</div>
						</div>
					</div>
				</div>
			</div>
						<div class="col-md-2 col-sm-4 col-xs-12 product-col">			
			
<div class="product-block item-default" itemtype="http://schema.org/Product" itemscope>

	<div class="image">
			      					<a class="img" href="index8d24.html?route=product/product&amp;path=20&amp;product_id=29"><img src="<?= base_url(); ?>/image/cache/catalog/demo/product_17-199x201.jpg" alt="Palm Treo Pro" class="img-responsive" /></a>
				
			</div>
	
	<div class="product-meta">
		<div class="warp-info">
			<h3 class="name"><a href="index8d24.html?route=product/product&amp;path=20&amp;product_id=29">Palm Treo Pro</a></h3>			
				          <div class="rating">
	            	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            	          </div>
	         						<div class="price" itemtype="http://schema.org/Offer" itemscope itemprop="offers">
									<span class="special-price">$337.99</span>
					 
					<meta content="337.99" itemprop="price">
													<meta content="" itemprop="priceCurrency">
			</div>
				
			 
				<div class="description" itemprop="description">
	Redefine your workday with the Palm Treo Pro smartphone. Perfectly balanced, you can respond to b.....</div>
					
		</div> 

		
	</div>

</div>





   	
		</div>
		
						
						<div class="col-md-2 col-sm-4 col-xs-12 product-col">			
				<div class="product-block item-default" itemtype="http://schema.org/Product" itemscope>
					<div class="image">
			    		<a class="img" href="psample"><img src="<?= base_url(); ?>/image/cache/catalog/demo/product_01-199x201.jpg" alt="Apple Cinema 30&quot;" class="img-responsive" /></a>
					</div>
					<div class="product-meta">
						<div class="warp-info">
							<h3 class="name"><a href="psample">
								Apple Cinema 30&quot;</a>
							</h3>			
				          	<div class="rating">
	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	        </div>
	         				<div class="price" itemtype="http://schema.org/Offer" itemscope itemprop="offers">
								<span class="special-price">$122.00</span>
								<meta content="122.00" itemprop="price">
								<meta content="" itemprop="priceCurrency">
							</div>
							<div class="description" itemprop="description">
								The 30-inch Apple Cinema HD Display delivers an amazing 2560 x 1600 pixel resolution. Designed sp.....
							</div>
						</div>
					</div>
				</div>
			</div>
								<div class="col-md-2 col-sm-4 col-xs-12 product-col">			
			
<div class="product-block item-default" itemtype="http://schema.org/Product" itemscope>

	<div class="image">
			      					<a class="img" href="indexf470.html?route=product/product&amp;path=20&amp;product_id=35"><img src="<?= base_url(); ?>/image/cache/catalog/demo/product_18-199x201.jpg" alt="Product 8" class="img-responsive" /></a>
				
			</div>
	
	<div class="product-meta">
		<div class="warp-info">
			<h3 class="name"><a href="indexf470.html?route=product/product&amp;path=20&amp;product_id=35">Product 8</a></h3>			
				          <div class="rating">
	            	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            	          </div>
	         						<div class="price" itemtype="http://schema.org/Offer" itemscope itemprop="offers">
									<span class="special-price">$122.00</span>
					 
					<meta content="122.00" itemprop="price">
													<meta content="" itemprop="priceCurrency">
			</div>
				
			 
				<div class="description" itemprop="description">
	Product 8.....</div>
					
		</div>

	</div>

</div>





   	
		</div>
		
						
								<div class="col-md-2 col-sm-4 col-xs-12 product-col">			
			
<div class="product-block item-default" itemtype="http://schema.org/Product" itemscope>

	<div class="image">
			      					<a class="img" href="indexce1a.html?route=product/product&amp;path=20&amp;product_id=33"><img src="<?= base_url(); ?>/image/cache/catalog/demo/product_20-199x201.jpg" alt="Samsung 941BW" class="img-responsive" /></a>
				
			</div>
	
	<div class="product-meta">
		<div class="warp-info">
			<h3 class="name"><a href="indexce1a.html?route=product/product&amp;path=20&amp;product_id=33">Samsung 941BW</a></h3>			
				          <div class="rating">
	            	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            	          </div>
	         						<div class="price" itemtype="http://schema.org/Offer" itemscope itemprop="offers">
									<span class="special-price">$242.00</span>
					 
					<meta content="242.00" itemprop="price">
													<meta content="" itemprop="priceCurrency">
			</div>
				
			 
				<div class="description" itemprop="description">
	Imagine the advantages of going big without slowing down. The big 19" 941BW monitor combines wide.....</div>
					
		</div>
	</div>

</div>





   	
		</div> -->
		
				</div>
						
			</div>
</div>

<div class="">
	<div class="col-sm-6 text-left"></div>
	<div class="col-sm-6 text-right">Showing 1 to 11 of 11 (1 Pages)</div>
</div> 
   
      
        
      
      </div>
   </section> 
   <!-- Banners -->
	<!-- <aside id="sidebar-right" class="col-md-2" style="margin-top: 78px;">	
		<div id="column-right" class="hidden-xs">

<div class="pts-bannerbuilder clearfix hidden-sm hidden-xs">
	
 		    	        <div class="pts-container " >        
	        	<div class="pts-inner">
	      
	    <div class="row row-level-1">
	        	            <div class="col-lg-12 col-md-12 col-sm-6 col-xs-12"><div class="col-inner">
	                	                		                    <div class="banner-wrapper">
	                    	                        	<a href="<?= base_url(); ?>/#"><img alt="img" src="<?= base_url(); ?>image/catalog/demo/banners/banner4.jpg" class="img-responsive"></a>
                        	                   		</div>
                   			                	                	            </div></div>
	        	    </div>
	        	    <div class="row row-level-1">
	        	            <div class="col-lg-12 col-md-12 col-sm-6 col-xs-12"><div class="col-inner">
	                	                		                    <div class="banner-wrapper">
	                    	                        	<a href="<?= base_url(); ?>/#"><img alt="img" src="<?= base_url(); ?>image/catalog/demo/banners/banner4.jpg" class="img-responsive"></a>
                        	                   		</div>
                   			                	                	            </div></div>
	        	    </div>
	        	    <div class="row row-level-1">
	        	            <div class="col-lg-12 col-md-12 col-sm-6 col-xs-12"><div class="col-inner">
	                	                		                    <div class="banner-wrapper">
	                    	                        	<a href="<?= base_url(); ?>/#"><img alt="img" src="<?= base_url(); ?>image/catalog/demo/banners/banner4.jpg" class="img-responsive"></a>
                        	                   		</div>
                   			                	                	            </div></div>
	        	    </div>
	    	            </div>  </div>
	        </div>
 -->
<!--     <div class="category box box-info nopadding">
  <div class="box-heading"><span>Categories</span></div>
  <div class="box-content tree-menu">
    <ul id="832544356accordion" class="box-category box-panel accordion">
            <li class="haschild accordion-group">
                <a href="index98dc.html?route=product/category&amp;path=20" class="active">Desktops (11)</a>
                        <span class="head"><a data-toggle="collapse" data-parent="#832544356accordion" data-target="#732413330target0">+</a></span>
        
        <ul id="732413330target0" class="panel-collapse collapse accordion-body in">
                    <li>
                        <a href="indexd9fe.html?route=product/category&amp;path=20_26">PC (8)</a>
                      </li>
                    <li>
                        <a href="indexf345.html?route=product/category&amp;path=20_27">Mac (6)</a>
                      </li>
                  </ul>
              </li>
            <li class="haschild accordion-group">
                <a href="index7fa3.html?route=product/category&amp;path=18">Laptops &amp; Notebooks (8)</a>
                      </li>
            <li class="haschild accordion-group">
                <a href="index1647.html?route=product/category&amp;path=25">Components (11)</a>
                      </li>
            <li class="haschild accordion-group">
                <a href="index70a9.html?route=product/category&amp;path=57">Tablets (4)</a>
                      </li>
            <li class="haschild accordion-group">
                <a href="indexb152.html?route=product/category&amp;path=17">Software (7)</a>
                      </li>
            <li class="haschild accordion-group">
                <a href="indexc957.html?route=product/category&amp;path=24">Phones &amp; PDAs (3)</a>
                      </li>
            <li class="haschild accordion-group">
                <a href="index68ea.html?route=product/category&amp;path=33">Cameras (3)</a>
                      </li>
            <li class="haschild accordion-group">
                <a href="index8122.html?route=product/category&amp;path=34">MP3 Players (11)</a>
                      </li>
          </ul>
  </div>
</div>
<script type="text/javascript">
    $(document).ready(function(){
        var active = $('.collapse.in').attr('id');
        $('a[data-target=#'+active+']').html("-");

        $('.collapse').on('show.bs.collapse', function () {
            $('a[data-target=#'+$(this).attr('id')+']').html("-");
        });
        $('.collapse').on('hide.bs.collapse', function () {
            $('a[data-target=#'+$(this).attr('id')+']').html("+");
        });
    });
</script>
 -->
<!--   </div>
	</aside>
 -->	   <!-- Banners -->

</div>
</div>


<!--main body -->

<script type="text/javascript"><!--

	$( document ).ready(function() {
		var id = 'newsletter_1217394841';
		$('#'+id+' .box-heading').bind('click', function(){
			$('#'+id).toggleClass('active');
		});

		$('#formNewLestter').on('submit', function() {
			var email = $('.inputNew').val();
			$(".success_inline, .warning_inline, .error").remove();
			if(!isValidEmailAddress(email)) {				
			$('.valid').html("<div class=\"error alert alert-danger\">Email is not valid!<button type=\"button\" class=\"close\" data-dismiss=\"alert\">×</button></div></div>");
			$('.inputNew').focus();
			return false;
		}
		var url = "indexd513.html?route=extension/module/pavnewsletter/subscribe";
		$.ajax({
			type: "post",
			url: url,
			data: $("#formNewLestter").serialize(),
			dataType: 'json',
			success: function(json)
			{
				$(".success_inline, .warning_inline, .error").remove();
				if (json['error']) {
					$('.valid').html("<div class=\"warning_inline alert alert-danger\">"+json['error']+"<button type=\"button\" class=\"close\" data-dismiss=\"alert\">×</button></div>");
				}
				if (json['success']) {
					$('.valid').html("<div class=\"success_inline alert alert-success\">"+json['success']+"<button type=\"button\" class=\"close\" data-dismiss=\"alert\">×</button></div>");
				}
			}
		});
		return false;
	});
});

function isValidEmailAddress(emailAddress) {
	var pattern = new RegExp(/^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i);
	return pattern.test(emailAddress);
}
--></script>
     <!--  <div class="col-md-5 col-sm-6 col-xs-12">
          <div class="box">
            <div class="box-heading"><span>Map Locations</span></div>
            <div id="contact2-map"></div>
          </div>
      </div> -->

    
    <!-- <script type="text/javascript" src="<?= base_url(); ?>/http://maps.googleapis.com/maps/api/js?key=AIzaSyBEyQxItIt2AFXqZvOEFWttGyyH3U4oJaU"></script>
    <script type="text/javascript" src="<?= base_url(); ?>/catalog/view/javascript/gmap/gmap3.min.js"></script>
    <script type="text/javascript" src="<?= base_url(); ?>/catalog/view/javascript/gmap/gmap3.infobox.js"></script>
    <script type="text/javascript">
        var mapDiv, map, infobox;
        var lat = 40.705423;
        var lon = -74.008616;
        jQuery(document).ready(function($) {
            mapDiv = $("#contact2-map");
            mapDiv.height(200).gmap3({
                map:{
                    options:{
                        center:[lat,lon],
                        zoom: 15
                    }
                },
                marker:{
                    values:[
                        {latLng:[lat, lon], data:"79-99 Beaver Street, New York, NY 10005, USA"},
                    ],
                    options:{
                        draggable: false
                    },
                    events:{
                          mouseover: function(marker, event, context){
                            var map = $(this).gmap3("get"),
                                infowindow = $(this).gmap3({get:{name:"infowindow"}});
                            if (infowindow){
                                infowindow.open(map, marker);
                                infowindow.setContent(context.data);
                            } else {
                                $(this).gmap3({
                                infowindow:{
                                    anchor:marker, 
                                    options:{content: context.data}
                                }
                              });
                            }
                        },
                        mouseout: function(){
                            var infowindow = $(this).gmap3({get:{name:"infowindow"}});
                            if (infowindow){
                                infowindow.close();
                            }
                        }
                    }
                }
            });
        });
    </script> -->
<!-- <div id="top"><a class="scrollup" href="<?= base_url(); ?>/#"><i class="fa fa-angle-up"></i>Top</a></div>
 -->
  	
<script type="text/javascript">
$(document).ready( function (){
	$(".paneltool .panelbutton").click( function(){	
		$(this).parent().toggleClass("active");
	} );
} );

</script>
<script type="text/javascript">
$('#myTab a').click(function (e) {
	e.preventDefault();
	$(this).tab('show');
})
$('#myTab a:first').tab('show'); 
 

var $MAINCONTAINER = $("html");

/**
 * BACKGROUND-IMAGE SELECTION
 */
$(".background-images").each( function(){
	var $parent = this;
	var $input  = $(".input-setting", $parent ); 
	$(".bi-wrapper > div",this).click( function(){
		 $input.val( $(this).data('val') ); 
		 $('.bi-wrapper > div', $parent).removeClass('active');
		 $(this).addClass('active');

		 if( $input.data('selector') ){  
			$($input.data('selector'), $($MAINCONTAINER) ).css( $input.data('attrs'),'url('+ $(this).data('image') +')' );
		 }
	} );
} ); 

$(".clear-bg").click( function(){
	var $parent = $(this).parent();
	var $input  = $(".input-setting", $parent ); 
	if( $input.val('') ) {
		if( $parent.hasClass("background-images") ) {
			$('.bi-wrapper > div',$parent).removeClass('active');	
			$($input.data('selector'),$("#main-preview iframe").contents()).css( $input.data('attrs'),'none' );
		}else {
			$input.attr( 'style','' )	
		}
		$($input.data('selector'), $($MAINCONTAINER) ).css( $input.data('attrs'),'inherit' );

	}	
	$input.val('');

	return false;
} );



 $('.accordion-group input.input-setting').each( function(){
 	 var input = this;
 	 $(input).attr('readonly','readonly');
 	 $(input).ColorPicker({
 	 	onChange:function (hsb, hex, rgb) {
 	 		$(input).css('backgroundColor', '#' + hex);
 	 		$(input).val( hex );
 	 		if( $(input).data('selector') ){  
				$( $MAINCONTAINER ).find($(input).data('selector')).css( $(input).data('attrs'),"#"+$(input).val() )
			}
 	 	}
 	 });
	} );
 $('.accordion-group select.input-setting').change( function(){
	var input = this; 
		if( $(input).data('selector') ){  
		var ex = $(input).data('attrs')=='font-size'?'px':"";
		$( $MAINCONTAINER ).find($(input).data('selector')).css( $(input).data('attrs'), $(input).val() + ex);
	}
 } );
 

</script>
 <script>
function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
        x.className += " responsive";
    } else {
        x.className = "topnav";
    }
}
</script>

<!--  <div class="sidebar-offcanvas  visible-xs visible-sm">
      <div class="offcanvas-inner  panel-offcanvas">
          <div class="offcanvas-heading">
              <button data-toggle="offcanvas" class="btn btn btn-primary" type="button"> <span class="fa fa-times"></span></button>
          </div>
          <div class="offcanvas-body">
                <div id="offcanvasmenu"></div> 
          </div>
          <div class="offcanvas-footer panel-footer">
              <div class="input-group" id="offcanvas-search">
                <input type="text" class="form-control" placeholder="Search" value="" name="search">
                <span class="input-group-btn">
                  <button class="btn btn-primary" type="button"><i class="fa fa-search"></i></button>
                </span>
              </div>
          </div>
       </div> 
 </div> -->

<script type="text/javascript">
  $("#offcanvasmenu").html($("#bs-megamenu").html());
</script>
