<DOCTYPE html>
<!--[if IE]><![endif]-->
<!--[if IE 8 ]><html dir="ltr" lang="en" class="ie8"><![endif]-->
<!--[if IE 9 ]><html dir="ltr" lang="en" class="ie9"><![endif]-->
<!--[if (gt IE 9)|!(IE)]><!-->
<html dir="ltr" class="ltr" lang="en">
<!--<![endif]-->

<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>Carrovan</title>
<base  />
<meta name="description" content="My Store" />

<link href="<?= base_url(); ?>/catalog/view/theme/lexus_shopping/stylesheet/bootstrap.css" rel="stylesheet" />
<link href="<?= base_url(); ?>/catalog/view/theme/lexus_shopping/stylesheet/product.css" rel="stylesheet" />
<link href="<?= base_url(); ?>/catalog/view/theme/lexus_shopping/stylesheet/stylesheet.css" rel="stylesheet" />
<link href="<?= base_url(); ?>/catalog/view/theme/lexus_shopping/stylesheet/font.css" rel="stylesheet" />
<link href="<?= base_url(); ?>/catalog/view/javascript/font-awesome/css/font-awesome.min.css" rel="stylesheet" />

<script type="text/javascript" src="<?= base_url(); ?>/catalog/view/javascript/jquery/jquery-2.1.1.min.js"></script>
<script type="text/javascript" src="<?= base_url(); ?>/catalog/view/javascript/bootstrap/js/bootstrap.min.js"></script>

<style>
#more1 {display: none;}

#more2 {display: none;}
</style>

</head>

<body>
<div class="container">
	

<img src="<?= base_url(); ?>/image/catalog/demo/layerslider/bg_slider_home2.jpg" alt="" class="img-responsive" style="width:100%; height: 50%">

</div>
<div class="container">
	<div class="row">
		<div class=" col-md-3 textbox" ></div>

		<div class=" col-md-9 textbox" >
			<h1 style="margin-top: 5%"> <b>Emprowing</b><br> <b>Small</b> <br><b>Business</b> </h1>
		</div>
	</div>
	<div class="row">

		<div class=" col-md-3 textbox" ></div>
		<div class=" col-md-2 textbox" >
		
		
		<div class="fs3">
			<p>A paragraph (from the Ancient Greek παράγραφος paragraphos, "to write beside" or "written beside")
				A paragraph (from the Ancient Greek παράγραφος paragraphos, "to write beside" or "written beside")<br>A paragraph (from the Ancient Greek παράγραφος paragraphos, "to write beside" or "written beside")A paragraph (from the Ancient Greek παράγραφος paragraphos, "to write beside" or "written beside")A paragraph (from the Ancient Greek παράγραφος paragraphos, "to write beside" or "written beside") </p>
<ol>
			<li><b>A paragraph (from the Ancient<br> Greek παράγραφος paragraphos,</b></li>
			<li><b>A paragraph (from the Ancient</b></li>
			<li><b>A paragraph (from the Ancient</b></li>
			<li><b>A paragraph (from the Ancient</b></li>
	</ol>
		</div>

	</div>
	<div class="col-md-2 image_widgets" >

		<img src="<?= base_url(); ?>/image/catalog/demo/layerslider/bg_slider_home2.jpg" class="img-thumbnail img-responsive">
		<h1 class="hs1">More SMEs set to benefit from the digital economy in 2018</h1>
		<p class="fs3">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus imperdiet, nulla et dictum interdum, nisi lorem egestas vitae scel<span id="dots">...</span><span id="more1">erisque enim ligula venenatis dolor. Maecenas nisl est, ultrices nec congue eget, auctor vitae massa. Fusce luctus vestibulum augue ut aliquet. Nunc sagittis dictum nisi, sed ullamcorper ipsum dignissim ac. In at libero sed nunc venenatis imperdiet sed ornare turpis. Donec vitae dui eget tellus gravida venenatis. Integer fringilla congue eros non fermentum. Sed dapibus pulvinar nibh tempor porta.</span></p>
<button onclick="myFunction()" id="myBtn">Read more</button>

<script>
function myFunction() {
  var dots = document.getElementById("dots");
  var moreText = document.getElementById("more1");
  var btnText = document.getElementById("myBtn");

  if (dots.style.display === "none") {
    dots.style.display = "inline";
    btnText.innerHTML = "Read more"; 
    moreText.style.display = "none";
  } else {
    dots.style.display = "none";
    btnText.innerHTML = "Read less"; 
    moreText.style.display = "inline";
  }
}
</script>
	
	</div>

	<div class="col-md-2 image_widgets" >

		<img src="<?= base_url(); ?>/image/catalog/demo/layerslider/bg_slider_home2.jpg" class="img-thumbnail" height=30%; width:30%;>
	<h1 class="hs1">Unlocking the digital potential of rural areas could add £26 billion a year to our economy</h1>
	<p class="fs3">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus imperdiet, nulla et dictum interdum, nisi lorem egestas vitae scelerisque enim ligula venenatis dolor. Maecenas nisl est, ultrices nec congue eget, auctor vitae massa. Fusce luctus vesti<span id="dots2">...</span><span id="more2">bulum augue ut aliquet. Nunc sagittis dictum nisi, sed ullamcorper ipsum dignissim ac. In at libero sed nunc venenatis imperdiet sed ornare turpis. Donec vitae dui eget tellus gravida venenatis. Integer fringilla congue eros non fermentum. Sed dapibus pulvinar nibh tempor porta.</span></p>
<button onclick="myFunction1()" id="myBtn2">Read more</button>

<script>
function myFunction1() {
  var dots = document.getElementById("dots2");
  var moreText = document.getElementById("more2");
  var btnText = document.getElementById("myBtn2");

  if (dots.style.display === "none") {
    dots.style.display = "inline";
    btnText.innerHTML = "Read more"; 
    moreText.style.display = "none";
  } else {
    dots.style.display = "none";
    btnText.innerHTML = "Read less"; 
    moreText.style.display = "inline";
  }
}
</script>
</div>
	<div class="col-md-3" >
	</div>
	</div>




	<div class="row">
		<div class=" col-md-3 textbox" ></div>

		<div class=" col-md-9 textbox" >
			<h1 style="margin-top: 5%"> <b>Innovation</b> </h1>
		</div>
	</div>
	<div class="row">

		<div class=" col-md-3 textbox" ></div>
		<div class=" col-md-2 textbox" >
		
		
		<div class="fs3">
			<p>We're a company of builders. Of pioneers. It's our job to make bold bets, and we get our energy from inventing on behalf of customers. Here are just some of the innovations pioneered by Carrovan, and we're always looking for the next one.  </p>
<ol>
			<li><b>Innovations</b></li>
	</ol>
		</div>

	</div>
	<div class="col-md-2 image_widgets" >

		<img src="<?= base_url(); ?>/image/catalog/demo/layerslider/bg_slider_home2.jpg" class="img-thumbnail img-responsive">
		<h1 class="hs1">Pioneering: A passion for inventing</h1>
		<p class="fs3">The world's best inventors come to Amazon to build new technologies and services that improve the lives of customers: consumers, sellers, content creators, and developers around the world.<span id="dots3">...</span><span id="more3">It's still very much "Day 1" at Amazon—we're a large and growing company, but we're inventing new things every day and we value and encourage innovation at all levels of the company. While we have over 500,000 employees around the world, most of our teams are very small and each one operates much like a start-up, which means all team members are given opportunities to take on big challenges and make a difference for our customers.</span></p>
<button onclick="myFunction3()" id="myBtn3">Read more</button>

<script>
function myFunction3() {
  var dots = document.getElementById("dots3");
  var moreText = document.getElementById("more3");
  var btnText = document.getElementById("myBt3");

  if (dots.style.display === "none") {
    dots.style.display = "inline";
    btnText.innerHTML = "Read more"; 
    moreText.style.display = "none";
  } else {
    dots.style.display = "none";
    btnText.innerHTML = "Read less"; 
    moreText.style.display = "inline";
  }
}
</script>
	
	</div>

	<div class="col-md-2 image_widgets" >

		<img src="<?= base_url(); ?>/image/catalog/demo/layerslider/bg_slider_home2.jpg" class="img-thumbnail" height=30%; width:30%;>
	<h1 class="hs1">Prime Air</h1>
	<p class="fs3">Carrovan Prime Air is a future delivery system that will safely get packages to customers in 30 minutes or less using small unmanned aerial vehicles. <span id="dots4">...</span><span id="more4">Today, we are rapidly experimenting and iterating on Prime Air inside our next generation research and development labs, working to make our vision a reality. It may sound like science fiction, but it's real. Putting the system into service will take some time, but one day, seeing Prime Air vehicles will be as normal as seeing mail trucks on the road.</span></p>
<button onclick="myFunction1()" id="myBtn4">Read more</button>

<script>
function myFunction1() {
  var dots = document.getElementById("dots4");
  var moreText = document.getElementById("more4");
  var btnText = document.getElementById("myBtn4");

  if (dots.style.display === "none") {
    dots.style.display = "inline";
    btnText.innerHTML = "Read more"; 
    moreText.style.display = "none";
  } else {
    dots.style.display = "none";
    btnText.innerHTML = "Read less"; 
    moreText.style.display = "inline";
  }
}
</script>
</div>
	<div class="col-md-3" >
	</div>
	</div>



</div>
</body>
</html>