<div class="container" style="margin-top: 5%">
	<div class="header">
		<div class="row">
			<div class="col-md-5 col-md-offset-1" style="border: none">
				<h1 class="hs1"> Your Orders</h1>
			</div>
			<div class="col-md-5">
				<form class="form-inline" style="float: right;">
    				<input class="form-control mr-sm-2" type="text" placeholder="Search" aria-label="Search">
    				<button class="btn aqua-gradient btn-rounded btn-sm my-0" type="submit">Search orders</button>
				</form>
			</div>
		</div>
		<div class="col-md-offset-1">
		<div class="fs2">Status: 
			<select class="drop" style="margin-left: 22px; margin-bottom: 10px">
				<option>Completed</option>
				<option>Pending</option>
			</select>
		</div>

		<div class="fs2">Timeline: 
			<select class="drop" style="margin-left: 10px">
				<option>Last Day</option>
				<option>Last Week</option>
				<option>Last Month</option>
				<option>Last Year</option>
			</select>
		</div>
		</div>
	</div>
	<div class="col-md-offset-1">
	<div class="panel panel-default" style="margin-top: 10px">
		<div class="panel-heading">
			<div class="row text-center">
				<div class="col-md-3">
					<div class="hs2">Order Date<br>25/01/2013</div>
				</div>
				<div class="col-md-3">
					<div class="hs2">Total Amount<br>$ 5.00</div>
				</div>
				<div class="col-md-3">
					<div class="hs2">Delivery Address<br>H.H.H.H.H</div>
				</div>
				<div class="col-md-3">
					<div class="hs2">Order#276.12.358<br><a href="#" style="color: #009bcb">Details</a>|<a href="#" style="color: #009bcb">Invoice</a></div>
				</div>
			</div>
		</div>
		<div class="panel-body">
			<div class="fs1">Delivered 1st Apr 2018</div>
			<div class="col-md-3">
				<img src="<?= base_url(); ?>/image/cache/catalog/demo/product_12-199x201.jpg" alt="MacBook" class="img-responsive" />
			</div>
			<div class="col-md-6" style="margin-top: 3%">
				<p class="fs2">Apple Cinema 30"</p>
				<p class="fs2">$ 5.00</p>
				<a href="#" class="btn btn-primary">Order Again</a>
			</div>
			<div class="col-md-3" style="margin-top: 3%">
				<a href="#" class="btn btn-primary" style="width: 90%; margin-top: 5px">Return</a>
				<a href="#" class="btn btn-primary" style="width: 90%; margin-top: 5px">Report Problem</a>
				<a href="#" class="btn btn-primary" style="width: 90%; margin-top: 5px">Contact Buyer</a>
				<a href="#" class="btn btn-primary" style="width: 90%; margin-top: 5px">Leave Feedback</a>
			</div>
		</div>
	</div>
	</div>


	<div class="col-md-offset-1">
	<div class="panel panel-default" style="margin-top: 10px">
		<div class="panel-heading">
			<div class="row text-center">
				<div class="col-md-3">
					<div class="hs2">Order Date<br>25/01/2013</div>
				</div>
				<div class="col-md-3">
					<div class="hs2">Total Amount<br>$ 5.00</div>
				</div>
				<div class="col-md-3">
					<div class="hs2">Delivery Address<br>H.H.H.H.H</div>
				</div>
				<div class="col-md-3">
					<div class="hs2">Order#276.12.358<br><a href="#" style="color: #009bcb">Details</a>|<a href="#" style="color: #009bcb">Invoice</a></div>
				</div>
			</div>
		</div>
		<div class="panel-body">
			<div class="fs1">Delivered 1st Apr 2018</div>
			<div class="col-md-3">
				<img src="<?= base_url(); ?>/image/cache/catalog/demo/product_16-199x201.jpg" alt="MacBook" class="img-responsive" />
			</div>
			<div class="col-md-6" style="margin-top: 3%">
				<p class="fs2">Apple Cinema 30"</p>
				<p class="fs2">$ 5.00</p>
				<a href="#" class="btn btn-primary">Order Again</a>
			</div>
			<div class="col-md-3" style="margin-top: 3%">
				<a href="#" class="btn btn-primary" style="width: 90%; margin-top: 5px">Return</a>
				<a href="#" class="btn btn-primary" style="width: 90%; margin-top: 5px">Report Problem</a>
				<a href="#" class="btn btn-primary" style="width: 90%; margin-top: 5px">Contact Buyer</a>
				<a href="#" class="btn btn-primary" style="width: 90%; margin-top: 5px">Leave Feedback</a>
			</div>
		</div>
	</div>
	</div>


	<div class="col-md-offset-1">
	<div class="panel panel-default" style="margin-top: 10px">
		<div class="panel-heading">
			<div class="row text-center">
				<div class="col-md-3">
					<div class="hs2">Order Date<br>25/01/2013</div>
				</div>
				<div class="col-md-3">
					<div class="hs2">Total Amount<br>$ 5.00</div>
				</div>
				<div class="col-md-3">
					<div class="hs2">Delivery Address<br>H.H.H.H.H</div>
				</div>
				<div class="col-md-3">
					<div class="hs2">Order#276.12.358<br><a href="#" style="color: #009bcb">Details</a>|<a href="#" style="color: #009bcb">Invoice</a></div>
				</div>
			</div>
		</div>
		<div class="panel-body">
			<div class="fs1">Delivered 1st Apr 2018</div>
			<div class="col-md-3">
				<img src="<?= base_url(); ?>/image/cache/catalog/demo/product_13-199x201.jpg" alt="MacBook" class="img-responsive" />
			</div>
			<div class="col-md-6" style="margin-top: 3%">
				<p class="fs2">Apple Cinema 30"</p>
				<p class="fs2">$ 5.00</p>
				<a href="#" class="btn btn-primary">Order Again</a>
			</div>
			<div class="col-md-3" style="margin-top: 3%">
				<a href="#" class="btn btn-primary" style="width: 90%; margin-top: 5px">Return</a>
				<a href="#" class="btn btn-primary" style="width: 90%; margin-top: 5px">Report Problem</a>
				<a href="#" class="btn btn-primary" style="width: 90%; margin-top: 5px">Contact Buyer</a>
				<a href="#" class="btn btn-primary" style="width: 90%; margin-top: 5px">Leave Feedback</a>
			</div>
		</div>
	</div>
	</div>
</div>