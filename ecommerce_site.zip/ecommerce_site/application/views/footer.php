<!--  -->  <footer id="footer" class="footer">
 
  <div class="footer-top " id="pavo-footer-top">
  <div class="container">
  </div>
</div>
<script type="text/javascript">

  $( document ).ready(function() {
    var id = 'newsletter_1217394841';
    $('#'+id+' .box-heading').bind('click', function(){
      $('#'+id).toggleClass('active');
    });

    $('#formNewLestter').on('submit', function() {
      var email = $('.inputNew').val();
      $(".success_inline, .warning_inline, .error").remove();
      if(!isValidEmailAddress(email)) {       
      $('.valid').html("<div class=\"error alert alert-danger\">Email is not valid!<button type=\"button\" class=\"close\" data-dismiss=\"alert\">×</button></div></div>");
      $('.inputNew').focus();
      return false;
    }
    var url = "indexd513.html?route=extension/module/pavnewsletter/subscribe";
    $.ajax({
      type: "post",
      url: url,
      data: $("#formNewLestter").serialize(),
      dataType: 'json',
      success: function(json)
      {
        $(".success_inline, .warning_inline, .error").remove();
        if (json['error']) {
          $('.valid').html("<div class=\"warning_inline alert alert-danger\">"+json['error']+"<button type=\"button\" class=\"close\" data-dismiss=\"alert\">×</button></div>");
        }
        if (json['success']) {
          $('.valid').html("<div class=\"success_inline alert alert-success\">"+json['success']+"<button type=\"button\" class=\"close\" data-dismiss=\"alert\">×</button></div>");
        }
      }
    });
    return false;
  });
});

function isValidEmailAddress(emailAddress) {
  var pattern = new RegExp(/^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i);
  return pattern.test(emailAddress);
}
--></script></div>
    </div></div>  
      
  </div>
</div>

   <div class="footer-bottom " id="pavo-footer-bottom" style="margin-left:15% ;font-size: 15px">
  <div class="container"><div class="inner">
    <div class="row">    
      <div class="col-md-3 col-sm-6 col-xs-12">
         <div class="box">      <div class="box-heading"><span>About Us</span></div>      <div class="box-content"><p>Duis at nisl quis quam condimentum pulvinar. Quisque euismod convallis eros, quis lacinia enim rhoncus sed. Quisque euismod convallis eros, quis lacinia enim rhoncus sed.</p><ul class="list"> <li><span class="fa fa-phone">&nbsp;</span>Phone: +01 888 (000) 1234</li> <li><span class="fa fa-envelope">&nbsp;</span>Email: anh@gmail.com</li></ul></div>  </div>      </div>  

              <div class="col-md-2 col-sm-6 col-xs-12">
          <div class="box">
            <div class="box-heading"><span>Information</span></div>
            <ul class="list">
                            <li><a href="<?= base_url(); ?>/index8816-2.html?route=information/information&amp;information_id=4">About Us</a></li>
                            <li><a href="<?= base_url(); ?>/index1766-2.html?route=information/information&amp;information_id=6">Delivery Information</a></li>
                            <li><a href="<?= base_url(); ?>/index1679-2.html?route=information/information&amp;information_id=3">Privacy Policy</a></li>
                            <li><a href="<?= base_url(); ?>/index99e4-2.html?route=information/information&amp;information_id=5">Terms &amp; Conditions</a></li>
                            <li><a href="<?= base_url(); ?>/index4dd2-2.html?route=account/voucher">Gift Certificates</a></li>
              <li><a href="<?= base_url(); ?>/index3d18.html?route=affiliate/account">Affiliates</a></li>
            </ul>
          </div>
        </div>
        
      <div class="col-md-2 col-sm-6 col-xs-12">
        <div class="box">
            <div class="box-heading"><span>My Account</span></div>
            <ul class="list">
              <li><a href="<?= base_url(); ?>/indexe223.html?route=account/account">My Account</a></li>
              <li><a href="<?= base_url(); ?>/indexe223.html?route=account/order">Order History</a></li>
              <li><a href="<?= base_url(); ?>/indexe223.html?route=account/wishlist">Wish List</a></li>
              <li><a href="<?= base_url(); ?>/indexe223.html?route=account/newsletter">Newsletter</a></li>
              <li><a href="<?= base_url(); ?>/indexd773.html?route=product/manufacturer">Brands</a></li>
              <li><a href="<?= base_url(); ?>/indexf110.html?route=product/special">Specials</a></li>
            </ul>
          </div>
        </div>
         <div class="col-md-2 col-sm-6 col-xs-12">
        <div class="box">
            <div class="box-heading"><span>4th Menu</span></div>
            <ul class="list">
              <li><a href="<?= base_url(); ?>/indexe223.html?route=account/account">My Account</a></li>
              <li><a href="<?= base_url(); ?>/indexe223.html?route=account/order">Order History</a></li>
              <li><a href="<?= base_url(); ?>/indexe223.html?route=account/wishlist">Wish List</a></li>
              <li><a href="<?= base_url(); ?>/indexe223.html?route=account/newsletter">Newsletter</a></li>
              <li><a href="<?= base_url(); ?>/indexd773.html?route=product/manufacturer">Brands</a></li>
              <li><a href="<?= base_url(); ?>/indexf110.html?route=product/special">Specials</a></li>
            </ul>
          </div>
        </div>


     <!--  <div class="col-md-5 col-sm-6 col-xs-12">
          <div class="box">
            <div class="box-heading"><span>Map Locations</span></div>
            <div id="contact2-map"></div>
          </div>
      </div> -->

    </div>
  </div></div>
</div>

    <!-- <script type="text/javascript" src="<?= base_url(); ?>/http://maps.googleapis.com/maps/api/js?key=AIzaSyBEyQxItIt2AFXqZvOEFWttGyyH3U4oJaU"></script>
    <script type="text/javascript" src="<?= base_url(); ?>/catalog/view/javascript/gmap/gmap3.min.js"></script>
    <script type="text/javascript" src="<?= base_url(); ?>/catalog/view/javascript/gmap/gmap3.infobox.js"></script>
    <script type="text/javascript">
        var mapDiv, map, infobox;
        var lat = 40.705423;
        var lon = -74.008616;
        jQuery(document).ready(function($) {
            mapDiv = $("#contact2-map");
            mapDiv.height(200).gmap3({
                map:{
                    options:{
                        center:[lat,lon],
                        zoom: 15
                    }
                },
                marker:{
                    values:[
                        {latLng:[lat, lon], data:"79-99 Beaver Street, New York, NY 10005, USA"},
                    ],
                    options:{
                        draggable: false
                    },
                    events:{
                          mouseover: function(marker, event, context){
                            var map = $(this).gmap3("get"),
                                infowindow = $(this).gmap3({get:{name:"infowindow"}});
                            if (infowindow){
                                infowindow.open(map, marker);
                                infowindow.setContent(context.data);
                            } else {
                                $(this).gmap3({
                                infowindow:{
                                    anchor:marker, 
                                    options:{content: context.data}
                                }
                              });
                            }
                        },
                        mouseout: function(){
                            var infowindow = $(this).gmap3({get:{name:"infowindow"}});
                            if (infowindow){
                                infowindow.close();
                            }
                        }
                    }
                }
            });
        });
    </script> -->

<div id="powered">
  <div class="container">
    <div class="inner" style="margin-left: 35%">
      <div class="copyright pull-left">
          <center>        Carrovan Copyright @2018 Designed by <a href="http://www.ilegendtech.com/" title="pavothemes - opencart themes clubs">ILegendTech</a>
          </center>
      </div>  

              <div class="paypal pull-right">
          <img alt="img" src="<?= base_url(); ?>/image/catalog/paypal.png">        </div>
            </div>
  </div>
</div>

<!-- <div id="top"><a class="scrollup" href="#" onclick="topFunction"><i class="fa fa-angle-up"></i>Top</a></div>
 -->
</footer> 
    
<script>
function topFunction() {
//     document.body.scrollTop = 0; // For Safari
//     document.documentElement.scrollTop = 0; // For Chrome, Firefox, IE and Opera
// 
 currentYOffset = self.pageYOffset;
  initYOffset = currentYOffset;

  var intervalId = setInterval(function(){
  currentYOffset -= initYOffset*0.05; 
  document.body.scrollTop = currentYOffset ;
  document.documentElement.scrollTop = currentYOffset;

    if(self.pageYOffset == 0){
      clearInterval(intervalId);
    }
  }, 20);

}

</script>

</body>
<!-- Mirrored from www.themelexus.com/demo/opencart/shopping/demo1/ by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 02 Jun 2018 11:42:22 GMT -->
</html>
