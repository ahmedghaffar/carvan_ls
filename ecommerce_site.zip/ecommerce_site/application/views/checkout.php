



  
<div class="container">
  <div class="pav-inner" >
    <div class="row row-level-1 ">
      <div class="row-inner  clearfix" >
        <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12 " style="margin-top: 20px !important">
          <div class="col-inner">
            <div class="prefix box box-highlighted nopadding productcarousel" id="module31" style=" border-top: 1px solid #dbdbdb;border-right: 1px solid #dbdbdb !important; box-shadow: 0 0 7px 0px #dbdbdb;">
              <div class="box-heading" style="margin-right: 0px !important;"><span class="icon-heading" style="background: none !important;">&nbsp;</span><span class="hs1">Your Order Details</span>
              </div>
              <div class="row" style="padding: 10px">
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 fs2 ">
                  <p>Delivery Address :<br>
                    Kamran Khan<br>
                    Askari II<br>
                    Lahore Cantt
                  </p><br>
                  <a href="#" style="float: right">Change Address</a><br><br>
                  <p>Billing Address<br>
                    Husnain Hamdani<br>
                    Askari II<br>
                    Lahore
                  </p>
                  <a href="#" style="float: right;">Change</a>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 fs2 ">
                  <p>Payment Details</p>
                  <button type="button" id="button-cart" data-loading-text="Loading..." class="btn btn-default">
                    payment
                   </button>

                   <p>Ending in k123</p>
                   <a href="#" style="float: right">Change</a><br>
                   <hr style="width: 90%">
                  <p>
                    Discount Code <input type="text" name="code" placeholder="Enter Code"><button type="button" id="button-cart" data-loading-text="Loading..." class="btn btn-default" style="margin-left: 5px; margin-top: -2px">
                    Apply</button>
                  </p>
                </div>
              </div>
              </div>
            </div>

            <div class="prefix box box-highlighted nopadding productcarousel fs2" id="module31" style=" border-top: 1px solid #dbdbdb;border-right: 1px solid #dbdbdb !important; box-shadow: 0 0 7px 0px #dbdbdb;">
              <div class="box-heading" style="margin-right: 0px !important;"><span class="icon-heading" style="background: none !important;">&nbsp;</span><span class="hs1">Delivery Details</span>
              </div>
              <div class="row" style="padding: 10px">
                <p class="hs2">Estimated Delivery  : 6 Sept - 7th Sept 2018</p>
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 ">
                  <table style="border: none;">
                  <tbody>
                  <tr>
                    <td data-th="Product" style="width: 50%;padding: 5px">
                      <div class="row">
                        <div class="col-sm-2 hidden-xs"><img src="<?= base_url(); ?>image/catalog/demo/product_10.jpg" alt="..." class="img-responsive"/></div>
                        <div class="col-sm-10">
                          <h4 class="nomargin" class="hs2">HP LP3065</h4>
                          <ul><li class="fs2">Black</li>
                            <li class="fs2">Price:10.99</li>
                            <li class="fs2">Quantity
                            <select class="drop">
                              <option>1</option>
                              <option>2</option>
                              <option>3</option>
                              <option>4</option>
                              <option>5</option>
                            </select>
                          </li></ul>
                        </div>
                      </div>
                    </td>
                    <td data-th="Product" style="width: 50%;padding: 5px" class="fs2">
                      <h4 class="nomargin hs2">Delivery option:</h4>
                      <input type="radio" name="delivery" value="Standard Delivery"><span style="margin-left: 5px">Standard Delivery</span>
                      <br>
                      <input type="radio" name="delivery" value="Standard Delivery"><span style="margin-left: 5px">Priority Delivery</span>
                      <p>(Get it by 31st Aug 2018)</p>
                    </td>
                  </tr>
                  <tr>
                    <td data-th="Product" style="width: 50%;padding: 5px">
                      <div class="row">
                        <div class="col-sm-2 hidden-xs"><img src="<?= base_url(); ?>image/catalog/demo/product_04.jpg" alt="..." class="img-responsive"/></div>
                        <div class="col-sm-10 fs2">
                          <h4 class="nomargin" >T-Shirt</h4>
                          <ul><li class="fs2">Blue</li>
                            <li class="fs2">Price:5.29</li>
                            <li class="fs2">Quantity
                            <select class="drop">
                              <option>1</option>
                              <option>2</option>
                              <option>3</option>
                              <option>4</option>
                              <option>5</option>
                            </select>
                          </li></ul>
                        </div>
                      </div>
                    </td>
                    <td data-th="Product" style="width: 50%;padding: 5px">
                      <button type="button" id="button-cart" data-loading-text="Loading..." class="  btn btn-default">
                        Buy Now
                      </button>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
                
              </div>
              </div>

          </div>
          <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 "  style="margin-top: 20px !important;">
            <div class="col-inner  ">
              <div class="prefix box box-highlighted nopadding productcarousel fs2" id="module31" style=" border-top: 1px solid #dbdbdb;border-right: 1px solid #dbdbdb !important; box-shadow: 0 0 7px 0px #dbdbdb; padding-bottom: 10px">
                <div class="text-center"><button type="button" id="button-cart" data-loading-text="Loading..." class="  btn btn-default" style="margin-top: 10px; letter-spacing: 3px; font-weight: bold;">
                        Buy Now
                      </button></div>
                <p class="text-center" style="margin-top: 5px"><b>Order Summary</b></p>
                  <table style="border: none; margin-left: 30%" class="fs2">
                  <tbody>
                  <tr >
                    <td data-th="Product" style="width: 50%;padding: 5px;">
                      Items:
                    </td>
                    <td data-th="Product" style="width: 50%;padding: 5px; float: right;">
                      50.89
                    </td>
                  </tr>
                  <tr>
                    <td data-th="Product" style="width: 50%;padding: 5px;">
                      Postage:
                    </td>
                    <td data-th="Product" style="width: 50%;padding: 5px; float: right;">
                      10.89
                    </td>
                  </tr>
                  
                  <tr style="border-top: 1px solid black">
                    <td data-th="Product" style="width: 50%;padding: 5px;">
                      Total with Tax:
                    </td>
                    <td data-th="Product" style="width: 50%;padding: 5px; float: right;">
                      80.89
                    </td>
                  </tr>
                </tbody>
              </table>
              </div>
            </div>
          </div>

          <!-- <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12 " style="margin-top: 15px">
            <div class="col-inner  sidebar-right">
              <div class="pts-bannerbuilder clearfix hidden-sm hidden-xs">
                <div class="pts-container ">        
                 <div class="pts-inner">
                  <div class="row row-level-1">
                    <div class="col-lg-12 col-md-12 col-sm-6 col-xs-12"><div class="col-inner">
                      <div class="banner-wrapper">
                        <a href="desktop"><img alt="img" src="http://carrovan.ilegendtech.com/carrovan/image/catalog/demo/banners/banner4.jpg "  class="img-responsive">
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="pts-bannerbuilder clearfix hidden-sm hidden-xs">
            <div class="pts-container ">        
              <div class="pts-inner">
                <div class="row row-level-1">
                  <div class="col-lg-12 col-md-12 col-sm-6 col-xs-12"><div class="col-inner">
                    <div class="banner-wrapper">
                      <a href="desktop"><img alt="img" src="http://carrovan.ilegendtech.com/carrovan/image/catalog/demo/banners/banner4.jpg"    class="img-responsive">
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>-->
        </div> 
      </div>
    </div>
  </div>
</div></div></div>                           
                                                              




                               