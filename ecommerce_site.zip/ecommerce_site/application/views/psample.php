


<!-- sys-notification -->
<div id="sys-notification">
  <div class="container">
    <div id="notification"></div>
  </div>
</div>
<!-- /sys-notification -->






   
<div class="container-fluid">
    
  
<ul class="breadcrumb">
<!-- <li><a href="<?= base_url(); ?>/index9328.html?route=common/home"><i class="fa fa-home"></i></a></li>
<li><a href="<?= base_url(); ?>/index9a01.html?route=product/category&amp;path=20&amp;sort=pd.name&amp;order=ASC">Desktops</a></li> -->
<li><a href="<?= base_url(); ?>/index1db8.html?route=product/product&amp;path=20&amp;sort=pd.name&amp;order=ASC&amp;product_id=47"><!-- HP LP3065 --></a></li>
</ul>
  <div class="row"> 
  
   <section id="sidebar-main" class="col-md-10">        
        

<div class="product-info"> 
<div><!--mydiv-->   
    <?php foreach ($results as $key => $result) {
        # code...
    } 
    ?>
    <div class="row">
        <div class="col-md-6 col-sm-6 col-xs-12 image-container">
        <div id="img-detail" class="image">

          
        
        <a href="<?= base_url(); ?>/uploads/<?= $result->image; ?>" title="HP LP3065" class="imagezoom" itemscope>
            <img itemprop="image" src="<?= base_url(); ?>/uploads/<?= $result->image; ?>" title="HP LP3065" alt="HP LP3065" id="image"  style="
    height: 427px;" data-zoom-image="<?= base_url(); ?>/uploads/<?= $result->image; ?>" class="product-image-zoom img-responsive"/>
        </a>

    </div>
      
     <div class="thumbs-preview">
                 <div class="image-additional slide carousel horical" id="image-additional">
            <div id="image-additional-carousel" class="carousel-inner">
                                                        <div class="item clearfix">
                                            <a href="<?= base_url(); ?>/image/cache/catalog/demo/download.jpg" title="HP LP3065" class="imagezoom" data-zoom-image="<?= base_url(); ?>/image/cache/catalog/demo/download.jpg" data-image="<?= base_url(); ?>/image/cache/catalog/demo/download.jpg">
                            <img src="<?= base_url(); ?>/image/cache/catalog/demo/download.jpg" style="max-width:80px"  title="HP LP3065" alt="HP LP3065" data-zoom-image="<?= base_url(); ?>/image/cache/catalog/demo/download.jpg" class="product-image-zoom img-responsive" />
                        </a>

                             <a href="<?= base_url(); ?>/image/cache/catalog/demo/product_04-500x500.jpg" title="HP LP3065" class="imagezoom" data-zoom-image="<?= base_url(); ?>/image/cache/catalog/demo/product_04-500x500.jpg" data-image="<?= base_url(); ?>/image/cache/catalog/demo/product_04-500x500.jpg">
                           
                            <img src="<?= base_url(); ?>/image/cache/catalog/demo/product_04-80x82.jpg" style="max-width:80px"  title="HP LP3065" alt="HP LP3065" data-zoom-image="<?= base_url(); ?>/image/cache/catalog/demo/product_04-500x500.jpg" class="product-image-zoom img-responsive" />
                        </a>

                        <a href="<?= base_url(); ?>/image/cache/catalog/demo/product_07-500x500.jpg" title="HP LP3065" class="imagezoom" data-zoom-image="<?= base_url(); ?>/image/cache/catalog/demo/product_07-500x500.jpg" data-image="<?= base_url(); ?>/image/cache/catalog/demo/product_07-500x500.jpg">
                           
                            <img src="<?= base_url(); ?>/image/cache/catalog/demo/product_07-80x82.jpg" style="max-width:80px"  title="HP LP3065" alt="HP LP3065" data-zoom-image="<?= base_url(); ?>/image/cache/catalog/demo/product_07-500x500.jpg" class="product-image-zoom img-responsive" />
                        </a>

                        <a href="<?= base_url(); ?>/image/cache/catalog/demo/product_08-500x500.jpg" title="HP LP3065" class="imagezoom" data-zoom-image="<?= base_url(); ?>/image/cache/catalog/demo/product_08-500x500.jpg" data-image="<?= base_url(); ?>/image/cache/catalog/demo/product_08-500x500.jpg">
                           
                            <img src="<?= base_url(); ?>/image/cache/catalog/demo/product_08-80x82.jpg" style="max-width:80px"  title="HP LP3065" alt="HP LP3065" data-zoom-image="<?= base_url(); ?>/image/cache/catalog/demo/product_08-500x500.jpg" class="product-image-zoom img-responsive" />
                        </a>

                        <a href="<?= base_url(); ?>/image/cache/catalog/demo/product_09-500x500.jpg" title="HP LP3065" class="imagezoom" data-zoom-image="<?= base_url(); ?>/image/cache/catalog/demo/product_09-500x500.jpg" data-image="<?= base_url(); ?>/image/cache/catalog/demo/product_09-500x500.jpg">
                           
                            <img src="<?= base_url(); ?>/image/cache/catalog/demo/product_09-80x82.jpg" style="max-width:80px"  title="HP LP3065" alt="HP LP3065" data-zoom-image="<?= base_url(); ?>/image/cache/catalog/demo/product_09-500x500.jpg" class="product-image-zoom img-responsive" />
                        </a>

                        <a href="<?= base_url(); ?>/image/cache/catalog/demo/product_10-500x500.jpg" title="HP LP3065" class="imagezoom" data-zoom-image="<?= base_url(); ?>/image/cache/catalog/demo/product_10-500x500.jpg" data-image="<?= base_url(); ?>/image/cache/catalog/demo/product_10-500x500.jpg">
                           
                            <img src="<?= base_url(); ?>/image/cache/catalog/demo/product_10-80x82.jpg" style="max-width:80px"  title="HP LP3065" alt="HP LP3065" data-zoom-image="<?= base_url(); ?>/image/cache/catalog/demo/product_10-500x500.jpg" class="product-image-zoom img-responsive" />
                        </a>

                        <a href="<?= base_url(); ?>/image/cache/catalog/demo/product_11-500x500.jpg" title="HP LP3065" class="imagezoom" data-zoom-image="<?= base_url(); ?>/image/cache/catalog/demo/product_11-500x500.jpg" data-image="<?= base_url(); ?>/image/cache/catalog/demo/product_11-500x500.jpg">
                           
                            <img src="<?= base_url(); ?>/image/cache/catalog/demo/product_11-80x82.jpg" style="max-width:80px"  title="HP LP3065" alt="HP LP3065" data-zoom-image="<?= base_url(); ?>/image/cache/catalog/demo/product_11-500x500.jpg" class="product-image-zoom img-responsive" />
                        </a>

                        <a href="<?= base_url(); ?>/image/cache/catalog/demo/product_12-500x500.jpg" title="HP LP3065" class="imagezoom" data-zoom-image="<?= base_url(); ?>/image/cache/catalog/demo/product_12-500x500.jpg" data-image="<?= base_url(); ?>/image/cache/catalog/demo/product_12-500x500.jpg">
                           
                            <img src="<?= base_url(); ?>/image/cache/catalog/demo/product_12-80x82.jpg" style="max-width:80px"  title="HP LP3065" alt="HP LP3065" data-zoom-image="<?= base_url(); ?>/image/cache/catalog/demo/product_12-500x500.jpg" class="product-image-zoom img-responsive" />
                        </a>

                        <a href="<?= base_url(); ?>/image/cache/catalog/demo/product_13-500x500.jpg" title="HP LP3065" class="imagezoom" data-zoom-image="<?= base_url(); ?>/image/cache/catalog/demo/product_13-500x500.jpg" data-image="<?= base_url(); ?>/image/cache/catalog/demo/product_13-500x500.jpg">
                           
                            <img src="<?= base_url(); ?>/image/cache/catalog/demo/product_13-80x82.jpg" style="max-width:80px"  title="HP LP3065" alt="HP LP3065" data-zoom-image="<?= base_url(); ?>/image/cache/catalog/demo/product_13-500x500.jpg" class="product-image-zoom img-responsive" />
                        </a>

                        <a href="<?= base_url(); ?>/image/cache/catalog/demo/product_14-500x500.jpg" title="HP LP3065" class="imagezoom" data-zoom-image="<?= base_url(); ?>/image/cache/catalog/demo/product_14-500x500.jpg" data-image="<?= base_url(); ?>/image/cache/catalog/demo/product_14-500x500.jpg">
                           
                            <img src="<?= base_url(); ?>/image/cache/catalog/demo/product_14-80x82.jpg" style="max-width:80px"  title="HP LP3065" alt="HP LP3065" data-zoom-image="<?= base_url(); ?>/image/cache/catalog/demo/product_14-500x500.jpg" class="product-image-zoom img-responsive" />
                        </a>

                        <a href="<?= base_url(); ?>/image/cache/catalog/demo/product_15-500x500.jpg" title="HP LP3065" class="imagezoom" data-zoom-image="<?= base_url(); ?>/image/cache/catalog/demo/product_15-500x500.jpg" data-image="<?= base_url(); ?>/image/cache/catalog/demo/product_15-500x500.jpg">
                           
                            <img src="<?= base_url(); ?>/image/cache/catalog/demo/product_15-80x82.jpg" style="max-width:80px"  title="HP LP3065" alt="HP LP3065" data-zoom-image="<?= base_url(); ?>/image/cache/catalog/demo/product_15-500x500.jpg" class="product-image-zoom img-responsive" />
                        </a>

                                     <a href="<?= base_url(); ?>/image/cache/catalog/demo/product_01-500x500.jpg" title="HP LP3065" class="imagezoom" data-zoom-image="<?= base_url(); ?>/image/cache/catalog/demo/product_01-500x500.jpg" data-image="<?= base_url(); ?>/image/cache/catalog/demo/product_01-500x500.jpg">
                            <img src="<?= base_url(); ?>/image/cache/catalog/demo/product_01-80x82.jpg" style="max-width:80px"  title="HP LP3065" alt="HP LP3065" data-zoom-image="<?= base_url(); ?>/image/cache/catalog/demo/product_01-500x500.jpg" class="product-image-zoom img-responsive" />
                        </a>
                                        </div>
                                        
            </div>

            <!-- Controls -->
                    </div>          
        <script type="text/javascript">
            $('#image-additional .item:first').addClass('active');
            $('#image-additional').carousel({interval:false})
        </script>
         
    </div>  
</div>          

 
   
    <div class="product-view col-xs-12 col-sm-5 col-md-5">
        <h1 class="title-product hs1"><?= $result->title ;?></h1>
<!--                 <h2 class="title-product">Seller Name</h2>
 --> <p class="fs1">by HP</p>
                    <div class="rating">
                <p>
                <span class="fs1">Reviews</span>
                    <span class="fa fa-stack"><i class="fa fa-star fa-stack-1x"></i><i class="fa fa-star-o fa-stack-1x"></i></span>
                    <span class="fa fa-stack"><i class="fa fa-star fa-stack-1x"></i><i class="fa fa-star-o fa-stack-1x"></i></span>
                    <span class="fa fa-stack"><i class="fa fa-star fa-stack-1x"></i><i class="fa fa-star-o fa-stack-1x"></i></span>
                    <span class="fa fa-stack"><i class="fa fa-star fa-stack-1x"></i><i class="fa fa-star-o fa-stack-1x"></i></span>
                    <span class="fa fa-stack"><i class="fa fa-star fa-stack-1x"></i><i class="fa fa-star-o fa-stack-1x"></i></span>
                    <a href="#review-form" class="popup-with-form fs1" onclick="$('a[hrrf='#tab-review\']').trigger('click'); return false;" >2 verified reviews</a> <br>
                    <a href="#review-form"  class="popup-with-form fs1" onclick="$('a[href=\'#tab-review\']').trigger('click'); return false;" >Write a review</a>
                    </p>
             </div>

            <br>
            <br>
            <hr>
                <ul class="list-unstyled description">

                        <li class="text-price fs3">Uni Price : <?= $result->uprice ;?></li>
                        <li class="other-price fs2">Sale Price : <?= $result->uprice ;?></li>
                        <li class="other-price fs2">Savings : 02</li>
                        <li  class="fs3">In Stock</li>
                        <li>
                            <div class="form-group required" style="display:flex; flex-direction: row; justify-content: flex-start; align-items: baseline;">
                            <label class="control-label fs2" for="input-option225">Expected Delivery Date</label>
                            <input type="text" style="width: 150px; background-color: white; border: none" name="option[225]" value="<?php echo date('Y-m-d',strtotime("+7 days")); ?>" readonly id="input-option225" class="form-control" style="z-index: 0"  />
                        </li>
                        <li  class="fs1">Dispatched and Sold by Seller Name</li>
        </ul>
<div>
    <select class="drop">
  <option value="">Chose a Color</option>
  <option value="Green">Green</option>
  <option value="Red">Red</option>
  <option value="Yellow">Yellow</option>
</select>
   <select class="drop">
  <option value="">Chose a Size</option>
  <option value="Small">Small</option>
  <option value="Medium">Medium</option>
  <option value="Large">Large</option>
</select>
</div>
             
                
        <div id="product" class="product-extra ">
<!--                             <h3>Available Options</h3>
 -->                                                                                                                                                                                                            

            <div class="quantity-adder">
                                                   
            </div>
             <input type="hidden" name="product_id" value="47" /> 


<ul class="points fs3">
                    
                    
                        <li><span class="a-list-item"> 
                            Includes the latest Kindle Paperwhite 6" E-Reader with Special offers, Amazon Leather Cover, and Amazon Powerfast 9W Power Adapter
                            
                        </span></li>
                    
                        <li><span class="a-list-item"> 
                            Unsurpassed high-resolution 300 ppi display - reads like real paper
                            
                        </span></li>
                    
                        <li><span class="a-list-item"> 
                            Built-in adjustable light - read day and night
                            
                        </span></li>
                    
                        <li><span class="a-list-item"> 
                            Unlike tablets, no screen glare, even in bright sunlight
                            
                        </span></li>
                    
                        <li><span class="a-list-item"> 
                            A single battery charge lasts weeks, not hours
                            
                        </span></li>
                    
                        <li><span class="a-list-item"> 
                            Lighter than a paperback, holds thousands of books
                            
                        </span></li>
                    
                </ul>

            <div class="btn-group-justified">
                  </div>


        </div>
        
        <!-- AddThis Button BEGIN -->
        <div class="addthis_toolbox addthis_default_style"><a class="addthis_button_facebook_like"></a> <a class="addthis_button_tweet"></a> <a class="addthis_button_pinterest_pinit"></a> <a class="addthis_counter addthis_pill_style"></a></div>
        <script type="text/javascript" src="<?= base_url(); ?>/../../../../../s7.addthis.com/js/300/addthis_widget.js#pubid=ra-515eeaf54693130e"></script>
        <!-- AddThis Button END -->
    </div>
<!-- <div class="col-md-2 col-sm-2 col-xs-4" style="border: 1px solid #dbdbdb; text-align: center; padding: 10px">
    
</div>
 --></div><hr>
<div class="clearfix">
    <h1  class="hs1">DESCRIPTION</h1>
    
    <p  class="fs3">
	<?= $result->pd ;?>
    </p>
    </div>
</div> <!--mydiv-->
                    <!-- <div class="tab-pane table-responsive" id="tab-specification">
                <table class="table table-bordered">
                                            <thead>
                            <tr>
                                <td colspan="2"><strong>Memory</strong></td>
                            </tr>
                        </thead>
                        <tbody>
                                                            <tr>
                                    <td>test 1</td>
                                    <td>16GB</td>
                                </tr>
                                                    </tbody>
                                            <thead>
                            <tr>
                                <td colspan="2"><strong>Processor</strong></td>
                            </tr>
                        </thead>
                        <tbody>
                                                            <tr>
                                    <td>No. of Cores</td>
                                    <td>4</td>
                                </tr>
                                                    </tbody>
                                    </table>
            </div> -->

<hr>

                            <div class="clearfix">
                            <p class="hs1">CUSTOMER REVIEWS</p>
                            <div class="row">
                            <!-- <div class="review_customer">
                                <div class="r_profile">
                                    <img src="">
                                </div>
                            </div>-->
                            </div>
                            <fieldset>
                                    <div class="rating fs3" style="display: inline;">
      <input type="radio" id="star10" name="rating" value="10" /><label for="star10" title="Rocks!">5 stars</label>
      <input type="radio" id="star9" name="rating" value="9" checked/><label for="star9" title="Rocks!">4 stars</label>
      <input type="radio" id="star8" name="rating" value="8" /><label for="star8" title="Pretty good">3 stars</label>
      <input type="radio" id="star7" name="rating" value="7" /><label for="star7" title="Pretty good">2 stars</label>
      <input type="radio" id="star6" name="rating" value="6" /><label for="star6" title="Meh">1 star</label>
                            </div>
                            <span class="fs3">This is a nice and smartly designed Kindle E-Reader which works and performs wells.
                            </span>
                            </fieldset>
                            <div>
                                <p  class="fs2">21 Nov 2017</p>
                            </div>
                            <div>
                                <p  class="fs3">This is a nice and smartly designed Kindle E-Reader which works and performs wells.

The design and construction is compact, slim and durable. This item will not break or fall apart easy.

This item works and performs well. The touchscreen is responsive and the digital E-Reader is simple to operate.</p>
                            </div>
                            <div class="row">
                            <!-- <div class="review_customer">
                                <div class="r_profile">
                                    <img src="">
                                </div>
                            </div>-->
                            </div>
                            <fieldset>

                                    <div class="rating fs3" style="display: inline;">
      <input type="radio" id="star10" name="rating" value="10"/><label for="star10" title="Rocks!">5 stars</label>
      <input type="radio" id="star9" name="rating" value="9" /><label for="star9" title="Rocks!">4 stars</label>
      <input type="radio" id="star8" name="rating" value="8" /><label for="star8" title="Pretty good">3 stars</label>
      <input type="radio" id="star7" name="rating" value="7" /><label for="star7" title="Pretty good">2 stars</label>
      <input type="radio" id="star6" name="rating" value="6" /><label for="star6" title="Meh">1 star</label>
                            </div><span class="fs3">
                            This is a nice and smartly designed Kindle E-Reader which works and performs wells.
                            </span>
                            </fieldset>
                            <div>
                                <p class="fs2">21 Nov 2017</p>
                            </div>
                            <div>
                                <p class="fs3">This is a nice and smartly designed Kindle E-Reader which works and performs wells.

The design and construction is compact, slim and durable. This item will not break or fall apart easy.

This item works and performs well. The touchscreen is responsive and the digital E-Reader is simple to operate.</p>
                            </div>
            <p> <a href="#review-form"  class="popup-with-form btn btn-sm btn-danger" onclick="$('a[href=\'#tab-review\']').trigger('click'); return false;" >Write a review</a></p>

           <div class="hide"> <div id="review-form" class="panel review-form-width"><div class="review-form panel-body">
            <form class="form-horizontal" id="form-review">
                    <h2>Write a review</h2>
                    <div class="form-group required">
                        <div class="col-sm-12">
                            <label class="control-label" for="input-name">Your Name</label>
                            <input type="text" name="name" value="" id="input-name" class="form-control" />
                        </div>
                    </div>
                    <div class="form-group required">
                        <div class="col-sm-12">
                            <label class="control-label" for="input-review">Your Review</label>
                            <textarea name="text" rows="5" id="input-review" class="form-control"></textarea>
                            <div class="help-block"><span class="text-danger">Note:</span> HTML is not translated!</div>
                        </div>
                    </div>
                    <div class="form-group required">
                        <div class="col-sm-12">
                            <label class="control-label">Rating</label>
                            &nbsp;&nbsp;&nbsp; Bad&nbsp;
                            <input type="radio" name="rating" value="1" />
                            &nbsp;
                            <input type="radio" name="rating" value="2" />
                            &nbsp;
                            <input type="radio" name="rating" value="3" />
                            &nbsp;
                            <input type="radio" name="rating" value="4" />
                            &nbsp;
                            <input type="radio" name="rating" value="5" />
                            &nbsp;Good</div>
                    </div>

 <!--                    <fieldset>
  <legend>Captcha</legend>
  <div class="form-group required">
        <label class="col-sm-2 control-label" for="input-captcha">Enter the code in the box below</label>
    <div class="col-sm-10">
      <input type="text" name="captcha" id="input-captcha" class="form-control" />
      <img src="<?= base_url(); ?>/index24c7.jpg?route=extension/captcha/basic_captcha/captcha" alt="" />
          </div>
      </div>
</fieldset> -->
                    <div class="buttons">
                        <div class="pull-right">
                            <button type="button" id="button-review" data-loading-text="Loading..." class="btn btn-default">Continue</button>
                        </div>
                    </div>
                 </form></div></div></div>
            </div>
                <!-- customtab -->


                 <div class="product-related box box-default clearfix" style="border: none;"> <div class="box-heading">
	<span class="icon-heading"><i class="fa fa-cogs"></i></span>
	<span class="hs1">Related Products(2)</span>
</div>
<div id="product-related" class="slide carousel" data-interval="0">
		<div class="carousel-inner">
						<div class= "item active">
			<div class="row products-row">
					<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
				
<div class="product-block item-default" itemtype="http://schema.org/Product" itemscope>

	<div class="image">
			      					<a class="img" href="<?= base_url(); ?>/indexbb02.html?route=product/product&amp;product_id=42"><img src="<?= base_url(); ?>/image/cache/catalog/demo/product_01-199x201.jpg" alt="Apple Cinema 30&quot;" class="img-responsive" /></a>
				<!-- zoom image-->
	    	   <!--  <a href="<?= base_url(); ?>/image/catalog/demo/product_01.jpg" class="btn btn-danger product-zoom" title="Apple Cinema 30&quot;">
	    	<i class="fa fa-search-plus"></i>
	    </a>
	    				<a class="quickview btn btn-danger iframe-link" href="<?= base_url(); ?>/index793f.html?route=themecontrol/product&amp;product_id=42" title="Quick View">
			<i class='fa fa-eye'></i>
		</a> -->
			</div>
	
	<div class="product-meta fs2">
		<div class="warp-info fs2">
			<h3 class="name fs2"><a href="<?= base_url(); ?>/indexbb02.html?route=product/product&amp;product_id=42">Apple Cinema 30&quot;</a></h3>			
				          <div class="rating">
	            	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            	          </div>
	         						<div class="price" itemtype="http://schema.org/Offer" itemscope itemprop="offers">
									<span class="special-price">$122.00</span>
					 
					<meta content="122.00" itemprop="price">
													<meta content="" itemprop="priceCurrency">
			</div>
				
			 
				<div class="description" itemprop="description">
	The 30-inch Apple Cinema HD Display delivers an amazing 2560 x 1600 pixel resolution. Designed sp.....</div>
					
		</div>

		<!-- <div class="action"> 				     

		    				<div class="cart">
					<button data-loading-text="Loading..." type="button" value="Add to Cart" onclick="cart.add('42');" class="btn btn-outline-inverse"><i class="fa-fw fa fa-shopping-cart"></i><span>Add to Cart</span></button>		
				</div>
			
	    	<div class="wishlist">					
				<a class="btn btn-outline-inverse" title="Add to Wish List" onclick="wishlist.add('42');"><i class="fa-fw fa fa-heart"></i><span>Add to Wish List</span></a>	
			</div>
			<div class="compare">										
				<a class="btn btn-outline-inverse" title="Compare this Product" onclick="compare.add('42');"><i class="fa-fw fa fa-files-o"></i><span>Compare this Product</span></a>	
			</div>	
		</div> -->
		

	</div>

</div>





			</div>
									<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 product-col">
				
<div class="product-block item-default" itemtype="http://schema.org/Product" itemscope>

	<div class="image">
			      					<a class="img" href="<?= base_url(); ?>/indexb8ca.html?route=product/product&amp;product_id=43"><img src="<?= base_url(); ?>/image/cache/catalog/demo/product_12-199x201.jpg" alt="MacBook" class="img-responsive" /></a>
				<!-- zoom image-->
	    	   <!--  <a href="<?= base_url(); ?>/image/catalog/demo/product_12.jpg" class="btn btn-danger product-zoom" title="MacBook">
	    	<i class="fa fa-search-plus"></i>
	    </a>
	    				<a class="quickview btn btn-danger iframe-link" href="<?= base_url(); ?>/indexd8ee.html?route=themecontrol/product&amp;product_id=43" title="Quick View">
			<i class='fa fa-eye'></i>
		</a> -->
			</div>
	
	<div class="product-meta">
		<div class="warp-info">
			<h3 class="name"><a href="<?= base_url(); ?>/indexb8ca.html?route=product/product&amp;product_id=43">MacBook</a></h3>			
				          <div class="rating">
	            	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            	            	            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
	            	            	          </div>
	         						<div class="price" itemtype="http://schema.org/Offer" itemscope itemprop="offers">
									<span class="special-price">$602.00</span>
					 
					<meta content="602.00" itemprop="price">
													<meta content="" itemprop="priceCurrency">
			</div>
				
			 
				<div class="description" itemprop="description">
	
		Intel Core 2 Duo processor
	
		Powered by an Intel Core 2 Duo processor at speeds up to 2.1.....</div>
					
		</div>
<!-- 
		<div class="action"> 				     

		    				<div class="cart">
					<button data-loading-text="Loading..." type="button" value="Add to Cart" onclick="cart.add('43');" class="btn btn-outline-inverse"><i class="fa-fw fa fa-shopping-cart"></i><span>Add to Cart</span></button>		
				</div>
			
	    	<div class="wishlist">					
				<a class="btn btn-outline-inverse" title="Add to Wish List" onclick="wishlist.add('43');"><i class="fa-fw fa fa-heart"></i><span>Add to Wish List</span></a>	
			</div>
			<div class="compare">										
				<a class="btn btn-outline-inverse" title="Compare this Product" onclick="compare.add('43');"><i class="fa-fw fa fa-files-o"></i><span>Compare this Product</span></a>	
			</div>	
		</div> -->
		

	</div>

</div>





			</div>
					</div>
		</div>
					</div>
</div>
 </div>
        
          

          
         </section> 
	<aside id="sidebar-right" class="col-md-2">	
		<div id="column-right" class="hidden-xs">

<div class="pts-bannerbuilder clearfix hidden-sm hidden-xs">
    
                        <div class="pts-container " >        
                <div class="pts-inner">
          <div class="row row-level-1">
                            <div class="col-lg-12 col-md-12 col-sm-6 col-xs-12"><div class="col-inner">
                                                                    <div class="banner-wrapper text-center" style="border: 1px solid #dbdbdb; padding: 6px">
                                                       <h3 class="fs3">8+ Delivery</h3>
                                                       <span class="fs2">Quantity</span><select class="drop">
                                                           <option>1</option>
                                                           <option>2</option>
                                                           <option>3</option>
                                                           <option>4</option>
                                                           <option>5</option>
                                                           <option>6</option>
                                                       </select>
                                                       <div style="margin-top: 10px">
                                                       <div class="btn btn-primary" style="width: 80%;">Add to Basket</div></div>
                                                       <div style="margin-top: 10px">
                                                       <div class="btn btn-primary" style="width: 80%">Buy Now</div>
                                                       </div>
                                                       <p class="fs2">Delivery address<br>
                                                        Askari II,<br>
                                                        Lahore Cantt
                                                       </p>
                                                    </div>
                                                                                </div></div>
                    </div>
                        </div>  </div>
            </div>
        
   <!--  <div class="category box box-info nopadding">
  <div class="box-heading"><span>Categories</span></div>
  <div class="box-content tree-menu">
    <ul id="1093763689accordion" class="box-category box-panel accordion">
            <li class="haschild accordion-group">
                <a href="<?= base_url(); ?>/index98dc.html?route=product/category&amp;path=20" class="active">Desktops (11)</a>
                        <span class="head"><a data-toggle="collapse" data-parent="#1093763689accordion" data-target="#588510858target0">+</a></span>
        
        <ul id="588510858target0" class="panel-collapse collapse accordion-body in">
                    <li>
                        <a href="<?= base_url(); ?>/indexd9fe.html?route=product/category&amp;path=20_26">PC (8)</a>
                      </li>
                    <li>
                        <a href="<?= base_url(); ?>/indexf345.html?route=product/category&amp;path=20_27">Mac (6)</a>
                      </li>
                  </ul>
              </li>
            <li class="haschild accordion-group">
                <a href="<?= base_url(); ?>/index7fa3.html?route=product/category&amp;path=18">Laptops &amp; Notebooks (8)</a>
                      </li>
            <li class="haschild accordion-group">
                <a href="<?= base_url(); ?>/index1647.html?route=product/category&amp;path=25">Components (11)</a>
                      </li>
            <li class="haschild accordion-group">
                <a href="<?= base_url(); ?>/index70a9.html?route=product/category&amp;path=57">Tablets (4)</a>
                      </li>
            <li class="haschild accordion-group">
                <a href="<?= base_url(); ?>/indexb152.html?route=product/category&amp;path=17">Software (7)</a>
                      </li>
            <li class="haschild accordion-group">
                <a href="<?= base_url(); ?>/indexc957.html?route=product/category&amp;path=24">Phones &amp; PDAs (3)</a>
                      </li>
            <li class="haschild accordion-group">
                <a href="<?= base_url(); ?>/index68ea.html?route=product/category&amp;path=33">Cameras (3)</a>
                      </li>
            <li class="haschild accordion-group">
                <a href="<?= base_url(); ?>/index8122.html?route=product/category&amp;path=34">MP3 Players (11)</a>
                      </li>
          </ul>
  </div>
</div>
<script type="text/javascript">
    $(document).ready(function(){
        var active = $('.collapse.in').attr('id');
        $('a[data-target=#'+active+']').html("-");

        $('.collapse').on('show.bs.collapse', function () {
            $('a[data-target=#'+$(this).attr('id')+']').html("-");
        });
        $('.collapse').on('hide.bs.collapse', function () {
            $('a[data-target=#'+$(this).attr('id')+']').html("+");
        });
    });
</script> -->

  </div>	</aside>
</div>
<script type="text/javascript"><!--
$('select[name=\'recurring_id\'], input[name="quantity"]').change(function(){
	$.ajax({
		url: 'index.php?route=product/product/getRecurringDescription',
		type: 'post',
		data: $('input[name=\'product_id\'], input[name=\'quantity\'], select[name=\'recurring_id\']'),
		dataType: 'json',
		beforeSend: function() {
			$('#recurring-description').html('');
		},
		success: function(json) {
			$('.alert, .text-danger').remove();
			
			if (json['success']) {
				$('#recurring-description').html(json['success']);
			}
		}
	});
});
//--></script> 
<script type="text/javascript"><!--
$('#button-cart').on('click', function() {
	$.ajax({
		url: 'index.php?route=checkout/cart/add',
		type: 'post',
		data: $('#product input[type=\'text\'], #product input[type=\'hidden\'], #product input[type=\'radio\']:checked, #product input[type=\'checkbox\']:checked, #product select, #product textarea'),
		dataType: 'json',
		beforeSend: function() {
			$('#button-cart').button('loading');
		},
		complete: function() {
			$('#button-cart').button('reset');
		},
		success: function(json) {
			$('.alert, .text-danger').remove();
			$('.form-group').removeClass('has-error');

			if (json['error']) {
				if (json['error']['option']) {
					for (i in json['error']['option']) {
						var element = $('#input-option' + i.replace('_', '-'));
						
						if (element.parent().hasClass('input-group')) {
							element.parent().after('<div class="text-danger">' + json['error']['option'][i] + '</div>');
						} else {
							element.after('<div class="text-danger">' + json['error']['option'][i] + '</div>');
						}
					}
				}
				
				if (json['error']['recurring']) {
					$('select[name=\'recurring_id\']').after('<div class="text-danger">' + json['error']['recurring'] + '</div>');
				}
				
				// Highlight any found errors
				$('.text-danger').parent().addClass('has-error');
			}
			
			if (json['success']) {
				$('#notification').html('<div class="alert alert-success">' + json['success'] + '<button type="button" class="close" data-dismiss="alert">&times;</button></div>');
				 if( $("#cart-total").hasClass("cart-mini-info") ){
		              json['total'] = json['total'].replace(/-(.*)+$/,"");
		          }
				$('#cart-total').html(json['total']);
				
				$('html, body').animate({ scrollTop: 0 }, 'slow');
				
				$('#cart > ul').load('index1e1c.html?route=common/cart/info%20ul%20li');
			}
		}
	});
});
//--></script> 
<script type="text/javascript">

$('.date').datetimepicker({
	pickTime: false
});

$('.datetime').datetimepicker({
	pickDate: true,
	pickTime: true
});

$('.time').datetimepicker({
	pickDate: false
});

$('button[id^=\'button-upload\']').on('click', function() {
	var node = this;
	
	$('#form-upload').remove();
	
	$('body').prepend('<form enctype="multipart/form-data" id="form-upload" style="display: none;"><input type="file" name="file" /></form>');
	
	$('#form-upload input[name=\'file\']').trigger('click');

	if (typeof timer != 'undefined') {
    	clearInterval(timer);
	}

	timer = setInterval(function() {
		if ($('#form-upload input[name=\'file\']').val() != '') {
			clearInterval(timer);

			$.ajax({
				url: 'index.php?route=tool/upload',
				type: 'post',
				dataType: 'json',
				data: new FormData($('#form-upload')[0]),
				cache: false,
				contentType: false,
				processData: false,
				beforeSend: function() {
					$(node).button('loading');
				},
				complete: function() {
					$(node).button('reset');
				},
				success: function(json) {
					$('.text-danger').remove();

					if (json['error']) {
						$(node).parent().find('input').after('<div class="text-danger">' + json['error'] + '</div>');
					}

					if (json['success']) {
						alert(json['success']);

						$(node).parent().find('input').attr('value', json['code']);
					}
				},
				error: function(xhr, ajaxOptions, thrownError) {
					alert(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);
				}
			});
		}
	}, 500);
});
//--></script> 
<script type="text/javascript"><!--
$('#review').delegate('.pagination a', 'click', function(e) {
  e.preventDefault();

    $('#review').fadeOut('slow');

    $('#review').load(this.href);

    $('#review').fadeIn('slow');
});

$('#review').load('index027f.html?route=product/product/review&amp;product_id=47');

$('#button-review').on('click', function() {
	$.ajax({
		url: 'index.php?route=product/product/write&product_id=47',
		type: 'post',
		dataType: 'json',
		data: $("#form-review").serialize(),
		beforeSend: function() {
			$('#button-review').button('loading');
		},
		complete: function() {
			$('#button-review').button('reset');
		},
		success: function(json) {
			$('.alert-success, .alert-danger').remove();

			if (json['error']) {
				$('#review-form').prepend('<div class="alert alert-danger"><i class="fa fa-exclamation-circle"></i> ' + json['error'] + '</div>');
			}

			if (json['success']) {
				$('#review-form').prepend('<div class="alert alert-success"><i class="fa fa-check-circle"></i> ' + json['success'] + '</div>');

				$('input[name=\'name\']').val('');
				$('textarea[name=\'text\']').val('');
				$('input[name=\'rating\']:checked').prop('checked', false);
			}
		}
	});
});

$(document).ready(function() { 
	$('#img-detail a').click(
		function(){  
			$.magnificPopup.open({
			  items: {
			    src:  $('img',this).attr('src')
			  },
			  type: 'image'
			});	
			return false;
		}
	);
});
//--></script> 
<script type="text/javascript" src="<?= base_url(); ?>/catalog/view/javascript/jquery/elevatezoom/elevatezoom-min.js"></script>
<script type="text/javascript">
if( $(window).width() >= 992 ) {
		var zoomCollection = '#image';
		$( zoomCollection ).elevateZoom({
				lensShape : "basic",
		lensSize    : 150,
		easing:true,
		gallery:'image-additional-carousel',
		cursor: 'pointer',
		galleryActiveClass: "active"
	});
 }
</script>

<script>
	
	var x, i, j, selElmnt, a, b, c;
/*look for any elements with the class "custom-select":*/
x = document.getElementsByClassName("custom-select");
for (i = 0; i < x.length; i++) {
  selElmnt = x[i].getElementsByTagName("select")[0];
  /*for each element, create a new DIV that will act as the selected item:*/
  a = document.createElement("DIV");
  a.setAttribute("class", "select-selected");
  a.innerHTML = selElmnt.options[selElmnt.selectedIndex].innerHTML;
  x[i].appendChild(a);
  /*for each element, create a new DIV that will contain the option list:*/
  b = document.createElement("DIV");
  b.setAttribute("class", "select-items select-hide");
  for (j = 1; j < selElmnt.length; j++) {
    /*for each option in the original select element,
    create a new DIV that will act as an option item:*/
    c = document.createElement("DIV");
    c.innerHTML = selElmnt.options[j].innerHTML;
    c.addEventListener("click", function(e) {
        /*when an item is clicked, update the original select box,
        and the selected item:*/
        var y, i, k, s, h;
        s = this.parentNode.parentNode.getElementsByTagName("select")[0];
        h = this.parentNode.previousSibling;
        for (i = 0; i < s.length; i++) {
          if (s.options[i].innerHTML == this.innerHTML) {
            s.selectedIndex = i;
            h.innerHTML = this.innerHTML;
            y = this.parentNode.getElementsByClassName("same-as-selected");
            for (k = 0; k < y.length; k++) {
              y[k].removeAttribute("class");
            }
            this.setAttribute("class", "same-as-selected");
            break;
          }
        }
        h.click();
    });
    b.appendChild(c);
  }
  x[i].appendChild(b);
  a.addEventListener("click", function(e) {
      /*when the select box is clicked, close any other select boxes,
      and open/close the current select box:*/
      e.stopPropagation();
      closeAllSelect(this);
      this.nextSibling.classList.toggle("select-hide");
      this.classList.toggle("select-arrow-active");
  });
}
function closeAllSelect(elmnt) {
  /*a function that will close all select boxes in the document,
  except the current select box:*/
  var x, y, i, arrNo = [];
  x = document.getElementsByClassName("select-items");
  y = document.getElementsByClassName("select-selected");
  for (i = 0; i < y.length; i++) {
    if (elmnt == y[i]) {
      arrNo.push(i)
    } else {
      y[i].classList.remove("select-arrow-active");
    }
  }
  for (i = 0; i < x.length; i++) {
    if (arrNo.indexOf(i)) {
      x[i].classList.add("select-hide");
    }
  }
}
/*if the user clicks anywhere outside the select box,
then close all select boxes:*/
document.addEventListener("click", closeAllSelect);
</script>

</div>
 
<!-- 
  $ospans: allow overrides width of columns base on thiers indexs. format array( column-index=>span number ), example array( 1=> 3 )[value from 1->12]
 -->
